<?php

use Phinx\Migration\AbstractMigration;

class AddImageUploadEndpoint extends AbstractMigration
{

    public function up()
    {
        $endpointData = [
                ["url" => "media-service/image-upload","allowed_methods" => json_encode(['POST'])]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE from `endpoints` where `url` = "media-service/image-upload"');
    }
}
