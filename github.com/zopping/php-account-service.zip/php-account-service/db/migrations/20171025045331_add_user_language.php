<?php

use Phinx\Migration\AbstractMigration;

class AddUserLanguage extends AbstractMigration
{

    public function change()
    {
        $table = $this->table('users');
        $table->addColumn('lang_iso_code', 'string', array('limit' => 2, 'null' => true, 'after' => 'is_owner'))
            ->addForeignKey('lang_iso_code', 'languages', 'iso_code')
            ->save();
    }

}
