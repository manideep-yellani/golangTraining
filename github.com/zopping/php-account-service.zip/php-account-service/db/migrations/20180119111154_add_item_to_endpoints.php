<?php

use Phinx\Migration\AbstractMigration;

class AddItemToEndpoints extends AbstractMigration
{
    /**
     * Adding item of catalogue service to endpoints table with only read access
     * Read access is required by the website
     */
    public function up()
    {
        $endpointData = [
            [
                "url" => "catalogue-service/item",
                "allowed_methods" => json_encode(['GET'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
        $endpointId = $this->fetchRow(
            "select id from endpoints where url='catalogue-service/item'"
        )['id'];
        $developerId = $this->fetchRow(
            "select id from developers where token='59042d47-4b2a-4f87-8d78-6f8cae4ce199'"
        )['id'];
        $this->insert("endpoint_developer_permissions", [[
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1,
            "is_customer_required" => 0
        ]]);
    }

    public function down()
    {
        $developerId = $this->fetchRow(
            "select id from developers where token='59042d47-4b2a-4f87-8d78-6f8cae4ce199'"
        )['id'];
        $endpointId = $this->fetchRow(
            "select id from endpoints where url='catalogue-service/item'"
        )['id'];
        $this->execute('DELETE from `endpoint_developer_permissions`
              where endpoint_id="'.$endpointId.'" and developer_id="'.$developerId.'"');
        $this->execute("DELETE from `endpoints` where `url` = 'catalogue-service/item'");
    }
}
