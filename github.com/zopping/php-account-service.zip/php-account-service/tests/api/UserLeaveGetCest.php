<?php

class UserLeaveGetCest
{

    protected static $endpoint = '/user-leave';
    protected static $table = 'user_leaves';

    public function listUserLeaves(ApiTester $I)
    {
        $I->wantTo('Get list of user leaves');
        $I->sendGET(static::$endpoint, ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "userleave" => "array"
            )
        ));
    }

    public function listUserLeavesInvalidPage(ApiTester $I)
    {
        //Sending a page number which does not have data
        $I->wantTo('Get list of users with invalid page number');
        $I->sendGET(self::$endpoint . "?organizationId=1&page=10000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['userleave' => []]));
    }

    public function listUserLeavesForUser(ApiTester $I)
    {
        $leaveData = [
            'user_id' => 1,
            'from_date' => date('Y-m-d', strtotime("+2 days")),
            'to_date' => date('Y-m-d', strtotime("+10 days")),
            'reason' => "Personal",
            'type' => 'EARNED',
        ];
        $id = $I->haveInDatabase(self::$table, $leaveData);
        $I->wantTo('Get list of users with user id filter');
        $I->sendGET(self::$endpoint, ["organizationId" => 1, "userId" => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "userleave" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $id]);
    }

    public function listPendingApprovalUserLeaves(ApiTester $I)
    {
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Junior', 'manager_id' => $managerDesigId];
        $juniorId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $juniorId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Personal",
                'type' => 'SICK']
        );
        $data = [
            "user"=> '{
                        "id": ' . $managerId . ',
                        "name": "Test"
                }',
            "organizationId" => 1,
            "leaveType" => 'PENDING'
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "userleave" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $leaveId]);
    }

    public function listApprovedCancellableUserLeaves(ApiTester $I)
    {
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Junior', 'manager_id' => $managerDesigId];
        $juniorId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $juniorId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Personal",
                'type' => 'SICK',
                'status' => 'APPROVED']
        );
        $data = [
            "user"=> '{
                        "id": ' . $managerId . ',
                        "name": "Test"
                }',
            "organizationId" => 1,
            "leaveType" => 'APPROVED_CANCELLABLE'
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "userleave" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $leaveId]);
    }

}
