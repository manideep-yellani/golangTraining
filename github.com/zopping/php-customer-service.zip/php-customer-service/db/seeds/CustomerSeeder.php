<?php

use Phinx\Seed\AbstractSeed;

class CustomerSeeder extends AbstractSeed
{
    /**
     * Seeding customers, phones, emails and addreses table
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        $config = include 'config/test.php';
        $encryptionConfig['key'] = $config['ZopNow\Arya\Utility\Encryption']['key'];
        \ZopNow\Arya\Utility\Encryption::configure($encryptionConfig);
        $password = \ZopNow\Arya\Utility\Encryption::encrypt('password', false);
        
        $customerData = array(
            array(
                "name" => "Vishal Kumar",
                "image" => $faker->imageUrl(50, 50),
                "organization_id"=> 1,
                "password"=> $password
            ),
            array(
                "name" => "Saket Banerjee",
                "image" => $faker->imageUrl(50, 50),
                "organization_id"=> 1,
                "password"=> $password
            ),
            array(
                "name" => "Alokit Khan",
                "image" => $faker->imageUrl(50, 60),
                "organization_id"=> 1,
                "password"=> $password
            ),
            array(
                "name" => "Abraham L.",
                "image" => $faker->imageUrl(50, 60),
                "organization_id"=> 1,
                "password"=> $password
            ),
            array(
                "name" => "Vishal Kumar",
                "image" => $faker->imageUrl(50, 50),
                "organization_id"=> 2,
                "password"=> $password
            ),
            array(
                "name" => "Vishal Kumar",
                "image" => $faker->imageUrl(50, 50),
                "organization_id"=> 3,
                "password"=> $password
            ),
            array(
                "name" => "John Doe",
                "image" => $faker->imageUrl(50, 50),
                "organization_id" => 1,
                "password" => null,
            ),
        );
        for ($i = 0; $i < 100; $i++) {
            $name = $faker->name;
            $customerData[] = [
                'name' => $name,
                'image'=> $faker->imageUrl(50, 60),
                'organization_id' => $faker->numberBetween(1, 4),
                'password' => $password,
                ];
        }
        $this->table('customers')
             ->insert($customerData)
             ->save();
        /*
         * Updating joined_time and joined_on in seeding data
         */
        $this->execute("update customers set joined_time = created_at");
        $customerIds = array();
        for ($i = 0; $i< 20; $i++) {
            $customerIds[$i] = $faker->unique->numberBetween(10, 100);
        }

        //seeding phones
        $phoneData = array(
            array(
                "customer_id" => 1,
                "phone" => 919876543210,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 1,
                "phone" => 919876543211,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 1,
                "phone" => 919876543212,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 5,
                "phone" => 919876543210,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 6,
                "phone" => 919876543210,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 2,
                "phone" => 919846544210,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 3,
                "phone" => 919246544210,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 4,
                "phone" => 919866544210,
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 7,
                "phone" => 919898998989,
                "status" => "NEW",
            )
        );
        for ($i = 0; $i < 20; $i++) {
            $phoneData[] = [
                'customer_id' => $customerIds[$i],
                'phone' => "91".$faker->unique->numberBetween($min = 8000000000, $max = 9999999000)
                ];
        }
        $this->table('phones')
             ->insert($phoneData)
             ->save();

        //seeding emails
        $emailData = array(
            array(
                "customer_id" => 1,
                "email" => "vishal@gmail.com",
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 1,
                "email" => "vishal.khanna@gmail.com",
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 1,
                "email" => "vishal.4u@gmail.com",
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 5,
                "email" => "vishal@gmail.com",
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 6,
                "email" => "vishal@gmail.com",
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 2,
                "email" => "saket.009@yahoo.com",
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 3,
                "email" => "alokit.foru@gmail.com",
                "status" => "VERIFIED",
            ),
            array(
                "customer_id" => 4,
                "email" => "abraham14121994@gmail.com",
                "status" => "VERIFIED",
            )
        );
        for ($i = 0; $i < 20; $i++) {
            $emailData[] = [
                'customer_id' => $customerIds[$i],
                'email' => $faker->unique->email
                ];
        }
        $this->table('emails')
             ->insert($emailData)
             ->save();
        
        //seeding addresses
        $addressData = array(
            array(
                "customer_id" => 1,
                "address" => "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                "landmark" => "Madivala Lake",
                "pincode" => 560076,
                "city" => "Bangalore",
                "latitude" => '12.9580030000000',
                "longitude" => '77.7162120000000',
                "client_address_id" => 1,
            ),
            array(
                "customer_id" => 5,
                "address" => "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                "landmark" => "Madivala Lake",
                "pincode" => 560076,
                "city" => "Bangalore",
                "latitude" => '12.9580030000000',
                "longitude" => '77.7162120000000',
                "client_address_id" => 2
            ),
            array(
                "customer_id" => 6,
                "address" => "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                "landmark" => "Madivala Lake",
                "pincode" => 560076,
                "city" => "Bangalore",
                "latitude" => '12.9580030000000',
                "longitude" => '77.7162120000000',
                "client_address_id" => 3
            ),
            array(
                "customer_id" => 1,
                "address" => "#34, Vinayaka PG, Opposite Shakti Mall. ",
                "landmark" => "Shakti Mall",
                "pincode" => 500001,
                "city" => "Hyderabad",
                "latitude" => '17.3850000000000',
                "longitude" => '78.4867000000000',
                "client_address_id" => 4
            )
        );
        for ($i =0; $i < 20; $i++) {
            $addressData[] =array(
                "customer_id" => $customerIds[$i],
                "address" => $faker->address,
                "landmark" => $faker->company,
                "pincode" => $faker->numberBetween(560000, 570000),
                "city" => $faker->city,
                "latitude" => $faker->randomFloat(13, 0, 99),
                "longitude" => $faker->randomFloat(13, 0, 99),
                "client_address_id" => $i + 4,
            );
        }
        $this->table("addresses")
             ->insert($addressData)
             ->save();

        $clientCustomerData = [
            array(
                "customer_id" => 1,
                "organization_id" => 1,
                "client_id" => 1
            ),
            array(
                "customer_id" => 2,
                "organization_id" => 1,
                "client_id" => 2
            ),
            array(
                "customer_id" => 3,
                "organization_id" => 1,
                "client_id" => 3
            )
        ];
        $this->table("client_customers")
             ->insert($clientCustomerData)
             ->save();
    }
}
