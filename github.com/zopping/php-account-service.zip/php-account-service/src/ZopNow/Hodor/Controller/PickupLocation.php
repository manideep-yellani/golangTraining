<?php

namespace ZopNow\Hodor\Controller;

class PickupLocation extends \ZopNow\Arya\Controller\ModelController
{
    protected $allowNonPaginated = true;

    public function get()
    {
        $params = $this->getRequestParams(['organizationId']);
        $id = $this->id;
        if (!empty($id)) {
            if ($params['organizationId'] != $this->model->organization_id) {
                throw new \ZopNow\Arya\Exception\ModelException("Pickup location with id: "
                        . $id . " not found");
            }
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function post()
    {
        $mandatoryFields = array("organizationId", "name", "address");
        $otherFields = array("latitude", "longitude", "storeId");
        $data = $this->getRequestParams($mandatoryFields, $otherFields);
        $organizationController = (new Organization(array("id" => $data['organizationId'])));
        $organizationDetails = $organizationController->get()->getData()['data']['organization'];

        $multiStoreExtensionEnabled = false;
        if (!empty($organizationDetails['extension'])) {
            $slugs = array_column($organizationDetails['extension'], 'slug');
            if (in_array('MultiStoreSupport', $slugs)) {
                $multiStoreExtensionEnabled = true;
            }
        }
        if (!$multiStoreExtensionEnabled) {
            $data['storeId'] = $organizationDetails['defaultStore']['id'];
        } elseif (empty($data['storeId'])) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Missing Required Field - pickuplocation : store Id"
            );
        }
        //Validate store id
        $storeController = new Store(
            ['id' => $data['storeId'], 'organizationId' => $data['organizationId']]
        );
        $storeController->get();
        if (!empty($data['name'])) {
            $exists = $this->model->exists($data['organizationId'], $data['name']);
            if ($exists) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Pickup location with the name ".$data['name']." already exists"
                );
            }
        }
        $location = $this->add($data);
        return (new \ZopNow\Arya\View\Base(
            [
                'code' => 200,
                "status" => "SUCCESS",
                "data" => $location
            ]
        ));
    }

    public function save($data)
    {
        if (!empty($data['latitude'])
            && !\ZopNow\Arya\Utility\Validator::isLatitude($data['latitude'])
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid latitude value");
        }
        if (!empty($data['longitude'])
            && !\ZopNow\Arya\Utility\Validator::isLongitude($data['longitude'])
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid longitude value");
        }
        return parent::save($data);
    }

    public function put()
    {
        $id = $this->id;
        if (empty($id)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid id");
        }
        $optionalFields = array("name", "latitude", "longitude", "address", "storeId");
        $data = $this->getRequestParams(array("organizationId"), $optionalFields);
        $data['id'] = $this->model->id;
        if ($this->model->organization_id != $data['organizationId']) {
            throw new \ZopNow\Arya\Exception\ModelException(
                "Pickup location with id " . $id . "not found"
            );
        }
        if (!empty($data['name']) && $this->model->exists($this->model->organization_id, $data['name'])) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Pickup location with name '$data[name]' already exists"
            );
        }
        if (!empty($data['storeId']) && $this->model->store_id != $data['storeId']) {
            $organizationController = (new Organization(["id" => $data['organizationId']]));
            $organizationDetails = $organizationController->get()->getData()['data']['organization'];

            $multiStoreExtensionEnabled = false;
            if (!empty($organizationDetails['extension'])) {
                $slugs = array_column($organizationDetails['extension'], 'slug');
                if (in_array('MultiStoreSupport', $slugs)) {
                    $multiStoreExtensionEnabled = true;
                }
            }
            if ($multiStoreExtensionEnabled) {
                $data['storeId'] = $organizationDetails['defaultStore']['id'];
            }
            //Validate store id
            $storeController = new Store(
                ['id' => $data['storeId'], 'organizationId' => $data['organizationId']]
            );
            $storeController->get();
        }
        $location = $this->edit($data);

        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $location
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

}
