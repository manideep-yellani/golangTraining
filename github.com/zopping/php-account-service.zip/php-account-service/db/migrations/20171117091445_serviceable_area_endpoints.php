<?php

use Phinx\Migration\AbstractMigration;

class ServiceableAreaEndpoints extends AbstractMigration
{
    
    public function up()
    {
        $endpointData = [
                ["url" => "logistics-service/pincode","allowed_methods" => json_encode(['GET','POST', 'DELETE'])],
                ["url" => "logistics-service/polygonal-zone","allowed_methods" => json_encode(['GET','POST', 'PUT'])],
                ["url" => "logistics-service/radial-zone","allowed_methods" => json_encode(['GET','POST'])],
                ["url" => "logistics-service/serviceable-area","allowed_methods" => json_encode(['GET'])]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $urls = [
            'logistics-service/pincode',
            'logistics-service/polygonal-zone',
            'logistics-service/radial-zone',
            'logistics-service/serviceable-area',
        ];
        $this->execute('DELETE from `endpoints` where `url` in (\''.implode($urls, "','").'\')');
    }

}
