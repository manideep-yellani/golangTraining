<?php

use Phinx\Migration\AbstractMigration;

class OrganizationAddLogo extends AbstractMigration
{
    public function change()
    {
        $this->table('organizations')
            ->addColumn('logo', 'string', array('limit' => 500, 'null' => true))
            ->save();
    }
}
