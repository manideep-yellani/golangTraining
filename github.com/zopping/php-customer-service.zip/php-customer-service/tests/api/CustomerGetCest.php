<?php

class CustomerGetCest extends BaseCest
{
    protected static $endpoint = '/customer';
    protected static $table    = "customers";

    public function listCustomersWithoutOrganizationId(ApiTester $I)
    {
        $I->wantToTest("Customers listing with pagination");
        $I->sendGET(self::$endpoint);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
    }

  /*
    public function listCustomersForAnOrganization(ApiTester $I)
    {
        $I->wantToTest("Customers listing For a organization");
        $I->sendGET(self::$endpoint . "?organizationId=1");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => array(
                    "count" => "integer",
                    "offset" => "integer",
                    "limit" => "integer",
                    "customer" => "array"
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }
*/
    public function getDetailsOfACustomerWithoutOrganization(ApiTester $I)
    {
        $I->wantToTest("Try to access details of a customer without organization id");
        $I->sendGET(self::$endpoint."?/1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
    }

    public function getDetailsOfACustomerOfADifferentOrganization(ApiTester $I)
    {
        $I->wantToTest("Try to access details of a customer of a different organization");
        $I->sendGET(self::$endpoint."?/1?organizationId=2");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
    }
/*
    public function getDetailsOfACustomer(ApiTester $I)
    {
        $I->wantToTest("Get details for a customer with id=1");
        $I->sendGET(static::$endpoint . "/1?organizationId=1");
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => array(
                    "customer" => array(
                        "id" => "integer",
                        "name" => "string",
                        "image" => "string|null",
                        "joinedTime" => "string|null",
                        "joinedOn" => "string|null",
                        "totalOrders" => "integer | null",
                        "lastOrderedOn" => "string | null",
                        "phones" => "array",
                        "emails" => "array",
                        "addresses" => "array",
                        "orderSummary" => "array",
                        "isRegistered" => "boolean"
                    ) //
                )
            ));
        } catch (Exception $ex) {
            self::serviceDownTest($I);
        }
    }

  */
    public function getDetailsOfACustomerWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Get details of a customer with invalid id');
        $I->sendGET(self::$endpoint."/abcde");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Customer with id: abcde not found'));
    }
/*
    public function getDetailsOfACustomerWithPhoneFilter(ApiTester $I)
    {
        $I->wantTo('Get list of customers with Phone Filter');
        $I->sendGET(self::$endpoint."?organizationId=1&phone=919876543210");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseContainsJson(array(
                "data" => array(
                    "customer"=>array(
                        "id"=>1
                    )
                )
            ));
            $I->dontSeeResponseContainsJson(array(
                "data" => array(
                    "customer"=>array(
                        "id"=>2
                    )
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function getDetailsOfACustomerWithEmailFilter(ApiTester $I)
    {
        $I->wantTo('Get list of customers with Email Filter');
        $I->sendGET(self::$endpoint."?organizationId=1&email=vishal@gmail.com");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseContainsJson(array(
                "data" => array(
                    "customer"=>array(
                        "id"=>1
                    )
                )
            ));
            $I->dontSeeResponseContainsJson(array(
                "data" => array(
                    "customer"=>array(
                        "id"=>2
                    )
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function listCustomersWithPageNumberOutOfRange(ApiTester $I)
    {
        $I->wantToTest("Customer listing with page number out of range");
        $I->sendGET(self::$endpoint."?organizationId=1&page=8000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['customer' => []]));
    }

    public function getDetailsOfUnregisteredCustomer(ApiTester $I)
    {
        $I->wantTo('Get details of non registered customer');
        $I->sendGET(self::$endpoint."/7?organizationId=1");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseContainsJson(array(
                "data" => array(
                    "customer"=>array(
                        "id"=>7,
                        "isRegistered" => false,
                    )
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function testOrderSummaryDataInListingAndDetails(ApiTester $I)
    {
        $I->wantToTest("Order reated customer data in customer listing");
        // Testing customer listing api
        $I->sendGet(self::$endpoint, ["organizationId" => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $customers = $I->grabDataFromResponseByJsonPath("$.data.customer")[0];
        foreach($customers as $customer) {
            $I->assertNotNull($customer['totalOrders']);
            $I->assertNotNull($customer['totalAmount']);
            $I->assertArrayHasKey("lastOrderedOn", $customer);
            $I->assertArrayNotHasKey("orderSummary", $customer);
        }
        // Testing details api
        $I->sendGet(self::$endpoint."/1", ["organizationId" => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $customer = $I->grabDataFromResponseByJsonPath("$.data.customer")[0];
        $I->assertNotNull($customer['totalOrders']);
        $I->assertNotNull($customer['totalAmount']);
        $I->assertArrayHasKey("lastOrderedOn", $customer);
        $I->assertArrayHasKey("orderSummary", $customer);
    }

    public function getDetailsOfACustomerWithClientIdFilter(ApiTester $I)
    {
        $I->wantTo("Get list of customers with client id filter");
        $id = $I->haveInDatabase('customers', ['name' => 'Sam', 'organization_id' => 1]);
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 401]
        );
        $I->sendGET(self::$endpoint."?organizationId=1&clientId=401");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseContainsJson(array(
                "data" => array(
                    "customer"=>array(
                        "id"=>$id
                    )
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }
*/
}