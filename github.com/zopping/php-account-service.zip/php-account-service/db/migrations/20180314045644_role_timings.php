<?php

use Phinx\Migration\AbstractMigration;

class RoleTimings extends AbstractMigration
{

    public function up()
    {
        $userTimingsTable = $this->table("user_timings");
        $userTimingsTable
            ->addColumn("user_id","integer")
            ->addColumn("shift_start", "time",array('after' => 'lang_iso_code', 'null' => true))
            ->addColumn("shift_end", "time",array('after' => 'shift_start', 'null' => true))
            ->addColumn("weekly_off","integer",array("limit" => \Phinx\Db\Adapter\MysqlAdapter::INT_TINY, "null" => true))
            ->addColumn('created_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addIndex(['updated_at'])
            ->addForeignKey('user_id', 'users', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->create();
    }

    public function down() 
    {
        $this->dropTable('user_timings');
    }

}
