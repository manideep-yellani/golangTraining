<?php
require_once 'BaseCest.php';
class StoreDeleteCest
{
    protected static $endpoint = '/store';
    protected static $table = "stores";

    public function deleteStoreWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Delete a store');
        $I->sendDELETE(static::$endpoint . "/1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message" =>
                "Validation Exception: Missing Required Field - store : organization Id"]
        );
    }

    public function deleteStore(ApiTester $I)
    {
        $I->wantTo('Delete a store');
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Sample Store', 'organization_id' => 1]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array("message" => "Store deleted successfully"));
    }

    public function deleteStoreInvalidId(ApiTester $I)
    {
        $I->wantTo('Delete a store with invalid id');
        $I->sendDELETE(static::$endpoint . "/10000", ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Model Exception: Store with id: 10000 not found"]
        );
    }

    public function deleteStoreWithoutId(ApiTester $I)
    {
        $I->wantTo('Delete a store without passing id');
        $I->sendDELETE(static::$endpoint, ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Missing Required Field - store : id"]
        );
    }

    public function deleteStoreWhichIsDeleted(ApiTester $I)
    {
        $I->wantTo("Delete a store which is already deleted");
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Test Store', 'organization_id' => 1]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseContainsJson(
            ["message" => "Model Exception: Store with id: $id not found"]
        );
    }

}