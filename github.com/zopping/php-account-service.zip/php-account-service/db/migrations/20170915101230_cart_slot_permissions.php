<?php

use Phinx\Migration\AbstractMigration;

class CartSlotPermissions extends AbstractMigration
{

    public function change()
    {
        $developerId = $this->fetchRow("select id from developers where token='59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $endpointsData = [
            ['url' => "order-service/cart"],
            ['url' => "account-service/slot"]
        ];
        $this->insert("endpoints", $endpointsData);
        $endpointId = $this->fetchRow("select max(id) from endpoints")['max(id)'];
        $permissionData = [
            [
                "endpoint_id" => $endpointId,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1,
                "is_customer_required" => 0
            ],
            [
                "endpoint_id" => ($endpointId - 1),
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1,
                "is_customer_required" => 0
            ],
            [
                "endpoint_id" => ($endpointId - 1),
                "developer_id" => $developerId,
                "method" => "PUT",
                "has_permission" => 1,
                "is_customer_required" => 0
            ]
        ];
        $this->insert("endpoint_developer_permissions", $permissionData);
        
    }
}
