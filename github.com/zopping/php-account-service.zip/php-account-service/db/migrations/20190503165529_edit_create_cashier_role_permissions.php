<?php

use Phinx\Migration\AbstractMigration;

class EditCreateCashierRolePermissions extends AbstractMigration
{
    
    public function change()
    {
        $endpoints = ["account-service/store"  => ['GET']];
        $roleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in ('" . implode("','",
                array_keys($endpoints)) . "')");
        $roleId = $this->fetchRow("select id from roles where `name` = 'CASHIER'")['id'];
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach ($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'],
                    'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }
}
