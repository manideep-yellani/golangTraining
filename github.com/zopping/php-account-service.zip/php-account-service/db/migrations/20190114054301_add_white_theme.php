<?php

use Phinx\Migration\AbstractMigration;

class AddWhiteTheme extends AbstractMigration
{
    public function up() {
        $themes = [
            [
                'name' => 'White',
                'image' => '{"desktop":"http://via.placeholder.com/1024x768","mobile":"http://via.placeholder.com/414x736","tablet":"http://via.placeholder.com/1024x768"}',
                "slug" => 'theme-white',
                'description' => 'This is the White theme'
            ]
        ];
        $this->insert('themes', $themes);
    }

    public function down() {
        $this->execute("delete from themes where name = 'White'");
    }
}
