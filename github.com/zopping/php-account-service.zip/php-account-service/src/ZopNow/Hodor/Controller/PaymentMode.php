<?php

namespace ZopNow\Hodor\Controller;

class PaymentMode extends \ZopNow\Arya\Controller\Base
{

    private static $pgIcons = [
        3 => "https://storage.googleapis.com/static-zoppay/pg-icons/netbanking.png",
        4 => "https://storage.googleapis.com/static-zoppay/pg-icons/visa%20mastercard.png",
        5 => "https://storage.googleapis.com/static-zoppay/pg-icons/others%20card.png",
        6 => "https://storage.googleapis.com/static-zoppay/pg-icons/visa%20mastercard.png",
        7 => "https://storage.googleapis.com/static-zoppay/pg-icons/others%20card.png",
        10 => "https://storage.googleapis.com/static-zoppay/pg-icons/paytm.png",
        11 => "https://storage.googleapis.com/static-zoppay/pg-icons/amex.png",
        12 => "https://storage.googleapis.com/static-zoppay/pg-icons/mobiwiki.png",
        14 => "https://storage.googleapis.com/static-zoppay/pg-icons/ola%20money.png",
        15 => "https://storage.googleapis.com/static-zoppay/pg-icons/dinners%20club.png",
        16 => "https://storage.googleapis.com/static-zoppay/pg-icons/upi.png",
        17 => "https://storage.googleapis.com/static-zoppay/pg-icons/idea%20money.png",
        18 => "https://storage.googleapis.com/static-zoppay/pg-icons/phonepe.png",
    ];

    public function get()
    {
        $fields = $this->getRequestParams(['organizationId']);
        $currency = (new \ZopNow\Hodor\Controller\Organization(['id' => $fields['organizationId']]))->getCurrency();
        $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor('payment-mode.json', 'GET', ['currency' => $currency[0]['name']]))->execute();
        $details =  json_decode($response['response'], true);
        $pModeDetails = $details['data'] ?? [];
        $camelCaseResponse = \ZopNow\Hodor\Utility\Utility::convertKeysToCamelCase($pModeDetails);
        unset($details['data']);
        foreach ($camelCaseResponse as &$mode) {
            $id = $mode['id'];
            if (isset(self::$pgIcons[$id])) {
                $mode['imageUrl'] = self::$pgIcons[$id];
            }
        }
        $details['paymentmode'] = $camelCaseResponse;
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'code' => 200,
            'data' => $details
            ])
        );
    }

    public function getImageUrl()
    {
        $data = $this->getRequestParams(['id']);
        return self::$pgIcons[$data['id']] ?? null;
    }

}