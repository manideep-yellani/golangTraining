<?php

use Phinx\Migration\AbstractMigration;

class AddPreOrderExt extends AbstractMigration
{
    private $slug = "PreOrderSupport";

    public function up()
    {
        $enableHelperText = "Pre Order support enables you to set handling days at product level.| If the cart has such products then their stocks will not validated and order cannot be placed for the next X days.";
        $disableHelperText = "You can no longer manage pre ordering of products. Handling days will not be considered. ";
        $data = [
            "name" => "Pre Order Support",
            "slug" => $this->slug,
            "description" => "$enableHelperText,",
            "enable_helper_text" => "",
            "disable_helper_text" => $disableHelperText,
            // TODO ICON
            "icon" => "https://storage.googleapis.com/zopsmart-uploads/originals/20190319/preorder-20190319-120233.png",
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
    }
    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $this->execute("DELETE from `extension_organization` where `extension_id` = '$extensionId'");
        $this->execute("DELETE from `extensions` where `id` = $extensionId");
    }
}
    

