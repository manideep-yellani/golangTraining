<?php

use Phinx\Migration\AbstractMigration;

class UpdateStoreEndpoint extends AbstractMigration
{

    public function up()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
            . json_encode(['GET','POST','PUT','DELETE'])
            . '\' where url = "account-service/store"');
    }

    public function down()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
            . json_encode(['GET','POST','PUT'])
            . '\' where url = "account-service/store"');
    }
}
