<?php

class ThemeGetCest extends BaseCest
{

    protected static $endpoint = '/theme';
    protected static $table = 'themes';

    public function listThemes(ApiTester $I)
    {
        $I->wantTo('Get list of themes');
        parent::getAll($I);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "theme" => array(
                    array(
                        "id" => "integer",
                        "name" => "string",
                        "image" => "string|null",
                        "description" => "string|null"
                    )
                )
            )
        ));
    }

    public function listThemesInvalidPage(ApiTester $I)
    {
        //Sending a page number which does not have data
        $I->wantTo('Get list of themes with invalid page number');
        $I->sendGET(self::$endpoint . "?page=10000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['theme' => []]));
    }

    public function listThemesWithName(ApiTester $I)
    {
        //Sending name as a filter and checking if the required data is returned
        $I->wantTo('Get list of themes with name filter');
        $id = $I->haveInDatabase(
            self::$table,
            ['name' => 'Basic Theme', 'slug' => 'basic-theme', 'image' => 'http://via.placeholder.com/653X368']
        );
        $I->sendGET(self::$endpoint . "?name=Basic Theme");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "theme" => array(
                    array(
                        "id" => "integer",
                        "name" => "string",
                        "image" => "string|null",
                        "description" => "string|null"
                    )
                )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'Basic Theme']);
    }

    public function getTheme(ApiTester $I)
    {
        $I->wantTo('Get details of a theme with a valid id');
        $id = $I->haveInDatabase(
            self::$table,
            ['name' => 'Test Theme', 'slug' => 'test-theme', 'image' => 'http://via.placeholder.com/653X368']
        );
        parent::getSingle($I, $id);
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "theme" => array(
                    "id" => "integer",
                    "name" => "string",
                    "image" => "string|null",
                    "description" => "string|null"
                )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'Test Theme']);
    }

    public function getThemeInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of a theme with invalid id');
        $I->sendGET(self::$endpoint . "/theme1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Theme with id: theme1 not found'));
    }

}
