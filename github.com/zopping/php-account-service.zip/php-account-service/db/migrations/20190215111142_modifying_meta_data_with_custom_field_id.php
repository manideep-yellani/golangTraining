<?php

use Phinx\Migration\AbstractMigration;

class ModifyingMetaDataWithCustomFieldId extends AbstractMigration
{
    public function up()
    {
        $rows = $this->fetchAll("SELECT * from config_service.custom_fields where entity='Store'");
        $mapKeyID = $this->getMapKeyId($rows);
        $rows = $this->fetchAll("SELECT id,organization_id,meta_data from stores");
        $this->updateMetaData($rows, "stores", $mapKeyID);
    }
    //create a map of map[organizationID][key]=[id]
    private function getMapKeyId($rows)
    {
        $mapKeyID = array();
        foreach ($rows as $row) {
            $orgID = $row['organization_id'];
            $key = $row['key'];
            $mapKeyID[$orgID][$key] = $row['id'];
        }
        return $mapKeyID;
    }

    //create a map of map[organizationID][id]=[key]
    private function getMapIdKey($rows)
    {
        $mapIDKey = array();
        foreach ($rows as $row) {
            $orgID = $row['organization_id'];
            $id = $row['id'];
            $mapIDKey[$orgID][$id] = $row['key'];
        }
        return $mapIDKey;

    }

    private function updateMetaData($rows, $tableName, $mapKeyID)
    {
        foreach ($rows as $row) {
            $metaData = $row['meta_data'];
            $orgID = $row['organization_id'];
            $id = $row['id'];
            if (isset($metaData)) {
                $mp = json_decode($metaData, true);
                foreach ($mp as $key => $value) {
                    if(isset($mapKeyID[$orgID][$key])) {
                        $mp[$mapKeyID[$orgID][$key]] = $value;
                    }
                    unset($mp[$key]);
                }
                if(empty($mp)){
                    $this->execute('update ' . $tableName . ' set meta_data= NULL  where id=' . $id);
                }else{
                    $mp = json_encode($mp);
                    $this->execute('update ' . $tableName . ' set meta_data= \'' . $mp . '\'  where id=' . $id);
                }
            }
        }
    }

    public function down()
    {
        $rows = $this->fetchAll("SELECT * from config_service.custom_fields where entity='Store'");
        $mapIDkey = $this->getMapIdKey($rows);
        $rows = $this->fetchAll("SELECT id,organization_id,meta_data from stores");
        $this->updateMetaData($rows, "stores", $mapIDkey);
    }
}
