<?php

use Phinx\Migration\AbstractMigration;

class AddPricingForExtensions extends AbstractMigration
{

    public function up()
    {
        // Add pricing column in extensions
        $this->table("extensions")
            ->addColumn("pricing", "string", ['null' => true])
            ->update();
        // Update pricing details for extensions
        $extensions = [
            'MultiBrandSupport' => 'FREE',
            'MultiUserSupport' => 'FREE for 2 users and ₹ 100 per month for every user after that',
            'MultiStoreSupport' => 'FREE for 1 store and ₹ 1000 per month for every store after that',
        ];
        foreach ($extensions as $slug => $pricing) {
            $this->execute("update extensions set pricing='$pricing' where slug ='$slug'");
        }
    }

    public function down()
    {
        // Drop column pricing from extensions
        $this->table("extensions")
            ->removeColumn("pricing")
            ->update();
    }

}