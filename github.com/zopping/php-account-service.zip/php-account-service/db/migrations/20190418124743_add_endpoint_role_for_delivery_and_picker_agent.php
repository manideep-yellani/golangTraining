<?php

use Phinx\Migration\AbstractMigration;

class AddEndpointRoleForDeliveryAndPickerAgent extends AbstractMigration
{
    public function change()
    {
        $roleName=['DELIVERY AGENT','PICKER'];
        $roleIds = $this->fetchAll("select id from roles where name in  ('" . implode("','", $roleName) . "')");
        $endpointId=$this->fetchRow('select id from endpoints where url="config-service/config"');
        $eId=$endpointId['id'];
        foreach ($roleIds as $roleId) {
            $rid=$roleId['id'];
            $this->execute("replace into endpoint_role(`endpoint_id`,`role_id`,`method`)values($eId,$rid,\"GET\")");
        }
    }
}
