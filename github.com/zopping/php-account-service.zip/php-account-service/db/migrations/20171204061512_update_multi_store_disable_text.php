<?php

use Phinx\Migration\AbstractMigration;

class UpdateMultiStoreDisableText extends AbstractMigration
{

    public function change()
    {
        $disableHelperText = "Store interface will be disabled | ".
            "All the store specific data will be considered from the first store, so products not present in the first store are no longer shown in website| ".
            "Store specific delivery areas will not be supported  | ".
            "Store specific website pages cannot be designed  | ".
            "All types of analytics will show data for the single store | ".
            "Store Specific Campaigns or Coupons are not supported";
        $this->execute("update extensions set disable_helper_text ='$disableHelperText'"
                . " where `slug` = 'MultiStoreSupport'");
    }

}
