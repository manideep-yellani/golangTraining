<?php

use Phinx\Migration\AbstractMigration;

class ContentManagerPermissionFixes extends AbstractMigration
{
    public function change()
    {
        $endpoints = [
            "account-service/static-page"  => ['GET', 'PUT', 'POST'],
            "blog-service/category" => ["GET","POST","DELETE"],
            "blog-service/tag" => ["GET","POST","PUT","DELETE"],
            "blog-service/blog" => ["GET","POST","PUT","DELETE"],
            "media-service/image-upload" => ["POST"],
            "promo-service/banner" => ["GET","POST","PUT","DELETE"],
            "account-service/extension" => ["GET"],
        ];
        $roleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in ('" . implode("','",
                array_keys($endpoints)) . "')");
        $roleId = $this->fetchRow("select id from roles where `name` = 'CONTENT MANAGER' AND organization_id is null")['id'];
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);
        $roleId = $this->fetchRow("select id from roles where `name` = 'CONTENT WRITER' AND organization_id is null")['id'];
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach ($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'],
                    'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }
}
