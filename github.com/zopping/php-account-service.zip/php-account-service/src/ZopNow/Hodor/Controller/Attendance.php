<?php

namespace ZopNow\Hodor\Controller;

class Attendance extends \ZopNow\Arya\Controller\ModelController
{
    protected static $filterableFields = ['organization_id', 'user_id', 'date', 'out_time', 'store_id'];
    protected $allowNonPaginated = true;

    public function get()
    {
        $id = $this->id;
        $data = null;
        if (!empty($id)) {
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function post()
    {
        $fields = $this->getRequestParams(['organizationId', 'userId']);
        $user = (new User(['id' => $fields['userId'], 'organizationId' => $fields['organizationId'], 'include' => ['shiftDetails']]))->get()->getData();
        $userDetails = $user['data']['user'];
        if ($userDetails['timing_type']=='FIXED'&&(empty($userDetails['shiftStart']) && empty($userDetails['shiftEnd'])))  {
            throw new \ZopNow\Arya\Exception\ValidationException("No shift timings present for the user");
        }
        $crossShift = strtotime($userDetails['shiftStart']) > (strtotime($userDetails['shiftEnd'])) ? true : false;
        $activeAttendanceForUser = $this->model->getLastActiveAttendanceForUser($fields['userId']);
        if (!empty($activeAttendanceForUser) && empty($activeAttendanceForUser->out_time)) {
            throw new \ZopNow\Arya\Exception\ValidationException("The user has to be checked out first");
        }
        $currentTime = date("Y-m-d H:i:s");
        $date = date("Y-m-d");
        $minInTime = $date . " 00:00:00";
        $maxInTime = $date . " 23:59:59";
        if ($crossShift) {
            $lastShiftEndTime = strtotime($date . " " . $userDetails['shiftEnd']);
            $minInTime = date("Y-m-d H:i:s", $lastShiftEndTime + 1);
            $maxInTime = date("Y-m-d H:i:s", strtotime("+1 day", $lastShiftEndTime));
        }
        if($currentTime < $minInTime) {
            $attendanceDate = date("Y-m-d", strtotime("1 day ago"));
        } else {
            $attendanceDate = $date;
        }
        $fields['expectedIn'] = $attendanceDate. ' ' . $userDetails['shiftStart'];
        $fields['expectedOut'] = $crossShift ? date('Y-m-d', strtotime('+1 day', strtotime($attendanceDate))) .' '. $userDetails['shiftEnd'] :  $attendanceDate.' '. $userDetails['shiftEnd'];
        $fields['inTime'] = date('Y-m-d H:i:s');
        $fields['date'] = $attendanceDate;
        $details = $this->add($fields);
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $details,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function put()
    {
        $fields = $this->getRequestParams(['organizationId', 'id', 'userId']);
        if ($this->userId != $this->model->user_id || !empty($this->model->out_time)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid attendance");
        }
        $orderProcessMapping = json_decode(\ZopNow\Arya\Utility\MicroService::callService("go-order-service",
                "/picker-activity", "GET",
                ['organizationId' => $fields['organizationId'], 'pickerId' => $fields['userId']]
        )['body'], true)['data'] ?? [];
        if (sizeof($orderProcessMapping) > 0) {
            throw new \ZopNow\Arya\Exception\ValidationException("User has to finish picking/packing/delivery before checking out.");
        }
        $fields['outTime'] = date("Y-m-d H:i:s");
        $details = $this->edit($fields);
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $details,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function delete()
    {
        $this->getRequestParams(['organizationId', 'id']);
        if ($this->organizationId != $this->model->organization_id) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid attendance");
        }
        $this->model->delete();
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'message' => "Successfully deleted",
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public static function getLastCheckedInForUser($user)
    {
        return \ZopNow\Hodor\Model\Attendance::getLastCheckedInForUser($user);
    }

}
