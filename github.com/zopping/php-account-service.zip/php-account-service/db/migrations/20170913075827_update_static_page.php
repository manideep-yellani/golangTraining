<?php

use Phinx\Migration\AbstractMigration;

class UpdateStaticPage extends AbstractMigration
{

    public function change()
    {
        $this->execute("update pages set name = 'CONSTANT' where name = 'STATIC'");
    }
}
