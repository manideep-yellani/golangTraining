<?php

namespace ZopNow\Hodor\Model;

class Page extends \ZopNow\Arya\Model\Base
{

    public function layouts()
    {
        return $this->hasMany("\ZopNow\Hodor\Model\OrganizationPage");
    }
}
