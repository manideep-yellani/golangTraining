<?php


use Phinx\Migration\AbstractMigration;

class AddBalanceTransactionEndpoints extends AbstractMigration
{

    public function change()
    {
        $endpointData = [
                ["url" => "billing-service/balance"],
                ["url" => "billing-service/transaction"]
        ];
        $this->insert('endpoints', $endpointData);        
    }

}
