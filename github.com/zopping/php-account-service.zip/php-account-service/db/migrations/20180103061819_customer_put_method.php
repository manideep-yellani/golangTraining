<?php

use Phinx\Migration\AbstractMigration;

class CustomerPutMethod extends AbstractMigration
{
 
    /*
     * Adding PUT method for customer-service/customer API
     */
    public function change()
    {
        $id = $this->fetchRow("select id from endpoints where url = 'customer-service/customer'")['id'];
        $this->execute("update endpoints set allowed_methods = '".json_encode(["GET", "POST", "PUT"]). "' where id= $id");
        $this->table("endpoint_developer_permissions")
            ->insert([
                [
                    "endpoint_id" => $id,
                    "developer_id" => 2,
                    "method" => "PUT",
                    "has_permission" => 1,
                    "is_customer_required" => 1
                ]
            ])
            ->save();
    }
}
