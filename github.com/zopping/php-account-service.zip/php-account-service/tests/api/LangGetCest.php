<?php

class LangGetCest
{

    protected static $endpoint = '/lang';

    public function listAllSupportedLanguages(ApiTester $I)
    {
        $I->sendGET(self::$endpoint);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "lang" => "array"
            )
        ));
    }

    public function getDetailsForAValidLanguage(ApiTester $I)
    {
        $I->wantTo('Get configs for valid language iso code');
        $I->sendGET(self::$endpoint . "/en");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "lang" => "array"
                )
        ));
    }

    public function getDetailsForAnInvalidLanguage(ApiTester $I)
    {
        $I->wantTo('Get configs with invalid language type');
        $I->sendGET(self::$endpoint . "/yellow");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid Language'));
    }

}
