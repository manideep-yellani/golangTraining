<?php

require_once('BaseCest.php');
/**
 * Class consists of all the test cases for the CRUD operations in organization
 * which the API should handle
 */

class OrganizationCest extends BaseCest
{
    protected static $endpoint = '/organization';
    protected static $table = 'organizations';

    public function listOrganizations(ApiTester $I)
    {
        $I->wantTo('Get list of organizations');
        //This should return data as null since listing of all organizations is not allowed
        parent::getAll($I);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => "null"
        ));
    }

    public function listOrganizationsWithSlug(ApiTester $I)
    {
        //Sending a slug as a filter and checking if the required data is returned
        $I->wantTo('Get list of organizations with slug filter');
        $I->sendGET(self::$endpoint . "?slug=ruchis-biryani");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "organization" => array(
                    array(
                        "id" => "integer",
                        "name" => "string|null",
                        "domain" => "string|null",
                        "logo" => "string|null",
                        "currency" => array(
                            "id" => "integer",
                            "name" => "string",
                            "symbol" => "string"
                        ),
                    )
                )
            )
        ));
        $I->seeResponseContainsJson(array(['name' => "Ruchi's Biryani"]));
    }

    public function listOrganizationsInvalidSlug(ApiTester $I)
    {
        //Sending an invalid slug to check if the API returns an error response
        $I->wantTo('Get list of organizations with invalid slug filter');
        $I->sendGET(self::$endpoint . "?slug=abc");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['organization' => []]));
    }
/*
    public function getOrganization(ApiTester $I)
    {
        $I->wantTo('Get details of an organization with a valid id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Silbatti']);
        parent::getSingle($I, $id);
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "organization" => array(
                    "id" => "integer",
                    "name" => "string|null",
                    "domain" => "string|null",
                    "logo" => "string|null",
                    "currency" => array(
                        "id" => "integer",
                        "name" => "string",
                        "symbol" => "string"
                    ),
                    "owner" => array(
                )
            )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'Silbatti']);
    }
*/
    public function getOrganizationInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of an organization with invalid id');
        $I->sendGET(self::$endpoint . "/a1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Organization with id: a1 not found'));
    }
/*
    public function getOrganizationSlugId(ApiTester $I)
    {
        //Sending a slug with a valid id. The slug filter will not be applied
        $I->wantTo('Get details of an organization with a valid id and a slug');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Silbatti']);
        $slug = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Zopnow']);
        $I->sendGET(self::$endpoint . "/$id?slug=$slug");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "organization" => array(
                    "id" => "integer",
                    "name" => "string|null",
                    "domain" => "string|null",
                    "logo" => "string|null",
                    "currency" => array(
                        "id" => "integer",
                        "name" => "string",
                        "symbol" => "string"
                    ),
                    "owner" => array(
                    )
                )
            )
        ));
        $I->seeResponseContainsJson(array('id' => $id, 'name' => 'Silbatti'));
        $I->dontSeeResponseContainsJson(array('name' => 'Zopnow'));
    }
*/
    public function getOrganizationSlugInvalidId(ApiTester $I)
    {
        //Sending a slug with a invalid id. The slug filter will not be applied
        $I->wantTo('Get details of an organization with a invalid id and a slug');
        $slug = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Zopnow']);
        $I->sendGET(self::$endpoint . "/fg?slug=$slug");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Organization with id: fg not found'));
        $I->dontSeeResponseContainsJson(array('name' => 'Zopnow'));
    }

    public function listOrganizationsWithDomainFilter(ApiTester $I)
    {
        $domainName = "zopnow.com";
        $I->wantTo('Test domain filter in organization listing');
        $I->sendGet(self::$endpoint."?domain=$domainName");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "organization" => array(
                    array(
                        "id" => "integer",
                        "name" => "string|null",
                        "domain" => "string|null",
                        "logo" => "string|null",
                        "currency" => array(
                            "id" => "integer",
                            "name" => "string",
                            "symbol" => "string"
                        )
                    )
                )
            )
        ));
        $I->seeResponseContainsJson(array("data"=>array("count" => 1)));
        $domainFromResponse = $I->grabDataFromResponseByJsonPath("$..data.organization[0].domain")[0];
        $I->assertEquals($domainFromResponse, $domainName);
    }

    public function listOrganizationsWithInvaldDomainFilter(ApiTester $I)
    {
        $domainName = "bbbbbb.com"; //
        $I->wantTo('Test domain filter in organization listing');
        $I->sendGet(self::$endpoint."?domain=$domainName");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "organization" => "array"
            )
        ));
        $I->seeResponseContainsJson(array("data"=>array("count" => 0)));
    }
}
