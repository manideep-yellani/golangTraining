<?php

use Phinx\Migration\AbstractMigration;

class AddSlotAvailabilityEndpoint extends AbstractMigration
{
    private $slug = "DeliverySlots";

    public function up()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $endpointData = [
            [
                "url" => "logistics-service/slot-availability",
                "extension_id" => $extensionId,
                "allowed_methods" => json_encode(['POST'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'logistics-service/slot-availability'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `name` = 'Universal Key' and organization_id is null")['id'];
        $this->insert('endpoint_developer_permissions', array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1
        ));
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `extension_id` = '$extensionId' and `url` = 'logistics-service/slot-availability'"),
            'id'
        );
        $this->execute("DELETE from `endpoint_developer_permissions` where endpoint_id in"
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoints` where `extension_id` = '$extensionId'");
    }
}
