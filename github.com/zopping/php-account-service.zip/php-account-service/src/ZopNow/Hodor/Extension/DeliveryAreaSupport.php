<?php


namespace ZopNow\Hodor\Extension;

class DeliveryAreaSupport extends Base
{

    public function enable()
    {
        $organizationId = $this->organization->id;
        $resp = \ZopNow\Arya\Utility\MicroService::callService(
            "config-service", 
            "/config/website", 
            "GET", 
            ['organizationId' => $organizationId]
        );
        $googleMapsApiKey = json_decode($resp["body"], true)["data"]["website"]["googleApisKey"];
        if (empty($googleMapsApiKey)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please configure google maps api key");
        }

        return true;
    }

    public function disable()
    {
        $organizationId = $this->organization->id;
        \ZopNow\Arya\Utility\MicroService::callService("logistics-service", "/delivery-area", "PUT", ['organizationId' => $organizationId, 'force_disable_all' => true]);
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        $deliveryAreas = [];
        $cost = 0;
        $organizationId = $this->organization->id;
        if (!empty($pricingRule['TYPE']) && $pricingRule['TYPE'] == 'MONTHLY') {
            $start = date('Y-m-d 00:00:00', strtotime($startTime));
            $end = date('Y-m-d 23:59:59', strtotime($endTime));
            $enabledDeliveryAreas = $this->getEnabledDeliveryAreas($start,$end);
            $disabledDeliveryAreas = $this->getDisabledDeliveryAreas($startTime, $endTime);
            $deliveryAreas = array_merge($enabledDeliveryAreas, $disabledDeliveryAreas);
        }
        $numDays = date('t', strtotime($startTime));
        $count = sizeof($deliveryAreas);
        arsort($deliveryAreas);
        $freeCount = $pricingRule['FREE'] ?? 0;
        $deliveryAreas = array_slice($deliveryAreas, $freeCount, NULL, true);
        foreach ($deliveryAreas as $delId => $billingPeriod) {
            $cost += $pricingRule['COST'] * $billingPeriod /$numDays;
        }
        if (!empty($cost)) {
            \ZopNow\Arya\App\Application::log("Delivery areas billied for organization $organizationId", $deliveryAreas);
            $metaData = date('Y-m-d',strtotime($startTime))."-".date('Y-m-d',strtotime($endTime)).", Active number of delivery areas $count.";
        }
        return ['cost' => $cost, 'metaData' => $metaData ?? null];
    }

    private function getEnabledDeliveryAreas($startTime, $endTime)
    {
        $deliveryAreas = [];
        $page = 0;
        do {
            ++$page;
            $enabledDeliveryAreas = \ZopNow\Arya\Utility\MicroService::callService('logistics-service', '/delivery-area','GET',['organizationId' => $this->organization->id, 'page' => $page]);
            $enabledDeliveryAreas = json_decode($enabledDeliveryAreas['body'], true);
            $count = $enabledDeliveryAreas['data']['count'];
            $offset = $enabledDeliveryAreas['data']['offset'];
            $limit = $enabledDeliveryAreas['data']['limit'];
            $remaining = $count - ($offset + $limit);
            foreach ($enabledDeliveryAreas['data']['deliveryarea'] as $group) {
                if (strtotime($group['createdAt']) < strtotime($endTime)) {
                    $startPeriod = strtotime($group['createdAt']) < strtotime($startTime) ? strtotime($startTime) : strtotime($group['createdAt']);
                    $endPeriod = strtotime($endTime);
                    $diffDays = round(($endPeriod - $startPeriod)/86400);
                    if ($diffDays > 0) {
                        $deliveryAreas[$group['id']] = $diffDays;
                    }
                }
            }
        } while($remaining > 0);
        return $deliveryAreas;
    }

    private function getDisabledDeliveryAreas($startTime, $endTime)
    {
        $deliveryAreas = [];
        $page = 0;
        do{
            ++$page;
            $disabledDeliveryAreas = \ZopNow\Arya\Utility\MicroService::callService('logistics-service', '/delivery-area','GET',['organizationId' => $this->organization->id, 'page' => $page, 'status' => 'DISABLED', 'updatedAt' => [$startTime,$endTime]]);
            $disabledDeliveryAreas = json_decode($disabledDeliveryAreas['body'], true);
            $count = $disabledDeliveryAreas['data']['count'];
            $offset = $disabledDeliveryAreas['data']['offset'];
            $limit = $disabledDeliveryAreas['data']['limit'];
            $remaining = $count - ($offset + $limit);
            foreach ($disabledDeliveryAreas['data']['deliveryarea'] as $group) {
                if ($group['configType'] == 'PINCODE') {
                    $disabledAt = $group['pincodegroup']['updatedAt'];
                } else if ($group['configType'] == 'RADIAL') {
                    $disabledAt = $group['radialzone']['updatedAt'];
                }  else {
                    $disabledAt = $group['polygonalzone']['updatedAt'];
                }
                if (strtotime($disabledAt) < strtotime($endTime)) {
                    $startPeriod = strtotime($group['createdAt']) < strtotime($startTime) ? strtotime($startTime) : strtotime($group['createdAt']);
                    $endPeriod = strtotime($disabledAt);
                    $diffDays = round(($endPeriod - $startPeriod)/86400);
                    if ($diffDays > 0) {
                        $deliveryAreas[$group['id']] = $diffDays;
                    }
                }
            }
        } while($remaining > 0);
        return $deliveryAreas;
    }

    public function configurePrerequisites($prerequisites) {
        foreach ($prerequisites as &$prerequisite) {
            switch($prerequisite['name']) {
                case 'GOOGLE_MAP_API_KEY':
                    $organizationId = $this->organization->id;
                    $resp = \ZopNow\Arya\Utility\MicroService::callService(
                        "config-service", 
                        "/config/website", 
                        "GET", 
                        ['organizationId' => $organizationId]
                    );
                    $googleMapsApiKey = json_decode($resp["body"], true)["data"]["website"]["googleApisKey"];
                    $prerequisite['isConfigured'] = true;
                    if (empty($googleMapsApiKey)) {
                        $prerequisite['isConfigured'] = false;
                    }
            }
        }

        return $prerequisites;
    }
}
