<?php

namespace ZopNow\CustomerService\Model;

class Address extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'customer_id', 'client_address_id','customer'];
    protected $appends = ['clientId'];
    protected $casts = ['meta_data' => 'array'];

    public function customer()
    {
        return $this->belongsTo("\ZopNow\CustomerService\Model\Customer");
    }

    public static function getAddressFromClientAddressId($organizationId, $clientAddressId)
    {
        return Address::where(['client_address_id' => $clientAddressId])
                ->join('customers', 'customer_id' , "customers.id")
                ->where("organization_id", "=" ,$organizationId)
                ->select("addresses.*")
                ->first();
    }

    public function getClientIdAttribute()
    {
        return $this->client_address_id;
    }

}
