<?php

use Phinx\Migration\AbstractMigration;

class UpdateDeliveryArea extends AbstractMigration
{

    public function up()
    {
        $pricing = "FREE for 2 delivery areas and ₹ 100 per month for every delivery area after that";
        $this->query("UPDATE extensions SET `pricing`='" . $pricing . "'  WHERE `slug` = 'DeliveryAreaSupport'");
    }
    
    public function down()
    {
        // not required
    }
}
