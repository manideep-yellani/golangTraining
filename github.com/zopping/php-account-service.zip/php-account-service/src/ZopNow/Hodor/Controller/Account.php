<?php

namespace ZopNow\Hodor\Controller;

/**
 * Class Account
 * @package ZopNow\Hodor\Controller
 * Supports only /GET Requests and is not exposed.
 */
class Account extends \ZopNow\Arya\Controller\ModelController
{
    protected $allowNonPaginated = true;
    
    public function get()
    {
        $id = $this->id;
        $status = $this->status;
        $data = null;
        if (!empty($id)) {
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            if (empty($status)) {
                $list->addFilter("status", "ENABLED");
            }
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }
}
