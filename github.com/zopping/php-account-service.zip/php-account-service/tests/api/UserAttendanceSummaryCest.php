<?php

class UserAttendanceSummaryCest
{

    protected static $endpoint = '/attendance-summary';

    public function getAttendanceSummaryForAnOrganization(ApiTester $I)
    {
        $memberDesignation = [
            'organization_id' => 1, 'name' => 'Tech Support', 'timing_type' => 'FIXED'
        ];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userData = [
            'name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
            'organization_id' => 1, 'designation_id' => $desigId
        ];
        $userId1 = $I->haveInDatabase('users', $userData);
        $shiftTimings = ['shift_start' => '08:00:00', 'shift_end' => '19:00:00', 'weekly_off' => 96, 'user_id' => $userId1];
        $I->haveInDatabase('user_timings', $shiftTimings);
        $attendanceData = [
            'user_id' => $userId1,
            'expected_in' => date('Y-m-d 08:00:00'),
            'expected_out' => date('Y-m-d 19:00:00'),
            'in_time' => date('Y-m-d 08:05:00'),
            'out_time' => date('Y-m-d 10:50:45'),
            'date' => date('Y-m-d'),
        ];
        $I->haveInDatabase("attendance", $attendanceData);

        $userData['name'] = "User 2";
        $userId2 = $I->haveInDatabase('users', $userData);
        $attendanceData['user_id'] = $userId2;
        $I->haveInDatabase("attendance", $attendanceData);

        $data = [
            "organizationId" => 1,
            "from" => date('Y-m-d', strtotime("-1 month")),
            "to" => date('Y-m-d')
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "attendancesummary" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $userId1]);
        $I->seeResponseContainsJson(['id' => $userId2]);
    }

    public function getAttendanceSummaryForAUser(ApiTester $I)
    {
        $memberDesignation = [
            'organization_id' => 1, 'name' => 'Tech Support', 'timing_type' => 'FIXED'
        ];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userData = [
            'name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
            'designation_id' => $desigId, 'organization_id' => 1
        ];
        $userId1 = $I->haveInDatabase('users', $userData);
        $shiftTimings = ['shift_start' => '08:00:00', 'shift_end' => '19:00:00', 'user_id' => $userId1];
        $I->haveInDatabase('user_timings', $shiftTimings);
        $attendanceData = [
            'user_id' => $userId1,
            'expected_in' => date('Y-m-d 08:00:00'),
            'expected_out' => date('Y-m-d 19:00:00'),
            'in_time' => date('Y-m-d 08:05:00'),
            'out_time' => date('Y-m-d 10:50:45'),
            'date' => date('Y-m-d'),
        ];
        $I->haveInDatabase("attendance", $attendanceData);

        $userData['name'] = "User 2";
        $userId2 = $I->haveInDatabase('users', $userData);
        $attendanceData['user_id'] = $userId2;
        $I->haveInDatabase("attendance", $attendanceData);

        $data = [
            "organizationId" => 1,
            "userId" => $userId1,
            "from" => date('Y-m-d', strtotime("-1 month")),
            "to" => date('Y-m-d')
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "attendancesummary" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $userId1]);
        $I->dontSeeResponseContainsJson(['id' => $userId2]);
    }

    public function getAttendanceSummaryForInvalidDateFormat(ApiTester $I)
    {
        $data = [
            "organizationId" => 1,
            "from" => "2018-04",
            "to" => date('Y-m-d')
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: The from and to parameters must be of the format 'Y-m-d'"]
        );

        $data['from'] = date('Y-m-d');
        $data['to'] = "2018-04";
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: The from and to parameters must be of the format 'Y-m-d'"]
        );
    }

    public function getAttendanceSummaryForInvalidDateRange(ApiTester $I)
    {
        $data = [
            "organizationId" => 1,
            "from" => date('Y-m-d'),
            "to" => date('Y-m-d', strtotime("-1 day"))
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: From date is greater than to date"]
        );

        $data["from"] = date('Y-m-d', strtotime("-2 months"));
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Can view summary only for a month at a time."]
        );
    }

    public function getAttendanceSummaryForDaysBeyondCurrentDate(ApiTester $I)
    {
        $data = [
            "organizationId" => 1,
            "from" => date('Y-m-d'),
            "to" => date('Y-m-d', strtotime("+20 day"))
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Attendance cannot be fetched"
            . " for dates beyond current date"]
        );
    }

}
