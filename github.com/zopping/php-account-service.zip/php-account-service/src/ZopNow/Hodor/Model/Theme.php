<?php

namespace ZopNow\Hodor\Model;

class Theme extends \ZopNow\Arya\Model\Base
{
    protected $casts = [
        'image' => 'array'
    ];

}
