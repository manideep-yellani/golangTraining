<?php

use Phinx\Migration\AbstractMigration;

class RenamingEntityMetaDataToCustomFields extends AbstractMigration
{
    public function up()
    {
        $this->execute("UPDATE extensions set name= 'Custom Fields' where name='Entity MetaData'");
    }

    public function down()
    {
        $this->execute("UPDATE extensions set name= 'Entity MetaData' where name='Custom Fields'");
    }
}

