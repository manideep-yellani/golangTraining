<?php

require_once 'BaseCest.php';

class DeviceDeleteCest extends BaseCest
{
    protected static $endpoint = '/device';
    protected static $table = "devices";
    private static $deletedId;
    public function removeDeviceWithValidId(ApiTester $I)
    {
        $I->wantToTest("Removing device of a customer ");
        $customerId = 1;
        $organizationId = 1;
        $initial = [
            'uuid' => 'first-uuid-to-delete',
            "organization_id" => $organizationId,
            'token' => 'first-test-token-to-delete',
            'customer_id' => $customerId
        ];
        $id = self::$deletedId = $I->haveInDatabase(static::$table, $initial);
        $data = ["customer" => json_encode(['id' => $customerId]), "organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint . "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, ['id' => $id, "deleted_at" => null]);
    }

    public function removeDeviceWithoutId(ApiTester $I)
    {
        $I->wantToTest("Remove address without passing id");
        $customerId = 5;
        $organizationId = 2;
        $data = ["customer" => json_encode(['id' => $customerId]), "organizationId" => $organizationId];
        $I->sendDELETE(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please enter the id to be deleted"));
    }

    public function removeDeviceWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Delete a device with invalid id');
        $customerId = 5;
        $organizationId = 2;
        $data = ["customer" => json_encode(['id' => $customerId]), "organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint . "/abc", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Model Exception: Device with id: abc not found"));
    }

    public function deletingADeviceAgain(ApiTester $I)
    {
        $I->wantToTest("Double deletion of same device ID"); // in 1st test we have deleted this address
        $id = self::$deletedId;
        $organizationId = 1;
        $data = ["organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint . "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, ['id' => $id, "deleted_at" => null]);
        $I->seeResponseContainsJson(["message" => "Model Exception: Device with id: $id not found"]);
    }

    public function deletingAnAddressWithUuid(ApiTester $I)
    {
        $I->wantToTest("Deleting a device with uuid and organization id");
        $uuid = 'this-is-a-test-uuid-to-delete';
        $organizationId = 2;
        $initial = [
            'uuid' => $uuid,
            "organization_id" => $organizationId,
            'token' => 'test-token-to-delete'
        ];
        $I->haveInDatabase(static::$table, $initial);
        $data = [
            'uuid' => $uuid,
            "organizationId" => $organizationId
        ];
        $I->sendDELETE(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, [
            "uuid" => $uuid,
            "organization_id" => $organizationId,
            "deleted_at" => null
        ]);
    }
}