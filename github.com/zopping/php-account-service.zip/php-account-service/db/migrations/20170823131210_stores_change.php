<?php

use Phinx\Migration\AbstractMigration;

class StoresChange extends AbstractMigration
{
    /**
     * Allowing null values to be entered in name in stores table
     */
    public function change()
    {
        $store = $this->table('stores');
        $store->changeColumn('name', 'string', array('limit' => 45, 'null' => true))
              ->save();
    }
}