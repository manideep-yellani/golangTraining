<?php

use Phinx\Migration\AbstractMigration;

class AddAttendance extends AbstractMigration
{

    public function up()
    {
        $this->table("attendance")
            ->addColumn("user_id","integer")
            ->addColumn("expected_in", "timestamp", array('null' => true))
            ->addColumn("expected_out", "timestamp", array('null' => true))
            ->addColumn("in_time", "timestamp", array('null' => true))
            ->addColumn("out_time", "timestamp", array('null' => true))
            ->addColumn('date', 'date', array('null' => false))
            ->addColumn('created_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addIndex(['date'])
            ->addForeignKey('user_id', 'users', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->create();
    }

    public function down()
    {
        $this->dropTable("attendance");
    }

}
