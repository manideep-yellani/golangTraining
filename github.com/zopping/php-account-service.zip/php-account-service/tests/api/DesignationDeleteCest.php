<?php

class DesignationDeleteCest
{
    protected static $endpoint = '/designation';
    protected static $table = "designations";

    public function deleteDesignationWithoutOrganizationId(ApiTester $I)
    {
        $I->sendDELETE(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message" =>
                "Validation Exception: Missing Required Field - designation : organization Id"]
        );
    }

    public function deleteDesignation(ApiTester $I)
    {
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Manager', 'organization_id' => 1]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array("message" => "Designation deleted successfully"));
    }

    public function deleteDesignationOfDifferentOrganization(ApiTester $I)
    {
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Manager', 'organization_id' => 2]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Model Exception: Designation with id: $id not found"]
        );
    }

    public function deleteDesignationWithoutId(ApiTester $I)
    {
        $I->wantTo('Delete a designation without passing id');
        $I->sendDELETE(static::$endpoint, ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Missing Required Field - designation : id"]
        );
    }

    public function deleteOrganizationWhichIsDeleted(ApiTester $I)
    {
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Manager', 'organization_id' => 1]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseContainsJson(
            ["message" => "Model Exception: Designation with id: $id not found"]
        );
    }

    public function deleteDesignationWhichUsersAreMappedTo(ApiTester $I)
    {
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Manager', 'organization_id' => 1]
        );
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $id]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Designation cannot be deleted"
                . " as there are users mapped to it"]
        );
    }
}
