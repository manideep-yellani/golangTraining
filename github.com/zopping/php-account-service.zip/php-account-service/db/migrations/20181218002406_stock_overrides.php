<?php

use Phinx\Migration\AbstractMigration;

class StockOverrides extends AbstractMigration
{
    public function up() {
        $endpoints = [
            [
                'url' => 'catalogue-service/stock-override',
                'allowed_methods' => json_encode(["GET","PUT","DELETE"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('catalogue-service/stock-override')"), 'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoint_role` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('catalogue-service/stock-override')");
    }
}
