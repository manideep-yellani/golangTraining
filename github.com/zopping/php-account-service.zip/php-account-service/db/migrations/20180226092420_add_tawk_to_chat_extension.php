<?php

use Phinx\Migration\AbstractMigration;

class AddTawkToChatExtension extends AbstractMigration {

    public function up() {
        $data = [
            "name" => "Tawk.to Live Chat",
            "slug" => "TawkToLiveChat",
            "description" => "tawk.to is a 100% FREE live chat app that lets you monitor and chat with visitors on your SmartStore",
            "enable_helper_text" => "Allows you to setup a chat widget and add it to your SmartStore",
            "disable_helper_text" => "Chat widget will be removed",
            "pricing" => "FREE",
        ];
        $this->insert('extensions', $data);
    }

    public function down() {
        $this->execute('DELETE from `extensions` where `slug` = "TawkToLiveChat"');
    }

}
