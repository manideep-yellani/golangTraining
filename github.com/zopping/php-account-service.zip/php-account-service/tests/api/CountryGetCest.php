<?php

class CountryGetCest
{
    protected static $endpoint = '/country';
    protected static $table = 'countries';

    public function getCountryWithValidParams(ApiTester $I)
    {
        $I->wantTo('Get country details with valid country code as parameter');
        $I->sendGet(self::$endpoint . "?countryIsoCode=IN");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "country" => [
                    "id" => "integer",
                    "name" => "string",
                    "isoCode" => "string",
                    "defaultLang" => "array"
                ]
            )
        ));
        $I->seeResponseContainsJson(['name' => 'India', 'isoCode' => 'IN']);
    }

    public function getCountryWithoutIsoCode(ApiTester $I)
    {
        $I->wantTo('Get country details without country iso code');
        $I->sendGet(self::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Missing Required Field -'
                . ' country : country Iso Code']
        );
    }
    
    public function getCountryWithInvalidIsoCode(ApiTester $I)
    {
        $I->wantTo('Get country details with invalid country iso code');
        $I->sendGet(self::$endpoint . "?countryIsoCode=ABC");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Invalid country code ABC']
        );
    }

}
