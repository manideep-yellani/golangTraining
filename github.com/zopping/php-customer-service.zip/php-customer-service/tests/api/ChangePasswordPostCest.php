<?php

require_once('BaseCest.php');

class ChangePasswordPostCest extends BaseCest {

    protected static $endpoint = '/changePassword';
    protected static $table= 'customers';

    public function changePasswordWithDifferentNewPassword(ApiTester $I) {

        $I->wantTo("Check API with new password different than old password");
        $data = [
            "customer" => '{
                            "id": 21,
                            "name": "Saket Banerjee",
                            "image": "https://lorempixel.com/50/50/?81352",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 1,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 6,
                                    "phone": 9846544210,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 6,
                                    "email": "saket.009@yahoo.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": []
                    }',
            'oldPassword' => 'password',
            'newPassword' => 'pass'
        ];
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["status" => "SUCCESS","message" => "Password changed successfully!"]);
    }

    public function changePasswordWithCustomerId(ApiTester $I) {

        $I->wantTo("Check API with new password , for given customerId");
        $data = [
            "customerId" => 21,
            'oldPassword' => 'pass',
            'newPassword' => 'pass2'
        ];
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["status" => "SUCCESS","message" => "Password changed successfully!"]);
    }

    public function changePasswordWithIncorrectOldPassword(ApiTester $I) {

        $I->wantTo("Test API when old password is incorrect");
        $data = [
            'customer' => '{
                            "id": 1,
                            "name": "Vishal Kumar",
                            "image": "https://lorempixel.com/50/50/?69283",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 29,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 1,
                                    "phone": 9876543210,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "phone": 9876543211,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 3,
                                    "phone": 9876543212,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 3,
                                    "email": "vishal.4u@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "email": "vishal.khanna@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 1,
                                    "email": "vishal@gmail.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": [
                                {
                                    "id": 1,
                                    "address": "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                                    "landmark": "Madivala Lake",
                                    "pincode": 560076,
                                    "city": "Bangalore",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "12.9580030000000",
                                    "longitude": "77.7162120000000"
                                },
                                {
                                    "id": 4,
                                    "address": "#34, Vinayaka PG, Opposite Shakti Mall. ",
                                    "landmark": "Shakti Mall",
                                    "pincode": 500001,
                                    "city": "Hyderabad",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "17.3850000000000",
                                    "longitude": "78.4867000000000"
                                }
                            ],
                            "accessToken": "1504101604.9718zop59a6c4e4ed4248.94340370"
                    }',
            'oldPassword' => 'passwo',
            'newPassword' => 'pass'
        ];

        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Cannot change password, old password incorrect","status" => "ERROR"]);
    }

    public function changePasswordWithNewpasswordSameAsOldPassword(ApiTester $I) {

        $I->wantTo('Check API when new password is same as old password');
        $data = [
            'customer' => '{
                            "id": 1,
                            "name": "Vishal Kumar",
                            "image": "https://lorempixel.com/50/50/?69283",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 29,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 1,
                                    "phone": 9876543210,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "phone": 9876543211,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 3,
                                    "phone": 9876543212,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 3,
                                    "email": "vishal.4u@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "email": "vishal.khanna@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 1,
                                    "email": "vishal@gmail.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": [
                                {
                                    "id": 1,
                                    "address": "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                                    "landmark": "Madivala Lake",
                                    "pincode": 560076,
                                    "city": "Bangalore",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "12.9580030000000",
                                    "longitude": "77.7162120000000"
                                },
                                {
                                    "id": 4,
                                    "address": "#34, Vinayaka PG, Opposite Shakti Mall. ",
                                    "landmark": "Shakti Mall",
                                    "pincode": 500001,
                                    "city": "Hyderabad",
                                    "state": "Telangana",
                                    "countryCode": "IN",
                                    "latitude": "17.3850000000000",
                                    "longitude": "78.4867000000000"
                                }
                            ],
                            "accessToken": "1504101604.9718zop59a6c4e4ed4248.94340370"
                    }',
            'oldPassword' => 'password',
            'newPassword' => 'password'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: New password cannot be same as the old password",
            "status"=> "ERROR"]);
    }

    public function changePasswordWithMissingOldPassword(ApiTester $I) {

        $I->wantTo('Check API when old password field is missing');
        $data = [
            'customer' => '{
                            "id": 1,
                            "name": "Vishal Kumar",
                            "image": "https://lorempixel.com/50/50/?69283",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 29,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 1,
                                    "phone": 9876543210,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "phone": 9876543211,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 3,
                                    "phone": 9876543212,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 3,
                                    "email": "vishal.4u@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "email": "vishal.khanna@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 1,
                                    "email": "vishal@gmail.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": [
                                {
                                    "id": 1,
                                    "address": "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                                    "landmark": "Madivala Lake",
                                    "pincode": 560076,
                                    "city": "Bangalore",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "12.9580030000000",
                                    "longitude": "77.7162120000000"
                                },
                                {
                                    "id": 4,
                                    "address": "#34, Vinayaka PG, Opposite Shakti Mall. ",
                                    "landmark": "Shakti Mall",
                                    "pincode": 500001,
                                    "city": "Hyderabad",
                                    "state": "Telangana",
                                    "countryCode": "IN",
                                    "latitude": "17.3850000000000",
                                    "longitude": "78.4867000000000"
                                }
                            ],
                            "accessToken": "1504101604.9718zop59a6c4e4ed4248.94340370"
                    }',
            'newPassword' => 'pass'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Missing Required Field - changepassword : old Password",
            "status"=> "ERROR"]);
    }

    public function changePasswordWithMissingNewPassword(ApiTester $I) {

        $I->wantTo('Check API without providing new password field');
        $data = [
            'customer' => '{
                            "id": 1,
                            "name": "Vishal Kumar",
                            "image": "https://lorempixel.com/50/50/?69283",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 29,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 1,
                                    "phone": 9876543210,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "phone": 9876543211,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 3,
                                    "phone": 9876543212,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 3,
                                    "email": "vishal.4u@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "email": "vishal.khanna@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 1,
                                    "email": "vishal@gmail.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": [
                                {
                                    "id": 1,
                                    "address": "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                                    "landmark": "Madivala Lake",
                                    "pincode": 560076,
                                    "city": "Bangalore",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "12.9580030000000",
                                    "longitude": "77.7162120000000"
                                },
                                {
                                    "id": 4,
                                    "address": "#34, Vinayaka PG, Opposite Shakti Mall. ",
                                    "landmark": "Shakti Mall",
                                    "pincode": 500001,
                                    "city": "Hyderabad",
                                    "state": "Telangana",
                                    "countryCode": "IN",
                                    "latitude": "17.3850000000000",
                                    "longitude": "78.4867000000000"
                                }
                            ],
                            "accessToken": "1504101604.9718zop59a6c4e4ed4248.94340370"
                    }',
            'oldPassword' => 'password'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Missing Required Field - changepassword : new Password",
            "status"=> "ERROR"]);
    }

    public function changePasswordWithoutProvidingOldAndNewPassword(ApiTester $I) {

        $I->wantTo('Check API when old password and new password fields are not provided');
        $data = [
            'customer' => '{
                            "id": 1,
                            "name": "Vishal Kumar",
                            "image": "https://lorempixel.com/50/50/?69283",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 29,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 1,
                                    "phone": 9876543210,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "phone": 9876543211,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 3,
                                    "phone": 9876543212,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 3,
                                    "email": "vishal.4u@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "email": "vishal.khanna@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 1,
                                    "email": "vishal@gmail.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": [
                                {
                                    "id": 1,
                                    "address": "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                                    "landmark": "Madivala Lake",
                                    "pincode": 560076,
                                    "city": "Bangalore",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "12.9580030000000",
                                    "longitude": "77.7162120000000"
                                },
                                {
                                    "id": 4,
                                    "address": "#34, Vinayaka PG, Opposite Shakti Mall. ",
                                    "landmark": "Shakti Mall",
                                    "pincode": 500001,
                                    "city": "Hyderabad",
                                    "state": "Telangana",
                                    "countryCode": "IN",
                                    "latitude": "17.3850000000000",
                                    "longitude": "78.4867000000000"
                                }
                            ],
                            "accessToken": "1504101604.9718zop59a6c4e4ed4248.94340370"
                    }'
        ];
        $I->sendPOST(static::$endpoint,$data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Missing Required Field - changepassword : old Password",
            "status"=> "ERROR"]);
    }

    public function changePasswordWithoutId(ApiTester $I) {

        $I->wantTo('Check API when customer id is not provided');
        $data = [
            'customer' =>'{
                            "id": ,
                            "name": "Vishal Kumar",
                            "image": "https://lorempixel.com/50/50/?69283",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 29,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 1,
                                    "phone": 9876543210,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "phone": 9876543211,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 3,
                                    "phone": 9876543212,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 3,
                                    "email": "vishal.4u@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "email": "vishal.khanna@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 1,
                                    "email": "vishal@gmail.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": [
                                {
                                    "id": 1,
                                    "address": "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                                    "landmark": "Madivala Lake",
                                    "pincode": 560076,
                                    "city": "Bangalore",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "12.9580030000000",
                                    "longitude": "77.7162120000000"
                                },
                                {
                                    "id": 4,
                                    "address": "#34, Vinayaka PG, Opposite Shakti Mall. ",
                                    "landmark": "Shakti Mall",
                                    "pincode": 500001,
                                    "city": "Hyderabad",
                                    "state": "Telangana",
                                    "countryCode": "IN",
                                    "latitude": "17.3850000000000",
                                    "longitude": "78.4867000000000"
                                }
                            ],
                            "accessToken": "1504101604.9718zop59a6c4e4ed4248.94340370"
                    }',
            'oldPassword' => 'password',
            'newPassword' => 'pass'
            ];
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Please pass a valid Customer object or customerId",
            "status"=> "ERROR"]);
    }

    public function changePasswordWithAbsentUserId(ApiTester $I) {

        $I->wantTo('Check API when user id provided is not in the database');
        $data = [
           'customer' => '{
                            "id": 200,
                            "name": "Vishal Kumar",
                            "image": "https://lorempixel.com/50/50/?69283",
                            "joinedOn": "2017-08-30 19:26:45",
                            "totalOrders": 29,
                            "lastOrderedOn": "2017-08-30 19:29:51",
                            "phones": [
                                {
                                    "id": 1,
                                    "phone": 9876543210,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "phone": 9876543211,
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 3,
                                    "phone": 9876543212,
                                    "status": "VERIFIED"
                                }
                            ],
                            "emails": [
                                {
                                    "id": 3,
                                    "email": "vishal.4u@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 2,
                                    "email": "vishal.khanna@gmail.com",
                                    "status": "VERIFIED"
                                },
                                {
                                    "id": 1,
                                    "email": "vishal@gmail.com",
                                    "status": "VERIFIED"
                                }
                            ],
                            "addresses": [
                                {
                                    "id": 1,
                                    "address": "#452, 3rd Cross, 31st Main, BTM layout 2nd stage",
                                    "landmark": "Madivala Lake",
                                    "pincode": 560076,
                                    "city": "Bangalore",
                                    "state": "Karnataka",
                                    "countryCode": "IN",
                                    "latitude": "12.9580030000000",
                                    "longitude": "77.7162120000000"
                                },
                                {
                                    "id": 4,
                                    "address": "#34, Vinayaka PG, Opposite Shakti Mall. ",
                                    "landmark": "Shakti Mall",
                                    "pincode": 500001,
                                    "city": "Hyderabad",
                                    "state": "Telangana",
                                    "countryCode": "IN",
                                    "latitude": "17.3850000000000",
                                    "longitude": "78.4867000000000"
                                }
                            ],
                            "accessToken": "1504101604.9718zop59a6c4e4ed4248.94340370"
                    }',
            'oldPassword' => 'password',
            'newPassword' => 'pass'
            ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Model Exception: Customer with id: 200 not found",
            "status"=> "ERROR"]);
    }
}