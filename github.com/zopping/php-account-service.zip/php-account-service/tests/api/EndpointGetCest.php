<?php

/**
 * Class consists of the test cases for the get API in endpoint
 * which the API should handle
 */

class EndpointGetCest extends BaseCest
{
    protected static $endpoint = '/endpoint';
    protected static $table = 'endpoints';

    public function listEndpoints(ApiTester $I)
    {
        $I->wantTo('Get list of endpoints');
        parent::getAll($I);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "endpoint" => "array"
            )
        ));
    }

    public function listEndpointsInvalidPage(ApiTester $I)
    {
        //Get the list of endpoints for page number out of range
        $I->wantTo('Get list of endpoints for page number out of range');
        $I->sendGET(self::$endpoint . "?page=50000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "endpoint" => "array"
            )
        ));
        $I->seeResponseContainsJson(array('data' => ['endpoint' => []]));
    }

    public function listEndpointsValidUrl(ApiTester $I)
    {
        //Sending an valid url as a filter and checking if the required data is returned
        $I->wantTo('Get list of endpoints with valid url filter');
        $I->sendGET(self::$endpoint . "?url=catalogue-service/brand");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "endpoint" => "array"
            )
        ));
        $I->seeResponseContainsJson(['data' => ['endpoint' => array("url" => "catalogue-service/brand")]]);
    }

    public function listEndpointsInvalidUrl(ApiTester $I)
    {
        //Sending an invalid url to check if the API returns an error response
        $I->wantTo('Get list of endpoints with invalid url filter');
        $I->sendGET(self::$endpoint . "?url=abc");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "endpoint" => "array"
            )
        ));
        $I->seeResponseContainsJson(array('data' => ['endpoint' => []]));
    }

    public function getEndpoint(ApiTester $I)
    {
        $I->wantTo('Get details of a endpoint with a valid id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['url' => 'catalogue-service/brand']);
        parent::getSingle($I, $id);
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => "array"
        ));
        $I->seeResponseContainsJson(['id' => $id, 'url' => 'catalogue-service/brand']);
    }

    public function getEndpointInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of a endpoint with invalid id');
        $I->sendGET(self::$endpoint . "/1000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Endpoint with id: 1000 not found'));
    }

    public function getEndpointUrlId(ApiTester $I)
    {
        //Sending a url with a valid id. The url filter will not be applied
        $I->wantTo('Get details of a endpoint with a valid id and a url');
        $id = $I->grabFromDatabase(self::$table, 'id', ['url' => 'catalogue-service/brand']);
        $I->sendGET(self::$endpoint . "/$id?url=catalogue-service/product");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('id' => $id, 'url' => 'catalogue-service/brand'));
        $I->dontSeeResponseContainsJson(array('url' => 'catalogue-service/product'));
    }

    public function getEndpointKeyInvalidId(ApiTester $I)
    {
        //Sending a key with a invalid id. The key filter will not be applied
        $I->wantTo('Get details of a endpoint with a invalid id and a key');
        $I->sendGET(self::$endpoint . "/configId?url=product");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Endpoint with id: configId not found'));
        $I->dontSeeResponseContainsJson(array('key' => 'order_properties'));
    }
}

