<?php

namespace ZopNow\CustomerService\Controller;

class Verify extends \ZopNow\Arya\Controller\Base
{
    public function get()
    {
        $data = $this->getRequestParams(array("hash"));
        $customerController = new Customer($data);
        $customerController->verifyEmail();
        $response = array(
            'status' => 'SUCCESS',
            'message' => 'Email verified!',
        );
        return (new \ZopNow\Arya\View\Base($response));
    }
}


