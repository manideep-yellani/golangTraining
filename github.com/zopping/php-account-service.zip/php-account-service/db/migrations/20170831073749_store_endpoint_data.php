<?php

use Phinx\Migration\AbstractMigration;

class StoreEndpointData extends AbstractMigration
{
    /**
      * Give permission to store get api
      */
    public function change()
    {
        $row = $this->fetchRow("SELECT `id` FROM developers where token = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'");
        $developerId = $row['id'];
        $endpointIds = array(1,2,3,5,9);
        foreach ($endpointIds as $endpointId) {
            $data[] = array(
                "endpoint_id" => $endpointId,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            );
        }
        $this->insert('endpoint_developer_permissions', $data);
    }
}