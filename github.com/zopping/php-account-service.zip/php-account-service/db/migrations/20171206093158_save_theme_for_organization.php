<?php

use Phinx\Migration\AbstractMigration;

class SaveThemeForOrganization extends AbstractMigration
{
    public function up()
    {
        $this->table("organizations")
            ->addColumn("theme_id", "integer", ["limit" => 11, "after" => "domain", "null" => true])
            ->addForeignKey("theme_id", "themes", "id", ["constraint" => "fk_organizations_themes", 'delete' => 'NO_ACTION', 'update' => 'NO_ACTION'])
            ->save();
        
    }

    public function down()
    {
        $this->table("organizations")
            ->dropForeignKey("theme_id")
            ->removeColumn("theme_id")
            ->save();
    }
}
