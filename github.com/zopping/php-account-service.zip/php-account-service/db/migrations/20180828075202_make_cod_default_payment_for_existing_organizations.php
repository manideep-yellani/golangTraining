<?php

use Phinx\Migration\AbstractMigration;

class MakeCodDefaultPaymentForExistingOrganizations extends AbstractMigration
{

    public function change()
    {
        $organizationIds = array_column( $this->fetchAll('select id from organizations'), 'id');
        $existingOrganizationsWithPaymentMethodsSet = array_column($this->fetchAll('select organization_id from `configurations`'
                . ' where `key` like "%order.paymentMethods%";'), 'organization_id');
        $remainingOrdIds = array_diff($organizationIds, $existingOrganizationsWithPaymentMethodsSet);
        foreach ( $remainingOrdIds as $organizationId){
            $configurations[] = ["organization_id" => $organizationId,
                                 "key" => 'order.paymentMethods',
                                 "value" => '["COD"]'];
        }
        $this->table('configurations')
                ->insert($configurations)
                ->save();
    }
}
