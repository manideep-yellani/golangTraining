#!/bin/bash
mkdir -p /var/log/zopnow;
chmod -R 777 /var/log/zopnow;