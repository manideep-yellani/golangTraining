<?php

namespace ZopNow\Hodor\Helper;

class Password
{

    public static function generate()
    {
        return random_int(1234556, 99999999);
    }
}
