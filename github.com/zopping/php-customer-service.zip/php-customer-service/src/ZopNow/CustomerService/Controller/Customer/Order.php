<?php

namespace ZopNow\CustomerService\Controller\Customer;

class Order extends \ZopNow\Arya\Controller\ModelController
{

    /**
    * Method to fetch list of orders for a customer
    */
    public function get()
    {
        if (empty($this->data['id'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid ID");
        }
        $data = $this->getRequestParams(['organizationId'], ['page', 'perPage', 'orderType']);
        $page = 1;
        if(!empty($this->data['page'])){
            $page = intval($this->data['page']);
        }
        $orderRequestData = [
            "organizationId" => $this->organizationId,
            "customerId" => $this->id,
            "exclude" => "true",
            "page" => $page
        ];
        if(!empty($this->data['perPage'])){
            $orderRequestData["perPage"] = intval($this->data['perPage']);
        }
        if (!empty($this->data['referenceNumber'])) {
            $orderRequestData['referenceNumber'] = $this->data['referenceNumber'];
        }
        if (!empty($this->data['orderType'])) {
            $orderRequestData['orderType'] = $this->data['orderType'];
        }
        if(!empty($this->data['paymentStatus'])){
            $orderRequestData['paymentStatus'] = $this->data['paymentStatus'];
        }
        $orderObj = \ZopNow\Arya\Utility\MicroService::callService("order-service", "/order", 'GET', $orderRequestData);
        $response = [];
        if ($orderObj['statusCode'] == 200) {
            $orderData = json_decode($orderObj['body'], true);
            $response = $orderData['data'];
        } else {
            throw new \ZopNow\Arya\Exception\AppException(\ZopNow\Arya\Utility\MicroService::SERVICE_UNAVAILABLE);
        }
        return (new \ZopNow\Arya\View\Base([
                'status' => "SUCCESS",
                'message' => 'OK',
                'data' => $response
            ])
        );
    }
}