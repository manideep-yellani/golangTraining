<?php

namespace ZopNow\Hodor\Model;

/**
 * Class consists of the relationships which Store model will have with the other models
 * and other related methods
 */

class Store extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'organization_id', 'pivot'];
    protected $casts = ['meta_data' => 'array'];
    public function exists($organizationId, $name)
    {
        $store = Store::where([['organization_id', $organizationId], ['name', $name]])->first();
        if (!is_null($store)) {
            if (!is_null($this->id) && $store->id == $this->id) {
                return false;
            }
            return true;
        }
        return false;
    }

    public static function getDefaultStoreIdForOrganization($organizationId)
    {
        $id = null;
        $store = Store::where(['organization_id' => $organizationId])
                ->orderBy('id')->first();
        if (!is_null($store)) {
            $id = $store->id;
        }
        return $id;
    }

    public function getPhoneAttribute($value) {
        return '+'.$value;
    }
}
