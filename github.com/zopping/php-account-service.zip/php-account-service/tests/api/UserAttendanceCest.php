<?php

class UserAttendanceCest
{

    protected static $endpoint = '/attendance';
/*
    public function checkInAUser(ApiTester $I)
    {
        $I->wantTo("Check in a user");
        $data = [
            'organizationId' => 1,
            'userId' => '1'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' => 'array'
           )
        );
    }
*/
    public function checkInAUserWithNoShifts(ApiTester $I)
    {
        $I->wantTo("Check in a user");
        $data = [
            'organizationId' => 1,
            'userId' => '2'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }
/*
    public function checkOutAUser(ApiTester $I)
    {
        $I->wantTo("Check out a user");
        $data = [
            'organizationId' => 1,
            'userId' => '1',
            'id' => 1
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }

    public function checkOutAUserWhoHasAlreadyCheckedOut(ApiTester $I)
    {
        $I->wantTo("Check out a user who has already checked out");
        $data = [
            'organizationId' => 1,
            'userId' => '1',
            'id' => 1
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
    }
*/
    public function getAttendanceList(ApiTester $I)
    {
        $I->wantTo("Get attendance list of a particular user");
        $I->sendGET(static::$endpoint, ['userId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' => 'array'
           )
        );
    }
}
