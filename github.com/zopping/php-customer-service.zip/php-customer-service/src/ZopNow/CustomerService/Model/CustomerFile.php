<?php

namespace ZopNow\CustomerService\Model;

class CustomerFile extends \ZopNow\Arya\Model\Base
{
    protected $hidden = ['updated_at', 'deleted_at', "pivot"];

}
