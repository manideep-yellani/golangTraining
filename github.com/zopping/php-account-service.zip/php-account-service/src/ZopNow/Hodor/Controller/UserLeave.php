<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Utility\Validator;

class UserLeave extends \ZopNow\Arya\Controller\ModelController
{

    const ALLOWED_TYPES = ['EARNED', 'SICK', 'PATERNITY', 'MATERNITY', 'HALFDAY'];
    const LEAVES_URL = ZOPSMART_ADMIN . "/user/team-leaves";

    protected static $filterableFields = [
        'organization_id', 'user_id', 'from_date', 'to_date', 'type', 'status',
        'designation_id', 'from', 'to' //these filters have been added to fetch the leave summary
    ];
    protected $allowNonPaginated = true;

    public function get()
    {
        $params = $this->getRequestParams(['organizationId'], ['leaveType', 'from', 'to']);
        if (!empty($this->data['id'])) {
            $data = $this->getDetails();
        } else {
            if (!empty($params['leaveType'])) {
                $this->addAdditionalFilters($params['leaveType']);
            }
            if ((!empty($params['from']) && empty($params['to']))
                || (!empty($params['to']) && empty($params['from']))
            ) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Both from and to fields must be passed to get leaves for a range"
                );
            }
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    private function addAdditionalFilters($leaveType)
    {
        if ($leaveType == 'PENDING') {
            $status = ["PENDING", "CANCELLATION_PENDING"];
        } elseif ($leaveType == 'APPROVED_CANCELLABLE') {
            $status = ["APPROVED"];
            $this->data['toDate'] = ">=".date('Y-m-d');
        }
        $userIds = $this->getTeamMembers();
        $this->data['status'] = $status;
        $this->data['userId'] = $userIds;
    }

    private function getTeamMembers()
    {
        $params = $this->getRequestParams(['organizationId', 'user']);
        $userJson = json_decode($params['user'], true);
        $userId = $userJson['id'];
        $requestParams = ['id' => $userId, 'organizationId' => $params['organizationId'], 'paginated' => false];
        $userController = new User($requestParams);
        $teamMembers = $userController->getTeamMembers();
        return array_column($teamMembers, 'id');
    }

    public function post()
    {
        $mandatoryFields = array("organizationId", "user", "fromDate", "toDate", "reason", "type");
        $data = $this->getRequestParams($mandatoryFields);
        $userJson = json_decode($data['user'], true);
        $data['userId'] = $userJson['id'];
        $this->validateFields($data);
        $response = $this->add($data);
        $this->sendEmailToManagers($response['userleave'], $userJson);
        return (new \ZopNow\Arya\View\Base([
            'code' => 200,
            "status" => "SUCCESS",
            "data" => $response
        ]));
    }

    private function validateFields($data)
    {
        if (!empty($data['fromDate']) && !Validator::isDate($data['fromDate'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid from date");
        }
        if (!empty($data['toDate']) && !Validator::isDate($data['toDate'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid to date");
        }
        $fromDate = strtotime($data['fromDate']);
        $toDate = strtotime($data['toDate']);
        if ($fromDate > $toDate) {
            throw new \ZopNow\Arya\Exception\ValidationException("From date is greater than to date");
        }
        if ($data['type'] == 'HALFDAY' && $data['fromDate'] != $data['toDate']) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid date range for half-day leave.");
        }

        /**
         * Validate if leave exists already for the given date range
         */
        $list = $this->modelClass::getList();
        $list->addFilter('user_id', $data['userId']);
        $list->addFilter('status', ['PENDING', 'APPROVED']);
        $list->paginated = false;
        $currentLeaves = $this->getListData($list)['userleave'];
        foreach($currentLeaves as $leave) {
            if($leave['fromDate'] <= $data['toDate'] && $leave['toDate'] >= $data['fromDate']) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "A leave application for the same date range is already available"
                    . " for this user"
                );
            }
        }
        if (!empty($data['type']) && !Validator::isEnum($data['type'], self::ALLOWED_TYPES)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid value for type");
        }
    }

    private function sendEmailToManagers($leaveDetails, $loggedInUser)
    {
        $managerDesignationId = $loggedInUser['designation']['manager']['id'];
        if (empty($managerDesignationId)) {
            return;
        }
        $requestParams = [
            'organizationId' => $this->organizationId,
            'designationId' => $managerDesignationId
        ];
        $userController = new User($requestParams);
        $userResponse = $userController->get()->getData();
        if ($userResponse['data']['count'] > 0) {
            $users = $userResponse['data']['user'];
            $emails = [];
            foreach ($users as $user) {
                $emails[] = $user['emails'][0]['email'];
            }

            $emailData = [];
            $emailData['to'] = implode(',', $emails);
            $emailData['type'] = "client/leaveRequest";
            $emailData['data'] = [
                "name" => $loggedInUser['name'],
                "fromDate" => $leaveDetails['fromDate'],
                "toDate" => $leaveDetails['toDate'],
                "type" => $leaveDetails['type'],
                "reason" => $leaveDetails['reason'],
                "leavesUrl" => self::LEAVES_URL
            ];
            $emailData['transactional'] = true;
            \ZopNow\Arya\Utility\MicroService::callService("communication-service", "/email", 'POST', $emailData);
        }
    }

    public function put()
    {
        $id = $this->id;
        if (empty($id)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid id");
        }
        $optionalFields = ['status', 'fromDate', 'toDate', 'reason', 'type'];
        $data = $this->getRequestParams(['organizationId', 'id'], $optionalFields);

        $leaveDetails = [];
        if (!empty($data['status'])) {
            switch ($data['status']) {
                case 'CANCELLED':
                    $leaveDetails = $this->cancelLeave();
                    break;
                case 'APPROVED':
                    $leaveDetails = $this->approveLeave();
                    break;
                case 'REJECTED':
                    $leaveDetails = $this->rejectLeave();
                    break;
                default:
                    throw new \ZopNow\Arya\Exception\ValidationException(
                        "Invalid value for status"
                    );
            }
        } else {
            $fromDate = strtotime($this->model->from_date);
            $today = strtotime(date('Y-m-d'));
            if ($today >= $fromDate || $this->model->status != 'PENDING') {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Cannot edit the details of an ongoing or old leave"
                );
            }
            $leaveDetails = $this->edit($data);
        }
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $leaveDetails
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    private function cancelLeave()
    {
        $data = $this->getRequestParams(['user', 'id']);
        $userJson = json_decode($data['user'], true);
        $userId = $userJson['id'];
        if ($userId != $this->model->user_id) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Cannot cancel the leave since it was applied by a different user"
            );
        }
        $currentStatus = $this->model->status;
        if ($currentStatus != 'PENDING' && $currentStatus != 'APPROVED') {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Only pending or approved leaves can be cancelled"
            );
        }
        $updatedData = ['id' => $data['id']];
        $fromDate = strtotime($this->model->from_date);
        $toDate = strtotime($this->model->to_date);
        $today = strtotime(date('Y-m-d'));
        if ($currentStatus == 'PENDING' || $today < $fromDate) {
            $updatedData['status'] = 'CANCELLED';
        } else if($today >= $fromDate && $today <= $toDate) {
            $curDate = date('Y-m-d');
            $leaveDetails = $this->getDetails()['userleave'];
            if ($fromDate == $today ) {
                if ($currentStatus == 'APPROVED') {
                    $updatedData['status'] = 'CANCELLATION_PENDING';
                    $updatedData['toDate'] = $curDate;
                }
            } else {
                $newToDate = strtotime('- 1 day',$today);
                $updatedData['toDate'] = date('Y-m-d',$newToDate);
                $curDateData = array(
                    'fromDate' => $curDate,
                    'toDate' => $curDate,
                    'reason' => $leaveDetails['reason'],
                    'type' => $leaveDetails['type'],
                    'userId' => $userId,
                    'status' => 'CANCELLATION_PENDING'
                );
                $this->addNewLeave($curDateData);
            }
            if($toDate > $today) {
                $newFromDate = strtotime('+ 1 day',$today);
                $newData =  array(
                    'fromDate' => date('Y-m-d',$newFromDate),
                    'toDate' => date('Y-m-d',$toDate),
                    'reason' => $leaveDetails['reason'],
                    'type' => $leaveDetails['type'],
                    'userId' => $userId,
                    'applied_on' => $leaveDetails['appliedOn'],
                    'status' => $currentStatus
                );
                $this->addNewLeave($newData);
            }
        } else if ($today > $toDate) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Cannot cancel your leave after the leave date."
            );
        }
        $updatedLeave = $this->edit($updatedData);
        return $updatedLeave;
    }

    private function addNewLeave($data)
    {
        $leaveController = new UserLeave();
        $leaveController->add($data);
    }

    private function approveLeave()
    {
        return $this->manageTeamLeave('approve', ["PENDING", "CANCELLATION_PENDING"]);
    }

    private function rejectLeave()
    {
        return $this->manageTeamLeave('reject', ["PENDING", "APPROVED", "CANCELLATION_PENDING"]);
    }

    private function manageTeamLeave($functionality, $statusChecks)
    {
        $data = $this->getRequestParams(['user', 'id']);
        $userJson = json_decode($data['user'], true);
        $userId = $userJson['id'];
        $requestData = ['id' => $userId, 'organizationId' => $this->organizationId];
        $userController = new User($requestData);
        $userDetails = $userController->get()->getData()['data']['user'];
        if ($userId == $this->model->user_id
            || !$this->userHasPermission($userDetails['designation']['id'])
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "You are not entitled to $functionality this leave."
            );
        }
        $currentStatus = $this->model->status;
        if (!in_array($currentStatus, $statusChecks)) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Cannot $functionality leave of $currentStatus status."
            );
        }
        if ($functionality == "approve") {
            if($currentStatus == 'CANCELLATION_PENDING'){
                $newStatus = 'CANCELLED';
            } else {
                $newStatus = 'APPROVED';
            }
        } else {
            if($currentStatus == 'CANCELLATION_PENDING'){
                $newStatus = 'APPROVED';
            } else {
                $newStatus = 'REJECTED';
            }
        }
        $updatedData = [
            'id' => $data['id'],
            'status' => $newStatus
        ];
        $updatedLeave = $this->edit($updatedData);
        $this->sendEmailToUser($updatedLeave['userleave'], $userJson['name']);
        return $updatedLeave;
    }

    private function userHasPermission($currentUserDesignation)
    {
        $requestData = ['id' => $this->model->user_id, 'organizationId' => $this->organizationId];
        $userController = new User($requestData);
        $userDetails = $userController->get()->getData()['data']['user'];
        $allowedDesignationIds = [];
        $designation = $userDetails['designation'];
        while (!empty($designation['manager'])) {
            $managerDesignationId = $designation['manager']['id'];
            $allowedDesignationIds[] = $managerDesignationId;
            $designation = $designation['manager'];
        };
        if (in_array($currentUserDesignation, $allowedDesignationIds)) {
            return true;
        }
        return false;
    }

    private function sendEmailToUser($leaveDetails, $loggedInUserName)
    {
        $emailData = [];
        $emailData['to'] = $leaveDetails['user']['emails'][0]['email'];
        $emailData['type'] = "client/leaveApproval";
        $emailData['data'] = [
            "username" => $leaveDetails['user']['name'],
            "fromDate" => $leaveDetails['fromDate'],
            "toDate" => $leaveDetails['toDate'],
            "type" => $leaveDetails['type'],
            "reason" => $leaveDetails['reason'],
            "status" => ucfirst(strtolower($leaveDetails['status'])),
            "managerName" => $loggedInUserName,
        ];
        $emailData['transactional'] = true;
        \ZopNow\Arya\Utility\MicroService::callService("communication-service", "/email", 'POST', $emailData);
    }
}
