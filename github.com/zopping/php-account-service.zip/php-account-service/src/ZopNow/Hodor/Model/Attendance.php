<?php

namespace ZopNow\Hodor\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class Attendance extends \ZopNow\Arya\Model\Base
{
    use SoftDeletes;
    
    protected $table = 'attendance';
    protected $hidden = ['updated_at', 'deleted_at'];

    public function getLastActiveAttendanceForUser($userId)
    {
        return Attendance::where('user_id', $userId)
                ->orderBy('updated_at', 'desc')
                ->first();
    }

    public static function getListItems(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        if ($list->paginated) {
            $data->limit($list->getPerPage())->skip($list->getOffset());
        }
        return $data->select('attendance.*')->orderBy("attendance." . $list->getSortField(), $list->getSortOrder())->get();
    }

    public static function getListItemsCount(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        return $data->count();
    }

    private static function getQueryBuilder(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::query();
        $filters = $list->getFilters();
        $filterKeys = array_column($filters, 0);
        $storeKey = array_search('store_id', $filterKeys);
        if ($storeKey !== false) {
            $data->join('store_user', 'attendance.user_id', 'store_user.user_id')
                ->where("store_user.store_id", "=" ,$filters[$storeKey][1]);
            unset($filters[$storeKey]);
        }
        $orgKey = array_search('organization_id', $filterKeys);
        if ($orgKey !== false) {
            $data->join('users', 'attendance.user_id', 'users.id')
                ->where("users.organization_id", "=" ,$filters[$orgKey][1]);
            unset($filters[$orgKey]);
        }
        $userKey = array_search('user_id', $filterKeys);
        if ($userKey !== false) {
            $data->where("attendance.user_id", '=', $filters[$userKey][1]);
            unset($filters[$userKey]);
        }
        $data = self::addFilterQuery($data, $filters);
        return $data;
    }

    public static function getLastCheckedInForUser($user)
    {
        $query = "select user_id, max(in_time) as last_check_in_time from attendance ";
        if (is_array($user)) {
            $users = array_map("\ZopNow\Arya\DB\MySql::escape", $user);
            $query .= " where user_id in (" . implode(",", $users) . ")";
        } else {
            $query .= " where user_id = " . \ZopNow\Arya\DB\MySql::escape($user);
        }
        $query .= " group by user_id";
        $data = \ZopNow\Arya\DB\MySql::select($query);
        return array_column($data, 'last_check_in_time', 'user_id');
    }

}
