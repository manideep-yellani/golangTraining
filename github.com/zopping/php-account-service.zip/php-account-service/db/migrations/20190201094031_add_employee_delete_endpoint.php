<?php

use Phinx\Migration\AbstractMigration;

class AddEmployeeDeleteEndpoint extends AbstractMigration
{
    public function up() {
        $this->execute("update endpoints set allowed_methods = '[\"GET\",\"POST\",\"PUT\",\"DELETE\"]' where url = 'account-service/employee'");
    }

       
    public function down() {
       $this->execute("update endpoints set allowed_methods = '[\"GET\",\"POST\",\"PUT\"]' where url = 'account-service/employee'");
    }
}
