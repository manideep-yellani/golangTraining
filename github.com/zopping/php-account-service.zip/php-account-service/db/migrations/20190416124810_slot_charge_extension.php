<?php

use Phinx\Migration\AbstractMigration;

class SlotChargeExtension extends AbstractMigration
{
    public function up()
    {
        $data = [
            "name" => "Slot Charges",
            "slug" => "SlotCharges",
            "description" => "Allow support for slot based surcharges, discounts."
        ];
        $this->insert('extensions',$data);
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'SlotCharges'")['id'];
        $this->query("DELETE from extension_organization where extension_id='$extensionId'");
    }
    
}
