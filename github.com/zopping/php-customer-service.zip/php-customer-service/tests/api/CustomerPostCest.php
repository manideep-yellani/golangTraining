<?php 
require_once('BaseCest.php');

class CustomerPostCest extends BaseCest
{
    protected static $endpoint = '/customer';
    protected static $table    = "customers";

    private function testData(ApiTester $I, $data, $isGuest, $existingName = null)
    {
        try {
            $I->sendPost(self::$endpoint, $data);
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $I->seeResponseIsJson();
            $customerId = $I->grabDataFromResponseByJsonPath('$.data.customer.id')[0];
            $name = $existingName ?? $data['name'];
            $I->seeInDatabase(self::$table, ["id" => $customerId, "name" => $name, "image" => $data['image'] ?? null,
                "organization_id" => $data['organizationId']]);
            if (!empty($data['email'])) {
                $I->seeInDatabase("emails", ["customer_id" => $customerId, "email" => $data['email'], "deleted_at" => null]);
            }
            if (!empty($data['phone'])) {
                $I->seeInDatabase("phones", ["customer_id" => $customerId, "phone" => $data['phone'], "deleted_at" => null]);
            }
            if (!empty($data['address'])) {
                $I->seeInDatabase("addresses", ["customer_id" => $customerId, "address" => $data['address'],
                    "landmark" => $data['landmark'], "pincode" => $data['pincode'], "city" => $data['city'], 'state' => $data['state'], 'countryCode' => $data['countryCode'],
                    "deleted_at" => null, "latitude" => $data['latitude'] ?? null, "longitude"=> $data['longitude'] ?? null]);
            }
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }
/*
    public function createCustomerWithValidData(ApiTester $I)
    {
        $I->wantToTest("Creating customers with valid data");
        $data = array(
            "name" => "Heena Sb",
            "organizationId" => 1,
            "phone" => "+918877666645",
            "email" => "heena.sabha7@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        );
        $this->testData($I, $data, 0);
    }

*/
    public function creatingNonGuestCustomerWithExistingEmailInOrganization(ApiTester $I)
    {
        $I->wantToTest("Creating Non Guest Customer with existing Email in same organization");
        $data = array(
            "name" => "Vishal",
            "organizationId" => 1,
            "phone" => "+919965776629",
            "email" => "vishal@gmail.com",
            "address" => "Bommanahalli",
            "landmark" => "Oxford College",
            "pincode" => 560076,
            "city" => "Bangalore",
            "state" => "Karnataka",
            "countryCode" => "IN"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => "Validation Exception: Email already exists"]);
    }
/*
    public function creatingNonGuestCustomerWithExistingEmailInDiffOrg(ApiTester $I)
    {
        $I->wantToTest("Creating Non Guest Customer with exixsting Email in different organization");
        $data = array(
            "name" => "Vishal",
            "organizationId" => 4,
            "phone" => "+919965776629",
            "email" => "vishal@gmail.com",
            "address" => "Bommanahalli",
            "landmark" => "Oxford College",
            "pincode" => 560076,
            "city" => "Bangalore",
        );
        $this->testData($I, $data, 0);
    }
*/
    public function creatingNonGuestCustomerWithExistingPhone(ApiTester $I)
    {
        $I->wantToTest("Creating Non Guest Customer with existing phone in same organization");
        $data = array(
            "name" => "Vishal",
            "organizationId" => 1,
            "phone" => "+919876543210",
            "email" => "vishalsrivastava@gmail.com",
            "address" => "Bommanahalli",
            "landmark" => "Oxford College",
            "pincode" => 560076,
            "city" => "Bangalore",
            "state" => "Karnataka",
            "countryCode" => "IN"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => "Validation Exception: Phone already exists"]);
    }

/*
    public function createCustomerWithImage(ApiTester $I)
    {
        $I->wantToTest("Creating customers with image");
        $data = array(
            "name" => "Salman",
            "organizationId" => 1,
            "phone" => "+919965776629",
            "email" => "salman@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Mumbai",
            "image" => "http://media1.santabanta.com/full1/Indian%20%20Celebrities(M)/Salman%20Khan/salman-khan-39a.jpg"
        );
        $this->testData($I, $data, 0);
    }
*/
    public function createCustomerWithInvalidEmail(ApiTester $I)
    {
        $I->wantToTest("Create customer with invalid email");
        $data = array(
            "name" => "Rishabh Raj",
            "organizationId" => 1,
            "phone" => "+918876543210",
            "email" => "rishabh",
            "address" => "talwandi f phase",
            "landmark" => "Gandhi murti",
            "pincode" => 560076,
            "city" => "Kota",
            "state" => "Rajasthan",
            "countryCode" => "IN",
        );
        try {
            $I->sendPOST(self::$endpoint, $data);
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
            $I->seeResponseContainsJson(['message' => "Validation Exception: Invalid Email"]);
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function createCustomerWithInvalidPhone(ApiTester $I)
    {
        $I->wantToTest("Create customer with invalid Phone");
        $data = array(
            "name" => "Amrit Raj",
            "organizationId" => 1,
            "phone" => "8776543a",
            "email" => "amrit@yahoo.com",
            "address" => "talwandi f phase",
            "landmark" => "Gandhi murti",
            "pincode" => 560076,
            "city" => "Kota",
            "state" =>  "Rajasthan",
            "countryCode" => "IN",
        );
        try {
            $I->sendPOST(self::$endpoint, $data);
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
            $I->seeResponseContainsJson(['message' => "Validation Exception: Invalid Phone"]);
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }
/*
    public function createCustomerWithLatLong(ApiTester $I)
    {
        $I->wantToTest("Creating customers with Latitude longitude");
        $data = array(
            "name" => "Srikanth Prabhu",
            "organizationId" => 1,
            "phone" => "+919988775555",
            "email" => "srikanthPrabhu@gmail.com",
            "address" => "#24, BSK 3rd stage",
            "landmark" => "Jyoti temple",
            "pincode" => "560085",
            "city" => "Bangalore",
            "latitude" => 12.8329137232310,
            "longitude" => 77.2947508931600
        );
        $this->testData($I, $data, 0);
    }
  */
    public function createCustomerWithoutOrganizationId(ApiTester $I)
    {
        $I->wantToTest("Creating customers without organization Id");
        $data = array(
            "name" => "Heena Sb",
            "phone" => "+9199887766664",
            "email" => "heena.sabha6@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad",
            "state" => "Gujarat",
            "countryCode" => "IN",
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => "Validation Exception: Missing Required Field - customer : organization Id"]);
    }
/*
    public function createOfflineCustomer(ApiTester $I)
    {
        $I->wantToTest("Creating offline customer with valid data");
        $data = array(
            "name" => "Neha",
            "organizationId" => 1,
            "phone" => "+918877646589",
            "email" => "neha@gmail.com",
            "clientId" => 101,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 0);
    }

    public function createOfflineCustomerWithoutPhone(ApiTester $I)
    {
        $I->wantToTest("Creating offline customer with valid data without phone");
        $data = array(
            "name" => "Neha",
            "organizationId" => 1,
            "email" => "neha12@gmail.com",
            "clientId" => 105,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 0);
    }

    public function createOfflineCustomerWithoutEmail(ApiTester $I)
    {
        $I->wantToTest("Creating offline customer with valid data without email");
        $data = array(
            "name" => "Neha",
            "organizationId" => 1,
            "phone" => "+919846342786",
            "clientId" => 107,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 0);
    }

    public function createOfflineCustomerWithoutPhoneAndEmail(ApiTester $I)
    {
        $I->wantToTest("Creating offline customer without phone and email");
        $data = array(
            "name" => "Salman",
            "organizationId" => 1,
            "clientId" => 108,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 0);
    }
*/
}
