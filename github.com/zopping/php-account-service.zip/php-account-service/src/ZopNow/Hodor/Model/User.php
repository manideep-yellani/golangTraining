<?php

namespace ZopNow\Hodor\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class consists of the relationships which user model will have with the other models
 * and other related methods
 */

class User extends \ZopNow\Arya\Model\Base
{
    protected $hidden = ['updated_at', 'deleted_at', 'password', 'organization_id', 'lang_iso_code', 'designation_id'];
    protected $with = array('phones', 'emails', 'lang', 'stores', 'designation');
     

    protected $casts = [
        'verified' => 'boolean'
    ];
    use SoftDeletes;

    public static function getUserFromLogin($username, $params = [])
    {
        $user = null;
        if (!empty ($params['organizationId'])) {
            if (\ZopNow\Hodor\Helper\Validator::isEmail($username)) {
               $user = Email::getUserFromEmail($username);
               if (!empty($user) && $user->organization_id != $params['organizationId']) {
                   $user = null;
               }
            }
            else {
            $user = User::where("name", $username)->where("organization_id", $params['organizationId'])->first();
            }
        } elseif (\ZopNow\Hodor\Helper\Validator::isPhone($username)) {
            $user = Phone::getUserFromPhone($username);
        } elseif (\ZopNow\Hodor\Helper\Validator::isEmail($username)) {
            $user = Email::getUserFromEmail($username);
        }
        if (empty($user)) {
            throw new \ZopNow\Arya\Exception\AuthException("Invalid Credentials");
        }
        return $user;
    }

    public function phones()
    {
        return $this->hasMany("\ZopNow\Hodor\Model\Phone", 'user_id');
    }

    public function emails()
    {
        return $this->hasMany("\ZopNow\Hodor\Model\Email", 'user_id');
    }

    /**
     * Get the organization for the user.
     */
    public function organization()
    {
        return $this->belongsTo('ZopNow\Hodor\Model\Organization');
    }

    public function endpoints()
    {
        return $this->belongsToMany("\ZopNow\Hodor\Model\Endpoint", "endpoint_user_permissions")
                ->withPivot('has_permission', 'method', 'id');
    }

    public function designation()
    {
        return $this->belongsTo('ZopNow\Hodor\Model\Designation');
    }

    public function hasPermission($api, $method)
    {  
        if ($this->organization_id==1){
            return true;
        }
        $endpointModel = Endpoint::where(['url' => $api])->first();
        
        $allowedMethods = !empty($endpointModel) ? $endpointModel->allowed_methods : [];
        if (empty($endpointModel) || !in_array($method, $allowedMethods)) {
            throw new \ZopNow\Arya\Exception\ModelException("Invalid Endpoint");
        }
        
        
       if ($this->organization->status=='DISABLED' && $endpointModel->allow_from_inactive_account==0){
          return false;
        }
       
        if(!is_null($endpointModel->extension) && ($endpointModel->extension->status($this->organization->id) == 'DISABLED')){
            return false;
        }
        if ($this->organization->is_enterprise == 1 && $endpointModel->allow_enterprise_access == 0) {
            return false;
        }
        if ($this->is_owner) {
            return true;
        }
        // If the user is mapped to any role then check if the role has the associated permission
        $roles = $this->roles()->get();
        
        foreach ($roles as $role) {
            $count = $role->endpoints()->where(["url" => $api, "method" => $method])->count();
            if ($count > 0) {
                return true;
            }
        }
        $endpointId =$endpointModel->toArray()['id'];
        $endpoint = $this->endpoints()
                ->where(["endpoint_id" => $endpointId, "method" => $method])
                ->first();
        if (!is_null($endpoint)) {
            $userDetails = $endpoint->pivot;
            return $userDetails['has_permission'];
        }
        return false;
    }

    public function hasPermissionToStore($storeId) {
        if ($this->organization_id == 1) {
            return true;
        }
        if ($this->is_owner) {
            $userStores = $this->organization()->first()->stores()->get()->toArray();
        } else {
            $userStores = $this->stores()->get()->toArray();
        }
        $userStoreIds = array_column($userStores, 'id');
        if (!in_array($storeId, $userStoreIds)) {
            return FALSE;
        }
        return TRUE;
    }

    public function lang()
    {
        return $this->belongsTo('ZopNow\Hodor\Model\Lang', 'lang_iso_code', 'iso_code');
    }

    /**
     * This function checks if there is an entry in the endpoint_user_permissions table,
     * for the given user, endpoint and method.
     * If it does not exist, the function returns false.
     * If it exists, then the has_permission field is updated and it returns true.
     */
    public function updatePermissionIfExists($endpointId, $method, $permission)
    {
        $endpoint = $this->endpoints()
                ->where(["endpoint_id" => $endpointId, "method" => $method])
                ->first();
        if (is_null($endpoint)) {
            return false;
        }
        $pivotId = $endpoint->pivot->id;
        $this->endpoints()->newPivotStatement()->where('id', $pivotId)
            ->update(['has_permission' => $permission]);
        return true;
    }

    public function getPermissions()
    {
        $organizationExtensions = $this->organization->extension->toArray();
        $extensionIds = !empty($organizationExtensions) ?
                array_column($organizationExtensions, 'id') : [];
        /**
         * Fetching the endpoints that are mapped to the enabled extensions and
         * which are not linked to any extension.
         */
        if ($this->is_owner) {
            $endpointModel = Endpoint::whereNull('extension_id');
            if (!empty($extensionIds)) {
                $endpointModel->orWhereIn('extension_id', $extensionIds);
            }
        } else {
            $endpointModel = $this->endpoints();
            if (!empty($extensionIds)) {
                $endpointModel->where(function ($query) use ($extensionIds) {
                    $query->whereNull('extension_id')
                        ->orWhereIn('extension_id', $extensionIds);
                });
            } else {
                $endpointModel->whereNull('extension_id');
            }
        }
        $endpoints = $endpointModel->get();
        if ($this->is_owner) {
            foreach ($endpoints as $endpoint) {
                $endpoint->allowed_methods =
                    array_fill_keys($endpoint->allowed_methods, true);
            }
            return ['userEndpointPermissions' => $endpoints->toArray(), 'roleEndpointPermissions' => []];
        } else {
            $endpointData = $roleEndpointData = [];
            $roles = $this->roles()->get();
            foreach ($roles as $role) {
                if (!empty($extensionIds)) {
                    $roleEndpoints = $role->endpoints()->orWhereIn('extension_id', $extensionIds)
                            ->whereNull('extension_id');
                } else {
                    $roleEndpoints = $role->endpoints()->whereNull('extension_id');
                }
                $roleMappedEndpoints = $roleEndpoints->get();
                foreach ($roleMappedEndpoints as $endpoint) {
                    if (empty($roleEndpointData[$endpoint->id])) {
                        $roleEndpointData[$endpoint->id] = $endpoint->toArray();
                        unset($roleEndpointData[$endpoint->id]['allowedMethods']);
                    }
                    $roleEndpointData[$endpoint->id]['allowedMethods'][$endpoint->pivot->method] = true;
                }
            }
            foreach ($endpoints as $endpoint) {
                $roleEndpointMethods = !empty($roleEndpointData[$endpoint->id]) ? array_keys($roleEndpointData[$endpoint->id]['allowedMethods']) :[];
                if (empty($endpointData[$endpoint->id])) {
                    $endpoint->allowed_methods =
                        array_fill_keys(array_diff($endpoint->allowed_methods, $roleEndpointMethods), false);
                    $endpointData[$endpoint->id] = $endpoint->toArray();
                }
                if (in_array($endpoint->pivot->method, $roleEndpointMethods)) {
                    continue;
                }
                $permission = $endpoint->pivot->has_permission;
                settype($permission, 'boolean');
                $endpointData[$endpoint->id]['allowedMethods'][$endpoint->pivot->method]
                        = $permission;
            }
            return ['userEndpointPermissions' => $endpointData, 'roleEndpointPermissions' => $roleEndpointData];
        }
    }

    public function roles()
    {
        return $this->belongsToMany("\ZopNow\Hodor\Model\Role");
    }

    public static function getListItems(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        if ($list->paginated) {
            $data->limit($list->getPerPage())->skip($list->getOffset());
        }
        return $data->select('users.*')->orderBy("users." . $list->getSortField(), $list->getSortOrder())->get();
    }

    public static function getListItemsCount(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        return $data->count();
    }

    private static function getQueryBuilder(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::query();
        $filters = $list->getFilters();
        $filterKeys = array_column($filters, 0);
        $roleKey = array_search('role_id', $filterKeys);
        if ($roleKey !== false) {
            $data->join('role_user', 'role_user.user_id' , 'users.id')
                ->where("role_id", "=" ,$filters[$roleKey][1]);
            unset($filters[$roleKey]);
        }
        $storeKey = array_search('store_id', $filterKeys);
        if ($storeKey !== false) {
            $data->join('store_user', 'store_user.user_id' , 'users.id')
                ->where("store_id", "=" ,$filters[$storeKey][1]);
            unset($filters[$storeKey]);
        }
        $timingTypeKey = array_search('timing_type', $filterKeys);
        if ($timingTypeKey !== false) {
            $data->join('designations', 'designations.id' , 'users.designation_id')
                ->where("timing_type", "=", $filters[$timingTypeKey][1]);
            unset($filters[$timingTypeKey]);
        }
        $organizationIdKey = array_search('organization_id', $filterKeys);
        if ($organizationIdKey !== false) {
            $data->where("users.organization_id", "=", $filters[$organizationIdKey][1]);
            unset($filters[$organizationIdKey]);
        }
        $data = self::addFilterQuery($data, $filters);
        return $data;
    }

    public function stores()
    {
        return $this->belongsToMany("\ZopNow\Hodor\Model\Store");
    }

    public function addShiftDetails($weeklyOff, $shiftStart, $shiftEnd)
    {
        \ZopNow\Hodor\Model\UserTiming::insert(['user_id' => $this->id, 'shift_start' => $shiftStart, 'shift_end' => $shiftEnd, 'weekly_off' => $weeklyOff]);
    }

    public function getWeeklyOffAttribute($weeklyOff)
    {
        $index = 6;
        $days = array("Sunday", "Saturday", "Friday", "Thursday", "Wednesday", "Tuesday", "Monday");
        while ($weeklyOff || $index>=0 ) {
            if (!($weeklyOff & 1)) {
                unset($days[$index]);
            }
            --$index;
            $weeklyOff = $weeklyOff >> 1;
        }
        return array_reverse(array_values($days));
    }

    public function getShiftDetails($date)
    {
        $nextDate = date('Y-m-d', strtotime("+1 day", strtotime($date)));
        $userTiming = UserTiming::where([['user_id', $this->id], ['updated_at', '<=', $nextDate]])
                ->orderBy('updated_at', 'desc')
                ->first();
        $shiftDetails = ['shiftStart' => null, 'shiftEnd' => null, 'weeklyOff' => []];
        if (!empty($userTiming)) {
            $details = $userTiming->toArray();
            $shiftDetails['shiftStart'] = $details['shiftStart'];
            $shiftDetails['shiftEnd'] = $details['shiftEnd'];
            $shiftDetails['weeklyOff'] = !empty($details['weeklyOff'])? $this->getWeeklyOffAttribute($details['weeklyOff']) : [];
        }
        return $shiftDetails;
    }

}
