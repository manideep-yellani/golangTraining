<?php

namespace ZopNow\Hodor\Controller;

class Country extends \ZopNow\Arya\Controller\ModelController
{

    public function get()
    {
        $data = $this->getRequestParams(['countryIsoCode']);
        $this->model = $this->modelClass::getCountryFromIsoCode($data['countryIsoCode']);
        if (empty($this->model)) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Invalid country code " . $data['countryIsoCode']
            );
        }
        $this->data['id'] = $this->model->id;
        $details = $this->getDetails();
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $details,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }
}