<?php

/**
 * Class consists of all the test cases which API should handle during user signup
 */
class UserPostCest
{

    protected static $endpoint = '/user';
    protected static $table = 'users';

  /*
    public function validData(ApiTester $I)
    {
        $I->wantTo('Check the API when the user data are valid');
        $data = ['name' => 'test', 'phone' => '+919764578907', 'email' => 'test@zopnow.com', 'isOwner' => 1];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'data' => [
                "user" =>
                array(
                    'id' => 'integer',
                    'name' => 'string',
                    'isOwner' => 'integer',
                    'phones' => 'array',
                    'emails' => 'array',
                ),
            ]
        ));
        $id = $I->grabDataFromResponseByJsonPath('$.data.user.id')[0];
        $I->seeInDatabase(static::$table, ['name' => 'test', 'is_owner' => 1]);
        $I->seeInDatabase("phones", ["user_id" => $id, "phone" => '+919764578907']);
        $I->seeInDatabase("emails", ["user_id" => $id, 'email' => 'test@zopnow.com']);
    }
  */

    public function missingParameterName(ApiTester $I)
    {
        $I->wantTo('Check the API when name is missing');
        $data = ['phone' => '+919999999999', 'email' => 'test@zopnow.com', 'organizationId' => '19'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - user : name'));
    }
//
//    public function missingParameterPhone(ApiTester $I)
//    {
//        $I->wantTo('Check the API when phone is missing');
//        $data = ['name' => 'test', 'email' => 'test@zopnow.com'];
//        $I->sendPOST(static::$endpoint, $data);
//        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
//        $I->seeResponseIsJson();
//        $I->seeResponseContainsJson(array('status' => 'ERROR'));
//        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - user : phone'));
//    }
//
//    public function missingParameterEmail(ApiTester $I)
//    {
//        $I->wantTo('Check the API when email is missing');
//        $data = ['name' => 'test', 'phone' => '+918764578999'];
//        $I->sendPOST(static::$endpoint, $data);
//        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
//        $I->seeResponseIsJson();
//        $I->seeResponseContainsJson(array('status' => 'ERROR'));
//        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - user : email'));
//    }

    public function invalidPhone(ApiTester $I)
    {
        $I->wantTo('Check the API when incorrect phone is passed');
        $data = ['name' => 'test', 'phone' => '9999', 'email' => 'test@zopnow.com'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Incorrect Phone number'));
    }

    public function invalidEmail(ApiTester $I)
    {
        $I->wantTo('Check the API when incorrect email is passed');
        $data = ['name' => 'test', 'phone' => '+919754399009', 'email' => 'zopnow123.com'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Incorrect Email'));
    }
/*
    public function phoneExists(ApiTester $I)
    {
        $I->wantTo("Check the API when a phone already registered is passed");
        $data = ['name' => 'test', 'phone' => '+919764578907', 'email' => 'test@zopnow.com'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: This phone number is already registered'));
    }
*/
    public function emailExists(ApiTester $I)
    {
        $I->wantTo("Check the API when an email already registered is passed");
        $data = ['name' => 'test', 'phone' => '+919812346989', 'email' => 'admin@zopnow.com'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: This email is already registered'));
    }
/*
    public function validDataWithLanguage(ApiTester $I)
    {
        $I->wantTo('Add new user with valid data and valid language code');
        $data = [
            'name' => 'test',
            'phone' => '+919764578901',
            'email' => 'test@gmail.com',
            'langIsoCode' => 'hi',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'data' => [
                "user" =>
                array(
                    'id' => 'integer',
                    'name' => 'string',
                    'isOwner' => 'integer',
                    'phones' => 'array',
                    'emails' => 'array',
                ),
            ]
        ));
        $id = $I->grabDataFromResponseByJsonPath('$.data.user.id')[0];
        $I->seeInDatabase(static::$table, ['name' => 'test', 'is_owner' => 1]);
        $I->seeInDatabase("phones", ["user_id" => $id, "phone" => '+919764578901']);
        $I->seeInDatabase("emails", ["user_id" => $id, 'email' => 'test@gmail.com']);
    }

    public function invalidLanguageCode(ApiTester $I)
    {
        $I->wantTo('Add new user with invalid language code');
        $data = [
            'name' => 'test',
            'phone' => '+919764578900',
            'email' => 'testing@zopnow.com',
            'langIsoCode' => 'abc',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid Language'));
    }

    public function addUserWithImage(ApiTester $I)
    {
        $I->wantTo("Add a new user with valid image url");
        $data = [
            'name' => 'test',
            'phone' => '+919764571920',
            'email' => 'testing@gmail.com',
            'imageUrl' => 'https://lorempixel.com/50/50/?89419',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'data' => [
                "user" =>
                array(
                    'id' => 'integer',
                    'name' => 'string',
                    'isOwner' => 'integer',
                    'phones' => 'array',
                    'emails' => 'array',
                    'imageUrl' => 'string|null'
                ),
            ]
        ));
        $I->seeResponseContainsJson(['imageUrl' => 'https://lorempixel.com/50/50/?89419']);
    }

    public function addUserWithInvalidImageUrl(ApiTester $I)
    {
        $I->wantTo("Add a new user with invalid value for image url");
        $data = [
            'name' => 'test',
            'phone' => '+919764578920',
            'email' => 'sample@gmail.com',
            'imageUrl' => ':50',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => "Validation Exception: Invalid value for 'imageUrl'")
        );
    }
*/
}
