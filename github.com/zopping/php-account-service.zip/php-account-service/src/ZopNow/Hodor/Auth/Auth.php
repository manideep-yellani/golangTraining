<?php

namespace ZopNow\Hodor\Auth;

/**
 * Description of Auth
 */
class Auth extends \ZopNow\Arya\Auth\Auth
{

    const LONG_TERM_TOKEN_TTL = 31536000;
    const SHORT_TERM_TOKEN_TTL = 1800;
    const AUTH_MODEL_NAME = '\ZopNow\Hodor\Model\User';

    public static function getToken($username, $password, $remember = false, $organizationId = NULL)
    {
        $ttl = $remember ? self::LONG_TERM_TOKEN_TTL : self::SHORT_TERM_TOKEN_TTL;
        $params = !empty($organizationId) ? ["organizationId" => $organizationId] : [];
        $token = self::login($username, $password, self::AUTH_MODEL_NAME, $params,$ttl);
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $redis->setex("remember:user:".self::$id, $ttl, $remember);
        return $token;
    }

    public static function validateToken($guid, $api, $method, $storeId = NULL)
    {
        $user = self::who($guid);
        if (is_null($user)) {
            throw new \ZopNow\Arya\Exception\AuthException("Unauthorized");
        }
        if ($user->hasPermission($api, $method) == false) {
            throw new \ZopNow\Arya\Exception\ForbiddenException("Forbidden");
        }
        if (!empty($storeId) && $user->hasPermissionToStore($storeId) == FALSE) {
            throw new \ZopNow\Arya\Exception\ForbiddenException("Forbidden");
        }
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $remember = $redis->get("remember:user:".$user->id);
        self::$loginTtl = $remember ? self::LONG_TERM_TOKEN_TTL : self::SHORT_TERM_TOKEN_TTL;        
        self::renewGuid($guid);
        return $user;
    }

    public static function logout($guid, $logoutFromAll = false)
    {
        $user = parent::who($guid);
        if (!is_null($user)) {
            // unsetting remember-choice of user
            \ZopNow\Arya\Cache\CacheManager::delete("remember:customer:".$user->id);
        }
        parent::logout($guid);
        if ($logoutFromAll) {
            //Delete all guid cache keys mapped to the user
            $table = $user->getTable();
            $id = $user->id;
            $redis = \ZopNow\Arya\DB\Redis::getInstance();
            $allGuids = $redis->smembers("auth:$table:$id");
            foreach ($allGuids as $guid) {
                \ZopNow\Arya\Cache\CacheManager::delete("auth:guid:$guid");
                \ZopNow\Arya\Cache\CacheManager::delete("auth:guid:$guid:model");
            }
            \ZopNow\Arya\Cache\CacheManager::delete("auth:$table:$id");
        }
    }

}
