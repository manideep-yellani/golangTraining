<?php

use Phinx\Migration\AbstractMigration;

class ProductRankingEndpoint extends AbstractMigration
{
    public function up() {
        $endpoints = [
            [
                'url' => 'catalogue-service/product-ranking',
                'allowed_methods' => json_encode(["GET", "POST","PUT","DELETE"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('catalogue-service/product-ranking')"), 'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoint_role` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('catalogue-service/product-ranking')");
    }

}
