<?php

use Phinx\Migration\AbstractMigration;

class AddCustomerTagUploadEndpoint extends AbstractMigration
{
    public function change()
    {
	$this->execute('insert into endpoints(url,allowed_methods)values("customer-service/customer-tag-file","[\"POST\"]")');
    }
}
