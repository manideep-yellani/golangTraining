<?php

use Phinx\Migration\AbstractMigration;

class AddDeliveryAreaDeleteEndpoint extends AbstractMigration
{
    public function up()
    {
	$this->execute("update endpoints set allowed_methods='[\"GET\",\"POST\",\"PUT\",\"DELETE\"]' where url='logistics-service/delivery-area'");
    }

   public function down()
    {
	$this->execute("update endpoints set allowed_methods='[\"GET\",\"POST\",\"PUT\"]' where url='logistics-service/delivery-area'");
	}
}
