<?php

use Phinx\Migration\AbstractMigration;

class UpdatePricingOfLogisticsSupport extends AbstractMigration
{

    public function up()
    {
        $pricing = "1% of the transaction processed";
        $pricingRule = json_encode(['TYPE' => 'MONTHLY', 'RATE' => 'PERCENT', 'COST' => 1]);
        $this->query("UPDATE extensions SET `pricing`='" . $pricing . "',`pricing_rule`='" . $pricingRule. "'  WHERE `slug` = 'LogisticsSupport'");
    }

    public function down() 
    {
        $this->query("UPDATE extensions SET `pricing`= null, `pricing_rule`= null  WHERE `slug` = 'LogisticsSupport'");
    }
}
