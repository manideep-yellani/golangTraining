<?php

use Phinx\Migration\AbstractMigration;

class SupportForPickupTypeGuest extends AbstractMigration
{
    /**
     * For guest address data cant be mandatory. For customers which places
     * Pickup type of orders, their address data wont be required.
     */
    public function change()
    {
        $this->table("guests")
            ->changeColumn('address', 'string', array('limit' => 500, "null" => true))
            ->changeColumn('landmark', 'string', array('limit' => 500, "null" => true))
            ->changeColumn('pincode', 'integer', array('limit' => 6, "null" => true))
            ->changeColumn('city', 'string', array('limit' => 200, "null" => true))
            ->save();
    }
}
