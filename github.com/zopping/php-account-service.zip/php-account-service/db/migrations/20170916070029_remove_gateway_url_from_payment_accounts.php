<?php


use Phinx\Migration\AbstractMigration;

class RemoveGatewayUrlFromPaymentAccounts extends AbstractMigration
{

    public function change()
    {
        $paymentAccounts = $this->table("payment_accounts");
        $paymentAccounts->removeColumn('pay_url')
                        ->removeColumn("verify_url")
                        ->removeColumn("refund_url")
                        ->removeColumn("refund_enquiry_url")
                        ->save();
    }
}
