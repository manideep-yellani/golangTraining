<?php

use Phinx\Migration\AbstractMigration;

class Countries extends AbstractMigration
{
    /**
     * Database schema for "countries" table
     * It consists of the following fields :
     * name : stores the name of the country
     * iso_code : stores the iso code of the country
     * default_lang_id : stores the id of the default language for the country
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     *
     */
    public function change()
    {
        $country = $this->table('countries');
        $country->addColumn('name', 'string', array('limit' => 200))
                ->addColumn('iso_code', 'string', array('limit' => 2))
                ->addColumn("default_lang_id", 'integer', ['limit' => 11])
                ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addIndex(array('name'), array('unique' => true))
                ->addIndex(array('iso_code'), array('unique' => true))
                ->addForeignKey('default_lang_id', 'languages', 'id')
                ->create();
    }
}
