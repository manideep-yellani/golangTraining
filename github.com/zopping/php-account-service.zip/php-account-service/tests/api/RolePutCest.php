<?php

class RolePutCest
{
    protected static $endpoint = '/role';
    protected static $table = 'roles';

    public function editRoleWithoutRequiredData(ApiTester $I)
    {
        //Without organization id
        $data = [
            "name" => "Intern"
        ];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - role : organization Id",
        ));
        //Without id
        $data = [
            "organizationId" => 1,
            "name" => "Intern"
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - role : id",
        ));
        //Without name
        $data = [
            "organizationId" => 1,
        ];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - role : name",
        ));
    }

    public function editGlobalRole(ApiTester $I)
    {
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'PICKER']);
        $data = [
            "organizationId" => 1,
            "name" => "Agent"
        ];
        $I->sendPUT(static::$endpoint . "/$id", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Global roles cannot be edited",
        ));
    }

    public function editRoleWithExistingName(ApiTester $I)
    {
        $id = $I->haveInDatabase(self::$table, ['name' => 'CS Manager', 'organization_id' => 1]);
        $data = [
            "organizationId" => 1,
            "name" => "Delivery Agent"
        ];
        $I->sendPUT(static::$endpoint . "/$id", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Role with name 'Delivery Agent' already exists",
        ));
    }

    public function editRoleWithValidData(ApiTester $I)
    {
        $id = $I->haveInDatabase(self::$table, ['name' => 'Agent', 'organization_id' => 1]);
        $data = [
            "organizationId" => 1,
            "name" => "Assisstant Agent"
        ];
        $I->sendPUT(static::$endpoint . "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "role" => array(
                    "id" => "integer",
                    "name" => "string"
                )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'Assisstant Agent']);
    }

}
