<?php

require_once 'BaseCest.php';

class AddAddressCest extends BaseCest
{
    protected static $endpoint = '/address';
    protected static $table    = "addresses";

    public function addAddressWithCustomerObj(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId = $I->grabDataFromResponseByJsonPath('$.data.address.id')[0];
        $I->seeInDatabase(self::$table, ["id" => $phoneId, "customer_id" => $customerId, 
            "landmark" => $data['landmark'], "address" => $data['address'],
            "pincode" => $data['pincode'], "city" => $data['city'], "state" => $data['state'],"countryCode" =>$data['countryCode'] ,"deleted_at" => null]);
    }

    public function addAddressWithCustomerId(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customerId" => $customerId,
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId = $I->grabDataFromResponseByJsonPath('$.data.address.id')[0];
        $I->seeInDatabase(self::$table, ["id" => $phoneId, "customer_id" => $customerId,
            "landmark" => $data['landmark'], "address" => $data['address'],
            "pincode" => $data['pincode'], "city" => $data['city'],"state" => $data['state'], "countryCode" => $data['countryCode'], "deleted_at" => null]);
    }

    public function addAddressWithoutCustomer(ApiTester $I)
    {
        $organizationId = 1;
        $data = [
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Please pass a valid Customer object or customerId"));
    }

    public function addAddressWithoutOrganizationId(ApiTester $I)
    {
        $customerId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Missing Required Field - address : organization Id"));
    }

    public function addAddressWithInvalidLatitude(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN",
            "latitude" => 95.8329137232310,
            "longitude" => 13.2947508931600
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Invalid latitude"));
    }


    public function addAddressWithInvalidCustomerId(ApiTester $I)
    {
        $customerId = "xyz";
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array("message"=>"Model Exception: Customer with id $customerId and organization_id $organizationId not found"));
    }

    public function addAddressWithCustomerIdOfOtherOrganization(ApiTester $I)
    {
        $customerId = 5; //belongs to organization_id=2
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array("message"=>"Model Exception: Customer with id $customerId and organization_id $organizationId not found"));
    }

    public function addEmptyAddress(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "address" => "",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Missing Required Field - address : address"));
    }

    public function addEmptyLandmark(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "",
            "pincode" => 560076,
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' =>
            array(
                'address' =>
                array(
                    "id" => 'integer',
                    'address' => 'string',
                    'landmark' => 'string|null',
                    'pincode' => 'integer|null',
                    'city' => 'string',
                    'state' => 'string|null',
                    'countryCode' => 'string',
                    'latitude' => 'string|null',
                    'longitude' => 'string|null',
                ),
            ),
        ));
    }

    public function addInvalidPincode(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "School",
            "pincode" => "56007634a",
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Invalid Pincode"));
    }

    public function addAddressWithoutPincodeAndLandmark(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customerId" => $customerId,
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' =>
            array(
                'address' =>
                array(
                    "id" => 'integer',
                    'address' => 'string',
                    'landmark' => 'string|null', 
                    'pincode' => 'integer|null',
                    'city' => 'string',
                    'state' => 'string|null',
                    'countryCode' => 'string',
                    'latitude' => 'string|null',
                    'longitude' => 'string|null',
                ),
            ),
        ));
    }

    public function addAddressWithClientId(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customerId" => $customerId,
            "organizationId" => $organizationId,
            "address" => "#45, 3rd cross, 31st Main, BTM layout 2nd stage",
            "city" => "Bengaluru",
            "state" => "Karnataka",
            "countryCode" => "IN",
            "pincode" => 560076,
            "clientId" => 1001
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' =>
            array(
                'address' =>
                array(
                    "id" => 'integer',
                    'address' => 'string',
                    'landmark' => 'string|null',
                    'pincode' => 'integer|null',
                    'city' => 'string',
                    'state' => 'string|null',
                    'countryCode' => 'string',
                    'latitude' => 'string|null',
                    'longitude' => 'string|null',
                    'clientId' => 'string|null'
                ),
            ),
        ));
        $I->seeResponseContainsJson(
            ["address" => [
                "address" => "#45, 3rd cross, 31st Main, BTM layout 2nd stage",
                "city" => "Bengaluru",
                "state" => "Karnataka",
                "countryCode" => "IN",
                "pincode" => 560076,
                "clientId" => 1001]
            ]
        );
    }

}
