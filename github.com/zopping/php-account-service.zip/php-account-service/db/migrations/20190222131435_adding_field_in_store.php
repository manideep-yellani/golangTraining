<?php

use Phinx\Migration\AbstractMigration;

class AddingFieldInStore extends AbstractMigration
{
    public function up()
    {
        $this->table("stores")
            ->addColumn('has_delivery_hub', 'boolean', array('default' => false))
            ->addColumn('has_click_collect', 'boolean', array('default' => false))
            ->addColumn('has_picking', 'boolean', array('default' => false))
            ->addColumn('picking_store_id', 'integer', array('null' => true, 'limit' => 11))
            ->addColumn('business_hours', 'json', array('null' => true))
            ->addForeignKey('picking_store_id', 'stores', 'id', array('delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->save();
    }

    public function down()
    {
        $this->table('stores')
            ->removeColumn('has_delivery_hub')
            ->removeColumn('has_click_collect')
            ->removeColumn('has_picking')
            ->removeColumn('business_hours')
            ->dropForeignKey('picking_store_id')
            ->removeColumn('picking_store_id')
            ->save();
    }

}
