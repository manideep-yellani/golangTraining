<?php

use Phinx\Migration\AbstractMigration;

class RoleApi extends AbstractMigration
{

    public function up() {
       $roleEndpoints=$this->getMap();
       $roles =array();
       $urls = [];
       $roleName = array_keys($roleEndpoints);
       foreach ($roleEndpoints as $key => $value) {
       	  array_push($roles,["name" => $key]);
       	  $urls = array_merge($urls, array_keys($value));
       }
       $this->insert('roles',$roles);
       $roleIds = $this->fetchAll("select id,name from roles where name in  ('" . implode("','", $roleName) . "')");
       $endpointResponse = $this->fetchAll("select id,url from endpoints where url in  ('" . implode("','", $urls) . "')");
       $endpointIds = array_column($endpointResponse, 'id', 'url');
       foreach ($roleIds as $row) {
       	$key = $row['name'];
       	$roleId = $row['id'];
       	$endpoints = $roleEndpoints[$key];
       	foreach ($endpoints as $key => $methods) {
       		$endpointId = $endpointIds[$key];
       		$query = array();
       		foreach ($methods as $method) {
       			array_push($query, ["endpoint_id" => $endpointId,"role_id"=>$roleId,"method"=>$method]);
       		}
       		$this->insert('endpoint_role',$query);
       	}
       }
    }

    public function down() {
       $roleEndpoints=$this->getMap();
       $urls = [];
       $roleName = array_keys($roleEndpoints);
       foreach ($roleEndpoints as $key => $value) {
       	  $urls = array_merge($urls, array_keys($value));
       }
       $roleResponse = $this->fetchAll("select id,name from roles where name in  ('" . implode("','", $roleName) . "')");
       $endpointResponse = $this->fetchAll("select id,url from endpoints where url in  ('" . implode("','", $urls) . "')");
       $roleIds=array_column($roleResponse,'id');
       $endpointIds = array_column($endpointResponse, 'id', 'url');
        foreach ($roleResponse as $row) {
       	$key = $row['name'];
       	$roleId = $row['id'];
       	$endpoints = $roleEndpoints[$key];
       	foreach ($endpoints as $key => $methods) {
       		$endpointId = $endpointIds[$key];
       		$this->execute("DELETE FROM `endpoint_role` WHERE endpoint_id='$endpointId' AND role_id='$roleId' AND method IN ('" . implode("','", $methods) . "')");
       		}
    	}
    $this->execute("DELETE FROM `roles` WHERE id IN ('" . implode("','", $roleIds) . "')");
}

    private function getMap(){

		$roleEndpoints = [
       		"CONTENT MANAGER" => [
       			"catalogue-service/category" => ["GET", "PUT", "POST", "DELETE"],
       			"catalogue-service/brand" => ["GET", "PUT", "POST", "DELETE"],
       			"catalogue-service/tag" => ["GET", "PUT", "POST", "DELETE"],
       			"catalogue-service/product" => ["GET", "PUT", "POST", "DELETE"],
       			"catalogue-service/stats" => ["GET"],
       			"catalogue-service/sales" => ["GET"],
       			"account-service/store" => ["GET"],

       		],
       		"CONTENT WRITER" => [
       			"catalogue-service/category" => ["GET"],
       			"catalogue-service/brand" => ["GET"],
       			"catalogue-service/tag" => ["GET"],
       			"catalogue-service/product" => ["GET"],
       			"catalogue-service/stats" => ["GET"],
       			"catalogue-service/sales" => ["GET"],
       			"account-service/store" => ["GET"],

       		],
       		"HR MANAGER" => [
       			"account-service/attendance" => ["POST", "PUT"],
       			"account-service/employee" => ["GET", "PUT", "POST"],
       			"account-service/designation" => ["GET", "PUT", "POST", "DELETE"],
       			"account-service/role" => ["GET"],
       			"account-service/attendance-summary" => ["GET"],
       			"account-service/user-leave" => ["GET", "PUT", "POST"],
       			"account-service/store" => ["GET"],
       		],
       		"MARKETING MANAGER" => [
       			"blog-service/blog" => ["GET", "PUT", "POST"],
       			"promo-service/campaign" => ["GET", "PUT", "POST"],
       			"promo-service/coupon" => ["GET", "PUT", "POST", "DELETE"],
       			"account-service/static-page" => ["GET", "PUT", "POST"],
       			"account-service/store" => ["GET"],
       			"account-service/extension" => ["GET"],
       		],
       		"MARKETING EXECUTIVE" => [
       			"blog-service/blog" => ["GET"],
       			"promo-service/campaign" => ["GET"],
       			"promo-service/coupon" => ["GET"],
       			"account-service/static-page" => ["GET"],
       			"account-service/store" => ["GET"],
       			"account-service/extension" => ["GET"],
       		],
                  "LOGISTICS MANAGER" => [
                        "logistics-service/vehicle" =>  ["GET","PUT","POST"],
                        "logistics-service/vehicle-vendor" => ["GET","PUT","POST"],
                        "logistics-service/vehicle-planner" => ["GET","PUT","POST","DELETE"],
                        "logistics-service/vehicle-attendance" => ["GET","PUT","POST"] ,
                        "logistics-service/trip" => ["GET","PUT"],
                        "logistics-service/tripLocations" => ["GET"],
                        "logistics-service/trip-eta" => ["GET"],
                        "logistics-service/automation" => ["GET"],
                        "logistics-service/delivery-area" => ["GET"],
                        "order-service/order" => ["GET","PUT"],
                        "order-service/order-log" => ["GET"],
                        "account-service/extension" => ["GET"],
                        "account-service/store" => ["GET"],
                        "account-service/employee" => ["GET","PUT"],
                        "account-service/attendance" => ["PUT","POST"],
                        "account-service/config" => ["GET"],
                  ],
                  "STORE MANAGER" => [
                        "order-service/picking-queue" => ["GET"],
                        "order-service/picking-sequence" => ["GET","PUT"],
                        "order-service/store" => ["GET","PUT"],
                        "order-service/picker-activity" => ["GET"],
                        "order-service/order" => ["GET","PUT"],
                        "order-service/slot" => ["GET"],
                        "order-service/order-log" => ["GET"],

                        "catalogue-service/category" => ["GET", "PUT", "POST", "DELETE"],
                        "catalogue-service/brand" => ["GET", "PUT", "POST", "DELETE"],
                        "catalogue-service/tag" => ["GET", "PUT", "POST", "DELETE"],
                        "catalogue-service/product" => ["GET", "PUT", "POST", "DELETE"],
                        "catalogue-service/stats" => ["GET"],
                        "catalogue-service/sales" => ["GET"],

                        "account-service/employee" => ["GET","PUT"],
                        "account-service/attendance" => ["GET","POST"],
                        "account-service/store" => ["GET"],
                        "account-service/extension" => ["GET"],
                        "account-service/config" => ["GET"],

                        "customer-service/customer" => ["GET","PUT"],
                        "customer-service/address" => ["POST","PUT","GET"],
                        "customer-service/email" => ["POST"],
                        "customer-service/phone" => ["POST","GET"],
                       
                        "communication-service/call" => ["POST"],
                        "communication-service/email" => ["POST"],
                        "communication-service/sms" => ["POST"],
                        "customer-service/reset-password" => ["POST"],
                  ],
                  "PICKING MANAGER" => [
                        "order-service/order" => ["GET","PUT","POST"],
                        "order-service/order-log" => ["GET"],
                        "order-service/slot" => ["GET"],
                        "customer-service/customer" => ["GET","PUT"],
                        "order-service/store" => ["GET","PUT"],
                        "account-service/extension" => ["GET"],
                        "account-service/store" => ["GET"],
                        "account-service/employee" => ["GET","PUT"],
                        "account-service/attendance" => ["PUT","POST"],
                        "account-service/config" => ["GET"],
                        "order-service/picking-queue" => ["GET"],
                        "order-service/picking-sequence" => ["GET","PUT"],
                  ],

       ];
       return $roleEndpoints;
    }



}