<?php

namespace ZopNow\CustomerService\Model;

class ClientCustomer extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'organization_id', 'customer_id'];

}