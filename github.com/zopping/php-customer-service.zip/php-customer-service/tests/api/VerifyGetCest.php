<?php

class VerifyGetCest
{
    protected static $endpoint = '/verify';

    public function validHash(ApiTester $I)
    {
        $I->wantTo("Passing a valid hash value");
        //Fetch the configurations needed for the Encryption class
        $config = include 'config/test.php';
        $encryptionConfig['key'] = $config['ZopNow\Arya\Utility\Encryption']['key'];
        \ZopNow\Arya\Utility\Encryption::configure($encryptionConfig);

        $emailId = $I->haveInDatabase("emails", ["customer_id"=>1, "email"=>"hashTestOnce@encryption.com","status"=>"NEW"]);
        $hash = urlencode(ZopNow\Arya\Utility\Encryption::encrypt($emailId, true));
        $I->sendGET(static::$endpoint . "?hash=$hash");
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Email verified!"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeInDatabase("emails", ['email' => "hashTestOnce@encryption.com", 'customer_id' => 1, 'id' => $emailId, 'status' => "VERIFIED"]);
    }

    public function invalidHash(ApiTester $I)
    {
        $I->wantTo("Passing an invalid hash value");
        $I->sendGET(static::$endpoint . "?hash=1235hgboummskgbcnkk");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Model Exception: Invalid Email"]);
    }

    public function withoutHash(ApiTester $I)
    {
        $I->wantTo("Without passing an hash");
        $I->sendGET(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - verify : hash"]);
    }

    public function alreadyVerifiedEmail(ApiTester $I)
    {
        $I->wantTo("Verifying an already verified email");
        //Fetch the configurations needed for the Encryption class
        $config = include 'config/test.php';
        $encryptionConfig['key'] = $config['ZopNow\Arya\Utility\Encryption']['key'];
        \ZopNow\Arya\Utility\Encryption::configure($encryptionConfig);

        $emailId = $I->haveInDatabase("emails", ["customer_id"=>1, "email"=>"hashTestAgain@encryption.com","status"=>"NEW"]);
        $hash = urlencode(ZopNow\Arya\Utility\Encryption::encrypt($emailId, true));
        $I->sendGET(static::$endpoint . "?hash=$hash");
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Email verified!"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeInDatabase("emails", ['email' => "hashTestAgain@encryption.com", 'customer_id' => 1, 'id' => $emailId, 'status' => "VERIFIED"]);
        //verifying again
        $I->sendGET(static::$endpoint . "?hash=$hash");
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Email verified!"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeInDatabase("emails", ['email' => "hashTestAgain@encryption.com", 'customer_id' => 1, 'id' => $emailId, 'status' => "VERIFIED"]);
    }
}
