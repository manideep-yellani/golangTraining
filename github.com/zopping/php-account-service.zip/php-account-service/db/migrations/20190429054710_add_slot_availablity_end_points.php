<?php

use Phinx\Migration\AbstractMigration;

class AddSlotAvailablityEndPoints extends AbstractMigration
{

    public function change()
    {
        $row = $this->fetchRow('select id,extension_id from endpoints where url="order-service/slot"');
        $extensionId = $row['extension_id'];
        $endpointId = $row['id'];
        $rows = $this->fetchAll("select * from endpoint_role where endpoint_id = $endpointId");
        $this->execute("insert into endpoints(`url`,`allowed_methods`,`extension_id`)values('order-service/slot-availability','[\"GET\"]','$extensionId')");
        $row1 = $this->fetchRow('select id from endpoints where url="order-service/slot-availability"');
        $id=$row1['id'];
        foreach ($rows as $row) {
            $roleId=$row['role_id'];
            $this->execute("insert into endpoint_role (`endpoint_id`,`role_id`)values($id,$roleId)");
        }
    }
}