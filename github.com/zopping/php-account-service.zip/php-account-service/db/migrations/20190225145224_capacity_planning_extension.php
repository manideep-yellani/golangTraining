<?php

use Phinx\Migration\AbstractMigration;

class CapacityPlanningExtension extends AbstractMigration
{
    private $slug = "CapacityPlanning";

    public function change()
    {
        $enableHelperText  = "Provides an interface to manage Capacity for a slot | "
            . "To set capacity for given store on given day";
        $disableHelperText = "You will not be able to set capacity for your slots";
        $data              = [
            "name" => "Capacity Planning",
            "slug" => $this->slug,
            "description" => "Allows you to manage and set capacity for the slots.",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "Free",
        ];
        $this->insert('extensions', $data);
    }

    public function down()
    {
        $this->execute("DELETE extension_organization.* from `extension_organization` inner join extensions on extensions.id = extension_id and `slug` ='$this->slug'");
        $this->execute("DELETE from `extensions` where `slug` ='$this->slug'");
    }

}
