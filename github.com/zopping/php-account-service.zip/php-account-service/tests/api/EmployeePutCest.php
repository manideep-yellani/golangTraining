<?php

class EmployeePutCest
{

    protected static $endpoint = '/employee';
    protected static $table = 'users';

    public function updateEmployeeDetails(ApiTester $I)
    {
        $I->wantTo('Updating employee details without sending the id');
        $I->sendPUT(static::$endpoint, []);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Missing Required Field - employee : id"));
    }

    public function updateEmployeeDetailsWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Updating an employee with invalid id');
        $data = ['id' => 1000, 'organizationId' => 1];
        $I->sendPUT(static::$endpoint . "/1000", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
    }
/*
    public function updateInvalidShiftsForAnEmployee(ApiTester $I)
    {
        $I->wantTo('Updating an employee with invalid  shift details');
        $id = $I->haveInDatabase(
            'designations', ['name' => 'Tech Lead', 'organization_id' => 1, 'id' => 1]
        );
        $data = ['id' => 1, 'organizationId' => 1, 'designationId' => $id, 'shiftStart' => '1212-12', 'shiftEnd' => '12-12-2018'];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
    }

    public function updateShiftsForFlexiDesignationEmployee(ApiTester $I)
    {
        $I->wantTo('Updating shifts for an employee whose designation has a flexi timing type');
        $id = $I->haveInDatabase(
            'designations', ['name' => 'Tech Lead', 'organization_id' => 1, 'id' => 1]
        );
        $data = ['id' => 1, 'organizationId' => 1, 'designationId' => $id, 'shiftStart' => '09:00:00', 'shiftEnd' => '21:00:00'];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Shift details can be provided for designations with FIXED timing type"));
    }

    public function updateShiftsForFixedDesignationEmployee(ApiTester $I)
    {
        $I->wantTo('Updating shifts for an employee whose designation has a fixed timing type');
        $id = $I->haveInDatabase(
            'designations', ['name' => 'Tech Support', 'organization_id' => 1, 'timing_type' => 'FIXED']
        );
        $data = ['id' => 1, 'organizationId' => 1, 'designationId' => $id, 'shiftStart' => '09:00:00', 'shiftEnd' => '21:00:00'];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
    }

    public function updateInvalidWeeklyOffForAnEmployee(ApiTester $I)
    {
        $I->wantTo('Updating weekly off of the employee');
        $id = $I->haveInDatabase(
            'designations', ['name' => 'Tech Support', 'organization_id' => 1, 'timing_type' => 'FIXED']
        );
        $data = ['id' => 1, 'organizationId' => 1, 'designationId' => $id, 'weeklyOff' => ['Saturdaye', 'Sunday']];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
    }

    public function updateWeeklyOffForAnEmployee(ApiTester $I)
    {
        $I->wantTo('Updating weekly off of the employee');
        $id = $I->haveInDatabase(
            'designations', ['name' => 'Tech Support', 'organization_id' => 1, 'timing_type' => 'FIXED']
        );
        $data = ['id' => 1, 'organizationId' => 1, 'designationId' => $id, 'weeklyOff' => ['Saturday', 'Sunday']];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
    }
*/
}
