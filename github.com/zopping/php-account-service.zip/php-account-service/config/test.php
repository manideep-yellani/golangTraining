<?php

date_default_timezone_set('Asia/Kolkata');

if (!defined('DATA_DIRECTORY')) {
    define("DATA_DIRECTORY", __DIR__."/../data/");
}
if (!defined('ZOPSMART_ADMIN')) {
    define("ZOPSMART_ADMIN", "http://admin.zopnow.express");
}

return array(
    "ZopNow\Arya\DB\MySql" => array(
        "test_organizations" => [
            "read" => [
                'host' => 'localhost',
                'database' => 'test_organizations',
                'username' => 'root',
                'password' => 'password',
                'charset'   => 'utf8',
            ],
            "write" => [
                'host' => 'localhost',
                'database' => 'test_organizations',
                'username' => 'root',
                'password' => 'password',
                'charset'   => 'utf8',
            ],
        ]
    ),
    "ZopNow\Arya\Log" => array(
        "fileName" => "/var/log/zopnow/account-service-test.log"
    ),
    "ZopNow\Arya\DB\Redis" => array(
        "host" => "127.0.0.1",
        "port" => "6379"
    ),
    "ZopNow\Arya\App\RestApplication" => array(
        "controllerNamespace" => 'ZopNow\Hodor\Controller',
    ),
    "ZopNow\Arya\Utility\Encryption" => array(
        'key' => '223kj8ydshfads8hdf'
    ),
    "ZopNow\Arya\Utility\MicroService" => array(
        "go-communication-service" => "http://go-communication-service",
        "communication-service" => "http://communication-service",
        "catalogue-service" => "http://catalogue-service",
        "go-catalogue-service" => "http://go-catalogue-service",
        "customer-service" => "http://customer-service",
        "go-order-service" => "http://go-order-service",
    ),
);
