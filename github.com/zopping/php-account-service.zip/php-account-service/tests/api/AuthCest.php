<?php

/**
 * Class consists of the test cases which API should handle during authentication
 * when a POST request is made to the API.
 */

class AuthCest
{
    protected static $endpoint = '/auth';
    protected static $table = 'users';

    public function validLogin(ApiTester $I)
    {
        $I->wantTo('Check the API when the user credentials are valid');
        $data = ['username' => 'admin@zopnow.com', 'password' => 'justatestpassword'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(200);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseContainsJson(['name' => 'Admin']);
        $I->dontSeeResponseContainsJson(['password' => 'd94ebce3b206c791249430e5061dd2f6']);
    }

    public function missingParameter(ApiTester $I)
    {
        $I->wantTo('Check the API when username is missing');
        $data = ['password' => 'justatestpassword'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(400);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - auth : username'));
    }

    public function invalidPassword(ApiTester $I)
    {
        $I->wantTo('Check the API when incorrect password is passed');
        $data = ['username' => 'admin@zopnow.com', 'password' => 'password'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(401);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Auth Exception: Invalid Credentials'));
    }

    public function invalidUsername(ApiTester $I)
    {
        $I->wantTo('Check the API when incorrect username is passed');
        $data = ['username' => 'adminRuchis', 'password' => 'password'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(401);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Auth Exception: Invalid Credentials'));
    }

    public function unverifiedEmail(ApiTester $I)
    {
        $I->wantTo('Check the API when unverified email is passed');
        $id = $I->haveInDatabase(static::$table, ['name' => 'Test User',
            'password' => 'd94ebce3b206c791249430e5061dd2f6',
            'organization_id' => 4,
            'has_tool_access' => 1,
        ]);
        $I->haveInDatabase('emails', ['user_id' => $id, 'email' => 'testuser@silbatti.zopnowexpress.com']);
        $data = ['username' => 'testuser@silbatti.zopnowexpress.com', 'password' => 'justatestpassword'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('verified' => true));
    }

    public function checkIfCorrectPermissionsAreReturned(ApiTester $I)
    {
        $I->wantTo("Validate if the permissions returned in the response is correct");
        $id = $I->haveInDatabase(
            static::$table, ['name' => 'Test User',
            'password' => 'd94ebce3b206c791249430e5061dd2f6',
            'organization_id' => 10,
            'has_tool_access' => 1,]
        );
        $I->haveInDatabase(
            'emails', ['user_id' => $id, 'email' => 'testuser@zopnow.com']
        );
        $endpointId = $I->grabFromDatabase(
            'endpoints', 'id', ['url' => 'account-service/store']
        );
        $I->haveInDatabase(
            'endpoint_user_permissions',
            ['user_id' => $id, 'endpoint_id' => $endpointId, 'method' => 'GET',
                'has_permission' => true]
        );
        $extensionId = $I->grabFromDatabase('extensions', 'id', ['slug' => 'MultiStoreSupport']);
        $I->haveInDatabase(
            'extension_organization',
            ['extension_id' => $extensionId, 'organization_id' => 10]
        );
        $brandEndpointId = $I->grabFromDatabase(
            'endpoints', 'id', ['url' => 'catalogue-service/brand']
        );
        $I->haveInDatabase(
            'endpoint_user_permissions',
            ['user_id' => $id, 'endpoint_id' => $brandEndpointId, 'method' => 'GET',
                'has_permission' => true]
        );
        $data = ['username' => 'testuser@zopnow.com', 'password' => 'justatestpassword'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        /**
         * The endpoint 'catalogue-service/brand' should not be present in response
         *  since the extension is not enabled for the organization.
         */
        $I->seeResponseContainsJson(
            ['endpointPermissions' => [
                [
                    "id" => $endpointId,
                    "url" => "account-service/store",
                    "allowedMethods" => [
                        "GET" => true,
                        "POST" => false,
                        "PUT" => false
                    ],
                ]
            ]]
        );
        $I->dontSeeResponseContainsJson(['endpointPermissions' => [['id' => $brandEndpointId]]]);

        /**
         * Adding support for the extension to the organization.
         */
        $extensionId = $I->grabFromDatabase('extensions', 'id', ['slug' => 'MultiBrandSupport']);
        $I->haveInDatabase(
            'extension_organization',
            ['extension_id' => $extensionId, 'organization_id' => 10]
        );
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(
            ['endpointPermissions' => [
                [
                    "id" => $endpointId,
                    "url" => "account-service/store",
                    "allowedMethods" => [
                        "GET" => true,
                        "POST" => false,
                        "PUT" => false
                    ],
                ],
                [
                    "id" => $brandEndpointId,
                    "url" => "catalogue-service/brand",
                    "allowedMethods" => [
                        "GET" => true,
                        "POST" => false,
                        "PUT" => false
                    ],
                ],
            ]]
        );
    }
}
