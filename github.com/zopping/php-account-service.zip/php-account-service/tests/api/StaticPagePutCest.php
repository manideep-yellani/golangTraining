<?php

class StaticPagePutCest
{

    protected static $endpoint = '/static-page';

    public function editStaticPageWithoutId(ApiTester $I)
    {
        $I->wantTo('Edit static page without id');
        $data = [
            'layouts' => json_encode([
                [
                    "title" => "Title",
                    "message" => "Just a message"
                ]
            ])
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Validation Exception: Missing Required Field'
                . ' - staticpage : id'));
    }

    public function editStaticPageWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Edit static page without organization id');
        $data = [
            'layouts' => json_encode([
                [
                    "title" => "Title",
                    "message" => "Just a message"
                ]
            ])
        ];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Validation Exception: Missing Required Field'
                . ' - staticpage : organization Id'));
    }

    public function editStaticPageWithValidData(ApiTester $I)
    {
        $I->wantTo("Edit static page data with valid data");
        $pageId = $I->grabFromDatabase('pages', 'id', ['name' => 'CONSTANT']);
        $id = $I->haveInDatabase(
            'organization_page',
            [
                'page_id' => $pageId,
                'organization_id' => 3,
                'layouts' => json_encode(
                    [
                        [
                            "name" => 'ImageSlideshow',
                            "data" => array(
                                "text" => "Test Title",
                                "link" => "http://link1.com",
                                "imageUrl" => "http://www.image.com"
                            )
                        ],
                    ]
                ),
                'title' => "Sample Page",
                'url' => '/sample-page'
            ]
        );
        $data = [
            'organizationId' => 3,
            'layouts' => json_encode([
                [
                    "name" => 'ImageSlideshow',
                    "data" => [
                        "text" => "Title",
                        "link" => "http://link1.com",
                        "imageUrl" => "http://www.image.com"
                    ]
                ],
            ]),
            'title' => 'Test Page',
            'url' => 'test-page'
        ];
        $I->sendPUT(static::$endpoint . "/$id", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "staticpage" => array(
                    "id" => "integer",
                    "layouts" => "string|array",
                    "url" => "string",
                    "title" => "string",
                    "status" => "string"
                )
            )
        ));
        unset($data['organizationId']);
        $I->seeResponseContainsJson(['id' => $id]);
        $I->seeResponseContainsJson($data);
    }

    public function editStatusOfStaticPage(ApiTester $I)
    {
        $I->wantTo('Edit status of static page');
        $pageId = $I->grabFromDatabase('pages', 'id', ['name' => 'CONSTANT']);
        $id = $I->haveInDatabase(
            'organization_page',
            [
                'page_id' => $pageId,
                'organization_id' => 3,
                'layouts' => json_encode(
                    [
                        [
                            "name" => 'ImageSlideshow',
                            "data" => array(
                                "text" => "Test Title",
                                "link" => "http://link1.com",
                                "imageUrl" => "http://www.image.com"
                            )
                        ],
                    ]
                ),
                'title' => "Sample Page",
                'url' => '/sample-page'
            ]
        );
        $data = [
            'organizationId' => 3,
            'layouts' => json_encode(
                [
                    [
                        "name" => 'ImageSlideshow',
                        "data" => array(
                            "text" => "Test Title",
                            "link" => "http://link1.com",
                            "imageUrl" => "http://www.image.com"
                        )
                    ],
                ]
            ),
            'title' => 'Sample Page',
            'url' => 'sample-page',
            'status' => 'DISABLED'
        ];
        $I->sendPUT(static::$endpoint . "/$id", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "staticpage" => array(
                    "id" => "integer",
                    "layouts" => "string|array",
                    "url" => "string",
                    "title" => "string",
                    "status" => "string"
                )
            )
        ));
        $I->seeResponseContainsJson(
            ['staticpage' => ['id' => $id, 'status' => 'DISABLED']]
        );
    }

    public function editStaticPageWithoutUrl(ApiTester $I)
    {
        $I->wantTo('Edit static page without passing url');
        $pageId = $I->grabFromDatabase('pages', 'id', ['name' => 'CONSTANT']);
        $id = $I->haveInDatabase(
            'organization_page',
            [
                'page_id' => $pageId,
                'organization_id' => 3,
                'layouts' => json_encode(
                    [
                        [
                            "name" => 'ImageSlideshow',
                            "data" => array(
                                "text" => "Test Title",
                                "link" => "http://link1.com",
                                "imageUrl" => "http://www.image.com"
                            )
                        ],
                    ]
                ),
                'title' => "Sample Page",
                'url' => '/page'
            ]
        );
        $data = [
            'organizationId' => 3,
            'layouts' => json_encode(
                [
                    [
                        "name" => 'ImageSlideshow',
                        "data" => array(
                            "text" => "Test Title",
                            "link" => "http://link1.com",
                            "imageUrl" => "http://www.image.com"
                        )
                    ],
                ]
            ),
            'status' => 'DISABLED'
        ];
        $I->sendPUT(static::$endpoint . "/$id", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "staticpage" => array(
                    "id" => "integer",
                    "layouts" => "string|array",
                    "url" => "string",
                    "title" => "string",
                    "status" => "string"
                )
            )
        ));
        $I->seeResponseContainsJson(
            ['staticpage' => ['id' => $id, 'status' => 'DISABLED']]
        );
    }

    public function editStaticPageWithInvalidId(ApiTester $I)
    {
        $data = [
            'layouts' => json_encode([
                [
                    "title" => "Title",
                    "message" => "Just a message"
                ]
            ]),
            'organizationId' => 1
        ];
        $I->sendPUT(static::$endpoint . "/10000", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Validation Exception: Page with id 10000'
                . ' not found'));
    }
}
