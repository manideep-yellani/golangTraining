<?php

use Phinx\Migration\AbstractMigration;

class EnterpriseOrganization extends AbstractMigration
{
    public function change()
    {
        $this->table("organizations")
                ->addColumn("is_enterprise", "integer", ['limit' => 1, 'default' => 0])
                ->update();
    }
}
