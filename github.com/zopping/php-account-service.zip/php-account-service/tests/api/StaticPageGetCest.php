<?php

class StaticPageGetCest
{

    protected static $endpoint = '/static-page';

    public function listStaticPages(ApiTester $I)
    {
        $I->wantTo('Get list of static pages');
        $I->sendGET(static::$endpoint . "?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "staticpage" => "array"
            )
        ));
    }

    public function getDetailsOfAStaticPage(ApiTester $I)
    {
        $I->wantTo('Get details of a static page with a valid id');
        $pageId = $I->grabFromDatabase('pages', 'id', ['name' => 'CONSTANT']);
        $id = $I->haveInDatabase(
            'organization_page',
            [
                'page_id' => $pageId,
                'organization_id' => 2,
                'layouts' => json_encode(
                    [
                        [
                            "name" => 'ImageSlideshow',
                            "data" => array(
                                "text" => "Test Title",
                                "link" => "http://link1.com",
                                "imageUrl" => "http://www.image.com"
                            )
                        ],
                    ]
                ),
                'title' => "Sample Page",
                'url' => '/sample-page'
            ]
        );
        $I->sendGET(static::$endpoint . "/$id?organizationId=2");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['id' => $id]);
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "staticpage" => array(
                    "id" => "integer",
                    "layouts" => "string|array",
                    "url" => "string",
                    "title" => "string",
                    "status" => "string"
                )
            )
        ));
    }

    public function listStaticPagesInvalidPage(ApiTester $I)
    {
        $I->wantTo('Get list of static pages with invalid page number');
        $I->sendGET(static::$endpoint . "?organizationId=1&page=10000");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "staticpage" => "array"
            )
        ));
        $I->seeResponseContainsJson(array('data' => ['staticpage' => []]));
    }

    public function listStaticPagesWithTitleFilter(ApiTester $I)
    {
        $I->wantTo('Get list of static pages with title filter');
        $pageId = $I->grabFromDatabase('pages', 'id', ['name' => 'CONSTANT']);
        $id = $I->haveInDatabase(
            'organization_page',
            [
                'page_id' => $pageId,
                'organization_id' => 2,
                'layouts' => json_encode(
                    [
                        [
                            "name" => 'ImageSlideshow',
                            "data" => array(
                                "text" => "Test Title",
                                "link" => "http://link1.com",
                                "imageUrl" => "http://www.image.com"
                            )
                        ],
                    ]
                ),
                'title' => "Sample Page",
                'url' => '/sample-page'
            ]
        );
        $I->sendGET(static::$endpoint . "?organizationId=2&title=Sample Page");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "staticpage" => "array"
            )
        ));
        $I->seeResponseContainsJson([
            'id' => $id,
            'title' => 'Sample Page'
        ]);
    }

    public function listStaticPagesWithUrlFilter(ApiTester $I)
    {
        $I->wantTo('Get list of static pages with url filter');
        $pageId = $I->grabFromDatabase('pages', 'id', ['name' => 'CONSTANT']);
        $id = $I->haveInDatabase(
            'organization_page',
            [
                'page_id' => $pageId,
                'organization_id' => 2,
                'layouts' => json_encode(
                    [
                        [
                            "name" => 'ImageSlideshow',
                            "data" => array(
                                "text" => "Test Title",
                                "link" => "http://link1.com",
                                "imageUrl" => "http://www.image.com"
                            )
                        ],
                    ]
                ),
                'title' => "Sample Page",
                'url' => '/sample-page'
            ]
        );
        $I->sendGET(static::$endpoint . "?organizationId=2&url=/sample-page");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "staticpage" => "array"
            )
        ));
        $I->seeResponseContainsJson([
            'id' => $id,
            'url' => '/sample-page'
        ]);
    }

    public function listStaticPagesWithStatusFilter(ApiTester $I)
    {
        $I->wantTo('Get list of static pages with status filter');
        $pageId = $I->grabFromDatabase('pages', 'id', ['name' => 'CONSTANT']);
        $id = $I->haveInDatabase(
            'organization_page',
            [
                'page_id' => $pageId,
                'organization_id' => 2,
                'layouts' => json_encode(
                    [
                        [
                            "name" => 'ImageSlideshow',
                            "data" => array(
                                "text" => "Test Title",
                                "link" => "http://link1.com",
                                "imageUrl" => "http://www.image.com"
                            )
                        ],
                    ]
                ),
                'title' => "Sample Page",
                'url' => '/sample-page',
                'status' => 'DISABLED'
            ]
        );
        $I->sendGET(static::$endpoint . "?organizationId=2&status=DISABLED");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "staticpage" => "array"
            )
        ));
        $I->seeResponseContainsJson(
            [
            'staticpage' => [
                    'id' => $id,
                    'status' => 'DISABLED'
                ]
            ]
        );
    }
}
