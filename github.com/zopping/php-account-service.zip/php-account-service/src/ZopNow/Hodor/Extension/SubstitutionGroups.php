<?php


namespace ZopNow\Hodor\Extension;

use ZopNow\Arya\App\Application;
use ZopNow\Arya\Utility\MicroService;

class SubstitutionGroups extends Base
{

    public function enable()
    {
        return true;
    }

    public function disable()
    {
        $organizationId = $this->organization->id;
        $page = 0;
        do{
            ++$page;
            $substitutionGroups = MicroService::callService('catalogue-service', '/substitution-group','GET',['organizationId' => $organizationId, 'page' => $page]);
            $substitutionGroups = json_decode($substitutionGroups['body'], true);
            $count = $substitutionGroups['data']['count'];
            $offset = $substitutionGroups['data']['offset'];
            $limit = $substitutionGroups['data']['limit'];
            $remaining = $count - ($offset + $limit);
            foreach($substitutionGroups['data']['substitutiongroup'] as $group){
                MicroService::callService('catalogue-service', '/substitution-group/'.$group['id'],'PUT',['organizationId' => $organizationId, 'status' => 'DISABLED']);
            }
        } while($remaining > 0);
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        /**
         * @todo computing billing amount
         */
    }

}
