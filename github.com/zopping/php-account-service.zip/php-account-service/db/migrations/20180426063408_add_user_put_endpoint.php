<?php

use Phinx\Migration\AbstractMigration;

class AddUserPutEndpoint extends AbstractMigration
{

    public function up()
    {
        $allowedMethods = json_encode(["GET","PUT","DELETE"]);
        $this->execute("update endpoints set allowed_methods = '$allowedMethods' where url = 'account-service/user'");
    }

    public function down()
    {
        $allowedMethods = json_encode(["GET","DELETE"]);
        $this->execute("update endpoints set allowed_methods = '$allowedMethods' where url = 'account-service/user'");
    }

}
