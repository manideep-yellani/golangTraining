<?php

use Phinx\Migration\AbstractMigration;

class AddHasToolAccess extends AbstractMigration
{

    public function up()
    {
        $this->table('users')
                ->addColumn('has_tool_access', 'boolean', ['default' => 0])
                ->save();
        $this->query("update users set has_tool_access = 1");
        //Add POST to allowed methods for employee
        $allowedMethods = json_encode(['GET', 'POST', 'PUT']);
        $this->execute("update endpoints set allowed_methods = '$allowedMethods'"
            . " where url = 'account-service/employee'");
    }

    public function down()
    {
        $this->table('users')
            ->removeColumn('has_tool_access')
            ->save();
        $allowedMethods = json_encode(['GET', 'PUT']);
        $this->execute("update endpoints set allowed_methods = '$allowedMethods'"
            . " where url = 'account-service/employee'");
    }

}
