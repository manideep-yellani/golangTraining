<?php

use Phinx\Migration\AbstractMigration;

class EnterpriseAccessToEndpoints extends AbstractMigration
{

    public function up()
    {
        $this->table("endpoints")
            ->addColumn("allow_enterprise_access", 'boolean', array('default' => 1))
            ->update();
        $this->execute("update endpoints set allow_enterprise_access = 0 where url = 'account-service/extension'");
    }

    public function down()
    {
        $this->table("endpoints")
            ->removeColumn("allow_enterprise_access")
            ->update();
    }

}
