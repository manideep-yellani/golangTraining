<?php


use Phinx\Migration\AbstractMigration;

class AddCustomerUUIDMappingTable extends AbstractMigration
{
  public function up()
  {

    $table = $this->table('customer_uuid_mapping', ['id' => false, 'primary_key' => ['customer_id', 'uuid']]);
    $table->addColumn("customer_id", "integer", ["null" => false])
      ->addColumn("uuid", "string", array('limit' => 225, "null" => false))
      ->addForeignKey("customer_id", "customers", "id",
        array('constraint' => 'fk_customers_customer_uuid_mapping', 'update' => 'NO_ACTION'))
        ->create();
  }

  public function down()
  {
    $this->table("customer_uuid_mapping")->drop()->save();
  }

}
