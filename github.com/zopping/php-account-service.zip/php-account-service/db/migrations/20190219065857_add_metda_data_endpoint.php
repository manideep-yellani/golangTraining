<?php

use Phinx\Migration\AbstractMigration;

class AddMetdaDataEndpoint extends AbstractMigration
{
    public function up() {
        $endpoints = [
            [
                'url' => 'config-service/meta-data',
                'allowed_methods' => json_encode(["GET", "PUT"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);
        $accountConfigId = $this->fetchRow("SELECT `id` from `endpoints` where `url` in "
                    . "('account-service/config')")['id'];
        $id = $this->fetchRow("SELECT `id` from `endpoints` where `url` in "
                    . "('config-service/meta-data')")['id'];
        $this->execute("insert into endpoint_role(role_id , method , endpoint_id )"
            . " select role_id, method, '$id' from endpoint_role where endpoint_id  = '$accountConfigId' and method in ('GET')");
            $this->execute("insert into endpoint_role(role_id , method , endpoint_id )"
            . " select role_id, 'PUT', '$id' from endpoint_role where endpoint_id  = '$accountConfigId' and method in ('POST')");
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('config-service/meta-data')"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoint_role` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('config-service/meta-data')");
    }
}


