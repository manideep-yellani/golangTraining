<?php

use Phinx\Migration\AbstractMigration;

class AddStoreIdInConfigurations extends AbstractMigration
{

    public function up()
    {
        $this->table('configurations')
            ->addColumn('store_id', 'integer', array('limit' => 11, 'null' => true, 'after' => 'organization_id'))
            ->addForeignKey('store_id', 'stores', 'id', array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
            ->dropForeignKey('organization_id')
            ->removeIndex(['organization_id', 'key'])
            ->addForeignKey('organization_id', 'organizations', 'id', array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
            ->addIndex(['organization_id', 'store_id', 'key'])
            ->update();
        $this->table('extensions')
             ->addColumn('is_store_configurable', 'boolean', ['default' => 0])
             ->update();
        $this->query("UPDATE extensions set `is_store_configurable` = 1 where slug ='InStoreProcessing'");
    }

    public function down()
    {
        $this->table('configurations')
            ->dropForeignKey('store_id')
            ->removeColumn('store_id')
            ->update();
        $this->table('extensions')
             ->removeColumn('is_store_configurable')
             ->update();
    }

}
