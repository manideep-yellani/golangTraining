<?php

use Phinx\Migration\AbstractMigration;

class UserLeaves extends AbstractMigration
{

    public function change()
    {
        $this->table("user_leaves")
            ->addColumn("user_id","integer")
            ->addColumn("from_date", "date", array('null' => false))
            ->addColumn("to_date", "date", array('null' => false))
            ->addColumn("reason", "text", array('null' => false))
            ->addColumn(
                'type', 'enum',
                ['values' => ['EARNED','SICK','PATERNITY','MATERNITY','HALFDAY'], 'null' => false]
            )
            ->addColumn(
                'status', 'enum',
                ['values' => ['PENDING','APPROVED','REJECTED','CANCELLED','CANCELLATION_PENDING'],
                    'null' => false]
            )
            ->addColumn('created_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addColumn('deleted_at', 'timestamp', ['null' => true])
            ->addForeignKey('user_id', 'users', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->create();
    }
}
