<?php
namespace ZopNow\Hodor\Utility;

class ZoppayInteractor 
{

    private $api, $method, $data, $accessToken;
    private $curl;
    private static $configurations;

    public function __construct($api = NULL, $method = "GET",  $data = null, $accessToken = null)
    {
        $this->api = $api;
        $this->method = $method;
        $this->data = $data;
        $this->accessToken = $accessToken;
    }

    public static function configure($configurations) 
    {
        self::$configurations = $configurations;
    }

    private function setOptions() 
    {
        $url = self::$configurations['url']. $this->api;
        if ($this->method == 'GET' && !empty($this->data)) {
            $url .= '?'.http_build_query($this->data);
        }
        $this->curl = curl_init($url);
        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT ,0);
        curl_setopt($this->curl, CURLOPT_TIMEOUT, 10);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, False);
        curl_setopt($this->curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        if ($this->method == "POST") {
            curl_setopt($this->curl, CURLOPT_POST, 1);
            curl_setopt($this->curl, CURLOPT_POSTFIELDS, http_build_query($this->data));
        }
        curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($this->curl, CURLOPT_HEADER, 0);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, 1);               
        $headers = [];
        if (!empty($this->accessToken)) {
            $headers = array('Access-Token: '.$this->accessToken);
        } else {
            $headers = array('Developer-Token: '.self::$configurations['developer-token']);
        }
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
    }

    public function execute() 
    {
        $this->setOptions();
        $response = trim(curl_exec($this->curl));
        $statusCode = curl_getinfo($this->curl, CURLINFO_HTTP_CODE);
        curl_close($this->curl);
        if ($statusCode != 200) {
            \ZopNow\Arya\App\Application::log("Error Response for ".$this->api, ["requestData"=> $this->data, "responseCode" => $statusCode, "response" => $response]);
        }
        return array('response' => $response, 'statusCode' => $statusCode);
    }

}
