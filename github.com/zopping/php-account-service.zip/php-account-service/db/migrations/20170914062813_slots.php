<?php

use Phinx\Migration\AbstractMigration;

class Slots extends AbstractMigration
{

    /**
     * Database schema for "slots" table
     * It consists of the following fields :
     * start_time : start time of the slot
     * end_time : end time of the slot
     * organization_id : the id for the organization for which the slots are stored
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     * deleted_at : field will be NULL. This field will be set to the timestamp when the slot is deleted and it is a soft delete.
     *
     * "id" is the primary key for the table.
     * "organization_id" is a foriegn key which references the organizations table
     */
    public function change()
    {
        $table = $this->table('slots');
        $table->addColumn('start_time', 'time')
                ->addColumn('end_time', 'time')
                ->addColumn('organization_id', 'integer', array('limit' => 11))
                ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addColumn('deleted_at', 'timestamp', array('null' => true))
                ->addIndex(['organization_id'], ['name' => 'slot_organization'])
                ->addForeignKey('organization_id', 'organizations', 'id')
                ->create();
    }

}
