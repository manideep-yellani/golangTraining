<?php

namespace ZopNow\Hodor\Model;

class Service extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at','pivot'];

    protected $casts = [
        'pricing_rule' => 'array'
    ];

    public function organizationService()
    {
        return $this->hasMany("\ZopNow\Hodor\Model\OrganizationService");
    }

    public function getBillingStrategy($organizationId)
    {
        $organizationSpecificDetails = $this->organizationService()->where(['organization_id' => $organizationId])->first();
        $pricingRule = $organizationSpecificDetails->pricing_rule ?? null;
        if (empty($pricingRule)) {
            return $this->pricing_rule;
        }
        return json_decode($pricingRule, true);
    }
}