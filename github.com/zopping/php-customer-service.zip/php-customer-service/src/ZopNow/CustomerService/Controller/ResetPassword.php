<?php

namespace ZopNow\CustomerService\Controller;

class ResetPassword extends \ZopNow\Arya\Controller\Base
{

    public function post()
    {
        $data = $this->getRequestParams(['username', 'organizationId']);
        if (\ZopNow\Arya\Utility\Validator::isPhone($data['username'], ['validateIsdCode' => false])) {
            $user = Customer::getFromPhone($data['username'], $data['organizationId']);
            $errorMessage = "User with phone " . $data['username'] . " is not registered";
        } elseif (\ZopNow\Arya\Utility\Validator::isEmail($data['username'])) {
            $user = Customer::getFromEmail($data['username'], $data['organizationId']);
            $errorMessage = "User with email " . $data['username'] . " is not registered";
        } else {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid username");
        }
        if (empty($user)) {
            throw new \ZopNow\Arya\Exception\ModelException($errorMessage);
        }
        return (new Customer(['id' => $user['id']]))->resetPassword();
    }

}
