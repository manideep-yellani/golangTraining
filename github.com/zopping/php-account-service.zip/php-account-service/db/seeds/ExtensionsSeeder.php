<?php

use Phinx\Seed\AbstractSeed;

class ExtensionsSeeder extends AbstractSeed
{
    /*
     * Seeding the users table with name, email, phone, username, password, organization_id and is_owner.
     * Using faker factory for populating the database for 50 users
     * created_at, updated_at will be set to the current timestamp
     */
    public function run()
    {
        $extensionIds = array_column($this->fetchAll("SELECT `id` from extensions where is_private = 0 and name != 'Marketing Support'"),'id');
        $data = [];
        foreach($extensionIds as $id){
            $data[] = [
                'extension_id' => $id,
                'organization_id' => 1
            ];
        }
        $extensions = $this->table('extension_organization');
        $extensions->insert($data)
            ->save();
        /**
         * Setting slots extension for organization 2 and not 1 for supporting the test cases
         *  in order service.
         */
        $this->execute(
            "update extension_organization inner join extensions"
            . " on extensions.id=extension_id and extensions.slug = 'DeliverySlots'"
            . " set organization_id = 2 where organization_id = 1"
        );
    }
}
