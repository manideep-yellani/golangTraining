<?php

use Phinx\Migration\AbstractMigration;

class AddPageTitle extends AbstractMigration
{

    public function change()
    {
        $this->table('organization_page')
            ->addColumn('title', 'string', ['limit' => 100, 'null' => true])
            ->addColumn(
                'status', 'enum',
                array('values' => array('ENABLED', 'DISABLED'), 'null' => false, 'default' => 'ENABLED')
            )
            ->save();
    }
}
