<?php

require_once 'BaseCest.php';

class AddEmailCest extends BaseCest
{
    protected static $endpoint = '/email';
    protected static $table    = "emails";

    public function addEmailWithValidCustomerObject(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "email" => "fardeen12@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $emailId = $I->grabDataFromResponseByJsonPath('$.data.email.id')[0];
        $I->seeInDatabase(self::$table, ["id" => $emailId, "customer_id" => $customerId, "email" => $data['email'], "status" => "NEW", "deleted_at" => null]);
    }

    public function addEmailWithValidCustomerId(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customerId" => $customerId,
            "organizationId" => $organizationId,
            "email" => "fardeen1212@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $emailId = $I->grabDataFromResponseByJsonPath('$.data.email.id')[0];
        $I->seeInDatabase(self::$table, ["id" => $emailId, "customer_id" => $customerId, "email" => $data['email'], "status" => "NEW", "deleted_at" => null]);
    }

    public function addEmailWithoutCustomer(ApiTester $I)
    {
        $organizationId = 1;
        $data = [
            "organizationId" => $organizationId,
            "email" => "fardeen11@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Please pass a valid Customer object or customerId"));
    }

    public function addEmailWithoutOrganizationId(ApiTester $I)
    {
        $customerId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "email" => "fardeen11@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Missing Required Field - email : organization Id"));
    }


    public function addPhoneWithInvalidCustomerId(ApiTester $I)
    {
        $customerId = "xyz";
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "email" => "fardeen11@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array("message"=>"Model Exception: Customer with id $customerId and organization_id $organizationId not found"));
    }

    public function addPhoneWithCustomerIdOfOtherOrganization(ApiTester $I)
    {
        $customerId = 5; //belongs to organization_id=2
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "email" => "fardeen11@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array("message"=>"Model Exception: Customer with id $customerId and organization_id $organizationId not found"));
    }

    public function addInvalidEmail(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "email" => "fardeen11.gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Invalid Email"));
    }

    public function addEmptyEmail(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "email" => ""
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Missing Required Field - email : email"));
    }

    public function addEmailAgainInSameOrganization(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "email" => "vishal@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Email already exists"));
    }

    public function addEmailWithInproperCustomerFormat(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['customer' => $customerId]),
            "organizationId" => $organizationId,
            "email" => "vishal@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Please pass a valid Customer object or customerId"));
        $data = [
            "customer" => ['customer' => $customerId],
            "organizationId" => $organizationId,
            "email" => "vishal@gmail.com"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Please pass a valid Customer object or customerId"));
    }

    public function checkingRestoringOfEmail(ApiTester $I)
    {
        $email = "test@restore.com";
        $organizationId = 1;
        //Adding this number to customer-1
        $I->sendPost(self::$endpoint, ["email" => $email, "organizationId" => $organizationId, "customerId"=>1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $emailId = $I->grabDataFromResponseByJsonPath("$.data.email.id")[0];
        //Adding to customer -2 :- should give error
        $I->sendPost(self::$endpoint, ["email" => $email, "organizationId" => $organizationId, "customerId"=>2]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        // Deleting this email from customer-1
        $I->sendDELETE(self::$endpoint."/$emailId",["organizationId" => $organizationId, "customerId" => 1]);
        $deletedAt = $I->grabColumnFromDatabase(self::$table, "deleted_at", ["id" => $emailId, "customer_id" => 1, "email" => $email]);
        $I->assertNotNull($deletedAt);
        // Adding this email back :- should restore it
        $I->sendPost(self::$endpoint, ["email" => $email, "organizationId" => $organizationId, "customerId"=>1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $deletedAt = $I->grabFromDatabase(self::$table, "deleted_at", ["id" => $emailId, "customer_id" => 1, "email" => $email]);
        $I->seeResponseContainsJson([
            "data" => [
                "email" => [
                    "id" => $emailId,
                    "email" => $email
                ]
            ]
        ]);
        $I->assertNull($deletedAt);
    }

    public function addingDeletedEmailToNewCustomer(ApiTester $I)
    {
        $email = "testagain@restore.com";
        $organizationId = 1;
        //Adding this number to customer-1
        $I->sendPost(self::$endpoint, ["email" => $email, "organizationId" => $organizationId, "customerId"=>1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $emailId = $I->grabDataFromResponseByJsonPath("$.data.email.id")[0];
        // Deleting this email from customer-1
        $I->sendDELETE(self::$endpoint."/$emailId",["organizationId" => $organizationId, "customerId" => 1]);
        $deletedAt = $I->grabColumnFromDatabase(self::$table, "deleted_at", ["id" => $emailId, "customer_id" => 1, "email" => $email]);
        $I->assertNotNull($deletedAt);
        //Adding this email to customer-2 : Should add
        $I->sendPost(self::$endpoint, ["email" => $email, "organizationId" => $organizationId, "customerId"=>2]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $emailId2 = $I->grabDataFromResponseByJsonPath("$.data.email.id")[0];
        $I->assertNotEquals($emailId, $emailId2);
        // Deleting this email from customer-2
        $I->sendDELETE(self::$endpoint."/$emailId2",["organizationId" => $organizationId, "customerId" => 2]);
        $deletedAt2 = $I->grabColumnFromDatabase(self::$table, "deleted_at", ["id" => $emailId2, "customer_id" => 2, "email" => $email]);
        $I->assertNotNull($deletedAt2);
        //Addding to customer-3 should work
        $I->sendPost(self::$endpoint, ["email" => $email, "organizationId" => $organizationId, "customerId"=>3]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $emailId3 = $I->grabDataFromResponseByJsonPath("$.data.email.id")[0];
        $I->assertNotEquals($emailId3, $emailId2);
        $I->assertNotEquals($emailId3, $emailId);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson([
            "data" => [
                "email" => [
                    "id" => $emailId3,
                    "email" => $email
                ]
            ]
        ]);
    }
}