<?php

class ConfigGetCest extends BaseCest
{

    protected static $endpoint = '/config';

    public function listConfigsWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get configs without organization id');
        $I->sendGET(self::$endpoint);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - config : organization Id'));
    }
/*
    public function listAllConfigs(ApiTester $I)
    {
        $I->wantTo('Get all configuration sets for an organization');
        $I->sendGET(self::$endpoint . "?organizationId=1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "config" => array(
                    "basic" => array(
                        "organizationName" => "string|null",
                        "siteUrl" => "string|null",
                        "siteTagLine" => "string|null",
                        "logo" => "string|null",
                        "supportEmail" => "string|null",
                        "supportPhone" => "string|null"
                    )
                )
            )
        ));
    }

    public function listConfigForValidType(ApiTester $I)
    {
        $I->wantTo('Get configs for valid config type');
        $I->sendGET(self::$endpoint . "/basic?organizationId=1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "config" => array(
                    "basic" => array(
                        "organizationName" => "string|null",
                        "siteUrl" => "string|null",
                        "siteTagLine" => "string|null",
                        "logo" => "string|null",
                        "supportEmail" => "string|null",
                        "supportPhone" => "string|null"
                    )
                )
            )
        ));
    }
*/
    public function listConfigsWithInvalidType(ApiTester $I)
    {
        $I->wantTo('Get configs with invalid config type');
        $I->sendGET(self::$endpoint . "/abc?organizationId=1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: The configuration type abc does not exist.'));
    }
    
    public function listConfigsWithInvalidOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get configs with invalid organization id');
        $I->sendGET(self::$endpoint . "?organizationId=10000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "config" => array(
                    "basic" => array(
                        "organizationName" => "null",
                        "siteUrl" => "null",
                        "siteTagLine" => "null",
                        "supportEmail" => "null",
                        "supportPhone" => "null"
                    )
                )
            )
        ));
    }

}
