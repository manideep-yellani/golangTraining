<?php

use Phinx\Migration\AbstractMigration;

class CustomerGetPermission extends AbstractMigration
{
    /**
     * Customer is required to login to see details(GET Api)
     */
    public function change()
    {
        $url = "customer-service/customer";
        $developerId = $this->fetchRow("select id from developers where token='59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $endpointId = $this->fetchRow("select id from endpoints where url='$url'")['id'];
        $this->execute("update endpoint_developer_permissions set is_customer_required=1 "
            . "where endpoint_id = $endpointId and method ='GET' and developer_id=$developerId");
    }
}
