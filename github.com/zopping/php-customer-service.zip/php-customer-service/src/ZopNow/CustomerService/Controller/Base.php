<?php

namespace ZopNow\CustomerService\Controller;

/**
 * Base class for all the common functionalities related to customer-APIs
 */
class Base extends \ZopNow\Arya\Controller\ModelController
{

    /**
     * Fetches customer id from customer object or customerId parameter in request.
     * Checks whether this customer belongs to given organization. Throws exception if
     * not found, else returns customerId
     */
    public function getCustomerIdFromRequest()
    {
        $organizationId = $this->data['organizationId'] ?? null;
        if (empty($organizationId)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass Organization Id");
        }
        if (!empty($this->data['customer'])) {
            $customer   = $this->data['customer'];
            $customerId = json_decode($customer, true)['id'] ?? null;
        } else {
            $customerId = $this->data['customerId'] ?? null;
        }
        if (empty($customerId)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid Customer object or customerId");
        }
        Customer::validateCustomer($customerId, $organizationId);
        return $customerId;
    }
        
}