<?php

use Phinx\Migration\AbstractMigration;

class DefaultTheme extends AbstractMigration
{
    public function up()
    {
        $this->execute("UPDATE `organizations` set theme_id = 1 where theme_id is null");
    }

    public function down()
    {
        //This cannot be rolled back as it is modifying data
    }
}
