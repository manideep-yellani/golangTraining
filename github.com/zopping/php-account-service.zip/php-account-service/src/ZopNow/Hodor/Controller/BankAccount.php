<?php

namespace ZopNow\Hodor\Controller;

class BankAccount extends \ZopNow\Arya\Controller\Base
{

    public function get()
    {
        $fields = $this->getRequestParams(['organizationId']);
        $paymentAccount = (new \ZopNow\Hodor\Model\PaymentAccount())->getPaymentAccount($fields['organizationId']);
        $accessToken  = $paymentAccount->access_token;
        $zoppayResponse = (new \ZopNow\Hodor\Utility\ZoppayInteractor('bank-account.json', 'GET', ['status' => 'NEW,VERIFIED', 'paginated' => 'false'], $accessToken))->execute();
        $details =  json_decode($zoppayResponse['response'], true);
        $bankDetails = $details['data'] ?? [];
        $camelCaseResponse = \ZopNow\Hodor\Utility\Utility::convertKeysToCamelCase($bankDetails);
        unset($details['data']);
        $details['bankaccount'] = $camelCaseResponse;
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'code' => 200,
            'data' => $details
            ])
        );
    }

    public function post()
    {
        $requestParams = ['organizationId' , 'accountNumber', 'beneficiaryName', 'bankName', 'ifscCode', 'city'];
        $fields = $this->getRequestParams($requestParams, [ 'state', 'pincode']);
        $request = \ZopNow\Hodor\Utility\Utility::convertKeysToSnakeCase($fields);
        $paymentAccount = (new \ZopNow\Hodor\Model\PaymentAccount())->getPaymentAccount($fields['organizationId']);
        $accessToken  = $paymentAccount->access_token;
        $zoppayResponse = (new \ZopNow\Hodor\Utility\ZoppayInteractor('bank-account.json', 'POST', $request , $accessToken))->execute();
        $response = json_decode($zoppayResponse['response'], true);
        if ($zoppayResponse['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong please try again");
        }
        if (!empty($response[0]) && ($response[0]['type'] == 'Error')) {
            throw new \ZopNow\Arya\Exception\ValidationException($response[0]['data']);
        }
        $zoppayResp = $response[0]['data'] ?? [];
        $camelCaseResponse = \ZopNow\Hodor\Utility\Utility::convertKeysToCamelCase($zoppayResp);
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'code' => 200,
            'data' => ['bankaccount' => $camelCaseResponse]
            ])
        );
    }

    public function put()
    {
        $fields = $this->getRequestParams(['id', 'organizationId'], ['bankName', 'accountNumber', 'beneficiaryName', 'ifscCode', 'city', 'state', 'pincode', 'status']);
        $request = \ZopNow\Hodor\Utility\Utility::convertKeysToSnakeCase($fields);
        $paymentAccount = (new \ZopNow\Hodor\Model\PaymentAccount())->getPaymentAccount($fields['organizationId']);
        $accessToken  = $paymentAccount->access_token;
        $zoppayResponse = (new \ZopNow\Hodor\Utility\ZoppayInteractor('update-bank-account.json', 'POST', $request , $accessToken))->execute();
        $response = json_decode($zoppayResponse['response'], true);
        if ($zoppayResponse['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong please try again");
        }
        if (!empty($response[0]) && ($response[0]['type'] == 'Error')) {
            throw new \ZopNow\Arya\Exception\ValidationException($response[0]['data']);
        }
        $zoppayResp = $response[0]['data'] ?? [];
        $camelCaseResponse = \ZopNow\Hodor\Utility\Utility::convertKeysToCamelCase($zoppayResp);
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'code' => 200,
            'data' => ['bankaccount' => $camelCaseResponse]
            ])
        );
    }

}