<?php

use Phinx\Migration\AbstractMigration;

class AddVehicleEndpoints extends AbstractMigration {

    public function up() {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'LogisticsSupport'")['id'];
        $vehicleEndpoints = [
            [
                'url' => 'logistics-service/vehicle-attendance',
                'allowed_methods' => json_encode(['GET', 'PUT', 'POST']),
                'extension_id' => $extensionId,
            ],
            [
                'url' => 'logistics-service/vehicle-planner',
                'allowed_methods' => json_encode(['GET', 'PUT', 'POST', 'DELETE']),
                'extension_id' => $extensionId
            ]
        ];
        $this->insert('endpoints', $vehicleEndpoints);
    }

    public function down() {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'LogisticsSupport'")['id'];
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `extension_id` = '$extensionId' and "
                    . "`url` in ('logistics-service/vehicle-attendance','logistics-service/vehicle-planner')"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('logistics-service/vehicle-attendance', 'logistics-service/vehicle-planner')");
    }

}
