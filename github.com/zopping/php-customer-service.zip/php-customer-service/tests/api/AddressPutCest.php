<?php

class AddressPutCest
{
    protected static $endpoint = '/address';
    protected static $table    = "addresses";
/*
    public function updatingAddress(ApiTester $I)
    {
        $newAddress = "New address";
        $I->sendPUT(self::$endpoint, ["customer" => json_encode(['id' => 1]),"id" => 1, "organizationId" => 1, "address" => $newAddress]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $addressFromResponse = $I->grabDataFromResponseByJsonPath("$.data.address.address")[0];
        $I->assertEquals($addressFromResponse, $newAddress);
    }

    public function updatingLandmark(ApiTester $I)
    {
        $newLandmark = "new landmark";
        $I->sendPUT(self::$endpoint, ["customer" => json_encode(['id' => 1]),"id" => 1, "organizationId" => 1, "landmark" => $newLandmark]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $landmarkFromResponse = $I->grabDataFromResponseByJsonPath("$.data.address.landmark")[0];
        $I->assertEquals($landmarkFromResponse, $newLandmark);
    }

    public function updatingPincode(ApiTester $I)
    {
        $newPincode = 800001;
        $I->sendPUT(self::$endpoint, ["customerId"=>1, "id" => 1, "organizationId" => 1, "pincode" => $newPincode]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $pincodeFromResponse = $I->grabDataFromResponseByJsonPath("$.data.address.pincode")[0];
        $I->assertEquals($pincodeFromResponse, $newPincode);
    }

    public function updatingCity(ApiTester $I)
    {
        $newCity = "Jaipur";
        $newPincode = 800001;
        $I->sendPUT(self::$endpoint, ["customerId"=>1, "id" => 1, "organizationId" => 1, "pincode" => $newPincode,"city"=>$newCity]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $pincodeFromResponse = $I->grabDataFromResponseByJsonPath("$.data.address.pincode")[0];
        $I->assertEquals($pincodeFromResponse, $newPincode);
        $cityFromResponse = $I->grabDataFromResponseByJsonPath("$.data.address.city")[0];
        $I->assertEquals($cityFromResponse, $newCity);
    }

    public function updatingLatitude(ApiTester $I)
    {
        $newLatitude = 11.9;
        $I->sendPUT(self::$endpoint, ["customerId"=>1, "id" => 1, "organizationId" => 1, "latitude" => $newLatitude]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $latitudeFromResponse = $I->grabDataFromResponseByJsonPath("$.data.address.latitude")[0];
        $I->assertEquals($latitudeFromResponse, $newLatitude);
    }

    public function updatingLongitude(ApiTester $I)
    {
        $newLongitude = 77.9;
        $I->sendPUT(self::$endpoint, ["customerId"=>1, "id" => 1, "organizationId" => 1, "longitude" => $newLongitude]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $longitudeFromResponse = $I->grabDataFromResponseByJsonPath("$.data.address.longitude")[0];
        $I->assertEquals($longitudeFromResponse, $newLongitude);

    }
*/
    public function updatingLatLongAsInvalidValues(ApiTester $I)
    {
        $newLatitude = 177.9;
        $I->sendPUT(self::$endpoint, ["customerId"=>1, "id" => 1, "organizationId" => 1, "latitude" => $newLatitude]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Invalid latitude"]);
    }

    public function updatingLatLongOfAnotherCustomer(ApiTester $I)
    {
        $newLongitude = 77.9;
        // Address 2 belongs to customer -5
        $I->sendPUT(self::$endpoint, ["customerId"=>1, "id" => 2, "organizationId" => 1, "longitide" => $newLongitude]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Address not found"]);
    }
/*
    public function updatingClientIdOfAddress(ApiTester $I)
    {
        $addressId = $I->haveInDatabase(
            self::$table,
            ['customer_id' => 1,
                'address' => '#45, 3rd cross, 31st Main, BTM layout 2nd stage',
                'city' => 'Bengaluru']
        );
        $data = [
            "customerId" => 1,
            "organizationId" => 1,
            "clientId" => 1002,
            "id" => $addressId
        ];
        $I->sendPUT(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' =>
            array(
                'address' =>
                array(
                    "id" => 'integer',
                    'address' => 'string',
                    'landmark' => 'string|null',
                    'pincode' => 'integer|null',
                    'city' => 'string',
                    'latitude' => 'string|null',
                    'longitude' => 'string|null',
                    'clientId' => 'string|null'
                ),
            ),
        ));
        $I->seeResponseContainsJson(
            ["address" => [
                "id" => $addressId,
                "address" => "#45, 3rd cross, 31st Main, BTM layout 2nd stage",
                "city" => "Bengaluru",
                "clientId" => 1002]
            ]
        );
    }

    public function updatingDataUsingClientId(ApiTester $I)
    {
        $addressId = $I->haveInDatabase(
            self::$table,
            ['customer_id' => 1,
                'address' => '#48, 3rd cross, 31st Main, BTM layout 2nd stage',
                'city' => 'Bengaluru', 'client_address_id' => 1003]
        );
        $data = [
            "customerId" => 1,
            "organizationId" => 1,
            "clientId" => 1003,
            'latitude' => 11.9
        ];
        $I->sendPUT(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' =>
            array(
                'address' =>
                array(
                    "id" => 'integer',
                    'address' => 'string',
                    'landmark' => 'string|null',
                    'pincode' => 'integer|null',
                    'city' => 'string',
                    'latitude' => 'string|null',
                    'longitude' => 'string|null',
                    'clientId' => 'string|null'
                ),
            ),
        ));
        $I->seeResponseContainsJson(
            ["address" => [
                "id" => $addressId,
                "address" => "#48, 3rd cross, 31st Main, BTM layout 2nd stage",
                "city" => "Bengaluru",
                "clientId" => 1003,
                "latitude" => "11.9000000000000"]
            ]
        );
    }
*/
}
