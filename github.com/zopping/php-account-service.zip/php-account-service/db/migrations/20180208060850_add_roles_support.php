<?php

use Phinx\Migration\AbstractMigration;

class AddRolesSupport extends AbstractMigration
{
   public function up()
    {
        // Add table roles
        $this->createRoles();
        // Add table to map user to roles
        $this->createRoleUserMapping();
        // Add table to map role to endpoints
        $this->createRoleEndpointMapping();

        $roles = [["name" => "PICKER"],["name" => "CHECKER"],["name" => "PACKER"], ["name" => "DELIVERY AGENT"]];
        $this->insert('roles', $roles);
        $endpoints = ['account-service/me' => ['GET', 'PUT', 'DELETE'],
            'account-service/logout' => ['POST'],'order-service/picking-queue' => ['GET'],
            'order-service/checking-queue' => ['GET'],'order-service/packing-queue' => ['GET'],
            'order-service/order' => ['GET', 'PUT'], 'logistics-service/trip' => ['GET']];
        $pickerEndpoints = ["'account-service/me'", "'account-service/logout'", "'order-service/order'", "'order-service/picking-queue'"];
        $pickerRoleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in (". implode(',', $pickerEndpoints) . ")");
        $this->mapEndpoints(1, $pickerRoleEndpoints, $endpoints);
        $checkerEndpoints = ["'account-service/me'", "'account-service/logout'", "'order-service/order'", "'order-service/checking-queue'"];
        $checkerRoleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in (". implode(',', $checkerEndpoints) . ")");
        $this->mapEndpoints(2, $checkerRoleEndpoints, $endpoints);
        $packerEndpoints = ["'account-service/me'", "'account-service/logout'", "'order-service/order'", "'order-service/packing-queue'"];
        $packerRoleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in (". implode(',', $packerEndpoints) . ")");
        $this->mapEndpoints(3, $packerRoleEndpoints, $endpoints);
        $deliveryAgentEndpoints = ["'account-service/me'", "'account-service/logout'", "'order-service/order'", "'logistics-service/trip'"];
        $deliveryRoleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in (". implode(',', $deliveryAgentEndpoints) . ")");
        $this->mapEndpoints(4, $deliveryRoleEndpoints, $endpoints);
        $endpointData = [
            [
                "url" => "account-service/role",
                "allowed_methods" => json_encode(['GET']),
                "extension_id" => null
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute(
            "delete from endpoints where url ='account-service/role'"
        );
        $this->dropTable('endpoint_role');
        // Drop table role_users
        $this->dropTable('role_user');
        // Drop table roles
        $this->dropTable('roles');
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'], 'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }
    
    private function createRoles()
    {
        $this->table('roles')
             ->addColumn('name', 'string', ['limit' => 75, 'null' => false])
             ->addColumn('created_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
             ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
             ->addColumn('deleted_at', 'timestamp', ['null' => true])
             ->addIndex(['name'], ['unique' => true])
             ->create();
    }

    private function createRoleUserMapping()
    {
        $this->table('role_user')
            ->addColumn('role_id','integer')
            ->addColumn('user_id', 'integer')
            ->addColumn('created_at', 'timestamp', ['null' => false, 'default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addForeignKey('role_id', 'roles', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addForeignKey('user_id', 'users', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addIndex(['role_id','user_id'], ['unique' => true, "name" => "role_user_idx"])
            ->create();
    }
    
    private function createRoleEndpointMapping()
    {
        $this->table('endpoint_role')
            ->addColumn('endpoint_id','integer')
            ->addColumn('role_id', 'integer')
            ->addColumn('method', 'enum', array('values' => ["GET", "POST", "PUT", "DELETE"], 'default' => 'GET'))
            ->addColumn('created_at', 'timestamp', ['null' => false, 'default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addForeignKey('endpoint_id', 'endpoints', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addForeignKey('role_id', 'roles', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addIndex(['endpoint_id','role_id'], ["name" => "endpoint_role"])
            ->create();
    }

}
