<?php

class CustomerPutCest
{
    protected static $endpoint = '/customer';
    protected static $table    = "customers";
/*
    public function updatingName(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "name" => "Roshan"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(["name" => "Roshan"]);
    }

    public function updatingNameAsNull(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "name" => null]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(["name" => "Roshan"]);
    }
*/
    public function updatingNameAsEmptyString(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "name" => ""]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Invalid Name"]);
    }
/*
    public function updatingDefaultAddress(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "defaultAddressId" => 2]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $defaultAddresId = $I->grabDataFromResponseByJsonPath("$.data.customer.defaultAddress.id")[0];
        $I->assertEquals($defaultAddresId, 2);
    }
*/
    public function updatingDefaultAdresssToOthersAddress(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "defaultAddressId" => 30]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Address with id: 30 not found"]);
    }

    public function updatingDefaultAdresssToInValidAddress(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "defaultAddressId" => "xyz"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Address with id: xyz not found"]);
    }
/*
    public function updatingDefaultAddressAsNull(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "defaultAddressId" => null]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeInDatabase(self::$table, ["id" => 5, "default_address_id" => 2]);
    }

    public function updatingDefaultAddressAsEmptyString(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 2, "defaultAddressId" => ""]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Address with id:  not found"]);
    }

    public function updatingDefaultPhone(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 3, "organizationId" => 1, "defaultPhoneId" => 7]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $defaultPhoneId = $I->grabDataFromResponseByJsonPath("$.data.customer.defaultPhone.id")[0];
        $I->assertEquals($defaultPhoneId, 7);
    }
*/
    public function updatingDefaultPhoneToOthersPhone(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 3, "organizationId" => 1, "defaultPhoneId" => 30]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Phone with id: 30 not found"]);
    }

    public function updatingDefaultPhoneToInValidPhone(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 3, "organizationId" => 1, "defaultPhoneId" => "xyz"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Phone with id: xyz not found"]);
    }
/*
    public function updatingDefaultPhoneAsNull(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 3, "organizationId" => 1, "defaultPhoneId" => null]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeInDatabase(self::$table, ["id" => 3, "default_Phone_id" => 7]);
    }

    public function updatingDefaultPhoneAsEmptyString(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 3, "organizationId" => 1, "defaultPhoneId" => ""]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Phone with id:  not found"]);
    }

    public function updatingDefaultEmail(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 4, "organizationId" => 1, "defaultEmailId" => 8]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $defaultEmailId = $I->grabDataFromResponseByJsonPath("$.data.customer.defaultEmail.id")[0];
        $I->assertEquals($defaultEmailId, 8);
    }
*/
    public function updatingDefaultEmailToOthersEmail(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 4, "organizationId" => 1, "defaultEmailId" => 300]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Email with id: 300 not found"]);
    }

    public function updatingDefaultEmailToInValidEmail(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 4, "organizationId" => 1, "defaultEmailId" => "xyz"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Email with id: xyz not found"]);
    }
/*
    public function updatingDefaultEmailAsNull(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 4, "organizationId" => 1, "defaultEmailId" => null]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeInDatabase(self::$table, ["id" => 4, "default_Email_id" => 8]);
    }

    public function updatingDefaultEmailAsEmptyString(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 4, "organizationId" => 1, "defaultEmailId" => ""]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Email with id:  not found"]);
    }

    public function updatingOrganizationId(ApiTester $I)
    {
        $I->sendPUT(self::$endpoint, ["id" => 5, "organizationId" => 3]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Customer with id 5 and organization_id 3 not found"]);
    }
*/
}
