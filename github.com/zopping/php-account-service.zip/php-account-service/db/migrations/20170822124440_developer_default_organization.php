<?php

use Phinx\Migration\AbstractMigration;

class DeveloperDefaultOrganization extends AbstractMigration
{
    /**
     * Default value for organization id must be null
     */
    public function change()
    {
        $developers = $this->table('developers');
        $developers->changeColumn('organization_id', 'integer', array('limit' => 11, 'null' => true))
                ->save();
    }
}
