<?php

use Phinx\Migration\AbstractMigration;

class AddTagsExtension extends AbstractMigration
{
    private $slug = "CustomerTags";

    public function up()
    {
        $enableHelperText = "Customer Tags help you segregate customers into groups. There are system generated tags and custom tags.";
        $disableHelperText = "You can no longer manage system and custom generated tags for customers";
        $data = [
            "name" => "Customer Tags",
            "slug" => $this->slug,
            "description" => "$enableHelperText,",
            "enable_helper_text" => "",
            "disable_helper_text" => $disableHelperText,
            "icon" => "https://storage.googleapis.com/zopsmart-uploads/originals/20190121/UserTags-20190121-073555.png",
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);

        $endpoints = [
            [
                'url' => 'customer-service/tag',
                'allowed_methods' => json_encode(["GET","POST","PUT","DELETE"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);

        $endpoints = [
            [
                'url' => 'customer-service/customer/{id}/tag',
                'allowed_methods' => json_encode(["GET","POST","DELETE"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }
 
    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in ('customer-service/tag','customer-service/customer/{id}/tag')"),
            'id'
        );
        if(sizeof($endpointIds)>0) {
        $this->execute("DELETE from `endpoint_developer_permissions` where endpoint_id in"
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoints` where `id` in "
            . " ( " . implode(",", $endpointIds) . ")");
        }
        $this->execute("DELETE from `extension_organization` where `extension_id` = '$extensionId'");
        $this->execute("DELETE from `extensions` where `id` = $extensionId");
    }
}
