<?php

require_once('BaseCest.php');
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class ChangePasswordPostCest extends BaseCest
{
    protected static $endpoint = '/changePassword';
    protected static $table= 'users';


    public function changePasswordWithDifferentNewPassword(ApiTester $I)
    {
        $I->wantTo("Change the password of the user with old password being different from new password");
        $data=[
                "user"=> '{
                            "id": 12,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => 'justatestpassword',
                "newPassword" => 'password123',
        ];
        
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["status" => "SUCCESS","message" => "Password changed successfully!"]);
    }
    
     public function changePasswordWithIncorrectOldPassword(ApiTester $I)
    {
        $I->wantTo("Change the password of the user with incorrect old password");
        $data=[
                "user"=> '{
                            "id": 50,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => 'password123',
                "newPassword" => 'pass',
        ];
        
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Cannot change password, old password incorrect","status" => "ERROR"]);
    }
    
    
    public function changePasswordWithSameOldPassword(ApiTester $I)
    {
        $I->wantTo("Change the password with new password being the same as the old password");
        $data=[
                "user"=> '{
                            "id": 28,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => 'justatestpassword',
                "newPassword" => 'justatestpassword',
        ];
        
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: New password cannot be same as the old password",
    "status"=> "ERROR"]);
                
    }
    
    public function changePasswordWithMissingOldPassword(ApiTester $I)
    {
        $I->wantTo("Change the password without providing the old password");
         $data=[
                "user"=> '{
                            "id": 28,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => '',
                "newPassword" => 'justatestpassword',
        ];
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Missing Required Field - changepassword : old Password",
    "status"=> "ERROR"]);
    }
    
    public function changePasswordWithMissingNewPassword(ApiTester $I)
    {
        $I->wantTo("Change the password without providing the new password");
         $data=[
                "user"=> '{
                            "id": 28,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => 'justatestpassword',
                "newPassword" => '',
        ];
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Missing Required Field - changepassword : new Password",
    "status"=> "ERROR"]);
    }
    
    public function changePasswordWithMissingOldAndNewPassword(ApiTester $I)
    {
         $I->wantTo("Change the password without providing the old and the new password");
         $data=[
                "user"=> '{
                            "id": 28,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => '',
                "newPassword" => '',
        ];
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Missing Required Field - changepassword : old Password",
    "status"=> "ERROR"]);
    }
    
    public function changePasswordWithoutId(ApiTester $I)
    {
         $I->wantTo("Change the password without providing the user id");
         $data=[
                "user"=> '{
                            "id": ,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => 'justatestpassword',
                "newPassword" => 'password123',
        ];
        $I->sendPost(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Validation Exception: Missing Required Field - user : id",
    "status"=> "ERROR"]);
    }
    
    public function ChangePasswordWithAbsentUserId(ApiTester $I)
    {
        $I->wantTo("Change the password providing user id that is absent in the db");
         $data=[
                "user"=> '{
                            "id": 121,
                            "name": "Admin",
                            "organizationId": 1,
                            "isOwner": 1,
                            "email": "admin@zopnow.com",
                            "phone": "9999999001",
                            "accessToken": "1499940878.4168zop5967480e65c101.15998648"
                }',
                
                "oldPassword" => 'justatestpassword',
                "newPassword" => 'password123',
        ];
        
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message"=> "Model Exception: User with id: 121 not found",
            
    "status"=> "ERROR"]);
    }
}

