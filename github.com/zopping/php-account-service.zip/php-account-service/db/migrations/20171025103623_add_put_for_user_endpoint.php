<?php

use Phinx\Migration\AbstractMigration;

class AddPutForUserEndpoint extends AbstractMigration
{
    public function change()
    {
        $methods = ['GET', 'POST', 'PUT'];
        $this->execute(
            "update endpoints set allowed_methods = '" . json_encode($methods)
            . "' where url = 'account-service/user'"
        );
    }
}
