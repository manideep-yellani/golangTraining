<?php

use Phinx\Migration\AbstractMigration;

class MapCsRoleEndpoints extends AbstractMigration
{
    public function up() {
        $roleIds = array_column($this->fetchAll("select id from roles where `name` in ('CS MANAGER', 'CS AGENT')"), 'id');
        $endpoints = [
            'account-service/store' => ['GET'],
            'account-service/config' => ['GET'],
            'account-service/extension' => ['GET'],
            'logistics-service/tripLocations' => ['GET'],
        ];
        $csAgentEndpoints = array_keys($endpoints);
        $csAgentRoleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in ('". implode("','", $csAgentEndpoints) . "')");
        $this->mapEndpoints($roleIds[0], $csAgentRoleEndpoints, $endpoints);
        $this->mapEndpoints($roleIds[1], $csAgentRoleEndpoints, $endpoints);
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'], 'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }

    public function down() {
        $roleIds = array_column($this->fetchAll("select id from roles where `name` in ('CS MANAGER', 'CS AGENT')"), 'id');
        $endpoints = [
            'account-service/store',
            'account-service/config',
            'account-service/extension',
            'logistics-service/tripLocations',
        ];
        $endpointIds = array_column($this->fetchAll("select id from endpoints where `url` in ('". implode("','", $endpoints) . "')"), "id");
        $this->execute(
            "delete from endpoint_role where role_id in ('" . implode("','", $roleIds) . "') "
                . "and endpoint_id in ('" . implode("','", $endpointIds) . "') "
        );
    }
}
