<?php

class OrganizationPostCest extends BaseCest
{
    protected static $endpoint = '/organization';
    protected static $table = 'organizations';
/*
    public function createOrganization(ApiTester $I)
    {
        $I->wantTo("Create organization with basic data");
        $data = [
            'name' => 'My More Store',
            'domain' => 'mymorestore.zopexpress.com',
            'currencyId' => 2,
            'logo' => 'http://kikkidu.com/wp-content/uploads/2011/08/hyperCity_250.jpg',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        unset($data['currencyId']);
        $I->seeResponseContainsJson($data);
        $databaseData = [
            'name' => 'My More Store',
            'domain' => 'mymorestore.zopexpress.com',
            'currency_id' => 2,
            'logo' => 'http://kikkidu.com/wp-content/uploads/2011/08/hyperCity_250.jpg',
        ];
        $I->seeInDatabase(static::$table, $databaseData);
    }

    public function createOrganizationWithoutName(ApiTester $I)
    {
        $I->wantTo("Create organization without name");
        $data = ['domain' => 'mymorestore.zopnow.express'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($data);
        $I->seeInDatabase(static::$table, $data);
    }

    public function createOrganizationWithoutDomain(ApiTester $I)
    {
        $I->wantTo("Create organization without domain");
        $data = ['name' => 'My More Store'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($data);
        $I->seeInDatabase(static::$table, $data);
    }
*/
    public function createOrganizationExistingDomain(ApiTester $I)
    {
        $I->wantTo("Create organization with an existing domain");
        $data = ["name" => "Silbatti restaurant", "domain" => "silbatti.zopexpress.com"];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Organization already exists']);
    }

    public function createOrganizationInvaidDomain(ApiTester $I)
    {
        $I->wantTo("Create organization with invalid domain");
        $data = ["name" => "Test", "domain" => "test*gmail.com"];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid domain']);
    }

    public function createOrganizationInvalidCurrencyId(ApiTester $I)
    {
        $I->wantTo("Create organization with invalid currency id");
        $data = ["currencyId" => 1000];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Model Exception: Currency with id: 1000 not found']);
    }

    public function createOrganizationInvalidLogo(ApiTester $I)
    {
        $I->wantTo("Create organization with invalid logo");
        $data = ["logo" => ":logo.png"];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid logo']);
    }

    public function addingOrganizationWithInvalidTheme(ApiTester $I)
    {
        $I->wantTo("Add organizations with invalid theme");
        $data = ["name" => "ZopExpress", "domain" => "zopexpress.com", "themeId" => 998];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Theme with id: 998 not found"]);
    }
/*
    public function addingOrganizationWithProperTheme(ApiTester $I)
    {
        $I->wantTo("Add organizations with valid theme");
        $data = ["name" => "ZopExpress", "domain" => "zopexpress.com", "themeId" => 6];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $themeId = $I->grabDataFromResponseByJsonPath("$.data.organization.theme.id")[0];
        $I->assertEquals($themeId, 6);
    }*/
}
