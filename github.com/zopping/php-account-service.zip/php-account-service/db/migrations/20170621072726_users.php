<?php

use Phinx\Migration\AbstractMigration;

class Users extends AbstractMigration
{
    /**
     * Database schema for "users" table
     * It consists of the following fields :
     * name : stores the name of the user
     * email : stores the email_id of the user
     * phone : stores the phone number of the user
     * username : stores the username for the user which will be used while logging in
     * password : stores the encrypted password for the user
     * organization_id : the id for the organization to which the user belongs to
     * is_owner : stores 1 if the user is the owner of the organization otherwise 0 for the other users
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     * deleted_at : field will be NULL. This field will be set to the timestamp when the organization is deleted and it is a soft delete.
     *
     * "id" is the primary key for the table. "email", "phone" and "username" are the unique indexes for the table
     * "organization_id" is a foriegn key which references the organizations table
     */
    public function change()
    {
        $table = $this->table('users');
        $table->addColumn('name', 'string', array('limit' => 200))
              ->addColumn('email', 'string', array('limit' => 100))
              ->addColumn('phone', 'biginteger', array('limit' => 12,'signed' => false))
              ->addColumn('username', 'string', array('limit' => 200))
              ->addColumn('password', 'string', array('limit' => 45))
              ->addColumn('organization_id', 'integer', array('limit'=> 11))
              ->addColumn('is_owner', 'boolean',array('default' => 0))
              ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
              ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
              ->addColumn('deleted_at', 'timestamp', array('null' => true))
              ->addIndex(array('email'), array('unique' => true))
              ->addIndex(array('phone'), array('unique' => true))
              ->addIndex(['username', 'organization_id'], ['name' => 'user_organization'])
              ->addForeignKey('organization_id', 'organizations', 'id')
              ->create();
    }
}
