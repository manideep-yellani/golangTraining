<?php

use Phinx\Migration\AbstractMigration;

class AddDefaultStoreIdInOrganization extends AbstractMigration
{
    public function up()
    {
        $this->table("organizations")
            ->addColumn("default_store_id", "integer", ["after" => "status", "null" => true])
            ->addForeignKey("default_store_id", "stores", "id", array('constraint' => 'fk_organizations_stores', 'delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->save();
    }

    public function down()
    {
        $this->table("organizations")
            ->dropForeignKey('default_store_id')
            ->removeColumn('default_store_id')
            ->save();
    }
}
