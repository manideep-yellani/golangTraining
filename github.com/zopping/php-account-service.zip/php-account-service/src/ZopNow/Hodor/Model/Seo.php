<?php

namespace ZopNow\Hodor\Model;


class Seo extends \ZopNow\Arya\Model\Base
{
    protected $table = 'seo';
    protected $hidden = ['updated_at', 'created_at','pivot','page_id','organization_id'];

    protected $with = ['page','organization'];

    public function page(){
        return $this->belongsTo('ZopNow\Hodor\Model\Page');
    }

    public function organization(){
        return $this->belongsTo('ZopNow\Hodor\Model\Organization');
    }

}
