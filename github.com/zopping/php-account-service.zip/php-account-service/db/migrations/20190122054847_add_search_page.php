<?php

use Phinx\Migration\AbstractMigration;

class AddSearchPage extends AbstractMigration
{
    public function up()
    {
	$this->insert('pages', ["id" => 8, "name" => "SEARCH"]);
    }

    public function down()
    {
        $this->execute("DELETE from `pages` where `id` = 8");
    }
}
