<?php

namespace ZopNow\Hodor\Model;

class Currency extends \ZopNow\Arya\Model\Base
{

}
