<?php

namespace ZopNow\Hodor\Controller;

class Designation extends \ZopNow\Arya\Controller\ModelController
{
    protected $allowNonPaginated = true;
    protected static $filterableFields = ['organization_id', 'name', 'manager_id'];
    private static $allowedTypes = ['FLEXI', 'FIXED'];

    public function get()
    {
        $this->getRequestParams(['organizationId']);
        $id = $this->id;
        $data = null;
        if (!empty($id)) {
            if ($this->organizationId != $this->model->organization_id) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid Designation");
            }
            $data = $this->getDetails();
        } else {
            if (!empty($this->data['name'])) {
                $this->data['name'] = $this->data['name'] . "*";
            }
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function post()
    {
        $fields = $this->getRequestParams(['organizationId', 'name', 'timingType'], ['managerId', 'roleIds']);
        if (!in_array($fields['timingType'], self::$allowedTypes)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Timing type");
        }
        if (!$this->model->isValidName($fields['name'], $this->organizationId)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid name");
        }
        if (!empty($fields['managerId']) && !$this->model->isValidDesignation($fields['managerId'], $this->organizationId)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid designation");
        }
        $this->add($fields);
        if (!empty($fields['roleIds'])) {
            $this->updateRoles($fields['roleIds']);
        }
        $this->model = $this->modelClass::find($this->model->id);
        $details = $this->getDetails();
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $details,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function put()
    {
        $fields = $this->getRequestParams(['id', 'organizationId'], ['name', 'timingType', 'managerId', 'roleIds']);
        if ($this->model->organization_id != $this->organizationId) {
            throw new \ZopNow\Arya\Exception\ModelException("Designation not found");
        }
        if (!empty($fields['timingType']) && !in_array($fields['timingType'], self::$allowedTypes)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Timing type");
        }
        if (!empty($fields['name']) && $fields['name'] != $this->model->name && !$this->model->isValidName($fields['name'], $this->organizationId)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid name");
        }
        if (!empty($fields['managerId']) && ($this->model->manager_id != $fields['managerId']) && 
                (!$this->model->isValidDesignation($fields['managerId'], $this->organizationId) || ($fields['managerId'] == $this->id))) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid designation");
        }
        if (isset($fields['managerId']) && empty($fields['managerId'])) { // when empty string is passed, remove manager
            $fields['managerId'] = null;
        }
        $this->edit($fields);
        if (isset($fields['roleIds'])) {
            $this->updateRoles($fields['roleIds']);
        }
        $this->model = $this->modelClass::find($this->model->id);
        $details = $this->getDetails();
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $details,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function delete()
    {
        $data = $this->getRequestParams(['organizationId', 'id']);
        if ($this->model->organization_id != $data['organizationId']) {
            throw new \ZopNow\Arya\Exception\ModelException(
                "Designation with id: " . $data['id'] . " not found"
            );
        }
        $userController = new User(
            ['organizationId' => $data['organizationId'], 'designationId' => $data['id']]
        );
        $userResponse = $userController->get()->getData()['data'];
        if ($userResponse['count'] > 0) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Designation cannot be deleted as there are users mapped to it"
            );
        }
        parent::delete();
        $response = array(
            'status' => 'SUCCESS',
            'message' => 'Designation deleted successfully',
            'data' => null
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    private function updateRoles($roleIds)
    {
        $this->model->updateRoles($roleIds);
        $users = $this->model->users;
        foreach ($users as $user) {
            $user->roles()->sync($roleIds);
        }
    }

}
