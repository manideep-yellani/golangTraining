<?php

use Phinx\Migration\AbstractMigration;

class AddCsRoles extends AbstractMigration
{
    public function up() {
        $roles = [["name" => "CS AGENT"],["name" => "CS MANAGER"]];
        $this->insert('roles', $roles);
        $roleIds = array_column($this->fetchAll("select id from roles where `name` in ('CS MANAGER', 'CS AGENT')"), 'id');
        $endpoints = [
            'account-service/me' => ['GET', 'PUT', 'DELETE'],
            'account-service/logout' => ['POST'],
            'account-service/logout' => ['POST'],
            'customer-service/customer' => ['GET', 'PUT'],
            'customer-service/address' => ['PUT', 'POST', 'DELETE'],
            'customer-service/phone' => ['PUT', 'POST', 'DELETE'],
            'communication-service/email' => ['POST'],
            'communication-service/sms' => ['POST'],
            'communication-service/call' => ['POST'],
            'customer-service/reset-password' => ['POST'],
            'order-service/order' => ['GET', 'PUT'],
            'order-service/order-log' => ['GET'],
            'order-service/slot' => ['GET'],
            'catalogue-service/product' => ['GET'],
            'logistics-service/trip' => ['GET']
        ];
        $csAgentEndpoints = array_keys($endpoints);
        $csAgentRoleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in ('". implode("','", $csAgentEndpoints) . "')");
        $this->mapEndpoints($roleIds[0], $csAgentRoleEndpoints, $endpoints);
        $this->mapEndpoints($roleIds[1], $csAgentRoleEndpoints, $endpoints);
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'], 'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }

    public function down() {
        $roleIds = array_column($this->fetchAll("select id from roles where `name` in ('CS MANAGER', 'CS AGENT')"), 'id');
        $this->execute(
            "delete from endpoint_role where role_id in ('" . implode("','", $roleIds) . "')"
        );
        $this->execute(
            "delete from roles where name in ('CS AGENT', 'CS MANAGER')"
        );
    }
}
