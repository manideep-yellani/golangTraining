<?php

use Phinx\Migration\AbstractMigration;

class AddRechargeOnlinePaymentEndpoint extends AbstractMigration
{

    public function up()
    {
        $endpointData = [
            ["url" => "billing-service/online-payment","allowed_methods" => json_encode(['POST'])],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE FROM `endpoints` where `url` = "billing-service/online-payment"');
    }

}
