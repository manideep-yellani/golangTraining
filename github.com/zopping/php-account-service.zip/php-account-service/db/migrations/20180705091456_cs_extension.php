<?php

use Phinx\Migration\AbstractMigration;

class CsExtension extends AbstractMigration
{
    private $slug = "CustomerSupport";

    public function change()
    {
        $enableHelperText  = "Provides an interface to manage all your customers | "
            . "Search customers from phone number/email/order number | "
            . "Manage customer support agents";
        $disableHelperText = "You will not be able to search customers from phone number/email/order number | "
            . "You will not be able to manage customer support agents";
        $data              = [
            "name" => "Customer Support Features",
            "slug" => $this->slug,
            "icon" => "https://s3.ap-south-1.amazonaws.com/zopnow-uploads/customer%20support-20180705-093640.png",
            "description" => "Allows you to manage all your customers, their emails/calls etc.",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing_rule" => json_encode(['FREE' => 0, 'TYPE' => 'MONTHLY', 'RATE' => 'FIXED', 'COST' => 1000]),
            "pricing" => "₹ 1000 per month per customer support agent",
        ];
        $this->insert('extensions', $data);
    }

    public function down()
    {
        $this->execute("DELETE extension_organization.* from `extension_organization` inner join extensions on extensions.id = extension_id and `slug` ='$this->slug'");
        $this->execute("DELETE from `extensions` where `slug` ='$this->slug'");
    }
}