<?php

use Phinx\Migration\AbstractMigration;

class OrganizationChange extends AbstractMigration
{
    /**
     * Allowing null values to be entered in name, slug and domain fields in organizations table
     */
    public function change()
    {
        $organization = $this->table('organizations');
        $organization->changeColumn('name', 'string', array('limit' => 200, 'null' => true))
                    ->changeColumn('slug', 'string', array('limit' => 250, 'null' => true))
                    ->changeColumn('domain', 'string', array('limit' => 100, 'null' => true))   
                    ->save();
    }
}
