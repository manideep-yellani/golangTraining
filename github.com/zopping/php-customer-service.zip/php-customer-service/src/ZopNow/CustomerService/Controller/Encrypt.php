<?php

namespace ZopNow\CustomerService\Controller;

class Encrypt extends \ZopNow\Arya\Controller\Base
{

  public function get(){

    $data = $this->getRequestParams(['insecure']);
    $secure = \ZopNow\Arya\Utility\Encryption::encrypt($data['insecure'], FALSE);

    return new \ZopNow\Arya\View\Base([
      "code" => 200,
      "status" => "SUCCESS",
      "message" => "Password encrypted successfully!",
      "data" => $secure
    ]);
  }
}
