<?php

use Phinx\Migration\AbstractMigration;

class AddCustomerRequired extends AbstractMigration
{
    public function change()
    {
        $this->table('endpoint_developer_permissions')
                ->addColumn('is_customer_required', 'boolean', ['default' => 0])
                ->save();
        $urls = [
            "customer-service/address",
            "customer-service/email",
            "customer-service/phone",
            "order-service/summary"
        ];
        $endpointIds = [];
        $data = $this->fetchAll("select * from endpoints where url in ('" . implode("','", $urls) . "')");
        foreach ($data as $row) {
            if ($row['url'] == 'order-service/summary') {
                $this->execute("update endpoint_developer_permissions set is_customer_required = 1"
                        . " where endpoint_id = " . $row['id'] . " and method = 'GET'");
            } else {
                $endpointIds[] = $row['id'];
            }
        }
        $this->execute("update endpoint_developer_permissions set is_customer_required = 1"
                        . " where endpoint_id in ('" . implode("','", $endpointIds) . "') and method = 'POST'");
    }
}
