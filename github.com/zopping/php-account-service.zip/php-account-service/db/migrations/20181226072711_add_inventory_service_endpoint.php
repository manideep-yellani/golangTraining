<?php

use Phinx\Migration\AbstractMigration;

class AddInventoryServiceEndpoint extends AbstractMigration
{

    public function up()
    {
        $endpoints = [
            [
                'url' => 'inventory-service/item',
                'allowed_methods' => json_encode(["GET", "POST"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down()
    {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                . "('inventory-service/item')"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('inventory-service/item')");
    }
}
