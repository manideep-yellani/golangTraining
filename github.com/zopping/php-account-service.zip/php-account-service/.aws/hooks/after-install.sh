#!/bin/bash
cd /var/www/account-service/;
composer update --quiet --no-ansi --no-dev --no-interaction --no-progress --no-scripts --no-plugins --optimize-autoloader;
mysql -usqluser -psqlpassword -h mysql-master.internal.zopnow.com -e 'CREATE DATABASE IF NOT EXISTS `organization_service`';
php vendor/bin/phinx migrate -e production;