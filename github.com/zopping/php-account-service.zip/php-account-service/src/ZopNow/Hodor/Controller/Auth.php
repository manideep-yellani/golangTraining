<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\App\WebApplication;
use ZopNow\Arya\Exception\AuthException;
use ZopNow\Hodor\Model\Developer;

/**
 * Class consists of the APIs for the user authentication
 */

class Auth extends \ZopNow\Arya\Controller\Base
{
    /**
     * @todo Find a better way to handle validation of APIs.
     */
    const PUBLIC_APIS = [
        'POST /account-service/auth',
        'POST /account-service/reset-password',
        'POST /account-service/me',
        'GET /account-service/verify',
        'GET /account-service/lang',
        'GET /account-service/country',
        'POST /billing-service/verify-payment',
        'PUT /communication-service/device',
        'GET /communication-service/twilio',
        'GET /billing-service/pricing-rule',
        'POST /gateway-internal/enquiry',
        'POST /gateway-internal/auth',
    ];

    /**
     * Method to authenticate the user and generate the access_token for the user.
     *
     * @uses username The username of the user
     * @uses password The password of the user
     * @uses slug The slug of the organization to which the user belongs to
     * @return array Returns the status, message and data of the API.
     * The data consists of the user details with the access token if the status is 200.
     * @throws \ZopNow\Arya\Exception\ModelException when the username is not found
     * @throws \ZopNow\Arya\Exception\AuthException when the slug of the organization passed is invalid
     * @throws 401 when the password does not match the password set by the user
     */
    public function post()
    {
        $isEmailVerified = true;
        $mandatoryFields = array('username', 'password');
        $data = $this->getRequestParams($mandatoryFields, ['remember', 'organization']);
        $remember = isset($data['remember']) && \ZopNow\Hodor\Helper\Validator::isBoolean($data['remember']) && (bool) $data['remember'] === true;
        //Check if it is an enterprise
        $orgId = NULL;
        if (isset($data['organization'])) {
            $org = \ZopNow\Hodor\Model\Organization::where("name", $data['organization'])->first();
            $orgId = $org->id;
        }
        $token = \ZopNow\Hodor\Auth\Auth::getToken($data['username'], $data['password'], $remember, $orgId);
        if ($token == false) {
            throw new \ZopNow\Arya\Exception\AuthException('Invalid Credentials');
        }
        $modelClass = \ZopNow\Hodor\Auth\Auth::AUTH_MODEL_NAME;
        $user = $modelClass::find(\ZopNow\Arya\Auth\Auth::$id);
        if(!$user->has_tool_access){
            throw new \ZopNow\Arya\Exception\AuthException('You do not have access.');
        }
        //Enterprise login check
        $isEnterprise = $user->organization->is_enterprise;
        if ((!empty($data['organization']) && !$isEnterprise) || (empty($data['organization']) && $isEnterprise)) {
            throw new \ZopNow\Arya\Exception\AuthException('Invalid Credentials');
        }
        if ($user->verified == 0) {
            $emails = $user->emails;
            $phones = $user->phones;
            //Check if all the emails have been verified
            foreach ($emails as $email) {
                if ($email->verified == 0) {
                    if (sizeof($phones) == 0) {
                        $email->verified = 1;
                        $email->save();
                    } else {
                        $isEmailVerified = false;
                        break;
                    }
                }
            }
            //Check if the phones have been verified
            foreach ($phones as $phone) {
                if ($phone->verified != 1) {
                    $phone->verified = 1;
                    $phone->save();
                }
            }
            if ($isEmailVerified) {
                $user->verified = 1;
                $user->save();
            }
        }
        $response = [];
        $response['user'] = $user->toArray();
        $response['user']['accessToken'] = $token;
        $permissions = $user->getPermissions();
        if (empty($permissions['userEndpointPermissions'])) {
            $response['user']['endpointPermissions'] = array_values($permissions['roleEndpointPermissions']);
        } else {
            // Merge both user level permissions and role level permissions
            foreach ($permissions['userEndpointPermissions'] as $extensionId => &$details) {
                if (!empty($permissions['roleEndpointPermissions'][$extensionId])) {
                    $methods = array_keys($permissions['roleEndpointPermissions'][$extensionId]['allowedMethods']);
                    foreach ($methods as $method) {
                        $details['allowedMethods'][$method] = true;
                    }
                }
            }
            $response['user']['endpointPermissions'] = array_values($permissions['userEndpointPermissions']);
        }
        $response['organization'] = $user->organization;

        try{
            $configResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", '/config/inStoreProcessing.packedOrderEditAllowed', 'GET', array('organizationId' => $response['organization']['id']));
        }catch (\Exception $ex){
            \ZopNow\Arya\App\Application::log("Failed to get config-service response :- " . $ex->getMessage());
        }
        if (isset($configResponse['body'])){
            $configResponseBody=json_decode($configResponse['body'], true);
        }else{
            $configResponseBody=null;
        }

        if (isset($configResponseBody['data'])){
            $response['organization']['config']=$configResponseBody['data'];
        }else{
            $response['organization']['config']=null;
        }

        return new \ZopNow\Arya\View\Base([
                'code' => 200,
                'status' => "SUCCESS",
                'data' => $response,
            ]);
    }

    public function get()
    {
        $mandatoryFields = array('api','method');
        $data = $this->getRequestParams($mandatoryFields);
        $responseData = [];
        /**
         * @todo Check whether the API is a public API using the DB instead of the mapping here
         */
        if (!(in_array((strtoupper($data['method']).' /'.strtolower($data['api'])), self::PUBLIC_APIS))) {
            if (empty($this->data['accessToken']) && empty($this->data['developerToken'])) {
                throw new \ZopNow\Arya\Exception\AuthException("Unauthorized");
            }
            if (!empty($this->data['accessToken'])) {
                $storeId = !empty($this->data['storeId']) ? $this->data['storeId'] : NULL;
                $user = \ZopNow\Hodor\Auth\Auth::validateToken($this->data['accessToken'], $data['api'], $data['method'], $storeId);
                $responseData['user'] = $user->toArray();
                $responseData['organization'] = $user->organization;
            }
            if (!empty($this->data['developerToken'])) {
                $this->data['developerToken'] = \ZopNow\Arya\Utility\Encryption::encrypt($this->data['developerToken'], false);
                //Get organization details with developer token
                $developer = Developer::where('token', $this->data['developerToken'])->first();
                if (is_null($developer)) {
                    throw new \ZopNow\Arya\Exception\AuthException("Unauthorized");
                }
                $responseData['developer'] = $developer->toArray();
                $organization = $developer->organization;
                if (!empty($responseData['organization'])) {
                    if ($developer->organization->id != $responseData['organization']['id']) {
                        WebApplication::log("Mismatch in organization between developer token and access token", $this->data, 'ERROR');
                        throw new AuthException("Unauthorized");
                    }
                } else {
                    if (is_null($organization) && !empty($this->data['filter'])) {
                        if (!empty($this->data['filter']['id'])) {
                            $organizationController = new Organization(['id' => $this->data['filter']['id']]);
                            $organization = $organizationController->get()->getData()['data']['organization'];
                        } else if (!empty($this->data['filter']['domain'])) {
                            $organizationController = new Organization(['domain' => $this->data['filter']['domain']]);
                            $organization = $organizationController->get()->getData()['data']['organization'][0] ?? null;
                            if (is_null($organization)) {
                                throw new AuthException("Unauthorized");
                            }
                        }
                    }
                    $responseData['organization'] = $organization;
                }
                $developerPermissions = $developer->getPermissionDetails($data['api'], $data['method'], $organization['id']);
                if (empty($developerPermissions)) {
                    throw new \ZopNow\Arya\Exception\AuthException("Unauthorized");
                }
                $responseData['customer'] = null;
                if (!empty($organization)) {
                    $responseData['customer'] = $this->getCustomerDetails($developerPermissions['is_customer_required'], $organization['id']);
                }
                if (empty($responseData['customer']) && $developerPermissions['is_customer_required'] == true) {
                    throw new AuthException("Customer is unauthorized");
                }
            }
            if (!empty($responseData['organization']['id'])){
                if ((strpos($data['api'], "gateway-internal")!== false)&&($responseData['organization']['id']!=1)){
                     throw new \ZopNow\Arya\Exception\ForbiddenException("Forbidden");
                }    
            }
        }
        return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $responseData
        ]);
    }

    private function getCustomerDetails($isCustomerRequired, $organizationId)
    {
        $customer = null;
        //Fetch customer details from customer service if endpoint requires customer details
        if ($isCustomerRequired == true && empty($this->data['customerToken'])) {
            throw new \ZopNow\Arya\Exception\AuthException("Customer is unauthorized");
        }
        if (!empty($this->data['customerToken'])) {
            $requestData = ['accessToken' => $this->data['customerToken'], 'organizationId' => $organizationId];
            $customerDetails = \ZopNow\Arya\Utility\MicroService::callService("customer-service", '/login', 'GET', $requestData);
            if ($customerDetails['statusCode'] == 200) {
                $customer = json_decode($customerDetails['body'], true)['data']['customer'];
            }
        }
        return $customer;
    }

}
