<?php

namespace ZopNow\Hodor\Controller;

/**
 * Description of ChangePassword
 * Responsible for changing the user password and overriding the old password with the new password in the database.
 *
 * @author Amogh
 */
class ChangePassword extends \ZopNow\Arya\Controller\Base
{
    public function post()
    {
        $data = $this->getRequestParams(['user','oldPassword','newPassword']);
        $oldPassword = $data['oldPassword'];
        $newPassword = $data['newPassword'];
        $userJson= json_decode($data['user'], true);
        $userId=$userJson['id'];

        return (new User(['oldPassword'=>$oldPassword,'newPassword'=>$newPassword,'id'=>$userId]))->changePassword();
    }
}
