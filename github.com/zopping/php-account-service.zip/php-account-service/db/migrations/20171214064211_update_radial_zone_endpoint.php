<?php

use Phinx\Migration\AbstractMigration;

class UpdateRadialZoneEndpoint extends AbstractMigration
{
    public function up()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['GET','POST','PUT','DELETE'])
                . '\' where url = "logistics-service/radial-zone"');
    }

    public function down()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['GET','POST'])
                . '\' where url = "logistics-service/radial-zone"');
    }
}
