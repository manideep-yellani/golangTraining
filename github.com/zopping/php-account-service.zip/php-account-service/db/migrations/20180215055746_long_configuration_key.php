<?php

use Phinx\Migration\AbstractMigration;

class LongConfigurationKey extends AbstractMigration
{

    /**
     * Increasing the length of 'key' field to accept bigger configurations
     * like 'customerWalletRechargeEmailRecipients'.
     */
    public function change()
    {
        $this->table("configurations")->changeColumn("key", "string", array('limit' => 100, 'null' => FALSE));

    }
}
