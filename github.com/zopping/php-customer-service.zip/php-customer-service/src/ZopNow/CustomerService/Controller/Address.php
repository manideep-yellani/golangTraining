<?php

namespace ZopNow\CustomerService\Controller;

use ZopNow\Arya\Exception\ValidationException;

class Address extends Base
{
    protected static $filterableFields = ['customer_id', 'client_address_id','id'];

    public function post()
    {
       
        //In future, city will be taken from pincode.
        $mandatoryFields = array("organizationId", "address");
        $optionalFields = array("latitude", "longitude", "verifyAddress", "clientId",
            "metaData", "city","state","countryCode",
            "landmark", "pincode");
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);
        if (is_array($data['address'])) {
            $data = array_merge($data, $data['address']);
        }

        if(empty(trim($data["pincode"],' '))){
            $data["pincode"] = null;
        }

        if(empty(trim($data["state"],' '))){
            $data["state"] = null;
        }
        if(empty(trim($data["countryCode"],' '))){
            $data["countryCode"] = $this->getCountryCode($data["organizationId"]);
        }

        if ((!isset($data['verifyAddress'])) || (filter_var($data['verifyAddress'],FILTER_VALIDATE_BOOLEAN) === true)) {
            $this->checkServiceability();
        }
        $customerId = $this->getCustomerIdFromRequest();
        $currentCustomer = \ZopNow\CustomerService\Model\Customer::where(["id" => $customerId])->first();
        $existingAddress = null;
        if (!empty($data['clientId'])) {
            $existingAddress = \ZopNow\CustomerService\Model\Address::getAddressFromClientAddressId($data['organizationId'], $data['clientId']);
            $data['clientAddressId'] = $data['clientId'];
            unset($data['clientId']);
        }
        if (empty($existingAddress)) {
            $data['customerId'] = $customerId;
            $this->add($data);
            if (empty($currentCustomer->default_address_id)) {
                $currentCustomer->default_address_id = $this->data['id'];
            }
            $currentCustomer->updated_at = date("Y-m-d H:i:s");
            $currentCustomer->save();
        } else {
            $this->data = array_merge($this->data, $data);
            $this->data['id'] = $existingAddress->id;
            $this->model = $existingAddress;
            return $this->put();
        }
        $customer = $this->model->customer;
        $customer->updated_at = date("Y-m-d H:i:s");
        $customer->save();
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $this->getDetails()
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function save($data)
    {
        $data['latitude'] = isset($data['latitude']) ? floatval($data['latitude']) : null;
        $data['longitude'] = isset($data['longitude']) ? floatval($data['longitude']) : null;
        if (!empty($data['latitude']) && !\ZopNow\Arya\Utility\Validator::isLatitude($data['latitude'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid latitude");
        }
        if (!empty($data['longitude']) && !\ZopNow\Arya\Utility\Validator::isLongitude($data['longitude'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid longitude");
        }
        if (!empty($data['metaData'])) {
            if (!is_array($data['metaData'])) {
                throw new ValidationException("Invalid format for metadata");
            }
            $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'address']);
            $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
            if (empty($fieldData)) {
                throw new ValidationException("There is no metadata configured");
            }
            foreach ($data['metaData'] as $key => $value) {
                $flag = false;
                foreach ($fieldData as $customField) {
                    if ($key == $customField['key']) {
                        $flag = true;
                        $metaMap[$customField['id']] = $value;
                        break;
                    }
                }
                if ($flag == false) {
                    throw new ValidationException("$key not configured in metadata");
                }

            }
            $data['metaData'] = $metaMap;
        } else {
            $data['metaData'] = null;
        }


        return parent::save($data);
    }

    public function delete()
    {
        $customerId = $this->getCustomerIdFromRequest();
        if (empty($this->data['id'])) {
              throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid id");
        }
        if ($customerId != $this->model->customer_id) {
            throw new \ZopNow\Arya\Exception\ModelException("Address not found");
        }
        $defaultAddressId = $this->model->customer->default_address_id;
        if ($defaultAddressId == $this->data['id']) {
            throw new \ZopNow\Arya\Exception\ValidationException("Default address cannot be deleted");
        }
        //if count of addresses is 1 then dont allow deletion
        $addressCount = $this->model->customer->addresses->count();
        if ($addressCount == 1) {
            throw new \ZopNow\Arya\Exception\ValidationException("Address cannot be deleted as the customer has only 1 address");
        }
        $customer = $this->model->customer;
        $customer->updated_at = date("Y-m-d H:i:s");
        $customer->save();
        parent::delete();
        return (new \ZopNow\Arya\View\Base([
                'status' => "SUCCESS",
                'message' => 'Address deleted successfully',
                'data' => NULL
            ])
        );
    }

    public function checkServiceability()
    {
        $optionalFields = array("address", "landmark", "city", "state", "countryCode","pincode", "latitude", "longitude", "metaData");
        $data = $this->getRequestParams(['organizationId'], $optionalFields);
        if (is_array($data['address'])) {
            $data = array_merge($data, $data['address']);
        }

        $pincode = trim($data["pincode"],' ');
        if(empty($pincode)){
            $data["pincode"] = null;
        }
        if(empty(trim($data["state"],' '))){
            $data["state"] = null;
        }
        if(empty(trim($data["countryCode"],' '))){
            $data["countryCode"] = $this->getCountryCode($data["organizationId"]);
        }
        // Check if the address is served based on the serviceable areas configured by the organization
        $logisticsResponse = \ZopNow\Arya\Utility\MicroService::callService("go-logistics", "/serviceable-area", "GET", ['address' => $data, 'organizationId' => $data['organizationId']]);
        $resp = json_decode($logisticsResponse['body'], true);
        if (empty($resp['data'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Address is not served");
        }
    }

    public function getCustomerId()
    {
        return $this->model->customer_id;
    }

    public function get()
    {
        $data = $this->getRequestParams([], ['id', 'customerId','organizationId']);
        if (!empty($data['id']) && !is_array($data['id'])) {
            $this->getRequestParams(['customerId']);
            if ($data['customerId'] != $this->model->customer_id) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid customer");
            }
            $response = $this->getDetails();
        } elseif (!empty($this->data['clientId'])) {
            $params = $this->getRequestParams(['organizationId', 'clientId']);
            $existingAddress = \ZopNow\CustomerService\Model\Address::getAddressFromClientAddressId(
                $params['organizationId'], $params['clientId']);
            if (empty($existingAddress)) {
                throw new \ZopNow\Arya\Exception\ModelException(
                    "Address with client id " . $params['clientId'] . " not found"
                );
            }
            $this->model = $existingAddress;
            $this->data['id'] = $this->model->id;
            $response = $this->getDetails();
        } else {
            $list = $this->getList();
            $response = $this->getListData($list);
            $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'address']);
            $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
            foreach ($response['address'] as &$row) {
                $row['metaData'] = $this->getMetaData($row['metaData'], $fieldData);
            }

        }
        return (new \ZopNow\Arya\View\Base([
                'status' => "SUCCESS",
                'message' => 'OK',
                'data' => $response
            ])
        );
    }

    public function put()
    {
        $mandatoryFields = ["organizationId"];
        $optionalFields = ["latitude", "longitude", "clientId", "metaData", "address", "city", "state", "countryCode", "landmark", "pincode"];
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);
        if (empty($data['clientId'])) {
            $this->getRequestParams(['id']);
        } else if (!empty($data['clientId']) && !isset ($this->data['id'])) {
            $existingCust = \ZopNow\CustomerService\Model\Address::getAddressFromClientAddressId($data['organizationId'], $data['clientId']);
            if (empty($existingCust)) {
                throw new \ZopNow\Arya\Exception\ValidationException("No address found with the given client address id");
            }
            $this->model = $existingCust;
        }

        if(isset($data["pincode"]) && empty(trim($data["pincode"],' '))){
            $oldPincode = $this->model->pincode;
            $data["pincode"] = $oldPincode;
        }
        if(isset($data["state"]) && empty(trim($data["state"],' '))){
            $oldState = $this->model->state;
            $data["state"] = $oldState;
        }
        if(isset($data["countryCode"]) && empty(trim($data["countryCode"],' '))){
            $oldCountryCode = $this->model->country_code;
            $data["countryCode"] = $oldCountryCode;
        }

        $data['id'] = $this->model->id;
        $customerId = $this->getCustomerIdFromRequest();
        if ($customerId != $this->model->customer_id) {
            throw new \ZopNow\Arya\Exception\ModelException("Address not found");
        }
        if (!empty($data['clientId']) && ($data['clientId'] != $this->model->client_id)) {
            $existingAddress = \ZopNow\CustomerService\Model\Address::getAddressFromClientAddressId($data['organizationId'], $data['clientId']);
            if (!empty($existingAddress)) {
                throw new \ZopNow\Arya\Exception\ValidationException("Given client address id already exists");
            }
            $data['clientAddressId'] = $data['clientId'];
            unset($data['clientId']);
        }
        $data['customerId'] = $customerId;
        $address = $this->edit($data);
        $customer = $this->model->customer;
        $customer->updated_at = date("Y-m-d H:i:s");
        $customer->save();
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $redis->hDel("H:AddressAutoTaggingRetryCount",$data["id"]);
        return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $address
        ]);
    }

    public function getMetaData($customFieldMap, $fieldData)
    {
        if (empty($customFieldMap)) {
            return null;
        }
        foreach ($customFieldMap as $key => $value) {
            foreach ($fieldData as $customField) {
                if ($key == $customField['id']) {
                    $metaMap[$customField['key']] = $value;
                    break;
                }
            }
        }
        return $metaMap;
    }

    public function getDetails()
    {
        $details = parent::getDetails();
        $key = array_keys($details)[0];
        $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $this->data['organizationId'], 'entity' => 'address']);
        $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
        $details[$key]['metaData'] = $this->getMetaData($details[$key]['metaData'], $fieldData);
        if (in_array("zone", $this->include)) {
            $logisticsResponse = \ZopNow\Arya\Utility\MicroService::callService("logistics-service", "/serviceable-area", "GET", ['address' => $details[$key], 'organizationId' => $this->organizationId]);
            $resp = json_decode($logisticsResponse['body'], true);
            $details[$key]['zone'] = $resp['data']['zone'];
        }
        return $details;
    }

    private function getCountryCode($organizationId)
    {
        $orgData = \ZopNow\Arya\Utility\MicroService::callService(
            "go-account-service", "/organization", "GET", array("id" => $organizationId)
        );

        return json_decode($orgData['body'], true)['data']['organization']['countryCode'];
    }
}
