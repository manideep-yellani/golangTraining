<?php

use Phinx\Migration\AbstractMigration;

class AddZopnowTheme extends AbstractMigration
{
    public function up() {
        $themes = [
            [
                'name' => 'Zopnow',
                'image' => '{"desktop":"http://via.placeholder.com/1024x768","mobile":"http://via.placeholder.com/414x736","tablet":"http://via.placeholder.com/1024x768"}',
                "slug" => 'theme-zopnow',
                'description' => 'This is the ZopNow theme'
            ]
        ];
        $this->insert('themes', $themes);
    }

    public function down() {
        $this->execute("delete from themes where name = 'Zopnow'");
    }
}
