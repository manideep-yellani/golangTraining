<?php

use Phinx\Migration\AbstractMigration;

class PhoneNumberUpdate extends AbstractMigration
{
    /**
     * Adding the ISD code to phone numbers in phones table.
     */
    public function change()
    {
        $this->execute('UPDATE `phones` SET phone=concat(91, phone) WHERE length(phone) <= 10');
    }
}
