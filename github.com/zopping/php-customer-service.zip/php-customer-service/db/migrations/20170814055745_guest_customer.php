<?php

use Phinx\Migration\AbstractMigration;

class GuestCustomer extends AbstractMigration
{
    /**
     * Database schema for `guests` table. This table will be used to save the
     * required details of customer during guest checkout
     * 
     */
    public function change()
    {
        $this->table("guests")
            ->addColumn('name', 'string', array('limit' => 200))
            ->addColumn('organization_id', 'integer', array('limit'=> 11))
            ->addColumn("phone", 'biginteger', array('limit' => 12,'signed' => false))
            ->addColumn('email', 'string', array('limit' => 100))
            ->addColumn('address', 'string', array('limit' => 500))
            ->addColumn('landmark', 'string', array('limit' => 500))
            ->addColumn('pincode', 'integer', array('limit' => 6))
            ->addColumn('city', 'string', array('limit' => 200))
            ->addColumn('latitude', 'decimal', array('precision' => 16, 'scale' => 13, 'null' => true))
            ->addColumn('longitude', 'decimal', array('precision' => 16, 'scale' => 13, 'null' => true))
            ->addIndex(['phone'], ['name' => 'guest_phone'])
            ->addIndex(['email'], ['name' => 'guest_email'])
            ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->create();
    }
}
