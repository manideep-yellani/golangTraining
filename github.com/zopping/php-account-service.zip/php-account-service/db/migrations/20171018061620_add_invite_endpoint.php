<?php

use Phinx\Migration\AbstractMigration;

class AddInviteEndpoint extends AbstractMigration
{

    public function change()
    {
        $endpointData = [
                ["url" => "account-service/invite","allowed_methods" => json_encode(['POST'])]
        ];
        $this->insert('endpoints', $endpointData);
    }

}
