<?php

use Phinx\Migration\AbstractMigration;

class DropUsername extends AbstractMigration
{

    public function up()
    {
        $this->table('users')->removeColumn('username')->save();
    }

    public function down()
    {
        $this->table('users')->addColumn('username', 'string', array('limit' => 200))->save();
        $this->query('update users set username = email');
    }
}