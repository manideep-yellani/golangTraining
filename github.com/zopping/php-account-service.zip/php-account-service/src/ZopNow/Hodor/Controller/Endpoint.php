<?php

namespace ZopNow\Hodor\Controller;

class Endpoint extends \ZopNow\Arya\Controller\ModelController
{
    protected static $filterableFields = ['url'];

    public function get()
    {
        if (!empty($this->data['id'])) {
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }
}
