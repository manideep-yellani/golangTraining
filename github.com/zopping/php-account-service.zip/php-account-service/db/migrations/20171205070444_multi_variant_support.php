<?php

use Phinx\Migration\AbstractMigration;

class MultiVariantSupport extends AbstractMigration
{

    public function up()
    {
        $enableHelperText = "Products interface will allow user to add variants to their products | "
            . "It is not necessary to add variants for all products. However if you add a variant, you need to "
            . "specify mrp,discount, stock etc for these variants."
            . "Website will start showing variant, if the product has variant";

        $disableHelperText = "Products interface will not allow you to add variants to products | "
            . " Website will show only the products. None of the variants will be shown | "
            . " Product which earlier had multi variants will now get the price, stock etc from the first variant | "
            . " Pricing, discount, stock etc will be for prodicts and notfor variants";

        $data = [
            "name" => "Multi Variant Support",
            "slug" => "MultiVariantSupport",
            "description" => "Facilitates the organization to support multiple variants for their products",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => 'FREE'
        ];
        $this->insert('extensions',$data);
    }

    public function down()
    {
        $this->execute('DELETE from `extensions` where `slug` = "MultiVariantSupport"');
    }
}
