<?php


use Phinx\Migration\AbstractMigration;

class DropGuest extends AbstractMigration
{
    /**
     * Change Method.
     * Dropping Guest table. Customer and guest will be treated similarly.
     */
    public function change()
    {
        $this->table("guests")
            ->drop();
    }
}
