<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Exception\ValidationException;

class Employee extends \ZopNow\Arya\Controller\Base
{

    public function get()
    {
        $data = $this->getRequestParams(['organizationId'], ['id']);
        $this->data['include'] = ['shiftDetails'];
        $details = (new \ZopNow\Hodor\Controller\User($this->data))->get()->getData();
        if ((empty($data['id']) || is_array($data['id'])) && !empty($details['data']['user'])) {
            $details = $this->includeAdditonalDetails($details);
        } else if (!empty($data['id']) && !is_array($data['id'])) {
            $attendanceList = (new Attendance(['organizationId' => $this->organizationId, 'userId' => $data['id'], 'outTime' => null]))->get()->getData();
            $lastCheckedInDetails = Attendance::getLastCheckedInForUser($data['id']);
            $lastCheckInTime = $lastCheckedInDetails[$data['id']] ?? null;
            $details['data']['user']['lastCheckInTime'] = $lastCheckInTime;
            $details['data']['user']['hasCheckedInForDay'] = (empty($lastCheckInTime)) ? false
                : $this->getHasCheckedInForDay(
                    $lastCheckInTime, $details['data']['user']['shiftStart'], $details['data']['user']['shiftEnd']
                );
            $details['data']['user']['isCheckedIn'] = !empty($attendanceList['data']['count'])? true : false;
            $details['data']['user']['attendance'] = $attendanceList['data']['attendance'][0] ?? null;
        }
        $responseData = $details['data'];
        $responseData['employee'] = $responseData['user'];
        unset($responseData['user']);
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $responseData
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function put()
    {
        $fields = $this->getRequestParams(['id','organizationId'], ['name','designationId', 'weeklyOff', 'shiftStart', 'shiftEnd', 'storeIds', 'hasToolAccess',
            'email','phone',
        ]);
        (new \ZopNow\Hodor\Controller\User($fields))->put()->getData();
        return $this->get();
    }

    public function post() {
        $fields = $this->getRequestParams(
            ['organizationId', "name", "phone", "hasToolAccess"],
            ['sendInvite', 'password', 'designationId', "langIsoCode", "imageUrl", "storeIds","email","employeeId",
                "weeklyOff", "shiftStart", "shiftEnd"]
        );
        $data=[];
        $userData=[];
        $data['id']=$fields['organizationId'];
        if(empty($fields['email']) && !empty($fields['employeeId'])){
            $configResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/basic", 'GET', ['organizationId' => $fields['organizationId']]);
            $fieldData = json_decode($configResponse['body'], true)['data']['basic']['emailDomain'];
            if(!empty($fieldData)){
                $fields['email']=$fields['employeeId']."@".$fieldData;
            } else {
                $this->getRequestParams(['email']);
            }
        }
        if(empty($fields['email']) && empty($fields['employeeId'])){
            $this->getRequestParams(['email']);
        }
        $details = (new \ZopNow\Hodor\Controller\User($fields))->post()->getData();
        $this->data['id'] = $details['data']['user']['id'];
        return $this->get(); // Calling get to return the shift details along with user details
    }

    private function includeAdditonalDetails($details)
    {
        $attendanceList = (new Attendance(['organizationId' => $this->organizationId, 'outTime' => null, 'paginated' => false]))->get()->getData();
        $checkedInUsers = array_column($attendanceList['data']['attendance'], 'userId');
        $attendance = array_column($attendanceList['data']['attendance'], null, 'userId');
        $userIds = array_column($details['data']['user'], 'id');
        $lastCheckedInDetails = \ZopNow\Hodor\Model\Attendance::getLastCheckedInForUser($userIds);
        foreach ($details['data']['user'] as &$userDetails) {
            if (empty($userDetails['designation']) || $userDetails['designation']['timingType'] != 'FIXED') {
                $userDetails['shiftStart'] = $userDetails['shiftEnd'] = null;
            }
            $lastCheckInTime = $lastCheckedInDetails[$userDetails['id']] ?? null;
            $userDetails['lastCheckInTime'] = $lastCheckInTime;
            $userDetails['hasCheckedInForDay'] = (empty($lastCheckInTime)) ? false
                : $this->getHasCheckedInForDay(
                    $userDetails['lastCheckInTime'], $userDetails['shiftStart'], $userDetails['shiftEnd']
                );
            $userDetails['isCheckedIn'] = (in_array($userDetails['id'], $checkedInUsers)) ? true : false;
            $userDetails['attendance'] = $attendance[$userDetails['id']] ?? null;
        }
        return $details;
    }

    private function getHasCheckedInForDay($lastCheckInTime, $shiftStart, $shiftEnd)
    {
        $date = date("Y-m-d");
        $minInTime = $date . " 00:00:00";
        $maxInTime = $date . " 23:59:59";
        $crossShift = strtotime($shiftStart) > (strtotime($shiftEnd)) ? true : false;
        if ($crossShift) {
            $lastShiftEndTime = strtotime($date . " " . $shiftEnd);
            $minInTime = date("Y-m-d H:i:s", $lastShiftEndTime + 1);
            $maxInTime = date("Y-m-d H:i:s", strtotime("+1 day", $lastShiftEndTime));
        }
        if($minInTime <= $lastCheckInTime && $lastCheckInTime <= $maxInTime) {
            return true;
        } else {
            return false;
        }
    }

    public function delete()
    {
         $fields = $this->getRequestParams(['id','organizationId']);
         $details = (new \ZopNow\Hodor\Controller\User($fields))->delete();
         return $details;
    }

}
