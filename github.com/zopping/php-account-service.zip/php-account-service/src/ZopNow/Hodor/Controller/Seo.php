<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Controller\ModelController;
use ZopNow\Arya\Exception\ModelException;
use ZopNow\Arya\Exception\ValidationException;
use ZopNow\Arya\View\Base;

class Seo extends ModelController
{
    protected static $filterableFields = ['organization_id','page_id', 'url'];

    public function get() {
        if (!empty($this->data['id'])) {
            $this->getRequestParams(['organizationId']);
            if($this->model->organization->id != $this->organizationId){
                throw new ModelException("Seo with id: ".$this->data['id']." not found");
            }
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new Base($response);
    }

    public function post(){
        $data = $this->getRequestParams(['pageId','organizationId', 'title'],['url','keywords','description']);
        (new Organization(array("id" => $data['organizationId'])));
        $uniqueParams = ['organization_id' => $data['organizationId'],'page_id' => $data['pageId']];
        if (!empty($data['url'])) {
            $uniqueParams['url'] = $data['url'];
        }
        $exists = ($this->modelClass)::where($uniqueParams)->first();
        if ($exists) {
            throw new ValidationException("SEO configuration for the page already exists. ");
        }
        $seo = $this->add($data);
        $response = [
            'code' => 200,
            'status' => 'SUCCESS',
            'data' => $seo
        ];
        return new Base($response);
    }

    public function put(){
        $data = $this->getRequestParams(['organizationId','id'],['title','description','keywords']);
        (new Organization(array("id" => $data['organizationId'])));
        if($this->model->organization->id != $this->organizationId){
            throw new ModelException("Seo with id: ".$this->data['id']." not found");
        }
        $seo = $this->edit($data);
        $response = [
            'code' => 200,
            'status' => 'SUCCESS',
            'data' => $seo
        ];
        return new Base($response);
    }
}