<?php

use Phinx\Migration\AbstractMigration;

class AddStoresAsPickupLocations extends AbstractMigration
{
    /**
     * Made address column nullable to allow copying of store locations.
     * Added store id column 
     * Copying all existing stores to pickup_locations
     */
    public function change()
    {
        $this->table("pickup_locations")
            ->changeColumn('address', 'string', array('limit' => 500, 'null' => true))
            ->addColumn('store_id', 'integer', array('limit' => 11))
            ->addForeignKey(
                'store_id', 'stores', 'id', ['delete' => 'NO_ACTION', 'update' => 'NO_ACTION']
            )
            ->save();
        $this->execute(
            "insert into pickup_locations(organization_id, name, latitude, longitude,"
            . " address, store_id) select organization_id, name, latitude, longitude,"
            . " address, id as store_id from stores"
        );
    }

}
