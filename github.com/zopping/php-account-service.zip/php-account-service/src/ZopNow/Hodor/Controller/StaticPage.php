<?php

namespace ZopNow\Hodor\Controller;

class StaticPage extends \ZopNow\Arya\Controller\Base
{
    const NON_EDITABLE_STATIC_PAGE_TITLES = [
       "About Us", 
       "Terms and Conditions", 
       "Cancellation and Refund Policy", 
       "Shipping Policy", 
       "Privacy Policy"
    ];

    const NON_EDITABLE_STATIC_PAGE_URLS = [
        "about-us", 
        "terms", 
        "cancellation-and-refund-policy", 
        "shipping-policy", 
        "privacy"
    ];

    protected static $filterableFields = ['title', 'url', 'status', 'id'];

    public function get()
    {
        $data = $this->getRequestParams(['organizationId']);
        $id = $this->id;
        if (!empty($id) && !is_array($this->data['id'])) {
            $model = \ZopNow\Hodor\Model\OrganizationPage::whereNull('deleted_at')->find($id);
            if (empty($model) || $model->organization_id != $data['organizationId']) {
                throw new \ZopNow\Arya\Exception\ModelException(
                    "StaticPage with id: $id not found"
                );
            }
            $pageResponse = ['staticpage' => $model->toArray()];
        } else if (isset($this->data['id']) && is_array($this->data['id'])) {
            $staticPages = \ZopNow\Hodor\Model\OrganizationPage::whereIn('id', $this->data['id'])->where('organization_id', $data['organizationId'])->whereNull('deleted_at')->find($id);

            $pageResponse = [
                'count' => sizeof($staticPages),
                'offset' => 0,
                'limit' => sizeof($staticPages),
                'staticpage' => $staticPages
            ];
        } else {
            $requestData = [
                'id' => 'CONSTANT',
                'organizationId' => $data['organizationId']
            ];
            $pageController = new Page($requestData);
            $pageDetails = $pageController->get()->getData()['data'];

            //Set the page number of the data to be fetched
            $currentPage = $this->page ?? 1;
            \Illuminate\Pagination\Paginator::currentPageResolver(
                function () use ($currentPage) {
                    return $currentPage;
                }
            );
            //Add filters
            $filters = $this->getFilters();

            //Get list of data
            $list = \ZopNow\Hodor\Model\OrganizationPage::getStaticPageList(
                $data['organizationId'], $pageDetails['page']['id'], $filters
            );
            $listData = $list->toArray();
            $pageResponse = [
                "count" => $listData['total'],
                "offset" => ($listData['current_page']-1)*$listData['per_page'],
                "limit" => $listData['per_page'],
                "staticpage" => $listData['data']
            ];
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $pageResponse,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function post()
    {
        $data = $this->getRequestParams(
            ['organizationId', 'layouts', 'url', 'title'], ['status']
        );
        $data['id'] = 'CONSTANT';
        $pageController = new Page($data);
        $pageDetails = $pageController->put()->getData()['data'];
        $organizationPageModel = 
            \ZopNow\Hodor\Model\OrganizationPage::getFromOrganizationIdPageId(
                $data['organizationId'], $pageDetails['page']['id'], $data['url']
            )[0];
        $pageResponse = $organizationPageModel->toArray();
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => ['staticpage' => $pageResponse],
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function put()
    {
        $data = $this->getRequestParams(
            ['id', 'organizationId'], ['layouts', 'url', 'title', 'status']
        );
        $pageId = $data['id'];
        $data['id'] = 'CONSTANT';
        $data['organizationPageId'] = $pageId;
        $model = \ZopNow\Hodor\Model\OrganizationPage::find($pageId);
        if (!empty($data['url'])) {
            if (in_array(strtolower(strtolower($model->url)), array_map('strtolower', self::NON_EDITABLE_STATIC_PAGE_URLS))) {
                if (strtolower($model->url) != strtolower($data['url'])) {
                    throw new \ZopNow\Arya\Exception\ValidationException(
                        "static-page with url: " . $this->data['url'] . " can not be updated"
                    );
                }
            } else if (in_array(strtolower(strtolower($data['url'])), array_map('strtolower', self::NON_EDITABLE_STATIC_PAGE_URLS))) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "static-page with url: " . $this->data['url'] . " can not be updated"
                );
            }
        }
        if (!empty($data['title'])) {
            if (in_array(strtolower(strtolower($model['title'])), array_map('strtolower', self::NON_EDITABLE_STATIC_PAGE_TITLES))) {
                if (strtolower($model->title) != strtolower($data['title'])) {
                    throw new \ZopNow\Arya\Exception\ValidationException(
                        "the static-page with title: " . $this->data['title'] . "can not be editable"
                    );
                }
            } else if (in_array(strtolower(strtolower($data['title'])), array_map('strtolower', self::NON_EDITABLE_STATIC_PAGE_TITLES))) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "the static-page with title: " . $this->data['title'] . "can not be editable"
                );
            }
        }
        $pageController = new Page($data);
        $pageDetails = $pageController->put()->getData()['data'];
        $organizationPageModel = 
            \ZopNow\Hodor\Model\OrganizationPage::getFromOrganizationIdPageId(
                $data['organizationId'], $pageDetails['page']['id'], $data['url'] ?? null, $pageId)[0];
        $pageResponse = $organizationPageModel->toArray();
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => ['staticpage' => $pageResponse],
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    private function getFilters()
    {
        $filters = [];
        foreach (self::$filterableFields as $field) {
            $value = $this->$field;
            if (!empty($value)) {
                $filters[] = [$field, '=', $value];
            }
        }
        return $filters;
    }
}
