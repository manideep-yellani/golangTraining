<?php

namespace ZopNow\Hodor\Model;

class Country extends \ZopNow\Arya\Model\Base
{

    protected $hidden = ['created_at', 'updated_at', 'default_lang_id', 'currency_id'];
    protected $with = ['defaultLang', 'currency'];

    public static function getCountryFromIsoCode($isoCode)
    {
        return Country::where('iso_code', $isoCode)->first();
    }

    public function defaultLang()
    {
        return $this->belongsTo("\ZopNow\Hodor\Model\Lang", "default_lang_id", "id");
    }

    public function currency()
    {
        return $this->hasOne("\ZopNow\Hodor\Model\Currency", "id", "currency_id");
    }

}
