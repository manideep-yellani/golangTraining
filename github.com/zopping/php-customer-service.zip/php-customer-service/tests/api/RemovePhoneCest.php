<?php

class RemovePhoneCest extends BaseCest
{
    protected static $endpoint = '/phone';
    protected static $table    = "phones";

    public function removePhone(ApiTester $I)
    {
        //Phones with id 1,2,3 belong to one customer.
        $I->wantToTest("Removing phone of user under suitable scenario");
        $id = 1;
        $customerId = 1;
        $organizationId = 1;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint . "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, ['id' => $id, "deleted_at" => NULL]);
    }

    public function removePhoneWithoutCustomer(ApiTester $I)
    {
        $I->wantToTest("Removing phone of user without customer id");
        $id = 2;
        $I->sendDELETE(static::$endpoint . "/$id", ["organizationId" => 1]);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass a valid Customer object or customerId"));
    }

    public function removePhoneWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Delete a Phone with invalid id');
        $customerId = 1;
        $organizationId = 1;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint."/abc", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Model Exception: Phone with id: abc not found"));
    }

    public function removePhoneOfOther(ApiTester $I)
    {
        $I->wantToTest("Removing Phone of other");
        $invalidUserId = 5;
        $organizationId = 1;
        $data = ["customer" => json_encode(['id' => $invalidUserId]),"organizationId" => $organizationId];
        $I->sendDELETE(self::$endpoint."/2", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array("message"=>"Model Exception: Customer with id 5 and organization_id 1 not found"));
        $I->seeInDatabase(self::$table, ["id" => 2, "deleted_at" => null]);
    }

    public function removePhoneWithoutId(ApiTester $I)
    {
        $I->wantToTest("Remove phone without passing id");
        $customerId = 1;
        $organizationId = 1;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass a valid id"));
    }

    public function removingTheOnlyPhoneOfCustomer(ApiTester $I)
    {
        $I->wantToTest("Remove the only phone of customer");
        //Customer 5 of organization 2 has only 1 phone
        $I->sendDELETE(self::$endpoint."/4", ["customer" => json_encode(['id' => 5]), "organizationId" => 2]);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Phone cannot be deleted as the customer has only 1 phone number"));
    }
}