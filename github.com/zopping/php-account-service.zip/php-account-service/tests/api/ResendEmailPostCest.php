<?php

class ResendEmailPostCest
{
    protected static $endpoint = '/resend-verification-email';
    protected static $table = 'users';

    public function unverifiedUser(ApiTester $I)
    {
        $I->wantTo("Check API with unverified user");
        $id = $I->haveInDatabase(static::$table, ['name' => 'Moshe Daugherty', 'password' => 'justatestpassword', 
            'organization_id' => 1]);
        $emailId = $I->haveInDatabase('emails', ['user_id' => $id, 'email' => 'tiara75@dicki.info']);
        $data = [
            "user"=> json_encode(
                [
                    "id"=>$id,
                    "name"=>"Moshe Daugherty",
                    "organizationId"=>1
                ]
            )
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'SUCCESS']);
        $I->seeResponseContainsJson(["message" => "Email sent!"]);
    }

    public function verifiedUser(ApiTester $I)
    {
        $I->wantTo("Check API when user is verified");
        $I->sendPOST('/auth', ['username' => 'admin@zopnow.com', 'password' => 'justatestpassword']);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $user = $I->grabDataFromResponseByJsonPath('$.data.user')[0];
        $data = ['user' => json_encode($user)];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: User has already been verified']);
    }

    public function invalidUserId(ApiTester $I)
    {
        $I->wantTo("Check API when invalid email is sent");
        $data = ['user' => json_encode(
                    [
                        "id"=>'abc',
                        "name"=>"Moshe Daugherty",
                        "organizationId"=>1
                    ]
            )];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Model Exception: User with id: abc not found']);
    }

    public function missingUserEmail(ApiTester $I)
    {
        $I->wantTo("Check API when email is not sent");
        $I->sendPOST(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Missing Required Field - resendverificationemail : user']);
    }
}

