<?php

namespace ZopNow\Hodor\Model;


use Illuminate\Database\Eloquent\SoftDeletes;
use ZopNow\Arya\Listing\ObjectList;
use ZopNow\Arya\Model\Base;

class Extension extends Base
{
    use SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at','pivot', 'pricing_rule', 'dependant_on'];

    protected $casts = [
        'is_store_configurable' => 'boolean',
        'incompatibleExtensions' => 'array',
        'prerequisites' => 'array'
    ];

    public function organization(){
        return $this->belongsToMany('\ZopNow\Hodor\Model\Organization')->withPivot('pricing', 'pricing_rule');
    }

    public function status($organizationId) {
        $query = 'SELECT id FROM extension_organization WHERE organization_id = '. $organizationId . 
        ' AND extension_id = '. $this->attributes['id'];
        $isExtensionEnabled = \ZopNow\Arya\DB\MySql::select($query);
        if (sizeof($isExtensionEnabled) > 0) {
            return 'ENABLED';
        }

        return 'DISABLED';
    }

    public static function getListItems(ObjectList $list)
    {
        $data    = self::query();
        $filters = $list->getFilters();
        $filterKeys = array_column($filters, 0);
        $key = array_search('organizationId', $filterKeys);
        $statusKey = array_search('status', $filterKeys);
        if ($statusKey !== false) {
            $statusValue = $filters[$statusKey][1];
            unset($filters[$statusKey]);
        }
        if($key !== false){
            $organizationId = $filters[$key][1];
//            $data->with('organization');
            unset($filters[$key]);
            if ($statusKey !== false) {
                $data = self::addStatusFilter($data, $organizationId, $statusValue);
            }
        }
        $data    = self::addFilterQuery($data, $filters);
        if ($list->paginated) {
            $data->limit($list->getPerPage())->skip($list->getOffset());
        }
        $extensions = $data->select('extensions.*')
            ->orderBy('extensions.' . $list->getSortField(),$list->getSortOrder())->get();
        if(isset($organizationId)){
            foreach($extensions as $extension){
                if(!isset($hiddenColumns)){
                    $hiddenColumns = array_merge($extension->getHidden(), ['organization']);
                }
                $extension->status = $extension->status($organizationId);
                $extension->isConfigurable = false;
                if ($extension->status == 'ENABLED') {
                    $fileName = DATA_DIRECTORY . "configurations/" . lcfirst($extension->slug).".json";
                    if (file_exists($fileName)) {
                        $extension->isConfigurable = true;
                     }
 //$extension->pricing = $extension->organization->find($organizationId)->toArray()['pivot']['pricing'] ?? $extension->pricing;
                }
                $extension->setHidden($hiddenColumns);
            }
        }
        return $extensions;
    }

    public static function getListItemsCount(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data    = self::query();
        $filters = $list->getFilters();
        $filterKeys = array_column($filters, 0);
        $key = array_search('organizationId', $filterKeys);
        $statusKey = array_search('status', $filterKeys);
        if ($statusKey !== false) {
            $statusValue = $filters[$statusKey][1];
            unset($filters[$statusKey]);
        }
        if($key !== false){
            $organizationId = $filters[$key][1];
            unset($filters[$key]);
            if ($statusKey !== false) {
                $data = self::addStatusFilter($data, $organizationId, $statusValue);
            }
        }
        $data    = self::addFilterQuery($data, $filters);
        return $data->count();
    }

    private static function addStatusFilter($data, $organizationId, $status)
    {
        if ($status == 'ENABLED') {
            $data->join('extension_organization', function ($join) use ($organizationId) {
                $join->on('extension_organization.extension_id', '=', 'extensions.id')
                    ->where('extension_organization.organization_id', '=', $organizationId);
            });
        } elseif ($status == 'DISABLED') {
            $data->leftJoin('extension_organization', function ($join) use ($organizationId) {
                $join->on('extension_organization.extension_id', '=', 'extensions.id')
                    ->where('extension_organization.organization_id', '=', $organizationId);
            });
            $data->where('extension_organization.extension_id', '=', null);
        }
        return $data;
    }

    public function getDependantOnAttribute($value)
    {
        $dependantOn = [];
        $dependantExtensions = !empty($value) ? explode(",", $value) : [];
        foreach ($dependantExtensions as $dependantExtension) {
            $dependantOn[] = \ZopNow\Hodor\Model\Extension::find($dependantExtension)->toArray();
        }
        return $dependantOn;
    }

    public function getIdFromSlug($slug)
    {
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $key = 'H:Extension:Static:Slug';
        $id = $redis->hget($key, $slug);
        if ($id === false) {
            $model = \ZopNow\Hodor\Model\Extension::where([['slug', $slug]])->first();
            $id = null;
            if (!empty($model)) {
                $redis->hset($key, $slug, $model->id);
                $id = $model->id;
            }
        }
        return $id;
    }

    public static function getParentExtensions($id) {
        $query = 'SELECT parent.id, parent.name, parent.slug, parent.dependant_on FROM organization_service.extensions as parent INNER JOIN organization_service.extensions as child WHERE FIND_IN_SET(child.id, parent.dependant_on) AND child.id = '. $id . ' AND child.deleted_at IS NULL';
        $extensions = \ZopNow\Arya\DB\MySql::select($query);
        return $extensions;
    }

    public static function getExtensions($organizationId, $extensions) {
        if (sizeof($extensions) == 0) {
            return $extensions;
        }

        $slugs = [];

        foreach ($extensions as &$extension) {
            $extension['status'] = "DISABLED";
            $slugs[] = $extension['slug'];
        }

        $query = "SELECT extensions.id, extensions.name, extensions.slug FROM extensions INNER JOIN extension_organization ON extensions.id = extension_organization.extension_id WHERE slug IN ('" . implode("','", $slugs) . "') AND extension_organization.organization_id = " .$organizationId . " AND extensions.deleted_at IS NULL";
        $enabledExtensions = \ZopNow\Arya\DB\MySql::select($query);
        
        foreach($enabledExtensions as $enabledExtension) {
            foreach ($extensions as &$extension) {
                if ($extension['slug'] == $enabledExtension['slug']) {
                    $extension['status'] = "ENABLED";
                    break;
                }
            }
        }

        return $extensions;
    }

}