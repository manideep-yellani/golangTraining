<?php

use Phinx\Migration\AbstractMigration;

class AddRedmartExtension extends AbstractMigration
{

    private $slug = "RedMartSupport";

    public function up()
    {
        $data = [
            "name" => "RedMart",
            "slug" => $this->slug,
            "description" => "Allows to support features specific to RedMart enterprise account",
            "is_private" => 1
        ];
        $this->insert('extensions', $data);
    }

    public function down()
    {
        $this->execute("DELETE extension_organization.* from `extension_organization`"
            . " inner join extensions on extensions.id = extension_id "
            . "and `slug` ='$this->slug'");
        $this->execute("DELETE from `extensions` where `slug` ='$this->slug'");
    }

}
