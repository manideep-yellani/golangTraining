<?php

class ConfigurationPutCest extends BaseCest
{
    protected static $endpoint = '/configuration';
    protected static $table = 'configurations';

    public function updateValueField(ApiTester $I)
    {
        $I->wantTo('Updating the value for a configuration');
        $id = $I->grabFromDatabase(static::$table, 'id', ['organization_id' => 1, 'key' => 'basic.organizationName']);
        $initialData = ['id' => $id, 'key' => 'basic.organizationName', 'value' => 'Zopnow'];
        $finalData = ['key' => 'basic.organizationName', 'value' => 'Zopnow Store'];
        $I->sendPUT(static::$endpoint . "/$id", $finalData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($finalData);
        $I->seeInDatabase(static::$table, $finalData);
        $I->dontseeResponseContainsJson($initialData);
        $I->dontSeeInDatabase(static::$table, $initialData);
    }

    public function updateKeyField(ApiTester $I)
    {
        $I->wantTo('Updating the key for a configuration to a key that does not exist in DB for that organization');
        $id = $I->grabFromDatabase(static::$table, 'id', ['organization_id' => 1, 'key' => 'basic.organizationName']);
        $initialData = ['id' => $id, 'key' => 'basic.organizationName'];
        $finalData = ['key' => 'basic.store', 'value' => 'Zopnow'];
        $I->sendPUT(static::$endpoint . "/$id", $finalData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($finalData);
        $I->seeInDatabase(static::$table, $finalData);
        $I->dontseeResponseContainsJson($initialData);
        $I->dontSeeInDatabase(static::$table, $initialData);
        //Changing the data back to initial data for use in later test cases
        $I->sendPUT(static::$endpoint . "/$id", $initialData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
    }

    public function updateKeyWithExistingData(ApiTester $I)
    {
        $I->wantTo('Updating the key for a configuration to a key that already exists for that organization');
        $id = $I->grabFromDatabase(static::$table, 'id', ['organization_id' => 1, 'key' => 'basic.organizationName']);
        $finalData = ['organizationId' => 1, 'key' => 'basic.siteUrl'];
        $I->sendPUT(static::$endpoint . "/$id", $finalData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Configuration exists with the same key']);
    }

    public function updateDataWithoutId(ApiTester $I)
    {
        $I->wantTo('Updating the data for a configuration without passing id');
        $finalData = ['key' => 'catalogue.hasMultipleBrands', 'value' => 'TRUE'];
        $I->sendPUT(static::$endpoint, $finalData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Please pass a valid id']);
    }

    public function updateDataWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Updating the data for a configuration with invalid id');
        $finalData = ['key' => 'catalogue.hasMultipleBrands', 'value' => 'TRUE'];
        $I->sendPUT(static::$endpoint . "/100000", $finalData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Model Exception: Configuration with id: 100000 not found']);
    }
}
