<?php

require_once('BaseCest.php');

class PickupLocationPutCest extends BaseCest
{

    protected static $endpoint = '/pickup-location';
    protected static $table = 'pickup_locations';

    public function updateEditableFields(ApiTester $I)
    {
        $I->wantToTest("Editing pickup location.");
        $initialData = array(
            "organizationId" => 2,
            "name" => "Big Bazaar, Surat",
            "latitude" => "40.8329137232310",
            "longitude" => "13.2947508931600",
            "address" => "Opposite Gandi maidan, Near Ram mandir, Rajiv Nagar, Surat",
            "storeId" => 2
        );
        $locationId = (string) $I->haveInDatabase(static::$table, $this->getDatabaseDataArray($initialData));
        unset($initialData['organizationId']);
        $updatedData = array(
            "latitude" => "21.6787583789220",
            "organizationId" => 2
        );
        parent::update($I, $locationId, $updatedData, $initialData);
    }

    public function updatingWithoutId(ApiTester $I)
    {
        $I->wantToTest("Updating without passing id");
        $updatedData = array(
            "latitude" => "21.6787583789220",
        );
        $I->sendPUT(static::$endpoint . "/", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass a valid id"));
    }

    public function updatingWithInvalidLatitudeLongitute(ApiTester $I)
    {
        $I->wantToTest("Updating with invalid latitude");
        $initialData = array(
            "organization_id" => 1,
            "name" => "Big Bazaar, Surat",
            "latitude" => "40.8329137232310",
            "longitude" => "13.2947508931600",
            "address" => "Opposite Gandi maidan, Near Ram mandir, Rajiv Nagar, Surat",
            "store_id" => 1,
        );
        $locationId = (string) $I->haveInDatabase(static::$table, $initialData);
        $updatedData = array(
            "latitude" => "21234",
            "organizationId" => 1,
        );
        $I->sendPUT(static::$endpoint . "/$locationId", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Invalid latitude value"));
    }

    public function updatingToAlreadyExistingName(ApiTester $I)
    {
        $I->wantToTest("Updating with invalid latitude");
        $initialData = array(
            "organization_id" => 1,
            "name" => "Big Bazaar, Surat",
            "latitude" => "40.8329137232310",
            "longitude" => "13.2947508931600",
            "address" => "Opposite Gandi maidan, Near Ram mandir, Rajiv Nagar, Surat",
            "store_id" => 1
        );
        $locationId = (string) $I->haveInDatabase(static::$table, $initialData);
        $updatedData = array(
            "name" => "Hypercity, Meenakshi Mall",
            "organizationId" => 1,
        );
        $I->sendPUT(static::$endpoint . "/$locationId", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Pickup location with name '$updatedData[name]' already exists"));
    }
}
