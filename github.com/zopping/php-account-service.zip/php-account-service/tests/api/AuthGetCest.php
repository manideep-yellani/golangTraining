<?php

/**
 * Class consists of the test cases which API should handle during authentication
 * when a GET request is made to the API.
 */

class AuthGetCest
{
    protected static $endpoint = '/auth';

    private function login(ApiTester $I)
    {
        $I->sendPOST(static::$endpoint, ['username' => 'admin@zopnow.com', 'password' => 'justatestpassword']);
        return $I->grabDataFromResponseByJsonPath('$.data.user.accessToken')[0];
    }
    
    public function validAccessTokenAndInvalidEndpoint(ApiTester $I)
    {
        $I->wantTo("Passing a valid access token but an invalid endpoint");
        $accessToken = $this->login($I);
        $I->sendGET(static::$endpoint."?accessToken=$accessToken&api=test&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
    }

    public function invalidAccessToken(ApiTester $I)
    {
        $I->wantTo("Passing a invalid access token");
        $I->sendGET(static::$endpoint."?accessToken=accessToken&api=test&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Auth Exception: Unauthorized"]);
    }

    public function noAccessToken(ApiTester $I)
    {
        $I->wantTo("Checking with no access token");
        $I->sendGET(static::$endpoint."?&api=test&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Auth Exception: Unauthorized"]);
    }

    public function publicAPI(ApiTester $I)
    {
        $I->wantToTest("authenticating a public API");
        $I->sendGET(static::$endpoint."?&api=account-service/reset-password&method=POST");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }

    public function validDeveloperToken(ApiTester $I)
    {
        $I->wantToTest("authenticating with valid developer token");
        $endpointId = $I->grabFromDatabase('endpoints', 'id', ['url' => 'catalogue-service/product']);
        $developerId = $I->grabFromDatabase('developers', 'id', ['token' => '0ccdc347506fa12134fff339fb447f90']);
        $I->haveInDatabase("endpoint_developer_permissions",
                ["endpoint_id" => $endpointId,
                    "developer_id" => $developerId,
                    "method" => "GET",
                    "has_permission" => true]);
        $I->sendGET(static::$endpoint."?developerToken=7e57d004-2b97-0e7a-b45f-5387367791cd&api=catalogue-service/product&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["name"=> "Self Checkout App"]);
    }

    public function invalidDeveloperToken(ApiTester $I)
    {
        $I->wantToTest("authenticating with an invalid developer token");
        $I->sendGET(static::$endpoint."?developerToken=developerToken&api=test&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Auth Exception: Unauthorized"]);
    }

    public function validDeveloperAndAccessToken(ApiTester $I)
    {
        $I->wantToTest("authenticating with valid developer token");
        $I->sendPOST(static::$endpoint, ['username' => 'admin@carrefour.zopnow.express', 'password' => 'justatestpassword']);
        $accessToken = $I->grabDataFromResponseByJsonPath('$.data.user.accessToken')[0];
        $endpointId = $I->grabFromDatabase('endpoints', 'id', ['url' => 'catalogue-service/product']);
        $developerId = $I->grabFromDatabase('developers', 'id', ['token' => '0ccdc347506fa12134fff339fb447f90']);
        $I->haveInDatabase("endpoint_developer_permissions",
                ["endpoint_id" => $endpointId,
                    "developer_id" => $developerId,
                    "method" => "GET",
                    "has_permission" => true]);
        $I->sendGET(static::$endpoint."?accessToken=$accessToken&developerToken=7e57d004-2b97-0e7a-b45f-5387367791cd&api=catalogue-service/product&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["name"=> "Self Checkout App"]);
        $I->seeResponseContainsJson(["email" => "admin@carrefour.zopnow.express"]);
    }

    public function mismatchDeveloperAndAccessToken(ApiTester $I)
    {
        $I->wantToTest("authenticating with valid developer token & access token but of different organization");
        $I->sendPOST(static::$endpoint, ['username' => 'admin@ruchisbiryani.zopnow.express', 'password' => 'justatestpassword']);
        $accessToken = $I->grabDataFromResponseByJsonPath('$.data.user.accessToken')[0];
        $I->sendGET(static::$endpoint."?accessToken=$accessToken&developerToken=7e57d004-2b97-0e7a-b45f-5387367791cd&api=catalogue-service/product&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Auth Exception: Unauthorized"]);
    }

    public function validOrganizationIndependentDeveloperToken(ApiTester $I)
    {
        $I->wantToTest("authenticating with valid developer token which is organization independent without any filters");
        $id = $I->haveInDatabase('developers', ['name' => 'Test Token', 'token' => 'bde45201c218ae35b0279d2d02d4c8c8']);
        $endpointId = $I->grabFromDatabase('endpoints', 'id', ['url' => 'catalogue-service/product']);
        $I->haveInDatabase("endpoint_developer_permissions",
                ["endpoint_id" => $endpointId,
                    "developer_id" => $id,
                    "method" => "GET",
                    "has_permission" => true]);
        $I->sendGET(static::$endpoint."?developerToken=7e57d004-2b97-0e7a-b45f-5387367791ce&api=catalogue-service/product&method=GET");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["name"=> "Test Token"]);
        $I->seeResponseContainsJson(["organization" => null]);
    }
/*
    public function validDeveloperTokenWithOrganizationIdFilter(ApiTester $I)
    {
        $I->wantToTest("authenticating with valid developer token which is organization independent with organization id as filter");
        $id = $I->haveInDatabase('developers', ['name' => 'Test Token', 'token' => 'bde45201c218ae35b0279d2d02d4c8c8']);
        $endpointId = $I->grabFromDatabase('endpoints', 'id', ['url' => 'catalogue-service/product']);
        $I->haveInDatabase("endpoint_developer_permissions",
                ["endpoint_id" => $endpointId,
                    "developer_id" => $id,
                    "method" => "GET",
                    "has_permission" => true]);
        $I->sendGET(static::$endpoint."?developerToken=7e57d004-2b97-0e7a-b45f-5387367791ce&api=catalogue-service/product&method=GET&filter[id]=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["name"=> "Test Token"]);
        $I->seeResponseContainsJson(["organization" => ['id' => 1]]);
    }
*/
    public function validDeveloperTokenWithOrganizationDomainFilter(ApiTester $I)
    {
        $I->wantToTest("authenticating with valid developer token which is organization independent with organization domain as filter");
        $id = $I->haveInDatabase('developers', ['name' => 'Test Token', 'token' => 'bde45201c218ae35b0279d2d02d4c8c8']);
        $endpointId = $I->grabFromDatabase('endpoints', 'id', ['url' => 'catalogue-service/product']);
        $I->haveInDatabase("endpoint_developer_permissions",
                ["endpoint_id" => $endpointId,
                    "developer_id" => $id,
                    "method" => "GET",
                    "has_permission" => true]);
        $I->sendGET(static::$endpoint."?developerToken=7e57d004-2b97-0e7a-b45f-5387367791ce&api=catalogue-service/product&method=GET&filter[domain]=ruchisbiryani.zopexpress.com");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["name"=> "Test Token"]);
        $I->seeResponseContainsJson(["organization" => ['domain' => 'ruchisbiryani.zopexpress.com']]);
    }
}
