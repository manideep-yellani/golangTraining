<?php

use Phinx\Migration\AbstractMigration;

class ModifyUserEndpoint extends AbstractMigration
{
    public function up()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\'["GET","DELETE"]\' 
                where url = "account-service/user"');
    }

    public function down()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\'["GET","PUT","POST]\' 
                where url = "account-service/user"');
    }
}
