<?php

class LoginGetCest
{
    protected static $endpoint = '/login';

    private function login(ApiTester $I)
    {
        $I->sendPOST(static::$endpoint, ['username' => '+919876543210', 'password' => 'password', 'organizationId' => 1]);
        return $I->grabDataFromResponseByJsonPath('$.data.customer.accessToken')[0];
    }

    public function validAccessToken(ApiTester $I)
    {
        $I->wantTo("Passing a valid access token");
        $accessToken = $this->login($I);
        $I->sendGET(static::$endpoint . "?accessToken=$accessToken&organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["name" => "Vishal Kumar"]);
    }

    public function invalidAccessToken(ApiTester $I)
    {
        $I->wantTo("Passing a invalid access token");
        $I->sendGET(static::$endpoint . "?accessToken=accessToken&organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Auth Exception: Unauthorized"]);
    }

    public function noAccessToken(ApiTester $I)
    {
        $I->wantTo("Checking with no access token");
        $I->sendGET(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - login : access Token"]);
    }

    public function noOrganizationId(ApiTester $I)
    {
        $I->wantTo("Checking with no organizationId");
        $accessToken = $this->login($I);
        $I->sendGET(static::$endpoint . "?accessToken=$accessToken");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - login : organization Id"]);
    }

    public function mismatchOrganizationId(ApiTester $I)
    {
        $I->wantTo("Passing organizationId different from that of the user");
        $accessToken = $this->login($I);
        $I->sendGET(static::$endpoint . "?accessToken=$accessToken&organizationId=2");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Auth Exception: Unauthorized"]);
    }

}
