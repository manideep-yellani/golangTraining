<?php

require_once('BaseCest.php');

class PageGetCest extends BaseCest
{

    protected static $endpoint = '/page';
    protected static $table = 'pages';

    public function listPages(ApiTester $I)
    {
        $I->wantTo('Get list of pages');
        parent::getAll($I);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "page" => array(
                    array(
                        "id" => "integer",
                        "name" => "string",
                    )
                )
            )
        ));
    }

    public function listPagesInvalidPage(ApiTester $I)
    {
        //Sending a page number which does not have data
        $I->wantTo('Get list of pages with invalid page number');
        $I->sendGET(self::$endpoint . "?page=10000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['page' => []]));
    }

    public function listPagesWithName(ApiTester $I)
    {
        //Sending name as a filter and checking if the required data is returned
        $I->wantTo('Get list of pages with name filter');
        $id = $I->haveInDatabase(self::$table, ['name' => 'TestPage']);
        $I->sendGET(self::$endpoint . "/TestPage?organizationId=2");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "page" => array(
                    "id" => "integer",
                    "name" => "string",
                )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'TestPage']);
    }

    public function listPagesWithOrganizationId(ApiTester $I)
    {
        //Sending organization id as a filter and checking if the required data is returned
        $I->wantTo('Get list of pages with organization id filter');
        $id = $I->haveInDatabase(self::$table, ['name' => 'TestPage']);
        $I->sendGET(self::$endpoint . "?organizationId=6");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "page" => array(
                    array(
                        "id" => "integer",
                        "name" => "string",
                    )
                )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'TestPage']);
    }

    public function getPageInvalidName(ApiTester $I)
    {
        //Sending an invalid name
        $I->wantTo('Get details of a page with invalid name');
        $I->sendGET(self::$endpoint . "/page1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Page with name page1 not found'));
    }

    public function getPageWithUrlFilter(ApiTester $I)
    {
        $I->wantTo('Get list of pages with name and url filters');
        $pageId = $I->haveInDatabase(self::$table, ['name' => 'TestPage']);
        $layoutData = array(
            0 => array(
                'data' => array(
                    'link' => '',
                    'title' => 'Welcome to home',
                    'imageUrl' => "http://via.placeholder.com/250X141",
                    'description' => 'Home page description',
                    ),
                'name' => 'ImageWithText',
            ),
        );
        $id = $I->haveInDatabase(
            'organization_page', [
                'organization_id' => 2,
                'page_id' => $pageId,
                'url' => '/testHome',
                'layouts' => json_encode($layoutData)
            ]
        );
        $I->sendGET(self::$endpoint . "/TestPage?organizationId=2&url=/testHome");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(
            array(
                "code" => "integer",
                "status" => "string",
                "data" => array(
                    "page" => array(
                        "id" => "integer",
                        "name" => "string",
                        "layouts" => "array"
                    )
                )
            )
        );
        $I->seeResponseContainsJson(
            ['id' => $pageId, 'name' => 'TestPage', 'layouts' => $layoutData]
        );
    }

    public function getPageWithInvalidUrlFilter(ApiTester $I)
    {
        $I->wantTo('Get list of pages with name and invalid url filters');
        $pageId = $I->haveInDatabase(self::$table, ['name' => 'TestPage']);
        $layoutData = array(
            0 => array(
                'data' => array(
                    'link' => '',
                    'title' => 'Test home page',
                    'imageUrl' => "http://via.placeholder.com/250X141",
                    'description' => 'Home page description',
                    ),
                'name' => 'ImageWithText',
            ),
        );
        $id = $I->haveInDatabase(
            'organization_page', [
                'organization_id' => 2,
                'page_id' => $pageId,
                'layouts' => json_encode($layoutData)
            ]
        );
        $I->sendGET(self::$endpoint . "/TestPage?organizationId=2&url=/testHomePage");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(
            array(
                "code" => "integer",
                "status" => "string",
                "data" => array(
                    "page" => array(
                        "id" => "integer",
                        "name" => "string",
                        "layouts" => "array"
                    )
                )
            )
        );
        $I->seeResponseContainsJson(
            ['id' => $pageId, 'name' => 'TestPage', 'layouts' => $layoutData]
        );
    }

    public function getStaticPageWithUrlFilter(ApiTester $I)
    {
        $I->wantTo('Get details of CONSTANT page with url filter');
        $pageId = $I->grabFromDatabase(self::$table, 'id', ['name' => 'CONSTANT']);
        $layoutData = array(
            0 => array(
                'data' => array(
                    'link' => '',
                    'title' => 'Static Page',
                    'imageUrl' => "http://via.placeholder.com/250X141",
                    'description' => 'Test Static page description',
                    ),
                'name' => 'ImageWithText',
            ),
        );
        $id = $I->haveInDatabase(
            'organization_page', [
                'organization_id' => 2,
                'page_id' => $pageId,
                'url' => 'testStatic',
                'layouts' => json_encode($layoutData)
            ]
        );
        $I->sendGET(self::$endpoint . "/CONSTANT?organizationId=2&url=testStatic");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(
            array(
                "code" => "integer",
                "status" => "string",
                "data" => array(
                    "page" => array(
                        "id" => "integer",
                        "name" => "string",
                        "layouts" => "array"
                    )
                )
            )
        );
        $I->seeResponseContainsJson(
            ['id' => $pageId, 'name' => 'CONSTANT', 'layouts' => $layoutData]
        );
    }

    public function getPageWithStatusFilter(ApiTester $I)
    {
        $I->wantTo("Get page with the status filter");
        $pageId = $I->grabFromDatabase(self::$table, 'id', ['name' => 'BRAND']);
        $layoutData = array(
            0 => array(
                'data' => array(
                    'link' => '',
                    'title' => 'Brand Page',
                    'imageUrl' => "http://via.placeholder.com/250X141",
                    'description' => 'Sample Brand Page',
                    ),
                'name' => 'ImageWithText',
            ),
        );
        $id = $I->haveInDatabase(
            'organization_page', [
                'organization_id' => 3,
                'page_id' => $pageId,
                'layouts' => json_encode($layoutData),
                'status' => 'DISABLED'
            ]
        );
        $I->sendGET(self::$endpoint . "/BRAND?organizationId=3&status=ENABLED");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(
            array(
                "code" => "integer",
                "status" => "string",
                "data" => array(
                    "page" => array(
                        "id" => "integer",
                        "name" => "string",
                        "layouts" => "array"
                    )
                )
            )
        );
        $I->sendGET(self::$endpoint . "/BRAND?organizationId=3&status=DISABLED");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(
            array(
                "code" => "integer",
                "status" => "string",
                "data" => array(
                    "page" => array(
                        "id" => "integer",
                        "name" => "string",
                        "layouts" => "array"
                    )
                )
            )
        );
        $I->seeResponseContainsJson(
            ['id' => $pageId, 'name' => 'BRAND', 'layouts' => $layoutData]
        );
    }
}
