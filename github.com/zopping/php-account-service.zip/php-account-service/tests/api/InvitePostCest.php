<?php

class InvitePostCest
{
    protected static $endpoint = '/invite';

    public function validData(ApiTester $I)
    {
        $I->wantTo('Check the API when the user is invited');
        $data = ['name' => 'Invitee', 'phone' => '+919916228707', 'email' => 'livelikehimanshu@gmail.com','organizationId' => 2];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'data' => [
                "user" =>
                array(
                    'id' => 'integer',
                    'name' => 'string',
                    'isOwner' => 'integer',
                    'phones' => 'array',
                    'emails' => 'array',
                ),
            ]
        ));
        $id = $I->grabDataFromResponseByJsonPath('$.data.user.id')[0];
        $I->seeInDatabase("users", ['name' => 'Invitee', 'is_owner' => 0]);
        $I->seeInDatabase("emails", ["user_id" => $id, 'email' => 'livelikehimanshu@gmail.com']);
    }
}
