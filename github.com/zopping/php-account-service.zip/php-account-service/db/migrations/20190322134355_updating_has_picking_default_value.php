<?php

use Phinx\Migration\AbstractMigration;

class UpdatingHasPickingDefaultValue extends AbstractMigration
{

    public function change()
    {
    $this->table("stores")
        ->changeColumn("has_picking",'boolean',array('default' => true))
        ->save();
    }
}
