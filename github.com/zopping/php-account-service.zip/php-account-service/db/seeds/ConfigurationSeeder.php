<?php

use Phinx\Seed\AbstractSeed;

class ConfigurationSeeder extends AbstractSeed
{
    /**
     * Seeding the configurations table with organization_id, key and value
     * created_at, updated_at will be set to the current timestamp
     */
    public function run()
    {
        $this->execute('SET FOREIGN_KEY_CHECKS = 0');
        $data = [
            [
                'organization_id' => 1,
                'key' => 'basic.organizationName',
                'value' => 'Zopnow'
            ],
            [
                'organization_id' => 1,
                'key' => 'basic.siteUrl',
                'value' => 'www.zopnow.com'
            ],
            [
                'organization_id' => 1,
                'key' => 'basic.siteTagLine',
                'value' => 'Get Groceries Fast, Fresh, Easy'
            ],
            [
                'organization_id' => 1,
                'key' => 'basic.logo',
                'value' => 'http://sn.zopnow.com/images/icons/logo/ZopNow-logo.svg'
            ],
            [
                'organization_id' => 1,
                'key' => 'basic.supportEmail',
                'value' => 'cs@zopnow.com'
            ],
            [
                'organization_id' => 1,
                'key' => 'basic.supportPhone',
                'value' => '+91-80-30752433'
            ],
            [
                'organization_id' => 1,
                'key' => 'catalogue.hasMultipleBrands',
                'value' => 'TRUE'
            ],
            [
                'organization_id' => 1,
                'key' => 'catalogue.hasMultipleVariants',
                'value' => 'TRUE'
            ],
            [
                'organization_id' => 1,
                'key' => 'catalogue.brandProperties',
                'value' => json_encode(
                    [
                        [
                            'name' => 'status',
                            'displayName' => 'Status',
                            'type' => 'enum',
                            'typeMeta' => [
                                'values' => ['ENABLED', 'DISABLED', 'DELETED'],
                                'default' => 'ENABLED',
                            ],
                            'required' => true,
                        ],
                    ]
                )
            ],
            [
                'organization_id' => 1,
                'key' => 'catalogue.variantConfig',
                'value' => json_encode([
                    [
                        'name' => 'size',
                        'displayName' => 'Size',
                        'description' => 'This is the the size of the variant eg:- S, M, L',
                        'type' => 'text',
                        'required' => false,
                    ],
                    [
                        'name' => 'color',
                        'displayName' => 'Color',
                        'description' => 'This is the color of the variant',
                        'type' => 'text',
                        'required' => false,
                    ],
                    [
                        'name' => 'quantity',
                        'displayName' => 'Quantity',
                        'description' => 'This is the quantity of variant eg:- ml, g, pc',
                        'type' => 'quantity',
                        'typeMeta' =>
                        [
                            'values' => ['ml', 'l', 'pc', 'kg', 'g', 'pack', 'gr', 's', 'pcs', 'unit']
                        ],
                        'required' => false,
                    ]]
                )
            ],
            [
                'organization_id' => 2,
                'key' => 'basic.organizationName',
                'value' => 'Ruchi\'s Biryani'
            ],
            [
                'organization_id' => 2,
                'key' => 'basic.siteUrl',
                'value' => 'www.ruchisbiryani.com'
            ],
            [
                'organization_id' => 2,
                'key' => 'basic.logo',
                'value' => 'https://dinerdeliver.com/assets/images/profile-images/ruchis%20biryani-logo.jpg'
            ],
            [
                'organization_id' => 2,
                'key' => 'basic.siteTagLine',
                'value' => 'Real taste of Hyderabadi Dum Biryani'
            ],
            [
                'organization_id' => 2,
                'key' => 'basic.supportEmail',
                'value' => 'cs@ruchisbiryani.com'
            ],
            [
                'organization_id' => 2,
                'key' => 'basic.supportPhone',
                'value' => '+91-80-70752466'
            ],
            [
                'organization_id' => 3,
                'key' => 'basic.organizationName',
                'value' => 'Silbatti'
            ],
            [
                'organization_id' => 3,
                'key' => 'basic.siteUrl',
                'value' => 'www.silbatti.com'
            ],
            [
                'organization_id' => 3,
                'key' => 'basic.logo',
                'value' => 'https://d1bj9m7vro2dcz.cloudfront.net/mp_487852_2016-11-29-16-54-48-000913.png'
            ],
            [
                'organization_id' => 3,
                'key' => 'basic.siteTagLine',
                'value' => 'Authentic Nati Food'
            ],
            [
                'organization_id' => 3,
                'key' => 'basic.supportEmail',
                'value' => 'cs@silbatti.com'
            ],
            [
                'organization_id' => 3,
                'key' => 'basic.supportPhone',
                'value' => '+91-80-80752467'
            ],
            [
                'organization_id' => 4,
                'key' => 'basic.organizationName',
                'value' => 'Rashtrakutas'
            ],
            [
                'organization_id' => 4,
                'key' => 'basic.siteUrl',
                'value' => 'www.rashtrakutas.com'
            ],
            [
                'organization_id' => 4,
                'key' => 'basic.logo',
                'value' => 'https://media-cdn.tripadvisor.com/media/photo-s/0d/5c/15/1f/logo.jpg'
            ],
            [
                'organization_id' => 4,
                'key' => 'basic.supportEmail',
                'value' => 'cs@rashtrakutas.com'
            ],
            [
                'organization_id' => 4,
                'key' => 'basic.supportPhone',
                'value' => '+91-80-50752488'
            ],
        ];
        foreach ([1, 2, 3] as $id) {
            $data = array_merge([
                [
                    'organization_id' => $id,
                    'key' => 'catalogue.categoryProperties',
                    'value' => json_encode(
                        [
                            [
                                'name' => 'foodCouponsAllowed',
                                'displayName' => 'Food coupons allowed',
                                'description' => 'Allow food coupons for the category or not',
                                'type' => 'boolean',
                                'typeMeta' => [
                                    "default" => true,
                                ],
                                'required' => false,
                            ],
                            [
                                'name' => 'status',
                                'displayName' => 'Status',
                                'type' => 'enum',
                                'typeMeta' => [
                                    'values' => ['ENABLED', 'DISABLED', 'DELETED'],
                                    'default' => 'ENABLED',
                                ],
                                'required' => false,
                            ],
                        ]
                    )
                ],
                [
                    'organization_id' => $id,
                    'key' => 'catalogue.productProperties',
                    'value' => json_encode(
                        [
                            [
                                'name' => 'veg',
                                'displayName' => 'Vegetarian',
                                'type' => 'boolean',
                                'typeMeta' => [
                                    "default" => true,
                                ],
                                'required' => false,
                            ],
                            [
                                'name' => 'status',
                                'displayName' => 'Status',
                                'type' => 'enum',
                                'typeMeta' => [
                                    'values' => ['ENABLED', 'DISABLED', 'DELETED'],
                                    'default' => 'ENABLED',
                                ],
                                'required' => true,
                            ],
                        ]
                    )
                ],
                [
                    'organization_id' => $id,
                    'key' => 'order.orderProperties',
                    'value' => json_encode(
                        [
                            [
                                'name' => 'status',
                                'displayName' => 'Status',
                                'type' => 'enum',
                                'typeMeta' => [
                                    'values' => ['PENDING', 'DISPATCHED', 'CANCELLED',
                                        'COMPLETED', 'EDITING', 'PARTIAL', 'CHECKED',
                                        'IN-CHECK', 'PICKING', 'PICKED', 'PACKED',
                                        'IN-TRANSIT', 'IN-HUB', 'RETURNED'],
                                    'default' => 'PENDING',
                                ],
                                'required' => true,
                            ],
                        ]
                    )
                ],
            ],$data);
        }
        $data[] = array(
            'organization_id' => 1,
            'key' => "order.orderTypes",
            'value' => '["DELIVERY","PICKUP"]'
        );
        $data[] = array(
            'organization_id' => 1,
            'key' => "order.paymentMethods",
            'value' => '["COD","ONLINE"]'
        );
        $configurations = $this->table('configurations');
        $configurations->insert($data)
                       ->save();
    }
}
