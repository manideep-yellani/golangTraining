<?php

use Phinx\Migration\AbstractMigration;

class SupportRefundsForOrganizations extends AbstractMigration
{

    public function change()
    {
        $paymentAccounts = $this->table("payment_accounts");
        $paymentAccounts->addColumn('refund_url','string', array('null' => true))
                    ->addColumn('refund_enquiry_url','string', array('null' => true))
                    ->save();
    }
}
