<?php

use Phinx\Migration\AbstractMigration;

class AddOrderLogEndpoint extends AbstractMigration
{

    public function up()
    {
        $endpointData = [[
            "url" => "order-service/order-log",
            "allowed_methods" => json_encode(['GET'])
        ]];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute("DELETE FROM endpoints WHERE url = 'order-service/order-log'");
    }
}
