<?php

namespace ZopNow\Hodor\Extension;

use ZopNow\Hodor\Controller\Extension;

class MarketPlace extends Base
{
    public function enable()
    {
        $organizationId = $this->organization->id;

        $requestData = [
            'organizationId' => strval($organizationId),
            'slug' => 'EntityMetaData',
            'status' => 'ENABLED'
        ];

        $extensionController = new Extension($requestData);
        $extensionController->put()->getData();

        $resp = \ZopNow\Arya\Utility\MicroService::callService(
            "config-service",
            "/meta-data",
            "GET",
            ['organizationId' => $organizationId]
        );
        if($resp['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please try it again");
        }

        $entityMetaData = json_decode($resp["body"], true);

        $this->updateMetaData($entityMetaData, "product");

        $resp = \ZopNow\Arya\Utility\MicroService::callService(
            "config-service",
            "/meta-data",
            "PUT",
            [
                'organizationId' => strval($organizationId),
                'config' => $entityMetaData["data"]['config']
            ]
        );

        if($resp['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("error while adding the custom fields");
        }

        return true;
    }

    public function disable()
    {
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule){
        return ['cost' => 0, 'metaData' =>  null];
    }

    private function updateMetaData(&$entityMetaData, $entity) {
        $metaData = $entityMetaData["data"]['config']["entityMetaData"][$entity];

        $isSellerExists = false;
        foreach($metaData as $data) {
            if(strtolower($data['displayName']) == 'seller') {
                if($data['type'] != 'string'){
                    throw new \ZopNow\Arya\Exception\ValidationException("product custom field seller should be string");
                }
                $isSellerExists = true;
            }
        }

        if(!$isSellerExists) {
            $entityMetaData['data']['config']['entityMetaData'][$entity]['Seller'] = [
                'type' => 'string',
                'isSystemGenerated' => true,
                'indexed' => true
            ];
        }
    }
}