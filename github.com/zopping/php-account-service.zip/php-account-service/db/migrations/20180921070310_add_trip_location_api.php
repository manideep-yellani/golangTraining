<?php

use Phinx\Migration\AbstractMigration;

class AddTripLocationApi extends AbstractMigration
{
    public function up() {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'LogisticsSupport'")['id'];
        $endpoints = [
            [
                'url' => 'logistics-service/tripLocations',
                'allowed_methods' => json_encode(["GET", "POST"]),
                'extension_id' => $extensionId,
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('logistics-service/tripLocations')"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('logistics-service/tripLocations')");
    }
}
