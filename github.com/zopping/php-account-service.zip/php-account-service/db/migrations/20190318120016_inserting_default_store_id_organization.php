<?php

use Phinx\Migration\AbstractMigration;

class InsertingDefaultStoreIdOrganization extends AbstractMigration
{
    public function change()
    {
        $rows = $this->fetchAll("SELECT organization_id,MIN(created_at) as created_at from stores where deleted_at is null GROUP BY organization_id");
        foreach ($rows as $row) {
            $organizationId = $row['organization_id'];
            $createdAt = $row['created_at'];
            $store = $this->fetchRow("SELECT id from stores where organization_id=$organizationId and created_at='$createdAt'");
            $storeId = $store['id'];
            $this->execute("update organizations set default_store_id= $storeId  where id= $organizationId");
        }
    }
}
