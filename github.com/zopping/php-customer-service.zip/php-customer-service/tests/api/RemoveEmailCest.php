<?php

class RemoveEmailCest extends BaseCest
{
    protected static $endpoint = '/email';
    protected static $table    = "emails";

    public function removeEmailWithValidId(ApiTester $I)
    {
        //customer (id=1) has 3 emails - (1,2,3) as per seeding
        $I->wantToTest("Removing email of a customer with multiple email");
        $customerId = 1;
        $organizationId = 1;
        $id = 1;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint. "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, ['id' => $id, "deleted_at" => NULL]);
    }

    public function removeEmailOfCustomerWith1Email(ApiTester $I)
    {
        //Customer 6 has only 1 address
        $I->wantToTest("Removing email of customer with only 1");
        $customerId = 6;
        $organizationId = 3;
        $emailId = $I->grabFromDatabase(self::$table, "id", ["customer_id" => $customerId, "deleted_at" => null]);
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint."/$emailId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Email cannot be deleted as the customer has only 1 email"]);
        $I->seeInDatabase(self::$table, ['id' => $emailId, "deleted_at" => NULL]);
     }

    public function removeEmailWithoutId(ApiTester $I)
    {
        $I->wantToTest("Remove email without passing id");
        $customerId = 6;
        $organizationId = 3;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass a valid id"));
    }

    public function removeEmailWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Delete Email with invalid id');
        $customerId = 2;
        $organizationId = 3;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint."/abc", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Model Exception: Email with id: abc not found"));
    }

    public function deletingAnEmailAgain(ApiTester $I)
    {
        $I->wantToTest("Double deletion of same email"); // in 1st test we have deleted this address
        $id = 1;
        $customerId = 1;
        $organizationId = 1;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint. "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, ['id' => $id, "deleted_at" => NULL]);
        $I->seeResponseContainsJson(["message" => "Model Exception: Email with id: $id not found"]);
    }
}