<?php

use Phinx\Migration\AbstractMigration;

class EntityMetaDataBoolAndEnumSupport extends AbstractMigration
{

    public function up()
    {
        $rows = $this->fetchAll("select `id`, `key`, `value` from configurations where `key` like 'entityMetaData.%'");
        foreach ($rows as $row) {
            $json = json_decode($row['value'], true);
            $nv   = [];
            foreach ($json as $key => $value) {
                $nv[$key] = [
                    "type" => "$value",
                ];
            }
            $newVal = json_encode($nv);
            $this->execute("update configurations set `value` = '$newVal' where id = $row[id]");
        }
    }

    public function down()
    {
        $rows = $this->fetchAll("select `id`, `key`, `value` from configurations where `key` like 'entityMetaData.%'");
        foreach ($rows as $row) {
            $json = json_decode($row['value'], true);
            $nv = [];
            foreach ($json as $key => $value) {
                $nv[$key] = $value["type"];
            }
            $newVal = json_encode($nv);
            $this->execute("update configurations set `value` = '$newVal' where id = $row[id]");
        }
    }
}