<?php

return array(
    "ZopNow\Arya\App\RestApplication" => array(
        'controllerNamespace' => "ZopNow\\CustomerService\\Controller",
    ),
    "ZopNow\Arya\DB\MySql" => array(
        "test_customer_service" => array(
            "write" => array(
                "host" => 'localhost',
                "database" => 'test_customer_service',
                "username" => "root",
                "password" => "password"
            ),
            "read" => array(
                "host" => 'localhost',
                "database" => 'test_customer_service',
                "username" => "root",
                "password" => "password"
            )
        )
    ),
    "ZopNow\Arya\DB\Redis" => array(
        "host" => "127.0.0.1",
        "port" => "6379",
        "database" => 2
    ),
    "ZopNow\CustomerService\Utility\Event" => [
        "pubsubProjectId" => 'zopsmart-176211',
        "pretend" => true,
    ],
    "ZopNow\Arya\Utility\Encryption" => array(
        'key' => '223kj8ydshfads8hdf'
    ),
    "ZopNow\Arya\Log" => array(
        "fileName" => "/var/log/zopnow/customer-service.log",
        "level" => "DEBUG" // DEBUG < INFO < NOTICE < WARNING < ERROR < CRITICAL < ALERT < EMERGENCY
    ),
    "\ZopNow\Arya\Utility\MicroService" => array(
        "order-service" => "http://order-service",
        "config-service" => "http://config-service",
        "communication-service" => "http://communication-service",
        "account-service" => "http://account-service",
        "logistics-service" => "http://logistics-service"
    ),
    "\ZopNow\CustomerService\Controller\CustomerUpload" => array(
        "uploadDir" => __DIR__ . "/../data/",
        "fileIndex" => "fileUpload",
    ),
);
