<?php


namespace ZopNow\Hodor\Extension;

use ZopNow\Hodor\Controller\Extension;

class ShipRocket extends Base
{

    public function enable()
    {
        $organizationId = $this->organization->id;
        $resp = \ZopNow\Arya\Utility\MicroService::callService(
            "config-service",
            "/config/website",
            "GET",
            ['organizationId' => $organizationId]
        );
        $googleMapsApiKey = json_decode($resp["body"], true)["data"]["website"]["googleApisKey"];
        if (empty($googleMapsApiKey)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please configure google maps api key");
        }

        $requestData = [
            'organizationId' => strval($this->organization->id),
            'slug' => 'EntityMetaData',
            'status' => 'ENABLED'
        ];

        $extensionController = new Extension($requestData);
        $extensionController->put()->getData();

        $resp = \ZopNow\Arya\Utility\MicroService::callService(
            "config-service",
            "/meta-data",
            "GET",
            ['organizationId' => $organizationId]
        );

        $entityMetaData = json_decode($resp["body"], true);

        //update product
        $this->updateMetaData($entityMetaData,'product');
        //update variant
        $this->updateMetaData($entityMetaData,'variant');

        $resp = \ZopNow\Arya\Utility\MicroService::callService(
            "config-service",
            "/meta-data",
            "PUT",
            [
                'organizationId' => strval($organizationId),
                'config' => $entityMetaData["data"]['config']
            ]
        );

        if($resp['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("error during add the custom fields");
        }

        return true;
    }

    public function disable()
    {
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule) {
        return ['cost' => 0, 'metaData' =>  null];
    }

    public function configurePrerequisites($prerequisites) {
        foreach ($prerequisites as &$prerequisite) {
            switch($prerequisite['name']) {
                case 'GOOGLE_MAP_API_KEY':
                    $organizationId = $this->organization->id;
                    $resp = \ZopNow\Arya\Utility\MicroService::callService(
                        "config-service", 
                        "/config/website", 
                        "GET", 
                        ['organizationId' => $organizationId]
                    );
                    $googleMapsApiKey = json_decode($resp["body"], true)["data"]["website"]["googleApisKey"];
                    $prerequisite['isConfigured'] = true;
                    if (empty($googleMapsApiKey)) {
                        $prerequisite['isConfigured'] = false;
                    }
            }
        }

        return $prerequisites;
    }

    private function updateMetaData(&$entityMetaData,$entity) {
        $metaData = $entityMetaData["data"]['config']["entityMetaData"][$entity];

        $isWeight = false;
        $isCountryOrigin = false;
        foreach($metaData as $data) {
            if(strtolower($data['displayName']) == 'weight'){
                if($data['type'] != 'number'){
                    throw new \ZopNow\Arya\Exception\ValidationException("product custom field weight should be number");
                }
                $isWeight = true;
            }

            if(strtolower($data['displayName']) == 'country origin'){
                if($data['type'] != 'string'){
                    throw new \ZopNow\Arya\Exception\ValidationException("product custom field country origin should be string");
                }
                $isCountryOrigin = true;
            }
        }

        if(!$isWeight) {
            $entityMetaData['data']['config']['entityMetaData'][$entity]['Weight'] = [
                'type' => 'number',
                'isSystemGenerated' => true
            ];
        }

        if(!$isCountryOrigin) {
            $entityMetaData['data']['config']['entityMetaData'][$entity]['Country Origin'] = [
                'type' => 'string',
                'isSystemGenerated' => true
            ];
        }
    }
}
