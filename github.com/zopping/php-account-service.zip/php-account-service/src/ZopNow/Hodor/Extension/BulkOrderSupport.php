<?php

namespace ZopNow\Hodor\Extension;


use ZopNow\Arya\Exception\ValidationException;

class BulkOrderSupport extends Base
{
    public function enable()
    {
        $organizationId = $this->organization->id;
        \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", "POST", ['organizationId' => "$organizationId", 'key'=>"bulkOrder", 'entity'=>"order", 'type'=> "Boolean"]);
        return true;
    }

    public function disable()
    {
        return true;
    }
    public function getBillingAmount($startTime, $endTime, $pricingRule){
        return ['cost' => 0, 'metaData' =>  null];
    }

}