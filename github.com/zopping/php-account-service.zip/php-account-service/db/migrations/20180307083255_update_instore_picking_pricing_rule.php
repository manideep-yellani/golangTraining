<?php

use Phinx\Migration\AbstractMigration;

class UpdateInstorePickingPricingRule extends AbstractMigration
{

    public function up()
    {
        $pricingRule = json_encode(['TYPE' => 'DAILY', 'RATE' => 'PERCENT', 'COST' => 1]);
        $this->query("UPDATE extensions  set `pricing_rule`='" . $pricingRule. "'  WHERE `slug` = 'InStoreProcessing'");
    }

    public function down()
    {
        //Not required
    }

}
