<?php

use Phinx\Migration\AbstractMigration;

class AddOnlinePaymentsExtension extends AbstractMigration
{

    public function up()
    {
        $pricing = "1.75% of the transaction processed";
        $pricingRule = json_encode(['TYPE' => 'MONTHLY', 'RATE' => 'PERCENT', 'COST' => 1.75]);
        $data = [
            "name" => "Online Payments",
            "slug" => "OnlinePaymentSupport",
            "description" => "Enable online payments for your domain",
            "enable_helper_text" => "Online payments for an order is enabled and you can configure different payment options ",
            "disable_helper_text" => "Online payments are not supported for an order",
            "pricing" => $pricing,
            "pricing_rule" => $pricingRule
        ];
        $this->insert('extensions', $data);
        $extensionId = $this->fetchRow(
                "SELECT `id` from `extensions` where `slug` = 'OnlinePaymentSupport'"
            )['id'];
        $endpointData = [
            [ "url" => "account-service/payment-gateway", "allowed_methods" => json_encode(['GET'])],
            ["url" => "account-service/payment-mode", "allowed_methods" => json_encode(['GET']), "extension_id" => $extensionId],
            ["url" => "account-service/bank-account","allowed_methods" => json_encode(['GET', 'POST', 'PUT']),  "extension_id" => $extensionId]
        ];
        $this->insert('endpoints', $endpointData);
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
            . json_encode(['GET','PUT'])
            . '\' , extension_id = '.$extensionId.'  where url = "account-service/payment-account"');
    }

    public function down() 
    {
        $this->execute('DELETE from `extensions` where `slug` = "OnlinePaymentSupport"');
        $extensionId = $this->fetchRow(
                "SELECT `id` from `extensions` where `slug` = 'OnlinePaymentSupport'"
            )['id'];
        $this->execute("DELETE from `endpoints` where `extension_id` = $extensionId");
    }

}
