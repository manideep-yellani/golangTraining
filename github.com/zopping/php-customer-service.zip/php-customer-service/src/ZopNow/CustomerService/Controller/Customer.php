<?php

namespace ZopNow\CustomerService\Controller;

use ZopNow\Arya\Exception\ValidationException;

class Customer extends \ZopNow\Arya\Controller\ModelController
{
    //communication-type used by commuication-service
    const SIGNUP_COMMUNICATION = "customer/signup";
    const VERIFIED_COMMUNICATION = "customer/verified";
    const FORGOT_PASSWORD_COMMUNICATION = "customer/forgotPassword";
    protected static $filterableFields = ['organization_id', 'phone', 'email', 'client_id', 'id','joined_on','updated_at','updated_before','updated_after'];
    protected static $excludeAttributes = ['excludeOrderSummary'];
    public function get()
    {
        $data = $this->getRequestParams(['organizationId']);
        if (!empty($this->data['id']) && !is_array(($this->data['id']))) {
            $model = $this->model;
            if ($data['organizationId'] != $this->model->organization_id) {
                throw new ValidationException("Invalid customer");
            }
            $response = $this->getDetails();
        } elseif (!empty($this->data['clientId'])) {
            $params = $this->getRequestParams(['organizationId', 'clientId']);
            $customer = $this->modelClass::getFromClientId($params['clientId'], $params['organizationId']);
            if (empty($customer)) {
                throw new \ZopNow\Arya\Exception\ModelException(
                    "Customer with client id " . $params['clientId'] . " not found"
                );
            }
            $this->model = $customer;
            $this->data['id'] = $this->model->id;
            $response = $this->getDetails();
        } else {
            $data = $this->getRequestParams(['organizationId'], ['referenceNumber']);
            if (!empty($data['referenceNumber'])) {
                $orderObj = \ZopNow\Arya\Utility\MicroService::callService("order-service", "/order", 'GET', ["organizationId" => $this->organization_id, "id" => $data["referenceNumber"]]);
                $orderDetails = json_decode($orderObj['body'], true);
                $customerData = array();
                if (!empty($orderDetails['data'])) {
                    $customerData = $orderDetails['data']['order']['customer'];
                }
                $response = array("customer" => $customerData);
            } else {
                $list = $this->getList();
                $response = $this->getListData($list);
                $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'customer', 'paginate' => 'false']);
                $addressResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'address', 'paginate' => 'false']);
                $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
                $addressFieldData = json_decode($addressResponse['body'], true)['data']['customField'];
                foreach ($response['customer'] as &$row) {
                    $row['metaData'] = $this->getMetaData($row['metaData'], $fieldData);
                    $row['defaultAddress']['metaData'] = $this->getMetaData($row['defaultAddress']['metaData'], $addressFieldData);
                    foreach ($row['addresses'] as &$address) {
                        $address['metaData'] = $this->getMetaData($address['metaData'], $addressFieldData);
                    }
                }
            }
        }
        return (new \ZopNow\Arya\View\Base([
                'status' => "SUCCESS",
                'message' => 'OK',
                'data' => $response
            ])
        );
    }

    public function getDetails()
    {
        $details = parent::getDetails();
        $key = array_keys($details)[0];
        $exclude = $this->getRequestParams([],self::$excludeAttributes);
        if (!isset($exclude['excludeOrderSummary']) || $exclude['excludeOrderSummary'] == 'false') {
            $details[$key]['orderSummary'] = $this->model->order_summary;
        }
        $details[$key]['defaultPhone'] = $this->getDefaultParamAttribute($details[$key]['phones'],$this->model->default_phone_id);
        $details[$key]['defaultEmail'] = $this->getDefaultParamAttribute($details[$key]['emails'],$this->model->default_email_id);
        $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $this->model->organization_id, 'entity' => 'customer', 'paginate' => 'false']);
        $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
        $details[$key]['metaData'] = $this->getMetaData($details[$key]['metaData'], $fieldData);

        $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $this->model->organization_id, 'entity' => 'address', 'paginate' => 'false']);
        $addressFieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
        foreach ($details[$key]['addresses'] as &$address) {
            $address['metaData'] = $this->getMetaData($address['metaData'], $addressFieldData);
        }
        $details[$key]['defaultAddress']['metaData'] = $this->getMetaData($details[$key]['defaultAddress']['metaData'], $addressFieldData);
        if (empty($details[$key]['image'])) {
            $email = $details[$key]['emails'][0]['email'] ?? null;
            if (!empty($email)) {
                $details[$key]['image'] = "https://www.gravatar.com/avatar/" . md5(strtolower($email))
                        . "?d=" . "https://ui-avatars.com/api/name=" . urlencode($details[$key]['name']);
            } else {
                $details[$key]['image'] = "https://ui-avatars.com/api/name=" . urlencode($details[$key]['name']);
            }
        }
        return $details;
    }

    /**
     * To validate the given customerId exists in this organization
     * @return boolean
     */
    public static function validateCustomer($id, $organizationId)
    {
        return \ZopNow\CustomerService\Model\Customer::validateCustomer($id, $organizationId);
    }

    public static function getFromEmail($email, $organizationId)
    {
        return \ZopNow\CustomerService\Model\Customer::getFromEmail($email, $organizationId);
    }

    public static function getFromPhone($phone, $organizationId)
    {
        return \ZopNow\CustomerService\Model\Customer::getFromPhone($phone, $organizationId);
    }

    public function post()
    {
        $data = $this->getRequestParams(array("organizationId") , array("isOffline"));
        //Verifying domain.Fetched DomainName which will be used to send verify link in the email.
        $organizationResponse = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/organization/".$data['organizationId'], 'GET');
        if ($organizationResponse['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Organization");
        }
        $organization = json_decode($organizationResponse['body'], true)['data']['organization'];
        $isOfflineUser = !empty($data['isOffline']) ? filter_var($data['isOffline'], FILTER_VALIDATE_BOOLEAN) : false;

        if ($isOfflineUser) {
            $customerResponse = $this->addOfflineUser();
        }
        else {
            $customerResponse = $this->addOnlineUser($organization);
        }
        /**
         * The status code returned will be one of the following values:
         * 201 : If a new customer is created with the provided data.
         * 211 : If an existing customer details are edited and any new entities were linked to the same customer.
         * 212 : If two or more existing customers are merged to get a single customer.
         */
        $response = array(
            'code' => $customerResponse['code'],
            'status' => "SUCCESS",
            'data' => $customerResponse['customer']
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function put()
    {
        $data = $this->getRequestParams(["id","organizationId"], ["name", "image", "defaultAddressId","defaultPhoneId","defaultEmailId", "metaData", "clientId","status"]);
        self::validateCustomer($data['id'], $data['organizationId']);
        if (isset($data['name']) && $data['name'] == "") {
            throw new ValidationException("Invalid Name");
        }
        
        // Validate that the address belongs to this customer
        if (isset($data['defaultAddressId']) && $this->model->default_address_id != $data['defaultAddressId']) {
            $customerId = (new Address(["id" => $data['defaultAddressId']]))->getCustomerId();
            if ($customerId != $data['id']) {
                throw new \ZopNow\Arya\Exception\ModelException("Address with id: {$data['defaultAddressId']} not found");
            }
        }

        // Validate that the phone belongs to this customer
        if (isset($data['defaultPhoneId']) && $this->model->default_phone_id != $data['defaultPhoneId']) {
            $customerId = (new Phone(["id" => $data['defaultPhoneId']]))->getCustomerId();
            if ($customerId != $data['id']) {
                throw new \ZopNow\Arya\Exception\ModelException("Phone with id: {$data['defaultPhoneId']} not found");
            }
        }

        // Validate that the email belongs to this customer
        if (isset($data['defaultEmailId']) && $this->model->default_email_id != $data['defaultEmailId']) {
            $customerId = (new Email(["id" => $data['defaultEmailId']]))->getCustomerId();
            if ($customerId != $data['id']) {
                throw new \ZopNow\Arya\Exception\ModelException("Email with id: {$data['defaultEmailId']} not found");
            }
        }
        if (isset($data['metaData']) && !empty($data['metaData'])) {
            if (!is_array($data['metaData'])) {
                throw new ValidationException("Invalid format for metadata");
            }

            $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'customer', 'paginate' => "false"]);
            $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
            if (empty($fieldData)) {
                throw new ValidationException("There is no metadata configured");
            }
            foreach ($data['metaData'] as $key => $value) {
                $flag = false;
                foreach ($fieldData as $customField) {
                    if ($key == $customField['key']) {
                        $flag = true;
                        $metaMap[$customField['id']] = $value;
                        break;
                    }
                }
                if ($flag == false) {
                    throw new ValidationException("$key not configured in metadata");
                }

            }
            $data['metaData'] = $metaMap;
        }

        $oldData = $this->getDetails();
        if(empty($data['metaData'])) {
            $data['metaData'] = $this->model->meta_data;
        }
     
        if (!empty($data['clientId']) && $oldData['customer']['clientId'] != $data['clientId']) {
            $clientCustomers = \ZopNow\Arya\DB\MySql::select("SELECT id, customer_id FROM client_customers WHERE deleted_at IS NULL AND client_id = '". \ZopNow\Arya\DB\MySql::escape($data['clientId'])
                ."' AND organization_id = " . \ZopNow\Arya\DB\MySql::escape($data['organizationId']));
            if (sizeof($clientCustomers) > 0 && $clientCustomers[0]['customer_id'] != $data['id']) {
                throw new \ZopNow\Arya\Exception\ValidationException("clientId already exists");
            }
            
            if (empty($oldData['customer']['clientId'])) {
                $this->addRelationsData(["clientId" => $data['clientId'], "organizationId" => $data['organizationId']]);
            } else {
                $totalOrders = $oldData['customer']['totalOrders'];
                if ($totalOrders > 0) {
                    throw new \ZopNow\Arya\Exception\ValidationException("can not update clientId");
                } else {
                    $this->model->updateCustomerClientId($oldData['customer']['clientId'], $data['clientId'], $data['id'], $data['organizationId']);
                }
            }
        }

        $customer = $this->edit($data);
        
        $data['oldData'] = $oldData;
        $data['newData'] = $customer;
        (new \ZopNow\CustomerService\Utility\Event("customer", $data))->publish();

        return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $customer
        ]);
    }

    public function changePassword()
    {
        $data = $this->getRequestParams(['oldPassword', 'newPassword']);
        $orgId = $this->model->organization_id;
        $configResponse= \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/passwordEncryption.algorithm", "GET", ["organizationId" => $orgId]);
        $passEnc=json_decode($configResponse['body'], true)['data']['passwordEncryption']['algorithm'];
        if (($configResponse['statusCode']==200&&$passEnc == "ZOPALGO")||($configResponse['statusCode']!=200)){
            $oldPassword = \ZopNow\Arya\Utility\Encryption::encrypt($data['oldPassword'], FALSE);
        } else {

            $passwordParam['salt']=strval($this->model->salt);
            $passwordParam['password']=strval($data['oldPassword']);
            $authResponse = \ZopNow\Arya\Utility\MicroService::callService("auth-service","/password",'POST',$passwordParam);
            $oldPassword= json_decode($authResponse['body'], true)['data']['hashedPassword'];
        }

        if($data['newPassword'] == $data['oldPassword']) {
            throw new \ZopNow\Arya\Exception\ValidationException("New password cannot be same as the old password");
        }
        if($this->model->password !== $oldPassword) {
            throw new \ZopNow\Arya\Exception\ValidationException("Cannot change password, old password incorrect");
        } else {
            if (($configResponse['statusCode']==200 && $passEnc == "ZOPALGO")||($configResponse['statusCode']!=200)){
                $newPassword = \ZopNow\Arya\Utility\Encryption::encrypt($data['newPassword'], FALSE);
                $this->model->password = $newPassword;
            } else {
                $passwordParam=[];
                $passwordParam['password']=strval($data['newPassword']);
                $authResponse = \ZopNow\Arya\Utility\MicroService::callService("auth-service","/password",'POST',$passwordParam);
                if($authResponse['statusCode']==200){
                    $newPassword= json_decode($authResponse['body'], true)['data']['hashedPassword'];
                    $salt = json_decode($authResponse['body'], true)['data']['salt'];
                    $this->model->password = $newPassword;
                    $this->model->salt = $salt;
                } else {
                    throw new \ZopNow\Arya\Exception\ValidationException("Invalid Password");
                }
            }
            
            $this->model->save();
        }
        return new \ZopNow\Arya\View\Base([
            "code" => 200,
            "status" => "SUCCESS",
            "message" => "Password changed successfully!",
        ]);
    }

    public function verifyEmail()
    {
        $data = $this->getRequestParams(array("hash"));
        $emailId = \ZopNow\Arya\Utility\Encryption::decrypt($data['hash']);
        try {
            $email = \ZopNow\CustomerService\Model\Email::findOrFail($emailId);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            throw new \ZopNow\Arya\Exception\ModelException("Invalid Email");
        }
        if ($email->status != "VERIFIED") {
            $email->status = "VERIFIED";
            $email->save();
            $customer = $email->customer;

            //Generate and send email for successful verification
            $organizationResponse = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/organization/".$customer['organization_id'], 'GET');
            if ($organizationResponse['statusCode'] != 200) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid Organization");
            }
            $response = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/config/orderCommunication", "GET", ["organizationId" => $customer['organization_id']]);
            $accountSpecificData = json_decode($response['body'], true)['data']['config']['orderCommunication'];
            if (isset($accountSpecificData['sendCommunication']) && !$accountSpecificData['sendCommunication']) {
                return;
            }
            $organization = json_decode($organizationResponse['body'], true)['data']['organization'];
            $emailData = [];
            $emailData['to'] = $email->email;
            $emailData['data'] = [
                "customerName" => $customer['name'],
                "loginUrl" => $organization['domain'],
                "organizationName" => $organization['name'],
                "organizationId" => $customer['organization_id'],
                "supportEmail" => $organization['owner']['emails'][0]['email']
            ];
            $emailData['type'] = self::VERIFIED_COMMUNICATION;
            $emailData['transactional'] = true;
            \ZopNow\Arya\Utility\MicroService::callService("communication-service", "/email", 'POST', $emailData);
        } else {
            //Logging
            \ZopNow\Arya\App\RestApplication::log("Customer email already verified", ["email" => $email]);
        }
    }

    public function resetPassword()
    {
        $data = $this->getRequestParams(['id']);
        $gPassword = \ZopNow\CustomerService\Utility\Password::generate();
        $orgId = $this->model->organization_id;
        $customer = \ZopNow\CustomerService\Model\Customer::findOrFail($data['id']);
        $configResponse= \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/passwordEncryption.algorithm", "GET", ["organizationId" => $orgId]);
        $passEnc=json_decode($configResponse['body'], true)['data']['passwordEncryption']['algorithm'];
        if (($configResponse['statusCode']==200&&$passEnc == "ZOPALGO")||($configResponse['statusCode']!=200)){
            $customer->password = \ZopNow\Arya\Utility\Encryption::encrypt($gPassword, false);
        } else {
            $passwordParam['salt']=strval($customer->salt);
            $passwordParam['password']=strval($gPassword);
            $authResponse = \ZopNow\Arya\Utility\MicroService::callService("auth-service","/password",'POST',$passwordParam);
            if($authResponse['statusCode']==200){
                $customer->password= json_decode($authResponse['body'], true)['data']['hashedPassword'];
            } else {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid Password");    
            }
        }
        $customer->save();

        //Send SMS using communication service
        $organizationResponse = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/organization/".$this->model->organization_id, 'GET');
        if ($organizationResponse['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Organization");
        }
        $organization = json_decode($organizationResponse['body'], true)['data']['organization'];

        $smsData = [];
        $smsData['phone'] = $customer->phones()->first()->phone;
        $smsData['type'] = self::FORGOT_PASSWORD_COMMUNICATION;
        $smsData["organizationId"] = "$organization[id]";
        $smsData['data'] = [
            "password" => "$gPassword",
            "organizationName" => $organization['name']
        ];
        $smsData['transactional'] = true;
        \ZopNow\Arya\Utility\MicroService::callService("go-communication-service", "/sms", 'POST', $smsData);

        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'message' => "Password Reset Successfully"
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function getStats()
    {
        $data = $this->getRequestParams(["organizationId","startDate", "endDate"]);
        $organizationId = $data['organizationId'];
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];
        $result = [];
        $customersAcquisitionData = \ZopNow\CustomerService\Model\Customer::getCustomerAcquired($organizationId, $startDate, $endDate);
        while (strtotime($startDate) <= strtotime($endDate)) {
            $result[$startDate] = $customersAcquisitionData[$startDate] ?? 0;
            $startDate = date ("Y-m-d", strtotime("+1 day", strtotime($startDate)));
  }
        return $result;
    }

    public static function getFromClientId($clientId, $organizationId)
    {
        return \ZopNow\CustomerService\Model\Customer::getFromClientId($clientId, $organizationId);
    }

    private function validateFields($data)
    {
        //Check if phone number validation is required
        $organizationResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", 'GET', ['organizationId' => $data['organizationId']]);
        $configData = json_decode($organizationResponse['body'], true)['data']['customers'];
        $validate = (isset($configData['validatePhone']) && !$configData['validatePhone']) ? FALSE : TRUE;
        if ($validate && !empty($data['phone'])) {
            //$data['phone'] = (strlen($data['phone']) == 10) ? "+91".$data['phone'] : $data['phone'];
            if (!is_numeric($data['phone'])) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid Phone");
            }
        }

        $verificationRequired = (isset($configData['verificationRequired']) && $configData['verificationRequired']);
        if($verificationRequired){
              $data['status'] = "DISABLED";
        }
        if (!empty($data['email'])
            && !\ZopNow\Arya\Utility\Validator::isEmail($data['email'])
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Email");
        }
        if (!empty($data['latitude'])
            && !\ZopNow\Arya\Utility\Validator::isLatitude(floatval($data['latitude']))
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid latitude");
        }
        if (!empty($data['longitude'])
            && !\ZopNow\Arya\Utility\Validator::isLongitude(floatval($data['longitude']))
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid longitude");
        }

        if(empty(trim($data["pincode"],' '))){
            $data["pincode"] = null;
        }
        if(empty(trim($data["state"],' '))){
            $data["state"] = null;
        }
        if(empty(trim($data["countryCode"],' '))){
            $data["countryCode"] = $this->getCountryCode($data["organizationId"]);
        }

        if (!empty($data['metaData'])) {
            if (!is_array($data['metaData'])) {
                throw new ValidationException("Invalid format for metadata");
            }
            $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'customer']);
            $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
            if (empty($fieldData)) {
                throw new ValidationException("There is no metadata configured");
            }
            foreach ($data['metaData'] as $key => $value) {
                $flag = false;
                foreach ($fieldData as $customField) {
                    if ($key == $customField['key']) {
                        $flag = true;
                        $metaMap[$customField['id']] = $value;
                        break;
                    }
                }
                if ($flag == false) {
                    throw new ValidationException("$key not configured in metadata");
                }

            }
            $data['metaData'] = $metaMap;
        }

        if (!empty($data['clientId'])) {
            $clientCustomers = \ZopNow\Arya\DB\MySql::select("SELECT id FROM client_customers WHERE deleted_at IS NULL AND client_id = ". \ZopNow\Arya\DB\MySql::escape($data['clientId'])
                ." AND organization_id = " . \ZopNow\Arya\DB\MySql::escape($data['organizationId']));
            if (sizeof($clientCustomers) > 0) {
                throw new \ZopNow\Arya\Exception\ValidationException("clientId already exists");
            }
        }

        return $data;
    }

    private function addRelationsData($data)
    {
       
        //Add clientId, phone & email if passed
        if (!empty($data['clientId'])) {
            //If client id is passed, then enter into client_customers table
            $client = new \ZopNow\CustomerService\Model\ClientCustomer();
            $client->client_id = $data['clientId'];
            $client->organization_id = $data['organizationId'];
            $this->model->clientIds()->save($client);
        }
        if (!empty($data['phone'])) {
            $phoneData = ["customerId" => $this->model->id,
                "organizationId" => $data['organizationId'],
                "phone" => $data['phone']];
            (new Phone($phoneData))->post();
        }
        if (!empty($data['email'])) {
            $emailData = ["customerId" => $this->model->id,
                "organizationId" => $data['organizationId'],
                "email" => $data['email']];
            (new Email($emailData))->post();
        }
    }

    private function addOfflineUser()
    {
        $mandatoryFields = array("organizationId", "name");
        //Either phone or email must be mandatory for offline users.
        $optionalFields  = array("phone", "email", "image","state" ,"countryCode","longitude", "latitude", "clientId", "metaData", "joinedTime");
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);
        $data = $this->validateFields($data);
        $fields = [];
        try{
            if (!empty($data['email'])) {
                \ZopNow\CustomerService\Model\Customer::acquireLock($data['email']);
                $fields[] = 'email';
            } 
            if (!empty($data['phone'])) {
                \ZopNow\CustomerService\Model\Customer::acquireLock($data['phone']);
                $fields[] = 'phone';
            }
        } catch (\Exception $e) {
            foreach ($fields as $field) {
                \ZopNow\CustomerService\Model\Customer::revertLock($data[$field]);
            }
            throw $e;
        }
        //if duplicatePhonesAllowed oldCustomerFromPhone is always null
        $configResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", 'GET', ['organizationId' => $data["organizationId"]]);
        $configData = json_decode($configResponse['body'], true)['data']['customers'];
        $duplicatePhonesAllowed = (isset($configData['duplicatePhonesAllowed']) && !$configData['duplicatePhonesAllowed']) ? FALSE : TRUE;
        if ($duplicatePhonesAllowed){
            $oldCustomerFromPhone = null;
        }else {
            $oldCustomerFromPhone = isset($data['phone']) ? Customer::getFromPhone($data['phone'], $data['organizationId']) : null;
        }
        $oldCustomerFromEmail = isset($data['email'])?Customer::getFromEmail($data['email'], $data['organizationId']):null;
        $oldCustomerFromClientId = !empty($data['clientId'])?Customer::getFromClientId($data['clientId'], $data['organizationId']):null;
        //Unsetting already existing relations so that they are not added again
        if (!empty($oldCustomerFromEmail)) {
            unset($data['email']);
        }
        if (!empty($oldCustomerFromPhone)) {
            unset($data['phone']);
        }
        if (!empty($oldCustomerFromClientId)) {
            unset($data['clientId']);
        }

        try {
            \ZopNow\Arya\DB\MySql::startTransaction();
            if (empty($oldCustomerFromPhone) && empty($oldCustomerFromEmail)
                && empty($oldCustomerFromClientId)
            ) {
                /**
                 * If there are no existing entries with either phone, email or clientId,
                 * add a new customer with the passed details
                 */
                $customer  = $this->add($data)['customer'];
                $this->addRelationsData($data);
                $statusCode = 201;
            } elseif (!empty($oldCustomerFromClientId)
                && empty($oldCustomerFromPhone) && empty($oldCustomerFromEmail)
            ) {
                /**
                 * If a customer exists for only the given client id, edit the existing customer details
                 *  and link the unlinked phone and email.
                 */
                $customer = $this->editExistingCustomer($oldCustomerFromClientId, $data);
                $statusCode = 211;
            }
            elseif (!empty($oldCustomerFromClientId)) {
                /**
                 * There exists a customer with given client id and
                 *  a customer with the given phone or email.
                 */
                if (!empty($oldCustomerFromEmail)
                    && !empty($oldCustomerFromEmail->clientIds->toArray())
                    && $oldCustomerFromClientId->id != $oldCustomerFromEmail->id
                ){
                    /**
                     * The ids of the customers do not match and
                     *  customer with email is already mapped to another client id.
                     */
                    throw new ValidationException("Email already exists");
                }
                if (!empty($oldCustomerFromPhone)
                    && !empty($oldCustomerFromPhone->clientIds->toArray())
                    && $oldCustomerFromClientId->id != $oldCustomerFromPhone->id
                ) {
                    /**
                     * The ids of the customers do not match and
                     *  customer with phone is already mapped to another client id.
                     */
                    throw new ValidationException("Phone already exists");
                }
                $statusCode = 211;
                if (!empty($oldCustomerFromEmail) && $oldCustomerFromClientId->id != $oldCustomerFromEmail->id) {
                    /**
                     * If a customer exists for the given email and is not mapped to a client id
                     *  and a customer exists for the given client id,
                     *  the two customer objects must be merged.
                     */
                    $this->mergeExistingCustomers($oldCustomerFromEmail, $oldCustomerFromClientId);
                    $statusCode = 212;
                }
                if (!empty($oldCustomerFromPhone) && $oldCustomerFromClientId->id != $oldCustomerFromPhone->id) {
                    /**
                     * If a customer exists for the given phone and is not mapped to a client id
                     *  and a customer exists for the given client id,
                     *  the two customer objects must be merged.
                     */
                    $this->mergeExistingCustomers($oldCustomerFromPhone, $oldCustomerFromClientId);
                    $statusCode = 212;
                }
                $customer = $this->editExistingCustomer($oldCustomerFromClientId, $data);
            } else {
                /**
                 * Reaches here if no customer exists for the given client id and
                 *  a customer exists for the given phone and/or email
                 */
                if (!empty($oldCustomerFromPhone)
                    && !empty($oldCustomerFromPhone->clientIds->toArray())
                    && !empty($data['clientId'])
                ) {
                    //Throw error since you are trying to map two client ids to the same customer
                    throw new ValidationException("Phone already exists");
                }
                if (!empty($oldCustomerFromEmail)
                    && !empty($oldCustomerFromEmail->clientIds->toArray())
                    && !empty($data['clientId'])
                ) {
                    //Throw error since you are trying to map two client ids to the same customer
                    throw new ValidationException("Email already exists");
                }
                if (empty($oldCustomerFromPhone)) {
                    $oldCustomer = $oldCustomerFromEmail;
                } elseif (empty($oldCustomerFromEmail)) {
                    $oldCustomer = $oldCustomerFromPhone;
                }
                if (!empty($oldCustomer)) {
                    /**
                     * If a customer exists for only the given phone or email,
                     *  edit the customer details and map the unmapped email, phone and client id
                     */
                    $customer = $this->editExistingCustomer($oldCustomer, $data);
                    $statusCode = 211;
                } else {
                    /**
                     * Reaches here only if a customer does not exist for the given client id
                     * and a customer exists for given phone and the given email
                     */
                    if (($oldCustomerFromPhone->id != $oldCustomerFromEmail->id)) {
                        throw new ValidationException("Email or phone already exists");
                    }
                    $statusCode = 211;
                    $customer = $this->editExistingCustomer($oldCustomerFromPhone, $data);
                }
            }
            \ZopNow\Arya\DB\MySql::commit();
        } catch (\Exception $e) {
            foreach ($fields as $field){
                \ZopNow\CustomerService\Model\Customer::revertLock($data[$field]);
            }
            \ZopNow\Arya\DB\MySql::rollback();
            throw $e;
        }
        $this->model = $this->modelClass::findOrFail($customer['id']);
        $customerDetails = $this->getDetails();
        foreach ($fields as $field){
            \ZopNow\CustomerService\Model\Customer::revertLock($data[$field]);
        }

        $response = [
            "code" => $statusCode,
            "customer" => $customerDetails
        ];
        return $response;
    }

    private function addOnlineUser($organizationDetails)
    {
        //$isSignup = $this->isSignup;
        //$isSignup = isset($isSignup) ? filter_var($isSignup, FILTER_VALIDATE_BOOLEAN) : true;
        $mandatoryFields = array("organizationId", "name");
        /*if ($isSignup) {
            $mandatoryFields = array_merge($mandatoryFields, ["city"]);
        }*/
        $optionalFields  = array("image", "landmark", "pincode", "longitude", "latitude",
            "addressMetaData","address","city","state", "countryCode",
            "clientId", "phone", "email", "metaData", "password", "communication", "familyMember");
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);
        if (empty($data['phone']) && empty($data['email'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Atleast one of phone, email must be provided");
        }
        $data = $this->validateFields($data);

        $customerGroupsResp = \ZopNow\Arya\Utility\MicroService::callService("go-account-service", "/extension", "GET",
            ['slug' => 'CustomerGroups', 'organizationId' => $this->data['organizationId']]);
        if ($customerGroupsResp['statusCode'] != 200) {
            \ZopNow\Arya\App\Application::log("error while fetching customerGroup extension details");
        }
        $customerGroupsStatus = json_decode($customerGroupsResp['body'], true)['data']['extension']['status'];
        if ($customerGroupsStatus == 'ENABLED') {
            $this->validateFamilyMemberCreateRequest();
        }

        $fields = [];
        $lockedFieldValues = [];
        try{
            if (!empty($data['email'])) {
                \ZopNow\CustomerService\Model\Customer::acquireLock($data['email']);
                $fields[] = 'email';
                $lockedFieldValues['email'] = $data['email'];
            } 
            if (!empty($data['phone'])) {
                \ZopNow\CustomerService\Model\Customer::acquireLock($data['phone']);
                $fields[] = 'phone';
                $lockedFieldValues['phone'] = $data['phone'];
            }
        } catch (\Exception $e) {
            foreach ($fields as $field) {
                \ZopNow\CustomerService\Model\Customer::revertLock($lockedFieldValues[$field]);
            }
            throw $e;
        }
        /**
         * If phone or email exists for an existing online user, throw error
         */
        //if duplicatePhonesAllowed shouldn't check customers phone number existence
        try {
            $configResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", 'GET', ['organizationId' => $data["organizationId"]]);
            $configData = json_decode($configResponse['body'], true)['data']['customers'];
            $duplicatePhonesAllowed = (isset($configData['duplicatePhonesAllowed']) && !$configData['duplicatePhonesAllowed']) ? FALSE : TRUE;
            if (!empty($data['phone']) && !$duplicatePhonesAllowed) {
                $oldCustomerFromPhone = Customer::getFromPhone($data['phone'], $data['organizationId']);
                if ((!empty($oldCustomerFromPhone) && !is_null($oldCustomerFromPhone->password))) {
                    throw new \ZopNow\Arya\Exception\ValidationException("This mobile number is already connected to an existing account");
                }
            }
            if (!empty($data['email'])) {
                $oldCustomerFromEmail = Customer::getFromEmail($data['email'], $data['organizationId']);
                if ((!empty($oldCustomerFromEmail) && !is_null($oldCustomerFromEmail->password))) {
                    throw new \ZopNow\Arya\Exception\ValidationException("Email already exists");
                }
            }
            if (!empty($data['address'])) {
                (new Address($data))->checkServiceability();
            }

            //Storing phone and email in variables for later use while sending signup messages.
            $email = $data['email'] ?? null;
            $phone = $data['phone'] ?? null;
            //Unsetting already existing relations so that they are not added again
            if (!empty($oldCustomerFromEmail)) {
                unset($data['email']);
            }
            if (!empty($oldCustomerFromPhone)) {
                unset($data['phone']);
            }
            $configResponse= \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/passwordEncryption.algorithm", "GET", ["organizationId" => $organizationDetails['id']]);
            $passEnc=json_decode($configResponse['body'], true)['data']['passwordEncryption']['algorithm'];
            // check config service if auto generate password is supportes
            $autoGeneratePassword= true; // default generation of password
            $response = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", "GET", ["organizationId" => $organizationDetails['id']]);
            if ($response['statusCode'] == 200){
                $autoGeneratePassword= json_decode($response['body'], true)['data']['customers']['autoGeneratePassword'];
            }
            if ($autoGeneratePassword) {
            //Generating password
                $data['password'] = \ZopNow\CustomerService\Utility\Password::generate();
                
            } else {
                if (empty($data['password'])){
                // throw error
                throw new ValidationException(
                        "Empty password sent in request"
                    );
                }
            }
            if (($configResponse['statusCode']==200 && $passEnc == "ZOPALGO")||($configResponse['statusCode']!=200)){
                $password = \ZopNow\Arya\Utility\Encryption::encrypt($data['password'], false);
                $salt = null;
            } else {
                $passwordParam=[];
                $passwordParam['password'] = strval($data['password']);
                $authResponse = \ZopNow\Arya\Utility\MicroService::callService("auth-service","/password",'POST',$passwordParam);
                if($authResponse['statusCode']!=200){
                    throw new \ZopNow\Arya\Exception\ValidationException("Invalid Password");
                }else{
                    $password= json_decode($authResponse['body'], true)['data']['hashedPassword'];
                    $salt = json_decode($authResponse['body'], true)['data']['salt'];
                }

            }
            $rand=$data['password'];
            $data['password'] = $password;
            $data['salt'] = $salt;
            $data['joinedTime'] = date('Y-m-d H:i:s');

            $status = 201;
            $data['metaData'] =  empty($data['metaData']) ? null : $data['metaData'];
            \ZopNow\Arya\DB\MySql::startTransaction();
            if (empty($oldCustomerFromEmail) && empty($oldCustomerFromPhone)) {
                /**
                 * If no customer exists for given phone and email add new customer with given details
                 */
                $customer = $this->addNewCustomer($data);
            } elseif ((!empty($oldCustomerFromEmail) && empty($oldCustomerFromPhone))
                || (!empty($oldCustomerFromPhone) && empty($oldCustomerFromEmail))
            ) {
                /**
                 * If offline customer exists for given phone OR email(not both),
                 * edit customer details and add unmapped phone or email.
                 */
                $oldCustomer = !empty($oldCustomerFromEmail) ?
                        $oldCustomerFromEmail : $oldCustomerFromPhone;
                $customer = $this->editExistingCustomer($oldCustomer, $data);
                $status = 211;
            } else {
                /**
                 * If offline customer exists for both given email and phone,
                 *  merge existing customers
                 */

                if ($oldCustomerFromEmail->id != $oldCustomerFromPhone->id) {
                    $this->mergeExistingCustomers($oldCustomerFromEmail, $oldCustomerFromPhone);
                    $status = 212;
                }
                $customer = $this->editExistingCustomer($oldCustomerFromPhone, $data);
            }

            //address Data
            $latitude    = $data['latitude'] ?? null;
            $longitude   = $data['longitude'] ?? null;
            if (!empty($data['address'])) {
                $addressData = ["customerId" => $this->model->id, "organizationId" => $data['organizationId'],
                    "address" => $data['address'], "landmark" => $data['landmark'] ?? null,
                    "metaData" => $data['addressMetaData'] ?? null,
                    "pincode" => $data['pincode'] ?? null, "city" => $data['city'], "state" => $data['state'] ?? null,"countryCode" => $data['countryCode'] ?? $this->getCountryCode($data["organizationId"]),
                    "latitude" => $latitude, "longitude" => $longitude,"verifyAddress" => false
                ];
                (new Address($addressData))->post();
            }
            \ZopNow\Arya\DB\MySql::commit();

            $this->model = $this->modelClass::findOrFail($customer['id']);
            $customerDetails = $this->getDetails();
            $customerName = $customerDetails['customer']['name'];
            $familyMemberId = "";
            if ($customerGroupsStatus == 'ENABLED') {
                $request = [
                    'organizationId' => $this->data['organizationId'],
                    'customerId' => strval($customerDetails['customer']['id']),
                    'name' => $this->data['familyMember']['name'],
                    'image' => isset($this->data['familyMember']['image']) ? $this->data['familyMember']['image'] : '',
                    'email' => $this->data['familyMember']['email'],
                    'phone' => $this->data['familyMember']['phone'],
                    'metaData' => isset($this->data['familyMember']['metaData']) ? $this->data['familyMember']['metaData'] : null,
                    'sendCommunication' => false,
                    'isHead' => true,
                ];
                $resp = \ZopNow\Arya\Utility\MicroService::callService("go-customer-service", "/family-member", "POST", $request);
                if ($resp['statusCode'] != 200) {
                    \ZopNow\Arya\App\Application::log("error while creating family member admin account");
                } else {
                    $id = json_decode($resp['body'], true)['data']['familyMember']['id'];
                    $email = $this->data['familyMember']['email'];
                    $phone = $this->data['familyMember']['phone'];
                    $customerName = $this->data['familyMember']['name'];
                    $familyMemberId = "f:" . $id; //id to verify the email of family member
                }
            }
            /**
             * Fetching the id of the email that was passed in request,
             *  to generate hash to be sent in verification mail
             */
            $emails = array_column($customerDetails['customer']['emails'], 'email');
            $index = array_search($email, $emails);
            $emailId = $customerDetails['customer']['emails'][$index]['id'];
            if(!empty($familyMemberId)) {
                $emailId = $familyMemberId;
            }
            $hash = urlencode(\ZopNow\Arya\Utility\Encryption::encrypt($emailId, true));
            //Sending SMS and email to online users
            $response = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/config/orderCommunication", "GET", ["organizationId" => $organizationDetails['id']]);
            $accountSpecificData = json_decode($response['body'], true)['data']['config']['orderCommunication'];
            $sendCommunication = true;
            if (isset($data["communication"]) && $data["communication"] == 0) {
                $sendCommunication = false;
            }
            if ((!isset($accountSpecificData['sendCommunication']) || $accountSpecificData['sendCommunication']) && $sendCommunication) {
                $this->sendSignupMessages(
                        $phone, $email, $rand, $hash, $organizationDetails['name'], $organizationDetails['domain'], $customerName, $data['organizationId'], $autoGeneratePassword, $organizationDetails['httpsEnabled']
                );
            }
            // Trigerring event when a new customer signups
            $eventData = [
                'customerId' => $this->model->id,
                'organizationId' => $this->model->organization_id,
            ];
            (new \ZopNow\CustomerService\Utility\Event('new-customer', $eventData))->publish();
        } catch (\Exception $ex) {
            foreach ($fields as $field){
                \ZopNow\CustomerService\Model\Customer::revertLock($lockedFieldValues[$field]);
            }            
            throw $ex;
        }
        foreach ($fields as $field){
            \ZopNow\CustomerService\Model\Customer::revertLock($lockedFieldValues[$field]);
        }       
        return [
            "code" => $status,
            "customer" => $customerDetails
        ];
    }

    private function validateFamilyMemberCreateRequest() {
        if (empty($this->data['familyMember'])) {
            throw new \ZopNow\Arya\Exception\ValidationException('Contact details are required');
        }

        if (empty($this->data['familyMember']['name'])) {
            throw new \ZopNow\Arya\Exception\ValidationException('Name is required');
        }

        if (empty($this->data['familyMember']['email'])) {
            throw new \ZopNow\Arya\Exception\ValidationException('Email is required');
        }

        if (empty($this->data['familyMember']['phone'])) {
            throw new \ZopNow\Arya\Exception\ValidationException('Phone is required');
        }

        if (substr($this->data['familyMember']['phone'], 0, strlen('+')) == '+') {
            $this->data['familyMember']['phone'] = substr($this->data['familyMember']['phone'], strlen('+'));
        }

        $familyMembers = \ZopNow\Arya\DB\MySql::select('SELECT id FROM customer_group_members WHERE organization_id = ' .
            $this->data['organizationId'] . ' AND (email = \''. $this->data['familyMember']['email'] .
            '\' OR phone = \''. $this->data['familyMember']['phone'] .'\') AND deleted_at IS NULL');
        if (sizeof($familyMembers) > 0) {
            throw new \ZopNow\Arya\Exception\ValidationException('Email or Phone already exists.');
        }
    }

    private function sendSignupMessages($phone, $email, $password, $hash, $organizationName, $domain, $customerName, $organizationId, $autoGeneratePassword, $httpsEnabled)
    {
        //Sending confirmation message with password for verification.
        if (!empty($phone) && $autoGeneratePassword) {
            $smsData = [];
            //$phone = (strlen($phone) == 10) ? "+91" . $phone : $phone;
            $smsData['phone'] = $phone;
            $smsData['type'] = self::SIGNUP_COMMUNICATION;
            $smsData['data'] = [
                "password" => "$password",
                "organizationName" => $organizationName
            ];
            $smsData['organizationId'] = $organizationId;
            $smsData['transactional'] = true;
            \ZopNow\Arya\Utility\MicroService::callService("go-communication-service", "/sms", 'POST', $smsData);
        }
        //Generate an email and send it.
        //check for the config Set and send verification email based on config
        $response = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", "GET", ["organizationId" => $organizationId]);
        $configResponse= json_decode($response['body'], true)['data']['customers']['emailVerificationRequired'];
        if ($configResponse==false){
            return;
        }
        if (!empty($email)) {
            $domainPrefix = 'http://';
            if ($httpsEnabled) {
                $domainPrefix = 'https://';
            }

            $emailData = [];
            $emailData['to'] = $email;
            $emailData['type'] = self::SIGNUP_COMMUNICATION;
            $emailData['data'] = [
                "customerName" => $customerName,
                "verifyUrl" => $domain . "/verify?e=$hash",
                "organizationName" => $organizationName,
                "organizationId" => $organizationId,
                "customerPhone" => $phone,
                "customerEmail" => $email,
                "loginUrl" => $domain,
                "domainUrl" => $domainPrefix.$domain,
            ];
            $emailData['organizationId']=$organizationId;
            $emailData['transactional'] = true;
            \ZopNow\Arya\Utility\MicroService::callService("go-communication-service", "/email", 'POST', $emailData);
        }
    }

    private function addNewCustomer($data) {
        $customer = $this->add($data)['customer'];
        $this->addRelationsData($data);
        $event = ['id' => $customer['id']];
        (new \ZopNow\CustomerService\Utility\Event("customer", $event))->publish();
        return $customer;
    }

    private function editExistingCustomer($oldCustomer, &$data)
    {
        $this->model = $oldCustomer;
        $data['id'] = $oldCustomer->id;
        $customer = $this->edit($data)['customer'];
        $this->addRelationsData($data);
        $event = ['id' => $customer['id']];
        (new \ZopNow\CustomerService\Utility\Event("customer", $event))->publish();
        return $customer;
    }

    private function mergeExistingCustomers($oldCustomer, &$newCustomer)
    {
        /**
         * If both the customers have already signed up, then they cannot be merged,
         * error must be thrown
         */
        if (!is_null($oldCustomer->password) && !is_null($newCustomer->password)) {
            throw new ValidationException(
                "Different customers exist for the given details"
            );
        }
        /**
         * If the old customer is a signed up customer,
         *  the details of the new customer must be merged into the old customer.
         * Hence, swapping the two customers.
         */
        if (!is_null($oldCustomer->password)) {
            $tempCustomer = $oldCustomer;
            $oldCustomer = $newCustomer;
            $newCustomer = $tempCustomer;
        }
        //Merge the two customers
        //Merge all emails
        $customerId = $newCustomer->id;
        $oldEmails = $oldCustomer->emails()->get()->toArray();
        foreach ($oldEmails as $oldEmailData) {
            $newEmailData = $oldEmailData;
            $newEmailData['customerId'] = $customerId;
            (new Email($oldEmailData))->edit($newEmailData);
        }
        //Merge all phones
        $oldPhones = $oldCustomer->phones()->get()->toArray();
        foreach ($oldPhones as $oldPhoneData) {
            $newPhoneData = $oldPhoneData;
            $newPhoneData['customerId'] = $customerId;
            (new Phone($oldPhoneData))->edit($newPhoneData);
        }
        //Merge client ids
        foreach ($oldCustomer->clientIds as $client) {
            $client->customer_id = $customerId;
            $client->save();
        }
    }

    private function getDefaultParamAttribute($params, $defaultParamId)
    {
        $defaultParam = null;
        if (!empty($params)) {
            $defaultParam = $params[0];
            if (!empty($defaultParamId)) {
                $paramIds = array_column($params, 'id');
                $key = array_search($defaultParamId, $paramIds);
                $defaultParam = $params[$key] ?? null;
            }
        }
        return $defaultParam;
    }


    public function getMetaData($customFieldMap, $fieldData)
    {
        if (empty($customFieldMap)) {
            return null;
        }
        foreach ($customFieldMap as $key => $value) {
            foreach ($fieldData as $customField) {
                if ($key == $customField['id']) {
                    $metaMap[$customField['key']] = $value;
                    break;
                }
            }
        }
        return $metaMap;
    }

    private function getCountryCode($organizationId)
    {
        $orgData = \ZopNow\Arya\Utility\MicroService::callService(
            "go-account-service", "/organization", "GET", array("id" => $organizationId)
        );

        return json_decode($orgData['body'], true)['data']['organization']['countryCode'];
    }
}
