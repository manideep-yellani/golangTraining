<?php

namespace ZopNow\Hodor\Controller\Employee;

/**
 * Description of EmployeePassword
 * Responsible for changing the user password and overriding the old password with the new password in the database
 * by anyone who can access the employee.
 *
 * @author uday
 */
class Password extends \ZopNow\Arya\Controller\Base
{
    public function put()
    {
        $data = $this->getRequestParams(['newPassword']);
        $newPassword = $data['newPassword'];
        $userId=$this->id;
        return (new \ZopNow\Hodor\Controller\User(['newPassword'=>$newPassword,'id'=>$userId]))->setNewPassword();
    }
}
