<?php

use Phinx\Migration\AbstractMigration;

class AddLayoutScheduleExt extends AbstractMigration
{
   
    private $slug = "LayoutSchedulingSupport";

    public function up()
    {
        $enableHelperText = "Layout Scheduling Support enables you to schedule layouts for each page";
        $disableHelperText = "You can no longer manage scheduling of page layouts.";
        $data = [
            "name" => "Layout Scheduling Support",
            "slug" => $this->slug,
            "description" => "$enableHelperText,",
            "enable_helper_text" => "",
            "disable_helper_text" => $disableHelperText,
            "icon" => "",
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
        $this->execute("ALTER TABLE `organization_page` drop foreign key `fk_page_layouts_organizations`");
        $this->execute("ALTER TABLE `organization_page` drop key `organization_page_url`");
        $this->execute("ALTER TABLE `organization_page` add CONSTRAINT fk_page_layouts_organizations foreign key  (`organization_id`) REFERENCES organizations (id)");
        $this->execute("ALTER TABLE `organization_page` add CONSTRAINT organization_page_url_validity unique (`organization_id`,`url`,`page_id`,`valid_from`,`valid_till`)");

    }
    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $this->execute("DELETE from `extension_organization` where `extension_id` = '$extensionId'");
        $this->execute("DELETE from `extensions` where `id` = $extensionId");

        $this->execute("ALTER TABLE `organization_page` drop foreign key `fk_page_layouts_organizations`");
        $this->execute("ALTER TABLE `organization_page`  drop key `organization_page_url_validity` ");
        $this->execute("ALTER TABLE `organization_page` add CONSTRAINT `organization_page_url` unique (`organization_id`,`url`,`page_id`)");
        $this->execute("ALTER TABLE `organization_page` add CONSTRAINT fk_page_layouts_organizations foreign key  (`organization_id`) REFERENCES organizations (id)");
    }
}
