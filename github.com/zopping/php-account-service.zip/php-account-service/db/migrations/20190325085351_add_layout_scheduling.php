<?php

use Phinx\Migration\AbstractMigration;

class AddLayoutScheduling extends AbstractMigration
{
 public function change()
    {
        $table = $this->table('organization_page');
        $table->addColumn('valid_from', 'timestamp', array('null' =>true))
              ->addColumn('valid_till', 'timestamp', array('null' =>true));
        $table->save();  
    }
}
