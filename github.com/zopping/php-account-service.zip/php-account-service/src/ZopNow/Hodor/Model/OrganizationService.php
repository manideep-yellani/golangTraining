<?php

namespace ZopNow\Hodor\Model;

class OrganizationService extends \ZopNow\Arya\Model\Base
{
    protected $hidden = ['created_at', 'updated_at', 'deleted_at', "pivot", 'service_id', 'organization_id'];

}
