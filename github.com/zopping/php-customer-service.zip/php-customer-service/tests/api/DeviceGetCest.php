<?php
require_once('BaseCest.php');
class DeviceGetCest extends BaseCest
{
    protected static $endpoint = '/device';
    protected static $table = "devices";

    public function listDevicesWithoutOrganizationId(ApiTester $I)
    {
        $I->wantToTest("Devices listing without organizationId");
        $I->sendGET(self::$endpoint);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
    }

    public function listDevicesForAnOrganzation(ApiTester $I)
    {
        $I->wantToTest("Devices listing for a organization");
        $I->sendGET(self::$endpoint . "?organizationId=1");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => array(
                    "count" => "integer",
                    "offset" => "integer",
                    "limit" => "integer",
                    "device" => "array"
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }


    public function getDetailsOfADevice(ApiTester $I)
    {
        $I->wantToTest("Get details for a device with id=1");
        $I->sendGET(static::$endpoint . "/1");
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => array(
                    "device" => array(
                        "id" => "integer",
                        "uuid" => "string",
                        "token" => "string|null",
                        "organizationId" => "integer",
                        "metadata" => "array | null",
                        "os" => "string | null",
                        "lastNotificationSendTime" => "string | null",
                        "lastNotificationClickTime" => "string | null",
                        "customer" => "array | null",
                    )
                )
            ));
        } catch (Exception $ex) {
            self::serviceDownTest($I);
        }
    }


    public function getDetailsOfADeviceWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Get details of a device with invalid id');
        $I->sendGET(self::$endpoint . "/abcde");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Device with id: abcde not found'));
    }

    public function getDetailsOfADeviceWithCustomerIdFilter(ApiTester $I)
    {
        $I->wantTo('Get list of devices with Customer Filter');
        $I->sendGET(self::$endpoint . "?organizationId=1&customerId=1");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseContainsJson(array(
                "data" => array(
                    "device" => array(
                        "id" => 1
                    )
                )
            ));
            $I->dontSeeResponseContainsJson(array(
                "data" => array(
                    "device" => array(
                        "id" => 2
                    )
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function getDetailsOfADeviceWithTokenFilter(ApiTester $I)
    {
        $I->wantTo('Get list of devices with Token Filter');
        $I->sendGET(self::$endpoint . "?organizationId=1&token=APA91bHx2GgNYjkqZ8WUfwCaAIr3X2eySkv3Hcje1wq1sPf8OHWlU4oROekIG6H1Clzs0Y2gWpDztD08Rhe7q_XrrBy6U8uEQ60OoCbewBINay3yaxQ1pDg");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseContainsJson(array(
                "data" => array(
                    "device" => array(
                        "id" => 1
                    )
                )
            ));
            $I->dontSeeResponseContainsJson(array(
                "data" => array(
                    "device" => array(
                        "id" => 2
                    )
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function getDetailsOfADeviceWithUuid(ApiTester $I)
    {
        $I->wantToTest("Get details for a device with id=1");
        $I->sendGET(static::$endpoint . "?organizationId=1&uuid=eab86a40-bfa9-4c30-b4b3-7e5c0ea060d4");
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => array(
                    "device" => array(
                        "id" => "integer",
                        "uuid" => "string",
                        "token" => "string|null",
                        "organizationId" => "integer",
                        "metadata" => "array | null",
                        "os" => "string | null",
                        "lastNotificationSendTime" => "string | null",
                        "lastNotificationClickTime" => "string | null",
                        "customer" => "array | null",
                    )
                )
            ));
        } catch (Exception $ex) {
            self::serviceDownTest($I);
        }
    }

    public function listdevicesWithPageNumberOutOfRange(ApiTester $I)
    {
        $I->wantToTest("device listing with page number out of range");
        $I->sendGET(self::$endpoint . "?organizationId=1&page=8000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['device' => []]));
    }
}