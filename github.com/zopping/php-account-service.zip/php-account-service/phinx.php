<?php

//Sample phinx configuration
$phinxConfig = array(
    "paths" => array(
        "migrations" => "db/migrations",
        "seeds" => "db/seeds",
    ),
    "environments" => array(
        "default_migration_table" => "migrations",
    )
);

$config = include 'config/test.php';
$databaseConfig = $config['ZopNow\Arya\DB\MySql'];
foreach ($databaseConfig as $databaseName => $configurations) {
    $phinxConfig['environments']['test'] = [
        "adapter" => "mysql",
        "host" => $configurations['write']['host'],
        "name" => $configurations['write']['database'],
        "user" => $configurations['write']['username'],
        "pass" => $configurations['write']['password'],
        "port" => $configurations['write']['port'] ?? 3306,
        "charset" => $configurations['write']['charset']
    ];
}

$config = include 'config/app.php';
$databaseConfig = $config['ZopNow\Arya\DB\MySql'];
$app = new ZopNow\Arya\App\ConsoleApplication(__DIR__ . '/config/app.php');
foreach ($databaseConfig as $databaseName => $configurations) {
    $phinxConfig['environments']['production'] = [
        "adapter" => "mysql",
        "host" => $configurations['write']['host'],
        "name" => $configurations['write']['database'],
        "user" => $configurations['write']['username'],
        "pass" => $configurations['write']['password'],
        "port" => $configurations['write']['port'] ?? 3306,
        "charset" => $configurations['write']['charset']
    ];
}
return $phinxConfig;
?>
