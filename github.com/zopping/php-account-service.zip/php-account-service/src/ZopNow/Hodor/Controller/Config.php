<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Utility\Validator;
use ZopNow\DB\Redis;

class Config extends \ZopNow\Arya\Controller\Base
{

    public function get()
    {
        $mandatoryFields = ['organizationId'];
        $data = $this->getRequestParams($mandatoryFields);
        if (!empty($this->data['id'])) {
            $files = [$this->data['id'] . ".json"];
        } else {
            $files = array_diff(scandir(DATA_DIRECTORY . "configurations/"), [".", ".."]);
        }
        $response = [];
        $configFiles = [];
        foreach ($files as $file) {
            $configFiles[$file] = $this->fetchConfigFile($file);
        }
        $configurationDetails = $this->getAllConfigValues($configFiles, $data['organizationId']);
        $configurationDetails = array_column($configurationDetails, 'value', 'key');
        foreach ($files as $file) {
            $configFileData = $configFiles[$file];
            //Get stored config values from DB for the concerned organization
            $configurations = [];
            foreach ($configFileData['configs'] as $configData) {
                $key = $configFileData['name'] . "." . $configData['name'];
                $defaultValue = $configData['default'] ?? null;
                $configurations[$configData['name']] = isset($configurationDetails[$key]) ? $configurationDetails[$key] : $defaultValue;
            }
            if ($configFileData['name'] == 'basic') {
                $defaultStore = (new Store(['organizationId' => $data['organizationId']]))->getDefaultStoreForOrganization()['store'];
                unset($defaultStore['id'],$defaultStore['clientStoreId'],$defaultStore['name']);
                foreach ($defaultStore as $key => $value) {
                    $configurations[$key] = $value;
                }
            }
            $response[$configFileData['name']] = $configurations;
        }
        return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'data' => ["config" => $response]
        ]);
    }

    public function post()
    {
        $mandatoryFields = ['organizationId'];
        $data = $this->getRequestParams($mandatoryFields);
        if (!empty($this->data['id'])) {
            $files = [$this->data['id'] . ".json"];
        } else {
            $files = array_diff(scandir(DATA_DIRECTORY . "configurations/"), [".", ".."]);
        }
        foreach ($files as $file) {
            $type = basename($file, ".json");
            if ($type == "order") {
                if(empty($this->data[$type])){
                    $this->data[$type] = [];
                }
                if(empty($this->data[$type]['orderTypes'])) {
                    $this->data[$type]['orderTypes'] = ["DELIVERY", "PICKUP"];
                }
            }
            /**
             * Setting default value for stock strategy if not set.
             */
            if ($type == "inventory" && empty($this->data[$type]["stockStrategy"])) {
                $this->data[$type]["stockStrategy"] = "BooleanStrategy";
            }
            if (empty($this->data[$type])) {
                continue;
            }
            $configFileData = $this->fetchConfigFile($file);
            //Validate all data that has been passed.
            //Validation and adding has been separated temporarily due to issues with transactions.
            foreach ($configFileData['configs'] as $configData) {
                if ($configData['required'] == true && !isset($this->data[$type][$configData['name']])) {
                    throw new \ZopNow\Arya\Exception\ValidationException("Missing Required Field - config : $type - " . $configData['name']);
                }
                if (isset($this->data[$type][$configData['name']])) {
                    $extraData = !empty($configData['typeMeta']) ? $configData['typeMeta'] : [];
                    $isValid = Validator::validate($this->data[$type][$configData['name']], $configData['type'], $extraData);
                    if (($isValid == false && $configData['required'] == true) || ($isValid == false && $configData['required'] == false && !empty($this->data[$type][$configData['name']]))) {
                        throw new \ZopNow\Arya\Exception\ValidationException("Invalid data for $type: " . $configData['name']);
                    }
                }
            }

            //Add new configurations for each of the keys
            \ZopNow\Arya\DB\MySql::startTransaction();
            foreach ($configFileData['configs'] as $configData) {
                $requestData = [];
                if (isset($this->data[$type][$configData['name']])) {
                    $requestData['organizationId'] = $data['organizationId'];
                    $requestData['key'] = $type . "." . $configData['name'];
                    $value = $this->data[$type][$configData['name']];
                    if (isset($value) && $value != "") {
                        $requestData['value'] = $value;
                        $cofigurationController = new Configuration($requestData);
                        $cofigurationController->post();
                    }
                }
            }

            if ($configFileData['name'] == "basic") {
                $request = $this->data["basic"];
                $organizationData = array(
                    "id" => $data["organizationId"],
                    "name" => $request["organizationName"],
                    "domain" => $request["siteUrl"],
                    "logo" => $request["logo"]
                );
                $organizationController = new Organization($organizationData);
                $organizationController->put();
                $storeData = [
                    "organizationId" => $data['organizationId'],
                ];
                $storeList = (new Store($storeData))->get()->getData();
                if($storeList['data']['count'] == 1){
                    $storeRequest = [
                        "id" => $storeList['data']['store'][0]['id'],
                        "organizationId" => $data['organizationId'],
                        "name" => $request["organizationName"],
                        "address" => $request['address'] ?? null,
                        "latitude" => $request['latitude'] ?? null,
                        "longitude" => $request['longitude'] ?? null,
                    ];
                    (new Store($storeRequest))->put();
                }
            }

            \ZopNow\Arya\DB\MySql::commit();
        }
        $this->refreshCache();
        return $this->get();
    }

    public function put()
    {
        $mandatoryFields = ['organizationId'];
        $data = $this->getRequestParams($mandatoryFields);
        if (!empty($this->data['id'])) {
            $files = [$this->data['id'] . ".json"];
        } else {
            $files = array_diff(scandir(DATA_DIRECTORY . "configurations/"), [".", ".."]);
        }
        //Fetch all config files
        $configFiles = [];
        foreach ($files as $file) {
            $configFiles[$file] = $this->fetchConfigFile($file);
        }
        //Fetch all existing configurations for the organization id passed
        $configurationDetails = $this->getAllConfigValues($configFiles, $data['organizationId']);
        $keys = array_column($configurationDetails, 'key');
        $organizationData = array_combine($keys, $configurationDetails);
        foreach ($files as $file) {
            $type = basename($file, ".json");
            /**
             * For inventory's stockStrategy config, if the value has not been set for the organization,
             *  it has to be set to the default value of 'BooleanStrategy'.
             * @to-do Figure out better way to implement default values
             */
            if (empty($this->data[$type]) && $type != "inventory") {
                continue;
            }
            $configFileData = $configFiles[$file];

            /**
             * Setting default value for stock strategy if not set.
             */
            if ($type == "inventory" && empty($this->data[$type]["stockStrategy"]) && empty($organizationData["inventory.stockStrategy"])) {
                $this->data[$type]["stockStrategy"] = "BooleanStrategy";
            }
            if (empty($this->data[$type])) {
                continue;
            }
            foreach ($configFileData['configs'] as $configData) {
                $requestData = [];
                if (isset($this->data[$type][$configData['name']])) {
                    $configKey = $type . "." . $configData['name'];
                    if (isset($organizationData[$configKey])
                        && $this->data[$type][$configData['name']] === $organizationData[$configKey]['value']
                    ) {
                        continue;
                    }
                    $method = "post";
                    $extraData = !empty($configData['typeMeta']) ? $configData['typeMeta'] : [];
                    $isValid = Validator::validate($this->data[$type][$configData['name']], $configData['type'], $extraData);
                    // @todo -regex validation to be moved to framework
                    if ($isValid && $configData['type'] == 'text' && !empty($extraData['regex']) &&
                        !preg_match($extraData['regex'], $this->data[$type][$configData['name']])) {
                        $isValid = false;
                    }
                    if (($isValid == false && $configData['required'] == true) || ($isValid == false && $configData['required'] == false && !empty($this->data[$type][$configData['name']]))) {
                        throw new \ZopNow\Arya\Exception\ValidationException("Invalid data for $type: " . $configData['name']);
                    }
                    $requestData['organizationId'] = $data['organizationId'];
                    $requestData['key'] = $configKey;
                    $value = $this->data[$type][$configData['name']];
                    $requestData['value'] = $value;
                    if (isset($organizationData[$configKey])
                        && $this->data[$type][$configData['name']] !== $organizationData[$configKey]['value']
                    ) {
                        $requestData['id'] = $organizationData[$configKey]['id'];
                        $method = "put";
                    }
                    if (($method == "post" && isset($value) && $value != "") || $method == "put") {
                        $cofigurationController = new Configuration($requestData);
                        $cofigurationController->$method();
                    }
                }
            }
            
            if ($configFileData['name'] == "basic") {
                $request = $this->data["basic"];
                if (!empty($request)) {
                    $requestParams = [];
                    $orgData = ["name" => "organizationName", "domain" => "siteUrl", "logo" => "logo", "address" => "address", "latitude" => "latitude", "longitude" => "longitude", "countryCode" => "countryIsoCode"];
                    foreach ($orgData as $key => $value) {
                        if (!empty($request[$value])) {
                            $requestParams[$key] = $request[$value];
                        }
                    }
                    if (!empty($requestParams)) {
                        $requestParams["id"] = $data["organizationId"];
                        $organizationController = new Organization($requestParams);
                        $organizationController->put();
                        if (!empty($requestParams['name']) || !empty($requestParams['latitude']) ||
                                !empty($requestParams['longitude'])) {
                            $storeData = [
                                "organizationId" => $data['organizationId'],
                            ];
                            $storeList = (new Store($storeData))->get()->getData();
                            if($storeList['data']['count'] == 1){
                                $storeRequest = [
                                    "id" => $storeList['data']['store'][0]['id'],
                                    "organizationId" => $data['organizationId'],
                                    "name" => $requestParams["name"] ?? null,
                                    "address" => $request['address'] ?? null,
                                    "latitude" => empty($request['latitude']) ? null : $request['latitude'],
                                    "longitude" => empty($request['longitude']) ? null: $request['longitude']
                                ];
                                (new Store($storeRequest))->put();
                            }
                        }
                    }
                }
            } elseif ($configFileData['name'] == 'multiLingualSupport') {
                $langs = $this->data["multiLingualSupport"]['languages'];
                \ZopNow\Arya\Utility\MicroService::callService('go-catalogue-service', '/catalog-language','PUT',['organizationId' => $data["organizationId"], 'languages' => $langs]);
            }
        }
        $this->refreshCache();
        return $this->get();
    }

    private function refreshCache() {
        $org = $this->organizationId;
        $r = \ZopNow\Arya\DB\Redis::getInstance();
        $r->del("O:Config:$org");
        $r->del("O:Organization:$org");
    }

    private function fetchConfigFile($configFile)
    {
        $fileName = DATA_DIRECTORY . "configurations/" . $configFile;
        if (!file_exists($fileName)) {
            throw new \ZopNow\Arya\Exception\ValidationException("The configuration type "
            . basename($configFile, ".json") . " does not exist.");
        }
        return json_decode(file_get_contents($fileName), true);
    }

    public function getAllConfigValues($fileData, $organizationId, $includeStoreSpecificConfig = false)
    {
        $allConfigKeys = [];
        foreach ($fileData as $file) {
            $configKeys = array_column($file['configs'], 'name');
            $name = $file['name'];
            array_walk($configKeys, function (&$item) use ($name) {
                $item = $name . "." . $item;
            });
            $allConfigKeys = array_merge($allConfigKeys, $configKeys);
        }
        $requestData = ['organizationId' => $organizationId, 'key' => $allConfigKeys];
        $requestData['paginated']  = false;
        if (!$includeStoreSpecificConfig) {
            $requestData['storeId'] = null;
        }
        $configurationController = new Configuration($requestData);
        $configurationData = $configurationController->get()->getData();
        return $configurationData['data']['configuration'];
    }
}
