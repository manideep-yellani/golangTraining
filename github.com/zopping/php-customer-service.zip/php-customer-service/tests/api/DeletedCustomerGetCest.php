<?php

class DeletedCustomerGetCest extends BaseCest
{
    protected static $endpoint = '/customer';
    protected static $table    = "customers";
/*
    public function listCustomerWhosePhoneNumberIsDeleted(ApiTester $I)
    {
        $I->wantToTest("Customers whose phone numbers are deleted.");
        $id = $I->haveInDatabase('customers', ['name' => 'Sam', 'organization_id' => 1]);
        $I->haveInDatabase(
            'phones',
            ['customer_id' => $id, 'phone' => 919848022338, 'deleted_at' => '2018-05-16 11:54:13']
        );
        $I->sendGET(self::$endpoint."?organizationId=1&phone=9393993939");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->dontSeeResponseContainsJson(array(
            "data" => array(
                "customer" => array(
                    "id" => $id,
                    'name' => 'Sam', 
                    'organization_id' => 1
                    )
                )
            )
        );
    }
    
    public function listCustomerWhoseEmailIsDeleted(ApiTester $I)
    {
        $I->wantToTest("Customers whose emails are deleted.");
        $id = $I->haveInDatabase('customers', ['name' => 'Sam', 'organization_id' => 1]);
        $I->haveInDatabase(
            'emails',
            ['customer_id' => $id, 'email' => 'sam@testzopnow.com', 'deleted_at' => '2018-05-16 11:54:13']
        );
        $I->sendGET(self::$endpoint."?organizationId=1&email=sam@testzopnow.com");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->dontSeeResponseContainsJson(array(
            "data" => array(
                "customer" => array(
                    "id" => $id,
                    'name' => 'Sam', 
                    'organization_id' => 1
                    )
                )
            )
        );
    }
 */
}