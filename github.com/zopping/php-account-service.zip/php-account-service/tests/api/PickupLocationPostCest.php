<?php

require_once('BaseCest.php');

class PickupLocationPostCest extends BaseCest
{
    protected static $endpoint = '/pickup-location';
    protected static $table = 'pickup_locations';
/*
    public function createValidPickupLocation(ApiTester $I)
    {
        $I->wantTo("Create pickup location with basic data");
        $data = [
            'name' => 'My More Store',
            'organizationId' => 2,
            'latitude' => "19.1109315000000",
            'longitude' => "72.9180475000000",
            'address' => "Banashankari 3rd stage, Bangalore - 85"
        ];
        parent::create($I, $data);
    }

    public function createPickupLocationWithoutRequiredFields(ApiTester $I)
    {
        $I->wantTo("Create pickup location without name");
        $data = [
            'organizationId' => 1,
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - pickuplocation : name"
        ));

        $I->wantTo("Create pickup location without organization");
        $data = [
            'name' => 'Naamdharis',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - pickuplocation : organization Id",
        ));

        $I->wantTo("Create pickup location without address");
        $data = [
            'organizationId' => 2,
            'name' => 'Naamdharis',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - pickuplocation : address",
        ));

        $I->wantTo(
            "Create pickup location without store id for organization with multiple stores"
        );
        $data = [
            'organizationId' => 1,
            'name' => 'Naamdharis',
            'address' => 'Banashankari 3rd stage, Bangalore - 85'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - pickuplocation : store Id",
        ));
    }

    public function createPickupLocationInvaidLatitude(ApiTester $I)
    {
        $I->wantTo("Create pickup location with invalid latitude");
        $data = [
            'name' => 'Carrefour',
            'organizationId' => 2,
            'address' => 'Abu Dhabi, UAE',
            'latitude' => "92.1109315000000",
            'longitude' => "72.9180475000000",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid latitude value']);
    }

    public function createPickupLocationInvaidLongitude(ApiTester $I)
    {
        $I->wantTo("Create pickup location with invalid latitude");
        $data = [
            'name' => 'Carrefour',
            'organizationId' => 2,
            'address' => 'Abu Dhabi, UAE',
            'latitude' => "19.1109315000000",
            'longitude' => "190.9180475000000",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid longitude value']);
    }
    
    public function createPickupLocationWithSameName(ApiTester $I)
    {
        $I->wantTo("Create pickup location with existing name in the organization");
        $data = [
            'name' => 'My More Store',
            'organizationId' => 2,
            'latitude' => "19.1109315000000",
            'longitude' => "72.9180475000000",
            'address' => "Banashankari 3rd stage, Bangalore - 85"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Pickup location with the name My More Store already exists']);
    }

    public function createPickupLocationWithNegativeLatLong(ApiTester $I)
    {
        $I->wantTo("Create pickup location with negative values for latitude and longitude");
        $data = [
            'name' => 'Big Bazaar',
            'organizationId' => 2,
            'address' => 'Whitefield',
            'latitude' => "-67.6789000000000",
            'longitude' => "-121.6789850000000",
        ];
        parent::create($I, $data);
    }*/
}