<?php

namespace ZopNow\Hodor\Extension;

class SoldByWeightSupport extends Base
{

    public function enable()
    {
        return true;
    }

    public function disable()
    {
        $organizationId = $this->organization->id;
        do{
            $response = \ZopNow\Arya\Utility\MicroService::callService(
                'catalogue-service', '/sold-by-weight', 'GET',
                ['organizationId' => $organizationId]
            );
            $soldByWeightProducts = json_decode($response['body'], true);
            $count = $soldByWeightProducts['data']['count'];
            foreach($soldByWeightProducts['data']['product'] as $product){
                \ZopNow\Arya\Utility\MicroService::callService(
                    'catalogue-service', '/sold-by-weight', 'DELETE',
                    ['organizationId' => $organizationId, 'productId' => $product['id']]
                );
            }
        } while($count > 0);
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        return 0;
    }

}
