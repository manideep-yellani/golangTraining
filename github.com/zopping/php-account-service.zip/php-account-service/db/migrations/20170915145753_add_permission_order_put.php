<?php


use Phinx\Migration\AbstractMigration;

class AddPermissionOrderPut extends AbstractMigration
{

    public function change()
    {
        $url = "order-service/order";
        $developerId = $this->fetchRow("select id from developers where token='59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $endpointId = $this->fetchRow("select id from endpoints where url='$url'")['id'];
        $this->insert("endpoint_developer_permissions", [[
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "PUT",
            "has_permission" => 1,
            "is_customer_required" => 0
        ]]);

    }
}
