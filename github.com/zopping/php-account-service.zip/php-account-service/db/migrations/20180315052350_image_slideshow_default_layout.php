<?php

use Phinx\Migration\AbstractMigration;

class ImageSlideshowDefaultLayout extends AbstractMigration
{

    public function up()
    {
        $layout = '[{"data": {"title": "Placeholder Banner", "images": [{"link": "#", "text": "This is where your text for this image goes", "imageUrl": "https://storage.googleapis.com/zopsmart-assets-internal/banner-placeholders/placeholder_green.png"}, {"link": "#", "text": "This is where your text for the second image goes", "imageUrl": "https://storage.googleapis.com/zopsmart-assets-internal/banner-placeholders/placeholder_pink.png"}]}, "name": "ImageSlideShow"}, {"data":{"tag":"","brand":"","title":"","sorting":"","category":"","hasImage":"","hasStock":"","hasOffers":""},"name":"ProductCollection"}]';
        $pageId = $this->fetchRow("select `id` from `pages` where `name` = 'HOME'")['id'];
        $this->execute("update organization_page set layouts = '$layout' where page_id = '$pageId' and organization_id is null");
    }

    public function down()
    {
        $layout = '[{"data":{"tag":"","brand":"","title":"","sorting":"","category":"","hasImage":"","hasStock":"","hasOffers":""},"name":"ProductCollection"}]';
        $pageId = $this->fetchRow("select `id` from `pages` where `name` = 'HOME'")['id'];
        $this->execute("update organization_page set layouts = '$layout' where page_id = '$pageId' and organization_id is null");
    }
}
