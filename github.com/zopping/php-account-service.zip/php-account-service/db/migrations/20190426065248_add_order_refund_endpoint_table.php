<?php

use Phinx\Migration\AbstractMigration;

class AddOrderRefundEndpointTable extends AbstractMigration
{
    public function change()
    {
	$this->execute('insert into endpoints(url,allowed_methods)values("order-service/order-refund","[\"POST\"]")');
    }
}
