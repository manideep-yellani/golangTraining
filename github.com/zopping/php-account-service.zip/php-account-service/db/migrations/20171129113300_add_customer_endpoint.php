<?php

use Phinx\Migration\AbstractMigration;

class AddCustomerEndpoint extends AbstractMigration
{
    public function up()
    {
        $endpointData = [
            ["url" => "customer-service/stats","allowed_methods" => json_encode(['GET'])],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE FROM `endpoints` where `url` = "customer-service/stats"');
    }
}
