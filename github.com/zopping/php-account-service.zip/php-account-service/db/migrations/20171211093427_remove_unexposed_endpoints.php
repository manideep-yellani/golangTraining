<?php

use Phinx\Migration\AbstractMigration;

class RemoveUnexposedEndpoints extends AbstractMigration
{

    /**
     * Removing 'order-service/order-item' from endpoints table since it should not be exposed
     */
    public function change()
    {
        $this->execute("delete from endpoints where url= 'order-service/order-item'");
    }
}
