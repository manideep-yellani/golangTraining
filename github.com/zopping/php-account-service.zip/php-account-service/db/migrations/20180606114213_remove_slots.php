<?php

use Phinx\Migration\AbstractMigration;

class RemoveSlots extends AbstractMigration
{

    public function up()
    {
        $endpointId = $this->fetchRow(
            "select id from endpoints where url='account-service/slot'"
        )['id'];
        $this->execute("delete from endpoint_developer_permissions where endpoint_id = $endpointId");
        $this->execute("delete from endpoint_user_permissions where endpoint_id = $endpointId");
        $this->execute("delete from endpoints where id = $endpointId");
        $this->dropTable("slots");
    }

    public function down()
    {
        $table = $this->table('slots');
        $table->addColumn('start_time', 'time')
            ->addColumn('end_time', 'time')
            ->addColumn('organization_id', 'integer', array('limit' => 11))
            ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addIndex(['organization_id'], ['name' => 'slot_organization'])
            ->addForeignKey('organization_id', 'organizations', 'id')
            ->create();

        $endpointData = [
            [
                "url" => "account-service/slot",
                "allowed_methods" => json_encode(['GET', 'POST', 'PUT'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'account-service/slot'")['id'];
        $developerId = $this->fetchRow(
            "SELECT `id` from `developers` where `name` = 'Universal Key' and organization_id is null"
        )['id'];
        $this->insert('endpoint_developer_permissions', array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1
        ));
    }

}
