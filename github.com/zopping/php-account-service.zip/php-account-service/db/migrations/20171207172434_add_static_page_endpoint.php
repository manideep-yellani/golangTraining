<?php

use Phinx\Migration\AbstractMigration;

class AddStaticPageEndpoint extends AbstractMigration
{
    public function up()
    {
        $endpointData = [
            [
                "url" => "account-service/static-page",
                "allowed_methods" => json_encode(['GET', 'POST', 'PUT'])
            ],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE FROM `endpoints` where `url` = "account-service/static-page"');
    }
}
