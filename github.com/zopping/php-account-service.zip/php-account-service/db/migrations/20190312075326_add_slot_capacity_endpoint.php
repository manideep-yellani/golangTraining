<?php

use Phinx\Migration\AbstractMigration;

class AddSlotCapacityEndpoint extends AbstractMigration
{
    public function up()
    {
	$this->execute("insert into endpoints(url,allowed_methods)values('logistics-service/slot-capacity','[\"GET\"]')");
    }
    public function down()
    {
	$this->execute("delete from endpoints where url='logistics-service/slot-capacity'");
    }
}
