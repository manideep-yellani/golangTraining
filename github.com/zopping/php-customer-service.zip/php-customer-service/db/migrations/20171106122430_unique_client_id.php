<?php


use Phinx\Migration\AbstractMigration;

class UniqueClientId extends AbstractMigration
{

    public function change()
    {
        $this->table('customers')
            ->addIndex(['organization_id', 'client_id'], ['name' => 'organization_client_id', 'unique' => true])
            ->save();
    }
}
