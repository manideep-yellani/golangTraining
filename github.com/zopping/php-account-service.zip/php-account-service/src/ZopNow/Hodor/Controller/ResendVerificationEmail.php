<?php

namespace ZopNow\Hodor\Controller;

class ResendVerificationEmail extends \ZopNow\Arya\Controller\Base
{
    const MODEL_NAME = '\ZopNow\Hodor\Model\User';

    public function post()
    {
        $data = $this->getRequestParams(array("user"));
        $modelClass = self::MODEL_NAME;
        $userJson= json_decode($data['user'], true);
        $userId=$userJson['id'];
        $user = $modelClass::find($userId);
        $parameters = ['id' => $userId];
        if (!empty($this->countryIsoCode)) {
            //If the country code has been passed in parameters, forwarding it to user controller
            $parameters['countryIsoCode'] = $this->countryIsoCode;
        }
        if (!empty($this->langIsoCode)) {
            //If the language code has been passed in parameters, forwarding it to user controller
            $parameters['langIsoCode'] = $this->langIsoCode;
        }
        $userObj = new \ZopNow\Hodor\Controller\User($parameters);

        if ($user->verified == 0) {
            $userObj->resendVerificationEmail($user->name, $user->emails()->first(), $user->organization_id);
            $response = array(
                'code' => 200,
                'status' => 'SUCCESS',
                'message' => 'Email sent!',
            );
            return (new \ZopNow\Arya\View\Base($response));
        }
        else {
            throw new \ZopNow\Arya\Exception\ValidationException("User has already been verified");
        }
    }
}

