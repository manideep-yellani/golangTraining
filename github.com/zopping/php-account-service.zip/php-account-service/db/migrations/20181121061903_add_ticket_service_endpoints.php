<?php

use Phinx\Migration\AbstractMigration;

class AddTicketServiceEndpoints extends AbstractMigration
{
    public function up() {
        $endpoints = [
            [
                'url' => 'ticket-service/ticket',
                'allowed_methods' => json_encode(["GET", "PUT", "POST"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('ticket-service/ticket')"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('ticket-service/ticket')");
    }
}
