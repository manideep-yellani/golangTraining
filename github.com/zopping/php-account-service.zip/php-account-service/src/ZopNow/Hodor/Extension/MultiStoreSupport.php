<?php


namespace ZopNow\Hodor\Extension;

class MultiStoreSupport extends Base
{

    public function enable()
    {
        return true;
    }

    public function disable()
    {
        $organizationId = $this->organization->id;
        $orgData = (new \ZopNow\Hodor\Controller\Organization(['id' => $organizationId]))->get()->getData();
        // Disable all stores except for the organization's default store
        $defaultStore = $orgData['data']['organization']['defaultStore']['id'];
        $allStores = $this->organization->stores->pluck('id')->toArray();
        $toBeDisabledStores =  array_diff($allStores,[$defaultStore]);
        foreach ($toBeDisabledStores as $store) {            
            (new \ZopNow\Hodor\Controller\Store(['id' => $store, 'organizationId' => $organizationId]))->delete();
        }
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        $organizationId = $this->organization->id;
        $cost  = $count = $billingPeriod = 0;
        $metaData = null;
        $stores = [];
        if (!empty($pricingRule['TYPE']) && $pricingRule['TYPE'] == 'MONTHLY') {
            $start = date('Y-m-d 00:00:00', strtotime($startTime));
            $end = date('Y-m-d 23:59:59', strtotime($endTime));
            $rows = \ZopNow\Arya\DB\MySql::select("select id, created_at, deleted_at  from `stores` "
                    . " where `organization_id` = $organizationId and ( `deleted_at` is null or `deleted_at` "
                    . " > '$start') order by created_at");
            foreach ($rows as $row) {
                $diffDays = 0;
                if ((strtotime($row['created_at']) < strtotime($end)) && (!is_null($row['deleted_at']) ||
                    strtotime($row['deleted_at']) < strtotime($end) || is_null($row['deleted_at']))) {
                    $startPeriod = strtotime($row['created_at']) < strtotime($start) ? strtotime($start) : strtotime($row['created_at']);
                    $endPeriod = !is_null($row['deleted_at']) ? strtotime($row['deleted_at']) : strtotime($end);
                    $diffDays = round(($endPeriod - $startPeriod)/86400);
                    if ($diffDays > 0) {
                        $stores[$row['id']] = $diffDays;
                    }
                }
            }
        }
        $numDays = date('t', strtotime($startTime));
        $count = sizeof($stores);
        arsort($stores);
        $freeCount = $pricingRule['FREE'] ?? 0;
        $stores = array_slice($stores, $freeCount, NULL, true);
        foreach ($stores as $storeId => $billingPeriod) {
            $cost += $pricingRule['COST'] * $billingPeriod /$numDays;
        }
        if (!empty($cost)) {
            \ZopNow\Arya\App\Application::log("Stores billied for organization $organizationId", $stores);
            $metaData = date('Y-m-d',strtotime($startTime))."-".date('Y-m-d',strtotime($endTime)).", Active number of stores $count.";
        }
        return ['cost' => $cost, 'metaData' => $metaData ?? null];
    }

}
