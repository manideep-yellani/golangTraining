<?php

use Phinx\Migration\AbstractMigration;

class AddAllowedMethodsInEndpoints extends AbstractMigration
{

    public function change()
    {
        $this->table('endpoints')
            ->addColumn('allowed_methods', 'string', array("null" => true))
            ->save();
        
        $endpointData = [
                ["url" => "account-service/resend-verification-email", "allowed_methods" => json_encode(['POST'])],
                ["url" => "inventory-service/stock", "allowed_methods" => json_encode(['GET', 'PUT'])],
                ["url" => "communication-service/call", "allowed_methods" => json_encode(['POST'])]
        ];
        $this->insert('endpoints', $endpointData);

        $endpoints = [
            'account-service/config' => ['GET', 'POST', 'PUT'],
            'account-service/configuration' => ['GET', 'POST', 'PUT'],
            'account-service/currency' => ['GET'],
            'account-service/endpoint' => ['GET'],
            'account-service/organization' => ['GET', 'POST', 'PUT'],
            'account-service/page' => ['GET', 'PUT'],
            'account-service/resetPassword' => ['POST'],
            'account-service/changePassword' => ['POST'],
            'account-service/store' => ['GET', 'POST', 'PUT'],
            'account-service/theme' => ['GET'],
            'account-service/user' => ['GET', 'POST'],
            'account-service/verify ' => ['GET'],
            'account-service/slot' => ['GET', 'POST', 'PUT'],
            'account-service/payment-account' => ['GET', 'POST'],
            'account-service/pickup-location' => ['GET', 'POST', 'PUT'],
            'catalogue-service/brand' => ['GET', 'POST', 'PUT', 'DELETE'],
            'catalogue-service/category' => ['GET', 'POST', 'PUT', 'DELETE'],
            'catalogue-service/product' => ['GET', 'POST', 'PUT', 'DELETE'],
            'catalogue-service/variant' => ['GET', 'POST', 'PUT', 'DELETE'],
            'catalogue-service/tag' => ['GET', 'POST', 'PUT'],
            'catalogue-service/productUpload' => ['GET', 'POST'],
            'catalogue-service/search' => ['GET'],
            'communication-service/email' => ['POST'],
            'communication-service/sms' => ['POST'],
            'inventory-service/item ' => ['GET', 'POST', 'PUT'],
            'customer-service/customer' => ['GET', 'POST'],
            'customer-service/guest' => ['POST'],
            'customer-service/login' => ['GET', 'POST'],
            'customer-service/phone' => ['POST', 'DELETE'],
            'customer-service/email' => ['POST', 'DELETE'],
            'customer-service/address' => ['POST', 'DELETE'],
            'customer-service/verify' => ['GET'],
            'customer-service/reset-password ' => ['POST'],
            'customer-service/change-password' => ['POST'],
            'customer-service/logout' => ['POST'],
            'customer-service/OAuth' => ['POST'],
            'order-service/order' => ['GET', 'POST', 'PUT'],
            'order-service/orderPayment' => ['GET', 'POST'],
            'order-service/stats' => ['GET'],
            'order-service/summary' => ['GET'],
            'order-service/verifyPayment' => ['POST'],
            'order-service/cart' => ['GET', 'PUT'],
            'billing-service/balance' => ['GET'],
            'billing-service/transaction' => ['GET']
        ];
        foreach ($endpoints as $url => $methods) {
            $this->execute("update endpoints set allowed_methods = '".json_encode($methods)."' where url = '$url'");
        }
    }

}
