<?php

use Phinx\Migration\AbstractMigration;

class CheckingQueue extends AbstractMigration
{

    public function up()
    {
        $extensionId = $this->fetchRow(
                "SELECT `id` from `extensions` where `slug` = 'InStoreProcessing'"
            )['id'];
        $endpointData = [
            [
                "url" => "order-service/checking-queue",
                "allowed_methods" => json_encode(['GET']),
                "extension_id" => $extensionId
            ],
            [
                "url" => "order-service/packing-queue",
                "allowed_methods" => json_encode(['GET']),
                "extension_id" => $extensionId
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $endpointsToBeDeleted = [
            "'order-service/checking-queue'",
            "'order-service/packing-queue'"
        ];
        $rows = $this->fetchAll(
            "select id from endpoints where url in (" . implode(',', $endpointsToBeDeleted) . ")"
        );
        $endpointIds = array_column($rows, 'id');
        $this->execute(
            "delete from endpoint_developer_permissions where endpoint_id in ("
            . implode(',', $endpointIds) . ")"
        );
        $this->execute(
            "delete from endpoint_user_permissions where endpoint_id in ("
            . implode(',', $endpointIds) . ")"
        );
        $this->execute(
            "delete from endpoints where url in (" . implode(',', $endpointsToBeDeleted) . ")"
        );
    }

}
