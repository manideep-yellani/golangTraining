<?php

require_once 'BaseCest.php';

class RemoveAddressCest extends BaseCest
{
    protected static $endpoint = '/address';
    protected static $table    = "addresses";
/*
    public function removeAddressWithValidId(ApiTester $I)
    {
        $I->wantToTest("Removing address of a customer with multiple address");
        $customerId       = 1;
        $organizationId   = 1;
        $customer         = json_encode(['id' => $customerId]);
        $data             = [
            "customer" => $customer,
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $id = $I->grabDataFromResponseByJsonPath('$.data.address.id')[0];

        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint. "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, ['id' => $id, "deleted_at" => NULL]);
    }
*/
    public function removeAddressOfCustomerWith1Address(ApiTester $I)
    {
        //Customer 6 has only 1 address
        $I->wantToTest("Removing an address of customer with only 1 address");
        $customerId = 6;
        $organizationId = 3;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $addressId = $I->grabFromDatabase(self::$table, "id", ["customer_id" => $customerId, "deleted_at" => null]);
        $I->sendDELETE(static::$endpoint."/$addressId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Address cannot be deleted as the customer has only 1 address"]);
        $I->seeInDatabase(self::$table, ['id' => $addressId, "deleted_at" => NULL]);
     }

    public function removeAddressWithoutId(ApiTester $I)
    {
        $I->wantToTest("Remove address without passing id");
        $customerId = 5;
        $organizationId = 2;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass a valid id"));
    }

    public function removeAddressWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Delete a Phone with invalid id');
        $customerId = 5;
        $organizationId = 2;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint."/abc", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Model Exception: Address with id: abc not found"));
    }

    public function deletingAnAddressAgain(ApiTester $I)
    {
        $I->wantToTest("Double deletion of same address ID"); // in 1st test we have deleted this address
        $id = 1;
        $customerId = 1;
        $organizationId = 1;
        $data = ["customer" => json_encode(['id' => $customerId]),"organizationId" => $organizationId];
        $I->sendDELETE(static::$endpoint. "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->sendDELETE(static::$endpoint. "/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->dontSeeInDatabase(self::$table, ['id' => $id, "deleted_at" => NULL]);
        $I->seeResponseContainsJson(["message" => "Model Exception: Address with id: $id not found"]);
    }
/*
    public function removeDefaultAddress(ApiTester $I)
    {
        $I->wantTo('Delete customer\'s default address');
        $customerId       = 1;
        $organizationId   = 1;
        $customer         = json_encode(['id' => $customerId]);
        $data             = [
            "customer" => $customer,
            "organizationId" => $organizationId,
            "address" => "#49, 3rd cross, 31st Main, BTM layout 2nd stage",
            "landmark" => "Vidya Jyothi school",
            "pincode" => 560076,
            "city" => "Bengaluru"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $defaultAddressId = $I->grabDataFromResponseByJsonPath('$.data.address.id')[0];

        $I->sendPUT('/customer/'.$customerId,
            compact('customer', 'organizationId', 'defaultAddressId')
        );
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);

        $I->sendDELETE(static::$endpoint."/$defaultAddressId",
            compact('customer', 'organizationId'));
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
    }*/
}