<?php

namespace ZopNow\Hodor\Model;

class Designation extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at' , 'organization_id', 'manager_id'];
    protected $with = ['manager', 'roles'];

    public function isValidDesignation($designationId, $organizationId)
    {
        $modelObject = \ZopNow\Hodor\Model\Designation::where([['id', $designationId],['organization_id', $organizationId]])->first();
        return !empty($modelObject) ? true : false;
    }

    public function isValidName($designationName, $organizationId)
    {
        $modelObject = \ZopNow\Hodor\Model\Designation::where([['name', $designationName],['organization_id', $organizationId]])->first();
        return empty($modelObject) ? true : false;
    }

    public function manager()
    {
        return $this->belongsTo('ZopNow\Hodor\Model\Designation', 'manager_id');
    }

    public function roles()
    {
        return $this->belongsToMany('ZopNow\Hodor\Model\Role')
                ->whereNull('designation_role.deleted_at');
    }

    public function updateRoles($roleIds)
    {
        $id = \ZopNow\Arya\DB\MySql::escape($this->id);
        $values = [];
        foreach ($roleIds as $roleId) {
            $roleId = \ZopNow\Arya\DB\MySql::escape($roleId);
            $values[] = "('$id', '$roleId')";
        }
        \ZopNow\Arya\DB\MySql::update("update `designation_role` "
            . " set deleted_at = now()"
            . " where designation_id = '$id'");
        if (sizeof($values)) {
            $valuesStr = implode(',', $values);
            \ZopNow\Arya\DB\MySql::insert("insert into `designation_role`"
                ." (`designation_id`, `role_id`) values $valuesStr"
                . " on duplicate key update deleted_at = null");
        }
    }

    public function users()
    {
        return $this->hasMany('ZopNow\Hodor\Model\User');
    }

}
