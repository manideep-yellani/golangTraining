<?php

use Phinx\Migration\AbstractMigration;

class UpdateMultiStore extends AbstractMigration
{
public function up()
    {
        $pricing = "FREE for 1 store and ₹ 1500 per month for every store after that";
        $pricingRule = json_encode(['FREE' => 1, 'TYPE' => 'MONTHLY', 'RATE' => 'FIXED', 'COST' => 1500]);
        $this->query("UPDATE extensions SET `pricing`='" . $pricing 
                . "', `pricing_rule`='" . $pricingRule . "'  WHERE `slug` = 'MultiStoreSupport'");
    }
    
    public function down()
    {
        // not required
    }
}
