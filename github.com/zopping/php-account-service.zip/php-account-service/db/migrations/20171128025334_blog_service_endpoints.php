<?php

use Phinx\Migration\AbstractMigration;

class BlogServiceEndpoints extends AbstractMigration
{
    public function up()
    {
        $endpointData = [
            ["url" => "blog-service/blog","allowed_methods" => json_encode(['GET', 'POST', 'PUT', 'DELETE'])],
            ["url" => "blog-service/category","allowed_methods" => json_encode(['GET', 'POST', 'DELETE'])],
            ["url" => "blog-service/tag","allowed_methods" => json_encode(['GET', 'POST', 'PUT', 'DELETE'])],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE FROM `endpoints` where `url` in ("blog-service/blog","blog-service/category","blog-service/tag")');
    }
}
