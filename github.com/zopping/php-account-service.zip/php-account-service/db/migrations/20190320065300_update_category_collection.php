<?php

use Phinx\Migration\AbstractMigration;

class UpdateCategoryCollection extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $rows = $this->fetchAll("select * from organization_page where layouts like '%CategoryCollection%'");
        foreach ($rows as $row) {
            $finalarr = [];
            $layouts = json_decode($row["layouts"],true);
            foreach ($layouts as $layout) {
             $updatedLayout=[];
               foreach ($layout['data'] as $key => $l){
                   if ($key == 'categoryIds') {
                       $a = $l;
                       $arr = [];
                       foreach ($a as $b) {
                           $id="C".$b;
                           array_push($arr,$id) ;
                       }
                       $l = $arr;
                   }
                   $updatedLayout[$key] = $l;
               }
               $layout['data'] = $updatedLayout;
               array_push($finalarr, $layout);
            }
            $var1 = json_encode($finalarr);
            $id=$row['id'];
            \ZopNow\Arya\DB\MySql::update("update organization_page set layouts='". \ZopNow\Arya\DB\MySql::escape($var1) . "'  where id=$id");
        }
    }
}

