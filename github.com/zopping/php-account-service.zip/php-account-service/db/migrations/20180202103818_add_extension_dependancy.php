<?php

use Phinx\Migration\AbstractMigration;

class AddExtensionDependancy extends AbstractMigration
{

    public function up()
    {
        $this->table('extensions')
            ->addColumn('dependant_on', 'string', ['null' => true])
            ->update();
    }

    public function down()
    {
        $this->table('extensions')
            ->removeColumn('dependant_on')
            ->update();
    }

}
