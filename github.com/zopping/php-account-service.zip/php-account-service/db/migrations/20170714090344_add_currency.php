<?php

use Phinx\Migration\AbstractMigration;

class AddCurrency extends AbstractMigration
{

    public function change()
    {
        $currencies = [
            ['name' => "INR", "symbol" => "₹"],
            ['name' => "USD", "symbol" => "$"],
            ['name' => 'IDR', "symbol" => 'Rp'],
        ];
        $this->table('currencies')
            ->addColumn('name', 'string', ['limit' => 10, 'null' => false])
            ->addColumn('symbol', 'string', ['limit' => 5])
            ->addIndex('name', ['unique' => true])
            ->insert($currencies)
            ->save();
        $this->table('organizations')
            ->addColumn('currency_id', 'integer', ['default' => 1])
            ->addForeignKey('currency_id', 'currencies', 'id',
                [
                'constraint' => 'fk_organizations_currencies',
                'delete' => 'NO_ACTION', 'update' => 'NO_ACTION'
            ])
            ->save();
    }
}