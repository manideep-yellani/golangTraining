<?php


use Phinx\Migration\AbstractMigration;

class AddCustomerDefaultPhoneAndEmail extends AbstractMigration
{
    public function change()
    {
        $this->table("customers")
            ->addColumn("default_email_id", "integer", ["after" => "default_address_id", "null" => true])
            ->addColumn("default_phone_id", "integer", ["after" => "default_email_id", "null" => true])
            ->addForeignKey("default_email_id", "emails", "id",
                array('constraint' => 'fk_customers_emails', 'delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->addForeignKey("default_phone_id","phones","id",
                array('constraint' => 'fk_customers_phones', 'delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->update();
    }
}
