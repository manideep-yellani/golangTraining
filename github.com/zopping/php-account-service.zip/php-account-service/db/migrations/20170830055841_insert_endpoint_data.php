<?php

use Phinx\Migration\AbstractMigration;

class InsertEndpointData extends AbstractMigration
{
    /**
     * Seeding the endpoints table with all the service endpoints
     */
    public function change()
    {
        $endpointData = array(
            array(
                "url" => "account-service/config"
            ),
            array(
                "url" => "account-service/configuration"
            ),
            array(
                "url" => "account-service/currency"
            ),
            array(
                "url" => "account-service/endpoint"
            ),
            array(
                "url" => "account-service/organization"
            ),
            array(
                "url" => "account-service/page"
            ),
            array(
                "url" => "account-service/resetPassword"
            ),
            array(
                "url" => "account-service/changePassword"
            ),
            array(
                "url" => "account-service/store"
            ),
            array(
                "url" => "account-service/theme"
            ),
            array(
                "url" => "account-service/user"
            ),
            array(
                "url" => "account-service/verify"
            ),
            array(
                "url" => "catalogue-service/brand"
            ),
            array(
                "url" => "catalogue-service/category"
            ),
            array(
                "url" => "catalogue-service/product"
            ),
            array(
                "url" => "catalogue-service/variant"
            ),
            array(
                "url" => "catalogue-service/tag"
            ),
            array(
                "url" => "catalogue-service/productUpload"
            ),
            array(
                "url" => "catalogue-service/search"
            ),
            array(
                "url" => "communication-service/email"
            ),
            array(
                "url" => "communication-service/sms"
            ),
             array(
                "url" => "customer-service/customer"
            ),
            array(
                "url" => "customer-service/guest"
            ),
            array(
                "url" => "customer-service/login"
            ),
            array(
                "url" => "customer-service/phone"
            ),
            array(
                "url" => "customer-service/email"
            ),
            array(
                "url" => "customer-service/address"
            ),
            array(
                "url" => "inventory-service/item"
            ),
            array(
                "url" => "order-service/order"
            ),
            array(
                "url" => "order-service/orderItem"
            ),
            array(
                "url" => "order-service/orderPayment"
            ),
            array(
                "url" => "order-service/stats"
            ),
            array(
                "url" => "order-service/summary"
            ),
        );
        $this->insert('endpoints', $endpointData);
        $row = $this->fetchRow("SELECT `id` FROM developers where token = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'");
        $developerId = $row['id'];
        $endpointId = $this->fetchRow("select max(id) as id from endpoints")['id'];
        $methods = array('POST', 'PUT', 'DELETE');
        $developerPermissions = array();
        for ($i = 6; $i <= $endpointId; $i++) {
            /* /page, /theme, /brand, /category, /product, /variant, /tag, /item,
             * /config, /configuration, /currency, /organization
             * Developer will have only GET permissions
             */
            if (in_array($i, array(1,2,3,5,6,10,13,14,15,16,17,28))) {
                $developerPermissions = array_merge(array(
                    array(
                        "endpoint_id" => $i,
                        "developer_id" => $developerId,
                        "method" => "GET",
                        "has_permission" => 1
                    )
                ), $developerPermissions);
            }
        }

        $developerPermissions = array_merge(array(
            //search
            array(
                "endpoint_id" => 19,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            ),
            //customer
            array(
                "endpoint_id" => 22,
                "developer_id" => $developerId,
                "method" => "POST",
                "has_permission" => 1
            ),
            //customer
            array(
                "endpoint_id" => 22,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            ),
            //guest
            array(
                "endpoint_id" => 23,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            ),
            //guest
            array(
                "endpoint_id" => 23,
                "developer_id" => $developerId,
                "method" => "POST",
                "has_permission" => 1
            ),
            //login
            array(
                "endpoint_id" => 24,
                "developer_id" => $developerId,
                "method" => "POST",
                "has_permission" => 1
            ),
            //login
            array(
                "endpoint_id" => 24,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            ),
            //customer phone
            array(
                "endpoint_id" => 25,
                "developer_id" => $developerId,
                "method" => "POST",
                "has_permission" => 1
            ),
            //customer phone
            array(
                "endpoint_id" => 25,
                "developer_id" => $developerId,
                "method" => "DELETE",
                "has_permission" => 1
            ),
            //customer email
            array(
                "endpoint_id" => 26,
                "developer_id" => $developerId,
                "method" => "POST",
                "has_permission" => 1
            ),
            //customer email
            array(
                "endpoint_id" => 26,
                "developer_id" => $developerId,
                "method" => "DELETE",
                "has_permission" => 1
            ),
            //customer address
            array(
                "endpoint_id" => 27,
                "developer_id" => $developerId,
                "method" => "POST",
                "has_permission" => 1
            ),
            //customer address
            array(
                "endpoint_id" => 27,
                "developer_id" => $developerId,
                "method" => "DELETE",
                "has_permission" => 1
            ),
            //order
            array(
                "endpoint_id" => 29,
                "developer_id" => $developerId,
                "method" => "POST",
                "has_permission" => 1
            ),
            //order
            array(
                "endpoint_id" => 29,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            ),
            //stats
            array(
                "endpoint_id" => 32,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            ),
            //summary
            array(
                "endpoint_id" => 33,
                "developer_id" => $developerId,
                "method" => "GET",
                "has_permission" => 1
            ),
        ), $developerPermissions);
        $this->insert('endpoint_developer_permissions', $developerPermissions);
    }
}
