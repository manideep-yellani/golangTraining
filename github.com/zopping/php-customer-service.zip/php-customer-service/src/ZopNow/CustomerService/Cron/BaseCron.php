<?php

namespace ZopNow\CustomerService\Cron;

abstract class BaseCron
{

    private static $queryCount = 0;

    public function __construct() {

    }

    /**
     * It should not actually DO anything. It should return a bool value
     * true if the cron will/should run at the passed timestamp, false otherwise.
     */
    abstract public function shouldExecuteAt($timestamp);

    /**
     * This function will contain actual working code of the cron.
     */
    abstract protected function steps();

    /**
     * This function will return the cron name.
     */
    protected function getCronName() {
        return get_called_class();
    }

    /**
     * This function will be called to run the cron.
     */
    final public function run()
    {
        try {
            $this->steps();
        } catch (CronException $e) {
            $this->fail($e->getMessage());
        } catch (\Exception $e) {
            $this->fail($e->getMessage());
        }
        $this->logMetrics();
    }

    private function logMetrics() 
    {
        $dataContext = array();

        $queryCount = \ZopNow\Arya\DB\MySql::getQueryCount();
        $dataContext['MysqlQueries'] = $queryCount - self::$queryCount;
        self::$queryCount = $queryCount;

        $cronName = $this->getCronName();
        \ZopNow\Arya\App\Application::log("Executed cron $cronName", $dataContext);
    }

    protected function fail($message)
    {
        echo "Failed with message: $message \n";
    }
}

class CronException extends \Exception
{

}
