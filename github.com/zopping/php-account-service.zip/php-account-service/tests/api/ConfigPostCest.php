<?php

require_once('BaseCest.php');

class ConfigPostCest extends BaseCest
{

    protected static $endpoint = '/config';

    public function addConfigsWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Add configs without organization id');
        $data = [
            'basic' => [
                'organizationName' => 'Hypercity',
                'siteUrl' => 'http://hypercity.zopexpress.com',
                'logo' => 'http://kikkidu.com/wp-content/uploads/2011/08/hyperCity_250.jpg',
            ]
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - config : organization Id'));
    }
/*
    public function addMultipleConfigs(ApiTester $I)
    {
        $I->wantTo("Add multiple configs for an organization in the same request");
        $data = [
            'organizationId' => 5,
            'basic' => [
                'organizationName' => 'Hypercity',
                'siteUrl' => 'http://hypercity.zopexpress.com',
                'logo' => 'http://kikkidu.com/wp-content/uploads/2011/08/hyperCity_250.jpg',
            ],
            'catalogue' => [
                'hasMultipleBrands' => 'FALSE',
                'hasMultipleVariants' => 'FALSE'
            ],
            "analytics" => [
		"gaAccount" => "",
		"conversionTag" => ""
            ]
        ];
        $I->sendPOST(static::$endpoint, []);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        unset($data['organizationId'], $data['analytics']);
        $I->seeResponseContainsJson($data);
        $I->seeInDatabase("organizations", ["name" => "Hypercity", "domain" => "hypercity.zopexpress.com"]);
        $I->dontSeeInDatabase("configurations", ["key" => "analytics.gaAccount", "organization_id" => 1]);
    }

    public function addSingleConfig(ApiTester $I)
    {
        $I->wantTo("Add single config for an organization");
        $data = [
            'organizationId' => 6,
            'basic' => [
                'organizationName' => 'Hypercity',
                'siteUrl' => 'http://hypercity.zopexpress.dev',
                'logo' => 'http://kikkidu.com/wp-content/uploads/2011/08/hyperCity_250.jpg',
        ]];
        $I->sendPOST(static::$endpoint . "/basic", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        unset($data['organizationId']);
        $I->seeResponseContainsJson($data);
    }
*/
    public function addConfigsWithoutARequiredFieldsInConfig(ApiTester $I)
    {
        $I->wantTo("Add configs for an organization without any of the required fields according to the config file");
        $data = [
            'organizationId' => 7,
            'basic' => [
                'siteUrl' => 'http://hypercity.zopexpress.com',
            ],
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Missing Required Field - config : basic - organizationName']);
    }

    public function addConfigsWithInvalidTextData(ApiTester $I)
    {
        $I->wantTo('Add configs for an organization with invalid data for text type');
        $data = ['organizationId' => 11,
            'basic' => [
                'organizationName' => '@!',
                'siteUrl' => 'http://www.mymorestore.com',
                'logo' => 'http://sn.zopnow.com/images/icons/logo/MyMoreStore-logo.svg']];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: organizationName'));
    }

    public function addConfigsWithInvalidUrlData(ApiTester $I)
    {
        $I->wantTo('Add configs for an organization with invalid data for url type');
        $data = ['organizationId' => 10,
            'basic' => [
                'organizationName' => 'My More Store',
                'siteUrl' => ':morestore',
                'logo' => 'http://sn.zopnow.com/images/icons/logo/MyMoreStore-logo.svg']];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: siteUrl'));
    }

    public function addConfigsWithInvalidEmailData(ApiTester $I)
    {
        $I->wantTo('Add configs for an organization with invalid data for email type');
        $data = ['organizationId' => 10,
            'basic' => [
                'organizationName' => 'My More Store',
                'siteUrl' => 'http://www.mymorestore.com',
                'logo' => 'http://sn.zopnow.com/images/icons/logo/MyMoreStore-logo.svg',
                'supportEmail' => 'more']];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: supportEmail'));
    }

    public function addConfigsWithInvalidPhoneData(ApiTester $I)
    {
        $I->wantTo('Add configs for an organization with invalid data for phone type');
        $data = ['organizationId' => 10,
            'basic' => [
                'organizationName' => 'My More Store',
                'siteUrl' => 'http://www.mymorestore.com',
                'logo' => 'http://sn.zopnow.com/images/icons/logo/MyMoreStore-logo.svg',
                'supportEmail' => 'cs@zopnow.com',
                'supportPhone' => 'abc']];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: supportPhone'));
    }

  /*public function addConfigsWithInvalidBooleanData(ApiTester $I)
    {
        $I->wantTo("Add configs for an organization with invalid data for boolean type");
        $data = [
            'organizationId' => 10,
            'basic' => [
                'organizationName' => 'My More Store',
                'siteUrl' => 'http://www.mymorestore.com',
                'logo' => 'http://sn.zopnow.com/images/icons/logo/MyMoreStore-logo.svg',
            ],
            'catalogue' => [
                'hasMultipleBrands' => 'ABC',
                'hasMultipleVariants' => 'FALSE'
            ],
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid data for catalogue: hasMultipleBrands']);
    }*/

    public function addConfigsWithValidBooleanData(ApiTester $I)
    {
        $I->wantTo("Add configs with value as boolean false");
        $data = [
            'organizationId' => 12,
            'catalogue' => [
                'hasMultipleBrands' => true,
                'hasMultipleVariants' => false
            ],
        ];
        $I->sendPOST(static::$endpoint . "/catalogue", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
    }

}
