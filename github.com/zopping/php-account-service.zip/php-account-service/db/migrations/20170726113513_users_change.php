<?php

use Phinx\Migration\AbstractMigration;

class UsersChange extends AbstractMigration
{

    public function up()
    {
        $this->table('phones')
                ->addColumn('user_id', 'integer')
                ->addColumn('phone', 'biginteger', array('limit' => 12, 'signed' => false))
                ->addColumn('verified', 'boolean', ['default' => 0])
                ->addColumn('deleted_at', 'timestamp', array('null' => true))
                ->addForeignKey('user_id', 'users', 'id', ['constraint' => 'fk_phones_users', 'delete' => 'NO_ACTION', 'update' => 'NO_ACTION'])
                ->addIndex(['user_id', 'phone'], ['unique' => true, 'name' => 'user_phones'])
                ->save();
        $this->table('emails')
                ->addColumn('user_id', 'integer')
                ->addColumn('email', 'string', array('limit' => 100))
                ->addColumn('verified', 'boolean', ['default' => 0])
                ->addColumn('deleted_at', 'timestamp', array('null' => true))
                ->addForeignKey('user_id', 'users', 'id', ['constraint' => 'fk_emails_users', 'delete' => 'NO_ACTION', 'update' => 'NO_ACTION'])
                ->addIndex(['user_id', 'email'], ['unique' => true, 'name' => 'user_emails'])
                ->save();
        $this->query("insert into phones(user_id, phone, deleted_at) select id, phone, deleted_at from users");
        $this->query("insert into emails(user_id, email, deleted_at) select id, email, deleted_at from users");
        $this->table("users")->removeColumn('phone')->removeColumn('email')->save();
    }

    public function down()
    {
        $this->table("users")
                ->addColumn('email', 'string', array('limit' => 100))
                ->addColumn('phone', 'biginteger', array('limit' => 12, 'signed' => false))
                ->save();
        $this->query("update users inner join phones on users.id = phones.user_id set users.phone = phones.phone");
        $this->query("update users inner join emails on users.id = emails.user_id set users.email = emails.email");

        $this->table("users")
                ->addIndex(array('email'), array('unique' => true))
                ->addIndex(array('phone'), array('unique' => true))
                ->save();
        $this->table('phones')->drop();
        $this->table('emails')->drop();
    }

}
