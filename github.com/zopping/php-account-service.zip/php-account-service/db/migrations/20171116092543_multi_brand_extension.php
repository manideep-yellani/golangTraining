<?php

use Phinx\Migration\AbstractMigration;

class MultiBrandExtension extends AbstractMigration
{

    public function up()
    {
        $data = [
            "name" => "Multi Brand Support",
            "slug" => "MultiBrandSupport",
            "description" => "Allows you to manage brands for your items.",
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'MultiBrandSupport'")['id'];
        $this->query("UPDATE endpoints SET `extension_id`='".$extensionId."' WHERE `url` = 'catalogue-service/brand'");
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'MultiBrandSupport'")['id'];
        $this->query("DELETE from extension_organization where extension_id='$extensionId'");
        $this->query("UPDATE endpoints SET `extension_id`=null WHERE `url` = 'catalogue-service/brand'");
        $this->execute('DELETE from `extensions` where `slug` = "MultiBrandSupport"');
    }
}
