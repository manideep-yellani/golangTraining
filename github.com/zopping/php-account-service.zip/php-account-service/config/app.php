<?php


if (!defined('DATA_DIRECTORY')) {
    define("DATA_DIRECTORY", __DIR__."/../data/");
}
if (!defined('ZOPSMART_ADMIN')) {
    $domain = getenv("ZOPSMART_ADMIN");
    if (empty($domain)) {
        $domain = "https://dashboard.zopsmart.com";
    }
    define("ZOPSMART_ADMIN", $domain);
}

if (!defined("ENABLE_DOMAIN_VALIDATION")) {
    define("ENABLE_DOMAIN_VALIDATION", getenv("ENABLE_DOMAIN_VALIDATION"));
}

return array(
    "ZopNow\Arya\DB\MySql" => array(
        "organization_service" => [
            "write" => [
                'host' => getenv("DB_HOST"),
                'database' => 'organization_service',
                'username' => getenv("DB_USER"),
                'password' => getenv("DB_PASSWORD"),
                'charset'   => 'utf8',
            ],
            "read" => [
                'host' => getenv("DB_HOST"),
                'database' => 'organization_service',
                'username' => getenv("DB_USER"),
                'password' => getenv("DB_PASSWORD"),
                'charset'   => 'utf8',
            ],
        ]
    ),
    "ZopNow\Arya\Log" => array(
        "level" => "INFO",
        "fileName" => getenv("DEV_MODE") == "true" ? "/var/log/zopnow/account-service.log" : "php://stdout",
    ),
    "ZopNow\Arya\DB\Redis" => array(
        "host" => getenv("REDIS_HOST"),
        "port" => "6379"
    ),
    "ZopNow\Arya\App\RestApplication" => array(
        "controllerNamespace" => 'ZopNow\Hodor\Controller',
    ),
    "ZopNow\Arya\Utility\Encryption" => array(
        'key' => '223kj8ydshfads8hdf'
    ),
    "ZopNow\Arya\Utility\MicroService" => array(
        "communication-service" => empty(getenv("PHP_COMMUNICATION_SVC_HOST")) ? "http://communication-service" : getenv("PHP_COMMUNICATION_SVC_HOST"),
        "go-communication-service"=> empty(getenv("COMMUNICATION_SVC_HOST")) ?  "http://go-communication-service" : getenv("COMMUNICATION_SVC_HOST"),
        "catalogue-service" => empty(getenv("PHP_CATALOGUE_SVC_HOST")) ? "http://platform-api/catalogue-service" : getenv("PHP_CATALOGUE_SVC_HOST"),
        "go-catalogue-service" => empty(getenv("CATALOGUE_SVC_HOST")) ? "http://go-catalogue-service" : getenv("CATALOGUE_SVC_HOST"),
        "customer-service" => empty(getenv("PHP_CUSTOMER_SVC_HOST")) ? "http://customer-service" : getenv("PHP_CUSTOMER_SVC_HOST"),
        "logistics-service" => empty(getenv("PHP_LOGISTICS_SVC_HOST")) ? "http://logistics-service" : getenv("PHP_LOGISTICS_SVC_HOST"),
        "order-service" => empty(getenv("PHP_ORDER_SVC_HOST")) ? "http://order-service" : getenv("PHP_ORDER_SVC_HOST"),
        "go-order-service" => empty(getenv("ORDER_SVC_HOST")) ? "http://go-order-service" : getenv("ORDER_SVC_HOST"),
	    "config-service" => "http://config-service",
        "go-account-service" => empty(getenv("ACCOUNT_SVC_HOST")) ? "http://go-account-service" : getenv("ACCOUNT_SVC_HOST"),
    ),
    "ZopNow\Hodor\Extension\OnlinePaymentSupport" => array(
        "zoppay-username-prefix" => empty(getenv("ZOPPAY_USERNAME_PREFIX")) ? "zopsmart" : getenv("ZOPPAY_USERNAME_PREFIX"),
    ),
   "ZopNow\Hodor\Utility\ZoppayInteractor" => array(
         "url" => empty(getenv("ZOPPAY_URL")) ? "http://admin.zoppay.com/" : getenv("ZOPPAY_URL"),
         "developer-token" => getenv("ZOPPAY_DEVELOPER_TOKEN"),
     ),
    "ZopNow\Hodor\Utility\Event" => [
        "pubsubProjectId" => getenv("PUBSUB_PROJECT_ID"),
        "pretend" => false,
    ],
);
