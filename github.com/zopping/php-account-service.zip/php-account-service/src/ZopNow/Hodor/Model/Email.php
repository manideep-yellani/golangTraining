<?php

namespace ZopNow\Hodor\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class Email extends \ZopNow\Arya\Model\Base
{

    public $timestamps = false;

    protected $hidden = ['deleted_at', 'user_id'];
    use SoftDeletes;

    public function user()
    {
        return $this->belongsTo("\ZopNow\Hodor\Model\User");
    }

    public static function getUserFromEmail($email)
    {
        $emailObj = Email::where('email', $email)->where(deleted_at, NULL)->first();
        if (!empty($emailObj)) {
            return $emailObj->user;
        }
        return null;
    }
}
