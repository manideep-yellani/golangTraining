<?php

use Phinx\Migration\AbstractMigration;

class Configurations extends AbstractMigration
{
    /**
     * Database schema for "configurations" table
     * It consists of the following fields :
     * organization_id : id of the organization to which the configuration corresponds to
     * key : stores the name of the config
     * value : stores the value of the config such as the fields or the language to be supported
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     * deleted_at : field will be NULL. This field will be set to the timestamp when the config is deleted and it is a soft delete.
     *
     * "id" is the primary key for the table. Combination of "key" and "organization_id" is the unique index for the table
     */
    public function change()
    {
        $configurations = $this->table('configurations');
        $configurations
                       ->addColumn('organization_id', 'integer', array('limit' => 11, 'null' => FALSE))
                       ->addColumn('key', 'string', array('limit' => 45, 'null' => FALSE))
                       ->addColumn('value', 'text', array('null' => FALSE))
                       ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                       ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                       ->addColumn('deleted_at', 'timestamp', array('null' => true))
                       ->addForeignKey('organization_id', 'organizations', 'id', array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
                       ->addIndex(['organization_id', 'key'], array('unique' => true));
        $configurations->create();
    }
}
