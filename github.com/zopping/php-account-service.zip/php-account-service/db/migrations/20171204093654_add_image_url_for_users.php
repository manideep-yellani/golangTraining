<?php

use Phinx\Migration\AbstractMigration;

class AddImageUrlForUsers extends AbstractMigration
{
    /**
     * Adding image_url column to users table
     */
    public function change()
    {
        $this->table('users')
            ->addColumn('image_url', 'string', array('limit' => 500, 'null' => true))
            ->save();
    }
}
