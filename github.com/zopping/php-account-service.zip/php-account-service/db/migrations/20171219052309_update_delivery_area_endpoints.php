<?php

use Phinx\Migration\AbstractMigration;

class UpdateDeliveryAreaEndpoints extends AbstractMigration
{
    public function up()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['GET','POST','PUT'])
                . '\' where url = "logistics-service/radial-zone"');

        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['GET','POST','PUT'])
                . '\' where url = "logistics-service/pincode"');
        
        $endpointData = [
            [
                "url" => "logistics-service/delivery-area",
                "allowed_methods" => json_encode(['GET', 'POST', 'PUT'])
            ],
        ];
        $this->insert('endpoints', $endpointData);    
    }

    public function down()
    {
        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['GET','POST', 'PUT','DELETE'])
                . '\' where url = "logistics-service/radial-zone"');

        $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['GET','POST', 'DELETE'])
                . '\' where url = "logistics-service/pincode"');

        $this->execute('DELETE FROM `endpoints` where `url` = "logistics-service/delivery-area"');
    }

}
