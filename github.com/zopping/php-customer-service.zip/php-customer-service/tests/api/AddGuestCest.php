<?php

require_once 'BaseCest.php';

class AddGuestCest extends BaseCest
{
    protected static $endpoint = "/guest";
    protected static $table = "customers";
/*
    public function createGuestWithValidData(ApiTester $I)
    {
        $I->wantToTest("Creating guest with valid data");
        $data = array(
            "name" => "Heena Sb",
            "organizationId" => 1,
            "phone" => "+919988776666",
            "email" => "heena.sabha1@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $guestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $I->seeInDatabase("phones",['customer_id'=>$guestId, "phone" => $data['phone'], 'status'=> 'NEW']);
        $I->seeInDatabase("emails",['customer_id'=>$guestId, "email" => $data['email'], 'status'=> 'NEW']);
        $I->seeInDatabase("addresses", ["customer_id"=>$guestId, "address"=> $data['address']]);
    }
*/
    public function createGuestWithoutOrganizationId(ApiTester $I)
    {
        $I->wantToTest("Creating guest without organization Id");
        $data = array(
            "name" => "Heena Sb",
            "phone" => "+9199887766664",
            "email" => "heena.sabha6@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad",
            "state" => "Gujarat",
            "countryCode" => "IN"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => "Validation Exception: Missing Required Field - guest : organization Id"]);
    }

/*
    public function createGuestWithSameEmailAndPhone(ApiTester $I)
    {
        $I->wantToTest("Creating guest with same email");
        $data = array(
            "name" => "Heena Sb",
            "organizationId" => 1,
            "phone" => "+919988776666",
            "email" => "heena.sabha3@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $guestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $data['name'] = "Amrit";
        //sending again with different name
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $newguestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $newAddressId = $I->grabDataFromResponseByJsonPath("$.data.customer.defaultAddress.id")[0];
        $I->assertEquals($newguestId, $guestId);
        //name is updated
        $I->seeInDatabase("customers", ['id'=> $newguestId,'name'=>$data['name']]);
        $I->seeInDatabase("addresses", ['id'=>$newAddressId, "address"=> $data['address']]);
    }

    public function createGuestWithSameEmailAndNewPhone(ApiTester $I)
    {
        $I->wantToTest("Creating guest with same email and new phone");
        $data = array(
            "name" => "Amrit Raj",
            "organizationId" => 1,
            "phone" => "+919741304655",
            "email" => "amrit.raj@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Karenss School",
            "pincode" => 800023,
            "city" => "Patna"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $oldGuestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $data['phone'] = "+919741304656";
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $newGuestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $I->assertEquals($oldGuestId, $newGuestId);
        $I->seeInDatabase("phones", ['customer_id'=>$newGuestId, 'phone'=> $data['phone'], 'status'=>'NEW']);
    }

    public function createGuestWithNewEmailAndSamePhone(ApiTester $I)
    {
        $I->wantToTest("Creating guest with new email and same phone");
        $data = array(
            "name" => "Shraddha",
            "organizationId" => 1,
            "phone" => "+918798122343",
            "email" => "shraddha.raj@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Karenss School",
            "pincode" => 800023,
            "city" => "Patna"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $oldGuestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $data['email'] = "shraddha.raj@hotmail.com";
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $newGuestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $I->assertEquals($oldGuestId, $newGuestId);
        $I->seeInDatabase("emails", ['customer_id'=>$newGuestId, 'email'=> $data['email'], 'status'=>'NEW']);

    }

    public function createGuestwithEmailAndPhoneOfOtherCustomer(ApiTester $I)
    {
        $I->wantToTest("Test guest creation with already taken phone and email by different customer");
        $phone1 = "+919741304656";
        $phone2 = "+919752404656";
        $email1 = "test@gmail.com";
        $email2 = "test2@gmail.com";
        $data = array(
            "name" => "Alokit",
            "organizationId" => 1,
            "phone" => $phone1,
            "email" => $email1,
            "address" => "House no-6, Saket",
            "landmark" => "St. Karenss School",
            "pincode" => 800023,
            "city" => "Patna"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $data = array(
            "name" => "Abhinav",
            "organizationId" => 1,
            "phone" => $phone2,
            "email" => $email2,
            "address" => "House no-6, Saket",
            "landmark" => "St. Karenss School",
            "pincode" => 800023,
            "city" => "Patna"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        //Sending for email and phone of different customer
        $data = array(
            "name" => "Abhinav",
            "organizationId" => 1,
            "phone" => $phone1,
            "email" => $email2,
            "address" => "House no-6, Saket",
            "landmark" => "St. Karenss School",
            "pincode" => 800023,
            "city" => "Patna"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message'=> "Validation Exception: Phone and Email already exists"]);
    }
*/

    public function creatingGuestWithInvalidPhone(ApiTester $I)
    {
        $I->wantToTest("Creating guest with Invalid phone");
        $data = array(
            "name" => "Heena Sb",
            "organizationId" => 1,
            "phone" => "998as",
            "email" => "heena.sabha6@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad",
            "state" => "Gujarat",
            "countryCode" => "IN"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => "Validation Exception: Invalid Phone"]);
    }

    public function creatingGuestWithInvalidEmail(ApiTester $I)
    {
        $I->wantToTest("Creating guest with Invalid email");
        $data = array(
            "name" => "Heena Sb",
            "organizationId" => 1,
            "phone" => "+919988776664",
            "email" => "heena.sabha6",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad",
            "state" => "Gujarat",
            "countryCode" => "IN"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => "Validation Exception: Invalid Email"]);
    }
/*
    public function createGuestWithoutAddress(ApiTester $I)
    {
        $I->wantToTest("Creating guest without address");
        $data = array(
            "name" => "Heena Sb",
            "organizationId" => 1,
            "phone" => "+919987766664",
            "email" => "heena.sabha6@gmail.com",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $guestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $defaultAddress = $I->grabDataFromResponseByJsonPath("$.data.customer.defaultAddress")[0];
        codecept_debug($defaultAddress);
        $I->assertEmpty($defaultAddress);
    }

    public function createCustomerWithLAtLong(ApiTester $I)
    {
        $I->wantToTest("Creating guest with latitude longitude values");
        $data = array(
            "name" => "Srikanth Prabhu",
            "organizationId" => 1,
            "phone" => "+919984775551",
            "email" => "srikanth@gmail.com",
            "address" => "#24, BSK 3rd stage",
            "landmark" => "Jyoti temple",
            "pincode" => "560085",
            "city" => "Bangalore",
            "latitude" => 12.8329137232310,
            "longitude" => 77.2947508931600
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseContainsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $guestId = $I->grabDataFromResponseByJsonPath("$.data.customer.id")[0];
        $defaultAdressId = $I->grabDataFromResponseByJsonPath("$.data.customer.defaultAddress.id")[0];
        $I->seeInDatabase("addresses", ["customer_id"=>$guestId, "id" => $defaultAdressId, "address"=> $data['address'], "latitude"=>$data['latitude'], "longitude"=>$data['longitude']]);
    }
*/
}
