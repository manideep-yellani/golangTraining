<?php

use Phinx\Migration\AbstractMigration;

class DeleteSubstitutionGroup extends AbstractMigration
{
  public function up()
  {
    $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
            . json_encode(['GET','POST','PUT','DELETE'])
            . '\' where url = "catalogue-service/substitution-group"');
  }

  public function down()
  {
    $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
            . json_encode(['GET','POST','PUT'])
            . '\' where url = "catalogue-service/substitution-group"');
  }
}
