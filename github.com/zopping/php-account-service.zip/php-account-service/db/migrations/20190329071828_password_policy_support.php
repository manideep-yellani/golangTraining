<?php

use Phinx\Migration\AbstractMigration;

class PasswordPolicySupport extends AbstractMigration
{
    private $slug = "PasswordPolicySupport";

    public function up(){
        $data = [
            "slug" => $this->slug,
            "name" => "Password Policy Support",
            "description" => "Allows you to configure password policy related variables.",
            "pricing" => "FREE",
            "enable_helper_text"=> "You will be able to configure the minimum password length of a password.|You will be able to configure the minimum number of numeric characters in a password.|You will be able to configure the minimum number of uppercase alphabets in a password.|You will be able to configure the minimum number of lowercase alphabets in a password.|You will be able to configure the minimum number of symbol characters in a password.|",
            "disable_helper_text" => "You will not be able to configure the minimum password length of a password.|You will not be able to configure the minimum number of numeric characters in a password.|You will not be able to configure the minimum number of uppercase alphabets in a password.|You will not be able to configure the minimum number of lowercase alphabets in a password.|You will not be able to configure the minimum number of symbol characters in a password.|",
            "icon" => "https://storage.googleapis.com/zopsmart-staging-uploads/originals/20190401/password-20190401-070517.png",
        ];
        $this->insert('extensions',$data);
    }
    public function down()
    {
        $this->execute("delete from extensions where slug = '$this->slug'");
    }
}
