<?php

use Phinx\Migration\AbstractMigration;

class MultiUserSupport extends AbstractMigration
{

    public function up()
    {
        $data = [
            "name" => "Multi User Support",
            "slug" => "MultiUserSupport",
            "description" => "Allows you to manage users for your organization.",
            "enable_helper_text" => "Allows multiple users to run the smart store | ".
                "Allows management of a user by providing only required permissions ",
            "disable_helper_text" => "Removes multiple users signed up with organization ",
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'MultiUserSupport'")['id'];
        $this->query("UPDATE endpoints SET `extension_id`='".$extensionId."' WHERE `url` = 'account-service/user'");
        $this->query("UPDATE endpoints SET `extension_id`='".$extensionId."' WHERE `url` = 'account-service/invite'");
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'MultiUserSupport'")['id'];
        $this->query("DELETE from extension_organization where extension_id='$extensionId'");
        $this->query("UPDATE endpoints SET `extension_id`=null WHERE `url` = 'account-service/user'");
        $this->query("UPDATE endpoints SET `extension_id`=null WHERE `url` = 'account-service/invite'");
        $this->execute("DELETE from `extensions` where `id` = '$extensionId'");
    }
}
