<?php

namespace ZopNow\CustomerService\Controller;

class OAuth extends \ZopNow\Arya\Controller\Base
{
    /*
     * This refers to keys used by account-service
     */
    const PROVIDER_KEY_MAPPING = [
        "Facebook" => ["hasFacebookLogin", "fbLoginCredentials"],
        "Twitter" => ["hasTwitterLogin", "twitterLoginCredentials"],
        "Google" => ["hasGooglePlusLogin", "googleLoginCredentials"]
    ];

    /**
     * Given a hybridauth acessToken, this function will forcelogin the customer and
     * return guid, if account exists.
     * @return \ZopNow\Arya\View\Base
     * @throws \ZopNow\Arya\Exception\AppException
     */
    public function post()
    {
        $mandatoryFields = ['provider','accessToken', 'organizationId'];
        $optionalFields = ['remember', 'accessTokenSecret'];
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);
        if ($data['provider'] == "Twitter" && empty($data['accessTokenSecret'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass accessTokenSecret");
        }
        $remember = !empty($data['remember']) ? filter_var($data['remember'], FILTER_VALIDATE_BOOLEAN) : false;
        $config = $this->getAuthConfig($data['provider'], $data['organizationId']);
        $adapter = null;
        try {
            $hybridauth = new \Hybrid_Auth( $config );
            $provider = strtolower(trim(strip_tags($data["provider"])));
            $accessToken = $data["accessToken"];
            /*
             * @TODO
             * Once Hybridauth 3.0 becomes stable, then we will be using built-in function
             * to manage tokens.
             */
            $hybridauth::storage()->set("hauth_session.$provider.is_logged_in", 1);
            $hybridauth::storage()->set("hauth_session.$provider.token.access_token", $accessToken);
            if ($provider == "twitter") {
                $hybridauth::storage()->set("hauth_session.$provider.token.access_token_secret", $data['accessTokenSecret']);
            }
            $adapter = $hybridauth->getAdapter($provider);
            $userProfile = $adapter->getUserProfile();
            $email = $userProfile->email;
            $token = \ZopNow\CustomerService\Auth\Auth::getTokenForOAuth($email, $data['organizationId'], $remember);
            if (empty($token)) {
                $response['customer'] = null;
            }
            else {
                $modelClass = \ZopNow\CustomerService\Auth\Auth::AUTH_MODEL_NAME;
                $customer = $modelClass::find(\ZopNow\Arya\Auth\Auth::$id);
                $response['customer'] = $customer->toArray();
                $response['customer']['accessToken'] = $token;
            }
        } catch(\ZopNow\Arya\Exception\AuthException $e) {
            $response['customer'] = null;
        } catch (\Exception $e) {
            // In case we have errors 6 or 7, then we have to use Hybrid_Provider_Adapter::logout() to
            // let hybridauth forget all about the user so we can try to authenticate again.
            // Display the received error,
            switch ($e->getCode()) {
                case 0 : $error = $e->getMessage();
                    break;
                case 1 : $error = "Configuration error.";
                    break;
                case 2 : $error = "Provider not properly configured.";
                    break;
                case 3 : $error = "Unknown or disabled provider.";
                    break;
                case 4 : $error = "Missing provider application credentials.";
                    break;
                case 5 : $error = "Authentication failed. The user has canceled the authentication or the provider refused the connection.";
                    break;
                case 6 : $error = "User profile request failed. Most likely the user is not connected to the provider and he should authenticate again.";
                    $adapter->logout();
                    break;
                case 7 : $error = "User not connected to the provider.";
                    $adapter->logout();
                    break;
                case 8 : $error = "Provider does not support this feature.";
                    break;
            }
            \ZopNow\Arya\Log::log("Hybrid Auth Error with message ".$error,$e->getTrace(),'ERROR');
            throw new \ZopNow\Arya\Exception\AppException($error);
        }
        return new \ZopNow\Arya\View\Base([
                'code' => 200,
                'status' => "SUCCESS",
                'data' => $response,
            ]);
    }

    private function getAuthConfig($provider, $organizationId)
    {
        $response = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/config/social", "GET", ["organizationId" => $organizationId]);
        $accountSpecificData = json_decode($response['body'], true)['data']['config']['social'];
        if (!$accountSpecificData[self::PROVIDER_KEY_MAPPING[$provider][0]]) {
            throw new \ZopNow\Arya\Exception\ValidationException("Organization doesnt support Login with $provider");
        }
        $config = array(
            "providers" => array(
                "Facebook" => array(
                    "enabled" => true,
                    "trustForwarded" => false,
                    "scope" => "email, user_about_me, user_birthday, user_hometown", // optional
                    "display" => "popup" // optional
                ),
                "Google" => array(
                    "enabled" => true,
                    "scope"   => "https://www.googleapis.com/auth/plus.login ". // optional
                                 "https://www.googleapis.com/auth/plus.me ". // optional
                                 "https://www.googleapis.com/auth/plus.profile.emails.read", // optional
                    "access_type"     => "offline",   // optional
                    "approval_prompt" => "force",     // optional
                    "hd"              => "domain.com" // optional
                ),
                "Twitter" => array(
                    "enabled" => true,
                    "includeEmail" => true
                )
            )
        );
        $config['providers'][$provider]['keys'] = $accountSpecificData[self::PROVIDER_KEY_MAPPING[$provider][1]];
        return $config;
    }
}
