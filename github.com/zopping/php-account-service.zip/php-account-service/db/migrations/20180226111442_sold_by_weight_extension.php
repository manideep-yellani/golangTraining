<?php

use Phinx\Migration\AbstractMigration;

class SoldByWeightExtension extends AbstractMigration
{
    public function up()
    {
        $enableHelperText = "Allows user to mark products as sold by weight from"
            . " the sold by weight products interface | "
            . "Products can be marked as sold by weight during product creation and bulk upload"
            . " | When order is placed with sold by weight products the prices are"
            . " computed based on the actual quantity of the products and not unit quantity";

        $disableHelperText = "Disables the sold by weight products interface | "
            . " All existing sold by weight products will be unmarked and their prices updated";

        $data = [
            "name" => "Sold By Weight Support",
            "slug" => "SoldByWeightSupport",
            "description" => "Allows to support products that are sold by weight",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow(
            "SELECT `id` from `extensions` where `slug` = 'SoldByWeightSupport'"
        )['id'];
        $endpointData = [
            [
                'url' => 'catalogue-service/sold-by-weight',
                'allowed_methods' => json_encode(['GET', 'POST', 'PUT']),
                'extension_id' => $extensionId
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'SoldByWeightSupport'")['id'];
        $this->execute('DELETE from `extension_organization` where id = ' . $extensionId);
        $this->execute("DELETE from `endpoints` where `extension_id` = $extensionId");
        $this->execute('DELETE from `extensions` where `slug` = "SoldByWeightSupport"');
    }
}
