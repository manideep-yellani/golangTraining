<?php

use Phinx\Migration\AbstractMigration;

class AddProductTagUpload extends AbstractMigration
{
    public function change()
    {
	$this->execute('insert into endpoints(url,allowed_methods) values("catalogue-service/product-tag-file","[\"POST\"]")');
    }
}
