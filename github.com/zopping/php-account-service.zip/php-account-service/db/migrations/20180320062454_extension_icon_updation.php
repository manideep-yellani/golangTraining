<?php

use Phinx\Migration\AbstractMigration;

class ExtensionIconUpdation extends AbstractMigration
{
    public function up()
    {
        $extensionIcons = [
            'TawkToLiveChat' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/twak%403x-20180320-061858.png',
            'Seo' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/SEO-20180320-063308.png',
            'SubstitutionGroups' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/substitution-groups%403x-20180320-061946.png',
            'ProductTagSupport' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/product-tag-support%403x-20180320-063139.png',
            'MultiVariantSupport' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/multi-variant%403x-20180320-062054.png',
            'MultiStoreSupport' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/multi-store-support%403x-20180320-061704.png',
            'LogisticsSupport' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/logistics-support%403x-20180320-061806.png',
            'Campaigns' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/campaigns%403x-20180320-061923.png',
            'DeliveryAreaSupport' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/delivery-area-support%403x-20180320-063217.png',
            'InStoreProcessing' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/instore-processing%403x-20180320-063158.png',
        ];
        foreach ($extensionIcons as $slug => $icon){
            $this->execute("UPDATE `extensions` set `icon` = '$icon' where `slug` ='$slug'");
        }
    }

    public function down()
    {
        $extensionIcons = [
            'TawkToLiveChat' => null,
            'Seo' => null,
            'SubstitutionGroups' => null,
            'ProductTagSupport' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/product-tag-support%403x-20180223-095255.png',
            'MultiVariantSupport' => null,
            'MultiStoreSupport' => null,
            'LogisticsSupport' => null,
            'Campaigns' => null,
            'DeliveryAreaSupport' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/delivery-area-support%403x-20180223-095255.png',
            'InStoreProcessing' => 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/instore-processing%403x-20180223-095255.png',
        ];
        foreach ($extensionIcons as $slug => $icon){
            $this->execute("UPDATE `extensions` set `icon` = '$icon' where `slug` ='$slug'");
        }
    }
}
