<?php

namespace ZopNow\Hodor\Controller;

class Currency extends \ZopNow\Arya\Controller\ModelController
{

    public function get()
    {
        if (!empty($this->data['id'])) {
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }
}
