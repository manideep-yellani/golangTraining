<?php

namespace ZopNow\Hodor\Controller;

class Store extends \ZopNow\Arya\Controller\ModelController
{
    protected static $filterableFields = ['organization_id', 'client_store_id'];
    protected $allowNonPaginated = true;

    public function getCustomField($organizationId,$entity){
       $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $organizationId, 'entity' => $entity,'paginate'=>'false']);
      return $customFieldResponse;  
    }

    public function get()
    {
        $params = $this->getRequestParams([],['organizationId']);
        if (!empty($this->data['id'])) {
            if (isset($params['organizationId']) && $params['organizationId'] != $this->model->organization_id) {
                throw new \ZopNow\Arya\Exception\ModelException("Store with id: "
                        . $this->data['id'] . " not found");
            }
            $data = $this->getDetails();
            $data['store']['hasDeliveryHub'] = $data['store']['hasDeliveryHub'] == 1 ? true : false;
            $data['store']['hasClickCollect'] = $data['store']['hasClickCollect'] == 1 ? true : false;
            $data['store']['hasPicking'] = $data['store']['hasPicking'] == 1 ? true : false;
            $data['store']['hasSelfCheckout'] = $data['store']['hasSelfCheckout'] == 1 ? true : false;
        } else {
            $params = $this->getRequestParams(['organizationId']);
            $list = $this->getList();
            $data = $this->getListData($list);
            $customFieldResponse = $this->getCustomField($params['organizationId'], 'store');
            $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
            foreach ($data['store'] as &$row) {
                $row['hasDeliveryHub'] = $row['hasDeliveryHub'] == 1 ? true : false;
                $row['hasClickCollect'] = $row['hasClickCollect'] == 1 ? true : false;
                $row['hasPicking'] = $row['hasPicking'] == 1 ? true : false;
                $row['hasSelfCheckout'] = $row['hasSelfCheckout'] == 1 ? true : false;
                $row['metaData'] = $this->getMetaData($row['metaData'], $fieldData);
            }
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function getDetails()
    {
        $details = parent::getDetails();
        $key = array_keys($details)[0];
        $customFieldResponse = $this->getCustomField($this->model->organization_id, 'store');
        $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
        $details[$key]['metaData'] = $this->getMetaData($details[$key]['metaData'], $fieldData);
        return $details;
    }

    public function post()
    {
        $mandatoryFields = array("organizationId", "name");
        $otherFields = array("clientStoreId", "latitude", "longitude", "address","metaData");
        $data = $this->getRequestParams($mandatoryFields, $otherFields);
        (new Organization(array("id" => $data['organizationId'])));
        if (!empty($data['name'])) {
            $exists = $this->model->exists($data['organizationId'], $data['name']);
            if ($exists) {
                throw new \ZopNow\Arya\Exception\ValidationException("Store with the name ".$data['name']." already exists");
            }
        }
        \ZopNow\Arya\DB\MySql::startTransaction();
        $store = $this->add($data);
        $organizationDetails = (new Organization(['id' => $data['organizationId']]))->getDetails();
        $ownerUserId = !empty($organizationDetails['organization']['owner']) ? $organizationDetails['organization']['owner']['id'] : NULL;
        if (!empty($ownerUserId)) {
            $ownerStoreIds = array_column($organizationDetails['organization']['owner']['stores'], 'id');
            $ownerStoreIds[] = $store['store']['id'];
            (new User(['id' => $ownerUserId, 'storeIds' => $ownerStoreIds]))->put();
        }
        \ZopNow\Arya\DB\MySql::commit();
        return (new \ZopNow\Arya\View\Base([
            'code' => 200,
            "status" => "SUCCESS",
            "data" => $store
        ]));
    }

    public function save($data)
    {
        if (!empty($data['latitude'])
            && !\ZopNow\Arya\Utility\Validator::isLatitude($data['latitude'])
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid latitude value");
        }
        if (!empty($data['longitude'])
            && !\ZopNow\Arya\Utility\Validator::isLongitude($data['longitude'])
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid longitude value");
        }
        if (!empty($data['metaData'])) {
            if (!is_array($data['metaData'])) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid format for metadata");
            }

            $customFieldResponse = $this->getCustomField($data['organizationId'], 'store');
            $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
            if (empty($fieldData)) {
                throw new \ZopNow\Arya\Exception\ValidationException("There is no metadata configured");
            }
            foreach ($this->data['metaData'] as $key => $value) {
                $flag = false;
                foreach ($fieldData as $customField) {
                    if ($key == $customField['key']) {
                        $flag = true;
                        $metaMap[$customField['id']] = $value;
                        break;
                    }
                }
                if ($flag == false) {
                    throw new \ZopNow\Arya\Exception\ValidationException("$key not configured in metadata");
                }
            }
            $data['metaData'] = $metaMap;
        }
        return parent::save($data);
    }

    public function put()
    {
        if (empty($this->data['id'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid id");
        }
        $optionalFields = array("name", "clientStoreId", "latitude", "longitude", "address","metaData");
        $data = $this->getRequestParams(array(), $optionalFields);
        $data['id'] = $this->model->id;
        if (!empty($data['name']) && $this->model->exists($this->model->organization_id, $data['name'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Store with name '$data[name]' already exists");
        }
        $store = $this->edit($data);

        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $store
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    public function delete()
    {
        $data = $this->getRequestParams(['organizationId', 'id']);
        if ($this->model->organization_id != $data['organizationId']) {
            throw new \ZopNow\Arya\Exception\ModelException(
                "Store with id: " . $data['id'] . " not found"
            );
        }
        parent::delete();
        $response = array(
            'status' => 'SUCCESS',
            'message' => 'Store deleted successfully',
            'data' => null
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function getDefaultStoreForOrganization()
    {
        $fields = $this->getRequestParams(['organizationId']);
        $defaultStoreId = $this->modelClass::getDefaultStoreIdForOrganization($fields['organizationId']);
        return !empty($defaultStoreId) ? (new Store(['id' => $defaultStoreId]))->getDetails() : ['store' => []];
    }

    public function getMetaData($customFieldMap, $fieldData)
    {
        if (empty($customFieldMap)) {
            return null;
        }
        foreach ($customFieldMap as $key => $value) {
            foreach ($fieldData as $customField) {
                if ($key == $customField['id']) {
                    $metaMap[$customField['key']] = $value;
                    break;
                }
            }
        }
        return $metaMap;
    }

}
