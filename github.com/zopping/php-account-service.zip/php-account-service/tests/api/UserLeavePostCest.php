<?php

class UserLeavePostCest
{

    protected static $endpoint = '/user-leave';
    protected static $table = 'user_leaves';

    public function applyForLeave(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $data = [
            "user"=> '{
                    "id": ' . $userId . ',
                    "name": "Test",
                    "designation": {
                        "id": ' . $desigId . ',
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "type" => 'EARNED',
            'fromDate' => date('Y-m-d'),
            'toDate' => date('Y-m-d', strtotime("+5 days")),
            'reason' => "Personal",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "userleave" => "array"
            )
        ));
    }

    public function applyWithoutAnyRequiredParams(ApiTester $I)
    {
        $data = [
            "organizationId" => 1,
            "type" => 'EARNED',
            'fromDate' => date('Y-m-d', strtotime("+2 days")),
            'toDate' => date('Y-m-d', strtotime("+5 days")),
            'reason' => "Personal",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Missing Required Field - userleave : user"]
        );
    }

    public function applyWithInvalidFromDate(ApiTester $I)
    {
        $data = [
            "user"=> '{
                    "id": 1,
                    "name": "Test",
                    "designation": {
                        "id": 1,
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "type" => 'EARNED',
            'fromDate' => '02-03-2018',
            'toDate' => date('Y-m-d', strtotime("+5 days")),
            'reason' => "Personal",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Invalid from date"]
        );
    }

    public function applyWithInvalidToDate(ApiTester $I)
    {
        $data = [
            "user"=> '{
                    "id": 1,
                    "name": "Test",
                    "designation": {
                        "id": 1,
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "type" => 'EARNED',
            'fromDate' => date('Y-m-d', strtotime("+5 days")),
            'toDate' => '02-03-2018',
            'reason' => "Personal",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Invalid to date"]
        );

        $data['toDate'] = date('Y-m-d', strtotime("+2 days"));
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: From date is greater than to date"]
        );
    }

    public function applyForInvalidHalfDay(ApiTester $I)
    {
        $data = [
            "user"=> '{
                    "id": 1,
                    "name": "Test",
                    "designation": {
                        "id": 1,
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "type" => 'HALFDAY',
            'fromDate' => date('Y-m-d', strtotime("+4 days")),
            'toDate' => date('Y-m-d', strtotime("+5 days")),
            'reason' => "Personal",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Invalid date range for half-day leave."]
        );
    }

    public function applyForDuplicateLeave(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $data = [
            "user"=> '{
                    "id": ' . $userId . ',
                    "name": "Test",
                    "designation": {
                        "id": ' . $desigId . ',
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "type" => 'EARNED',
            'fromDate' => date('Y-m-d', strtotime("+2 days")),
            'toDate' => date('Y-m-d', strtotime("+5 days")),
            'reason' => "Personal",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));

        $data['fromDate'] = date('Y-m-d', strtotime("+3 days"));
        $data['toDate'] = date('Y-m-d', strtotime("+6 days"));
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: A leave application for the same"
                . " date range is already available for this user"]
        );
    }

}
