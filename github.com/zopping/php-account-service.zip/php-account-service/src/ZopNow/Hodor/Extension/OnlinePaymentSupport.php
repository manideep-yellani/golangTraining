<?php


namespace ZopNow\Hodor\Extension;

class OnlinePaymentSupport extends Base
{
    private static $configurations;

    public static function configure($configurations) 
    {
        self::$configurations = $configurations;
    }

    public function enable()
    {
        $domainName = $this->organization->domain;
        if (empty($domainName)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please update the domain name to enable online payments");
        }
        $domainUrl = preg_replace('/^(?!https?:\/\/)/', 'http://', $domainName);
        if ($this->organization->getHttpsEnabledAttribute() === 1) {
            $domainUrl = str_replace('http://', 'https://', $domainUrl);
        }
        $paymentAccount = \ZopNow\Hodor\Model\PaymentAccount::withTrashed()
                ->where([['organization_id', $this->organization->id]])->first();
        if (!empty($paymentAccount)) {
            $accessToken  = $paymentAccount->access_token;
            $requestParams =  ['status' => 'ENABLED', 'referral_url' => $domainUrl."/pay.php",
                'redirect_url' => $domainUrl."/api/payment-response",
                'payment_verification_callback' => $domainUrl."/api/payment-response",
                'currency' => $this->organization->currency->name,
                'image' => $this->organization->logo];
            $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor("update-account.json", "POST", $requestParams , $accessToken))->execute();
            if ($response['statusCode'] != 200) {
                throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong, please try again later");
            }
            $paymentAccount->restore();
        }
        else {
            $owner = $this->organization->users->where("is_owner", 1)->toArray();
            $request = ['domain_name' => $this->organization->name, 'referral_url' => $domainUrl."/pay.php",
                'redirect_url' => $domainUrl."/api/payment-response", 'payment_verification_callback' => $domainUrl."/api/payment-response",
                'access_key' => microtime(true). uniqid('', true), 'secret_key' => microtime(true). uniqid($this->organization->id, true),
                'username' => self::$configurations['zoppay-username-prefix'].'-'.$this->organization->slug, 'response_method' => 'GET', 'type' => 'PRODUCTION',
                'public_name' => $this->organization->name, 'reporting_email' => $owner[0]['emails'][0]['email'], 'currency' => $this->organization->currency->name,
                'image' => $this->organization->logo
            ];
            $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor('account.json', 'POST', $request))->execute();
            if ($response['statusCode'] != 200) {
                throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong, please try again later");
            }
            $data = json_decode($response['response'], true);
            if (!empty($data[0]) && ($data[0]['type'] == 'Error')) {
                throw new \ZopNow\Arya\Exception\ValidationException($data[0]['data']);
            }
            $details = $data[0]['data'];
            $requestData = ['organizationId' => $this->organization->id, 'accessToken' => $details['developer_access_token'],
                     'accessKey' => $details['access_key'], 'secretKey' => $details['secret_key']];
            (new \ZopNow\Hodor\Controller\PaymentAccount($requestData))->add($requestData);
        }

        // online mode being added to paymentMethods config
        $resp = \ZopNow\Arya\Utility\MicroService::callService("config-service",
            "/config/order", "GET", [
                "organizationId" => (string)$this->organization->id
            ]);
        $paymentMethods=json_decode($resp["body"],true)["data"]["order"]["paymentMethods"];
        if(!in_array('ONLINE', $paymentMethods)) {
            $paymentMethods[] = 'ONLINE';
            \ZopNow\Arya\Utility\MicroService::callService("config-service",
                "/config", "POST", [
                    "organizationId" => (string)$this->organization->id,
                    "order" => ["paymentMethods" => $paymentMethods]
                ]);
        }
        return true;
    }

    public function disable()
    {
        $organizationId = $this->organization->id;
        $paymentAccount = (new \ZopNow\Hodor\Model\PaymentAccount())->getPaymentAccount($organizationId);
        $accessToken  = $paymentAccount->access_token;
        $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor("update-account.json", "POST", ['status' => 'DISABLED'] , $accessToken))->execute();
        if ($response['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong, please try again later");
        }
        $paymentAccount->delete();
        // online mode being removed from paymentMethods config
        $this->removePaymentMethod('ONLINE');
        $stores = $this->organization->stores;
        foreach ($stores as $store) {
            $this->removePaymentMethod('ONLINE', $store->id);
        }
        return true;
    }

    private function removePaymentMethod($paymentMethod, $storeId = NULL)
    {
        $resp = \ZopNow\Arya\Utility\MicroService::callService("config-service",
            "/config/order", "GET", [
                "organizationId" => (string)$this->organization->id,
                "storeId" => $storeId
            ]);
        $paymentMethods=json_decode($resp["body"],true)["data"]["order"]["paymentMethods"];
        $key = array_search($paymentMethod, $paymentMethods);
        if ($key !== false) {
            unset($paymentMethods[$key]);
            if (empty($paymentMethods)) {
                $paymentMethods = array("COD");
            }
            \ZopNow\Arya\Utility\MicroService::callService("config-service",
                    "/config", "POST", [
                        "organizationId" => (string)$this->organization->id,
                        "storeId" => $storeId,
                        "order" => ["paymentMethods" => array_values($paymentMethods)]
                    ]);
        }
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        $paymentAccount = \ZopNow\Hodor\Model\PaymentAccount::withTrashed()
                ->where([['organization_id', $this->organization->id]])->first();
        $billingAmt = 0;
        if (!empty($paymentAccount)) {
            $accessToken = $paymentAccount->access_token;
            $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor("transaction-stats.json", "GET", ['from' => $startTime, 'to' => $endTime] , $accessToken))->execute();
            if ($response['statusCode'] != 200) {
                throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong, please try again later");
            }
            $zoppayResponse = json_decode($response['response'], true);
            $totalPaidAmt = $zoppayResponse[0]['data']['payment_stats']['gross_amount'] ?? 0;
            $totalRefundedAmt = $zoppayResponse[0]['data']['refund_stats']['gross_amount'] ?? 0;
            $cost = $pricingRule['COST'];
            $billingAmt = ($totalPaidAmt - $totalRefundedAmt) * $cost/100;
            if ($billingAmt > 0) {
                $metaData = date('Y-m-d',strtotime($startTime))."-".date('Y-m-d',strtotime($endTime)).",Total Paid Amount - ".$totalPaidAmt.", Total Refunded Amount - ".$totalRefundedAmt.".";
            }
        }
        return ['cost' => ($billingAmt > 0)? $billingAmt : 0, 'metaData' => $metaData];
    }

}
