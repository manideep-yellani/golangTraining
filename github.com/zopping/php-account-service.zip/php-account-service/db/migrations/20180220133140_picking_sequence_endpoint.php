<?php

use Phinx\Migration\AbstractMigration;

class PickingSequenceEndpoint extends AbstractMigration
{

    public function up()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'InStoreProcessing'")['id'];
        $endpointData = [
            [
                'url' => 'order-service/picking-sequence',
                'allowed_methods' => json_encode(['GET', 'POST', 'PUT']),
                'extension_id' => $extensionId
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'InStoreProcessing'")['id'];
        $this->execute("DELETE from `endpoints` where `extension_id` = $extensionId");
    }

}
