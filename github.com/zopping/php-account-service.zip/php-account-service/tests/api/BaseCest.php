<?php

/**
 * Class consists of the basic test cases which are common to all the classes.
 * The cest classes should extend from this BaseCest class to use the basic test cases.
 */

class BaseCest
{
    protected static $endpoint;
    protected static $table;

    protected function getAll(ApiTester $I)
    {
        $I->sendGET(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }

    protected function getSingle(ApiTester $I, $id)
    {
        $I->sendGET(static::$endpoint . "/$id");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['id' => $id]);
    }

    protected function create(ApiTester $I, $data = null)
    {
        $I->sendPOST(static::$endpoint, []);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $param = [];
        if (isset($data['organizationId'])) {
            //Adding organization id in request params to GET request since most APIs require it
            $param['organizationId'] = $data['organizationId'];
            unset($data['organizationId']);
        }
        $objectName = str_replace('-', '', ltrim(static::$endpoint, "/"));
        $I->seeResponseContainsJson($data);
        $id = $I->grabDataFromResponseByJsonPath("$.data.$objectName.id")[0];
        $data['id'] = $id;
        $I->sendGET(static::$endpoint . "/$id", $param);
        $I->seeResponseCodeIs(200);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($data);
    }

    protected function update(ApiTester $I, $id, $updatedData = null, $initialData = null)
    {
        $I->sendPUT(static::$endpoint . "/$id", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        if (isset($updatedData['organizationId'])) {
            unset($updatedData['organizationId']);
        }
        if (isset($initialData['organizationId'])) {
            unset($initialData['organizationId']);
        }
        $I->seeResponseContainsJson($updatedData);
        $dbUpdatedData = $this->getDatabaseDataArray($updatedData);
        $I->seeInDatabase(static::$table, $dbUpdatedData);
        $I->dontseeResponseContainsJson($initialData);
        $dbInitialData = $this->getDatabaseDataArray($initialData);
        $I->dontSeeInDatabase(static::$table, $dbInitialData);
    }

    /**
     * This function converts the data that is passed to or returned from the API (in camel case),
     *  to the data format that can be used to check in the database (in snake case).
     * @param array $data : The array with the keys in camel case, which is the data passed to the API.
     */
    protected function getDatabaseDataArray($data)
    {
        $databaseKeys = array_map(function ($key) {
            return snake_case($key);
        }, array_keys($data));
        return array_combine($databaseKeys, $data);
    }
}
