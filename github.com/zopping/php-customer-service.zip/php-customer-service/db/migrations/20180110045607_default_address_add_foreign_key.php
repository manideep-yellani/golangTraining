<?php

use Phinx\Migration\AbstractMigration;

class DefaultAddressAddForeignKey extends AbstractMigration
{

    public function change()
    {
        $this->table('customers')
            ->addForeignKey("default_address_id", "addresses", "id",
                array('constraint' => 'fk_customers_addresses', 'delete' => 'NO_ACTION',
                'update' => 'NO_ACTION'))
            ->update();
    }
}