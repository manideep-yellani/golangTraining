<?php

namespace ZopNow\CustomerService\Controller;

use ZopNow\Arya\Exception\ControllerException;
use ZopNow\Arya\Exception\ModelException;
use ZopNow\Arya\Exception\ValidationException;

class Device extends Base
{
    protected static $filterableFields = ['organization_id', 'customer_id', 'uuid', 'token'];

    public function get()
    {
        if (!empty($this->data['id'])) {
            $response = $this->getDetails();
        } else {
            if (!empty($this->data['organizationId']) && !empty($this->data['uuid'])) {
                $this->model = \ZopNow\CustomerService\Model\Device::where([
                    'uuid' => $this->data['uuid'],
                    'organization_id' => $this->data['organizationId']
                ])->first();
                if (empty($this->model)) {
                    throw new ModelException("Device with uuid " . $this->data['uuid'] . " and "
                        . "organization_id " . $this->data['organizationId'] . " not found");
                }
                $this->data['id'] = $this->model->id;
                $response = $this->getDetails();
            } else {
                $this->getRequestParams(['organizationId']);
                $list = $this->getList();
                $response = $this->getListData($list);
            }
        }
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'message' => 'OK',
            'data' => $response
        ])
        );
    }

    public function post()
    {
        $params = $this->getRequestParams(['organizationId', 'token', 'uuid'], ['metadata']);
        if ((\ZopNow\CustomerService\Model\Device::where([
            'uuid' => $params['uuid'],
            'organization_id' => $params['organizationId']
        ])->exists())
        ) {
            throw new ValidationException("Device already exists");
        }
        if (!empty($params['token']) && (\ZopNow\CustomerService\Model\Device::where([
                'token' => $params['token']
            ])->exists())
        ) {
            throw new ValidationException("Token already exists");
        }
        if (!empty($this->data['customer']) || !empty($this->data['customerId'])) {
            $params['customerId'] = $this->getCustomerIdFromRequest();
        }
        if (isset($params['metadata']) && !empty($params['metadata'])) {
            if (!empty($params['metadata']['platform'])) {
                $params['os'] = $params['metadata']['platform'];
            }
        }
        $deletedModel = \ZopNow\CustomerService\Model\Device::onlyTrashed()->where([
            'uuid' => $params['uuid'],
            'organization_id' => $params['organizationId']
        ])->first();
        if (empty($deletedModel)) {
            $this->add($params);
        } else {
            $this->model = $deletedModel;
            $this->model->restore();
            $params['id'] = $this->model->id;
            $this->edit($params);
        }

        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $this->getDetails()
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function put()
    {
        if (empty($data['id'])) {
            if (!empty($this->data['organizationId']) && !empty($this->data['uuid'])) {
                $this->model = \ZopNow\CustomerService\Model\Device::where([
                    'uuid' => $this->data['uuid'],
                    'organization_id' => $this->data['organizationId'],
                ])->first();
                if(empty($this->model->id)){
                    throw new ModelException("Device with uuid " . $this->data['uuid'] . " and "
                        . "organization_id " . $this->data['organizationId'] . " not found");
                }
                $this->data['id'] = $this->model->id;
            }
        }
        if (empty($this->data['id'])) {
            throw new ValidationException("Please pass a valid ID");
        }
        $edits = $this->getRequestParams([],
            ['token', 'metadata', 'lastNotificationSendTime', 'lastNotificationClickTime']);
        $edits['id'] = $this->model->id;
        $edits = array_filter($edits);
        if (!empty($edits['token']) && (\ZopNow\CustomerService\Model\Device::where([
                'token' => $edits['token']
            ])->where('id','<>',$edits['id'])->exists())
        ) {
            throw new ValidationException("Token already exists");
        }
        if (!empty($this->data['customer']) || !empty($this->data['customerId'])) {
            $edits['customerId'] = $this->getCustomerIdFromRequest();
        }
        if (isset($edits['metadata']) && !empty($edits['metadata'])) {
            if (!empty($edits['metadata']['platform'])) {
                $edits['os'] = $edits['metadata']['platform'];
            }
        }
        $this->edit($edits);
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $this->getDetails()
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function delete()
    {
        if (empty($this->data['id'])) {
            if (!empty($this->data['organizationId']) && !empty($this->data['uuid'])) {
                $this->model = \ZopNow\CustomerService\Model\Device::where([
                    'uuid' => $this->data['uuid'],
                    'organization_id' => $this->data['organizationId']
                ])->first();
                if (empty($this->model)) {
                    throw new ModelException("Device with uuid " . $this->data['uuid'] . " and "
                        . "organization_id " . $this->data['organizationId'] . " not found");
                }
                $this->data['id'] = $this->model->id;
            }
        }
        if (empty($this->data['id'])) {
            throw new ValidationException("Please enter the id to be deleted");
        }
        $data = $this->getRequestParams(['organizationId']);
        if ($this->model->organization_id != $data['organizationId']) {
            throw new ValidationException("Please enter a valid id to be deleted");
        }
        parent::delete();
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'message' => 'Phone deleted successfully',
            'data' => null
        ])
        );
    }
}