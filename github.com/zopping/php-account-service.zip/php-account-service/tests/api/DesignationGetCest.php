<?php

class DesignationGetCest
{
    protected static $endpoint = '/designation';
    protected static $table = 'designation';

    public function getDesignationDetailsWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get designation details without passing organization id');
        $I->sendGet(self::$endpoint);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
    }

    public function getDesignationDetails(ApiTester $I)
    {
        $I->wantTo('Get designation details for a given organization id');
        $I->sendGet(self::$endpoint, ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }

}
