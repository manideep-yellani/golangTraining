<?php

use Phinx\Migration\AbstractMigration;

class PageLayouts extends AbstractMigration
{
    /**
     * Database schema for "pages" table
     * It has the following field:
     * name : stores the name of the page
     *
     * Database schema for "layouts" table
     * It consists of the following fields:
     * name : stores the name of the layout
     * configuration_rules : stores the json containing the configuration fields that can be set for the layout
     * data_rules : stores the json containing the fields expected in the data required by the layout
     *
     * Database schema for "page_layouts" table
     * This table is a mapping between the pages and layouts table with organization specific data for each page layout.
     * It consists of the following fields:
     * page_id : id of the page for which the layout details are to be stored
     * layout_id : id of the layout for which the details are to be stored
     * organization_id : id of the organization for which the details are to be stored. If this field is null, it refers to the default settings for the page.
     * configuration_values : stores the json containing the configuration values for the configuration fields of the layout
     * data_values : stores the json containing the data values for the data fields of the layout
     * sequence_number : indicates the sequence number of the layout in the specified page
     */

    public function change()
    {
        $pages = [];
        foreach (['HOME', 'BRAND', 'CATEGORY', 'PRODUCT', 'ERROR'] as $page) {
            $pages[] = ['name' => $page];
        }
        $this->table('pages')
                ->addColumn('name', 'string', ['limit' => 45, 'null' => false])
                ->addIndex(['name'], ['unique' => 'true'])
                ->insert($pages)
                ->save();
        $this->table('layouts')
                ->addColumn('name', 'string', ['limit' => 45, 'null' => false])
                ->addColumn('configuration_rules', 'json')
                ->addColumn('data_rules', 'json')
                ->addIndex(['name'], ['unique' => 'true'])
                ->save();
        $this->table('page_layouts')
                ->addColumn('page_id', 'integer', ['limit' => 11, 'null' => false])
                ->addColumn('layout_id', 'integer', ['limit' => 11, 'null' => false])
                ->addColumn('organization_id', 'integer', ['limit' => 11, 'null' => true])
                ->addColumn('configuration_values', 'json')
                ->addColumn('data_values', 'json')
                ->addColumn('sequence_number', 'integer', ['null' => false])
                ->addColumn('created_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
                ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
                ->addColumn('deleted_at', 'timestamp', ['null' => true])
                ->addForeignKey('organization_id', 'organizations', 'id', ['constraint' => 'fk_page_layouts_organizations', 'delete' => 'NO_ACTION',
                    'update' => 'NO_ACTION'])
                ->addForeignKey('layout_id', 'layouts', 'id', ['constraint' => 'fk_page_layouts_layouts', 'delete' => 'NO_ACTION',
                    'update' => 'NO_ACTION'])
                ->addForeignKey('page_id', 'pages', 'id', ['constraint' => 'fk_page_layouts_pages', 'delete' => 'NO_ACTION',
                    'update' => 'NO_ACTION'])
                ->addIndex(['organization_id', 'page_id', 'layout_id', 'sequence_number'], ['unique' => 'true'])
                ->save();
    }

}
