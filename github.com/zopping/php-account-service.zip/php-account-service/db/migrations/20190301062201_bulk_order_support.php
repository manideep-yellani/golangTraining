<?php

use Phinx\Migration\AbstractMigration;

class BulkOrderSupport extends AbstractMigration
{
    private $slug = "BulkOrderSupport";

    public function up(){
        $extData = [
            "slug" => $this->slug,
            "name" => "Bulk Order Support",
            "description" => "Allows you to set rules to treat an order as a bulk order",
            "pricing" => "FREE",
            "enable_helper_text"=> "You can set bulk order threshold at product level.|You can set min total units after which order will be considered as bulk.|You can define `n` to make slot for next `n` days to be blocked when a cart is considered to be bulk.|You can define delivery fee for bulk orders.",
            "disable_helper_text" => "You cannot set bulk order threshold at product level.|You cannot set min total units after which order will be considered as bulk.|You cannot define `n` to make slot for next `n` days to be blocked when a cart is considered to be bulk.|You cannot define delivery fee for bulk orders.",
            "icon" => "https://storage.googleapis.com/zopsmart-staging-uploads/originals/20190301/bulkorder-20190301-081112.png",
        ];
        $this->insert('extensions',$extData);
    }
    public function down()
    {
        $this->execute("delete from extensions where slug = '$this->slug'");
    }
}

