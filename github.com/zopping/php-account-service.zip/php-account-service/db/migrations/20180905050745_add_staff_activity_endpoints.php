<?php

use Phinx\Migration\AbstractMigration;

class AddStaffActivityEndpoints extends AbstractMigration
{
    public function up() {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'LogisticsSupport'")['id'];
        $endpoints = [
            [
                'url' => 'logistics-service/re-activity',
                'allowed_methods' => json_encode(['GET']),
                'extension_id' => $extensionId,
            ],
            [
                'url' => 'order-service/picker-activity',
                'allowed_methods' => json_encode(['GET'])
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('logistics-service/re-activity', 'order-service/picker-activity')"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('logistics-service/re-activity', 'order-service/picker-activity')");
    }
}
