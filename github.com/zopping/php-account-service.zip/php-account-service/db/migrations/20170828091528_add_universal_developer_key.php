<?php

use Phinx\Migration\AbstractMigration;

class AddUniversalDeveloperKey extends AbstractMigration
{

    public function change()
    {
        $data = [
            [
                'name' => 'Universal Key',
                'token' => '59042d47-4b2a-4f87-8d78-6f8cae4ce199'
            ]
        ];
        $this->insert('developers',$data);
        $row = $this->fetchRow("SELECT `id` FROM organizations where slug='carrefour'");
        $this->query("delete from developers where organization_id = " . $row['id']);
    }
}
