<?php

namespace ZopNow\Hodor\Extension;


use ZopNow\Arya\Exception\ValidationException;

class AbandonedCart extends Base
{
    public function enable()
    {

      $actionsTopic = getenv("ACTIONS_TOPIC");
      if ($actionsTopic != '') {
          $event = new \ZopNow\Hodor\Utility\Event($actionsTopic, [
              "actions" => [
                  ["status" => "COMPLETED", "id" => "ABANDONED_CART_EXTENSION"]
              ],
              "organizationId" => strval($this->organization->id)
          ]);
          $event->publish();
      }

        return true;
    }

    public function disable()
    {
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule){
        return ['cost' => 0, 'metaData' =>  null];
    }

}