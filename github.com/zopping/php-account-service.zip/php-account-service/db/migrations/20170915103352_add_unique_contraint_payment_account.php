<?php

use Phinx\Migration\AbstractMigration;

class AddUniqueContraintPaymentAccount extends AbstractMigration
{

    public function change()
    {
        $paymentAccounts = $this->table("payment_accounts");
        $paymentAccounts->addIndex(['organization_id'],['unique' => true])
                        ->save();
    }

}
