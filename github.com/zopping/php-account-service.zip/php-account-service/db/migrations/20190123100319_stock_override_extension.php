<?php

use Phinx\Migration\AbstractMigration;

class StockOverrideExtension extends AbstractMigration
{
    private $slug = "StockOverride";

    public function up()
    {
        $extData = [
          "slug" => $this->slug,
          "name" => "Stock Overrides",
          "description" => "Allows you to limit maximum purchasable quantity per order and set buffer stock to prevent from overbooking.",
          "enable_helper_text" => "This can be configured at account, store, category and product levels",
          "disable_helper_text" => "You will no longer be able to limit maximum purchasable quantity per order and set buffer stock to prevent from overbooking.",
          "pricing" => "FREE",
          "icon" => "https://storage.googleapis.com/zopsmart-uploads/originals/20190123/stock-override-20190123-102942.png",
        ];
        $this->insert('extensions',$extData);
    }

    public function down()
    {
        $this->execute("delete from extensions where slug = '$this->slug'");
    }    
}
