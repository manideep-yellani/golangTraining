<?php

use Phinx\Migration\AbstractMigration;

class UserPhoneModify extends AbstractMigration
{
    /**
     * Increase the number of digits available to store a phone number
     */
    public function change()
    {
        $this->table('phones')
            ->changeColumn('phone', 'biginteger', array('limit' => 20,'signed' => false))
            ->save();
    }
}