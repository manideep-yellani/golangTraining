<?php

namespace ZopNow\Hodor\Model;

class OrganizationPage extends \ZopNow\Arya\Model\Base
{
    protected $table = 'organization_page';
    protected $hidden = ['created_at', 'updated_at', 'deleted_at', "pivot", 'page_id', 'organization_id'];

    public static function getFromOrganizationIdPageId($organizationId, $pageId, $url = null, $id = null)
    {
        $organizationPage = OrganizationPage::where(
            [['organization_id', $organizationId], ['page_id', $pageId]]);
        if (!empty($url)) {
            $organizationPage = $organizationPage->where('url', $url);
        }
        if (!empty($id)) {
            $organizationPage = $organizationPage->where('id', $id);
        }
        $organizationPage->whereNull('deleted_at');
        return $organizationPage->get();
    }

    public function getLayoutsAttribute($value)
    {
        return json_decode($value, true);
    }

    public function setLayoutsAttribute($value)
    {
        $this->attributes['layouts'] = json_encode($value);
    }

    public static function getStaticPageList($organizationId, $pageId, $filters = null)
    {
        $list = \ZopNow\Hodor\Model\OrganizationPage::where([['organization_id', $organizationId], ['page_id', $pageId]])->whereNull('deleted_at')
            ->orderBy('id','desc');
        if (!empty($filters)) {
            $list = $list->where($filters);
        }
        return $list->paginate();
    }
}
