<?php

namespace ZopNow\Hodor\Controller;

class OnlinePayment extends \ZopNow\Arya\Controller\Base
{

    public function get()
    {
        $fields = $this->getRequestParams(['organizationId']);
        $paymentAccount = (new \ZopNow\Hodor\Model\PaymentAccount())->getPaymentAccount($fields['organizationId']);
        $details = [];
        if (!empty($paymentAccount)) {
            $details[] = $paymentAccount->toArray();
            $details[0]['accessKey'] = $paymentAccount->access_key;
            $details[0]['secretKey'] = $paymentAccount->secret_key;
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => ['onlinepayment' => $details],
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

}
