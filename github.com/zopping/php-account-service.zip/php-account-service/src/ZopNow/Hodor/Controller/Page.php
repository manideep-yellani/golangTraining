<?php

namespace ZopNow\Hodor\Controller;

class Page extends \ZopNow\Arya\Controller\ModelController
{
    const ALLOWED_STATUS = ['ENABLED', 'DISABLED'];
    protected static $filterableFields = ['name'];
    protected $allowNonPaginated = true;
    private $isStatic = false;
    const NON_DELETABLE_LAYOUTS = [
        "BRAND" => ["ProductCollection"],
        "CATEGORY" => ["ProductCollection"],
        "PRODUCT" => ["ProductDetail"],
        "TAG" => ["ProductCollection"]
    ];

    public function __construct(array $data = [])
    {
        //Name of the page should be accepted as the id.
        if (!empty($data['id'])) {
            $name = $data['id'];
            if ('CONSTANT' == strtoupper($name)) {
                $this->isStatic = true;
            }
            $modelObject = \ZopNow\Hodor\Model\Page::where([['name', $name]])->first();
            if (empty($modelObject)) {
                throw new \ZopNow\Arya\Exception\ModelException("Page with name $name not found");
            }
            $data['id'] = $modelObject['id'];
        }
        parent::__construct($data);
    }

    public function get()
    {
        if (!empty($this->data['id'])) {
            $this->getRequestParams(['organizationId']);
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function getDetails()
    {
        $details = parent::getDetails();
        $details['page']['layouts'] = [];
        if (empty($this->data['organizationId'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Missing Required Field - page : organization Id");
        }
        $url = $this->data['url'] ?? null;
        $layoutModel = $this->model->layouts()
            ->where([['organization_id', $this->data['organizationId']],['url', $url]]);
        $status = $this->status;
        if ($status) {
            $layoutModel = $layoutModel->where(['status' => $status]);
        }
        $layouts = $layoutModel->first();
        if (empty($layouts) && !empty($url)) {
            //If data for passed url does not exist, fetch layout data where url is null
            $layoutModel = $this->model->layouts()
                ->where([['organization_id', $this->data['organizationId']],['url', null]]);
            if ($status) {
                $layoutModel = $layoutModel->where(['status' => $status]);
            }
            $layouts = $layoutModel->first();
        }
        if (empty($layouts)) {
            $layouts = $this->model->layouts()->where(['organization_id' => null])->first();
        }
        $layoutData = [];
        if (!empty($layouts)) {
            $layoutData = $layouts->layouts;
        }
        $details['page']['layouts'] = $layoutData;
        return $details;
    }

    public function put()
    {
        $mandatoryFields = ['id', 'organizationId'];
        $data = $this->getRequestParams($mandatoryFields, ['layouts', 'url', 'title', 'status', 'organizationPageId']);
        new Organization(["id" => $data['organizationId']]);
        $mandatoryLayouts = self::NON_DELETABLE_LAYOUTS[$this->model->name] ?? [];
        if (isset($data['layouts']) && !empty($mandatoryLayouts)) {
            $layouts = array_column($data['layouts'], "name");
            $missingLayouts = array_diff($mandatoryLayouts, $layouts);
            if (!empty($missingLayouts)) {
                throw new \ZopNow\Arya\Exception\ValidationException("Missing required layouts - ". implode(', ', $missingLayouts));
            }
        }
        if ($this->isStatic && empty($data['organizationPageId']) && empty($data['url'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Missing Required Field - page : url");
        }
        $url = $this->url;
        if (!empty($data['organizationPageId'])) {
            $organizationPage = \ZopNow\Hodor\Model\OrganizationPage::whereNull('deleted_at')->find(
                $data['organizationPageId']
            );
            if (empty($organizationPage)) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Page with id " . $data['organizationPageId'] . " not found"
                );
            }
        } else {
            $organizationPages = \ZopNow\Hodor\Model\OrganizationPage::getFromOrganizationIdPageId(
                $data['organizationId'], $data['id'], $url
            );
            if (count($organizationPages) == 0) {
                $organizationPage = new \ZopNow\Hodor\Model\OrganizationPage();
                $organizationPage->organization_id = $data['organizationId'];
            } else {
                $organizationPage = $organizationPages[0];
            }
        }
        if (isset($data['layouts'])) {
            $organizationPage->layouts = $data['layouts'];
        }
        $organizationPage->url = $url ?? $organizationPage->url;
        $organizationPage->title = $data['title'] ?? $organizationPage->title;
        if (!empty($data['status'])) {
            if (!in_array($data['status'], self::ALLOWED_STATUS)) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Invalid value for status"
                );
            }
            $organizationPage->status = $data['status'];
        }
        $this->model->layouts()->save($organizationPage);
        $this->model = $this->modelClass::findOrFail($this->data['id']);

        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $this->getDetails(),
        ];
        return new \ZopNow\Arya\View\Base($response);
    }
}
