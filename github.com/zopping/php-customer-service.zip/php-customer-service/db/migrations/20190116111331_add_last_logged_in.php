<?php


use Phinx\Migration\AbstractMigration;

class AddLastLoggedIn extends AbstractMigration
{
     public function change()
    {
        $this->table("customers")
            ->addColumn("last_login_time", "timestamp", ["after" => "joined_on", "null" => true])
            ->update();
    }
}
