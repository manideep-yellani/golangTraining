<?php

use Phinx\Migration\AbstractMigration;

class CreateCashierRolePermissions extends AbstractMigration
{
    public function change()
    {
        $this->execute("insert into roles(name)values('CASHIER')");
        $endpoints = [
            "order-service/slot" => ['GET'],
            "account-service/config/communication" => ['GET'],
            "order-service/order"  => ['GET','PUT'],
            "account-service/extension"  => ['GET'],
            "config-service/config/customers"  => ['GET'],
            "account-service/config"  => ['GET'],
            "config-service/meta-data"  => ['GET'],
            "order-service/order-log"  => ['GET'],
            "catalogue-service/product" => ['GET'],
            "inventory-service/item"  => ['GET'],
            "logistics-service/trip"  => ['GET'],
            "account-service/config"  => ['GET'],
            "logistics-service/tripLocations"  => ['GET'],
            "logistics-service/trip-eta"  => ['GET'],
            "order-service/slot"  => ['GET'],
            "logistics-service/trip" => ['GET','PUT'],
            "account-service/config" => ['GET'],
            "logistics-service/tripLocations" => ['GET'],
            "logistics-service/trip-eta" => ['GET'],
            "order-service/slot" => ['GET']
        ];
        $roleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in ('" . implode("','",
                array_keys($endpoints)) . "')");
        $roleId = $this->fetchRow("select id from roles where `name` = 'CASHIER'")['id'];
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach ($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'],
                    'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }
}
