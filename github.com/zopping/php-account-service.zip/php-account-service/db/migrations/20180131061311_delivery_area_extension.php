<?php

use Phinx\Migration\AbstractMigration;

class DeliveryAreaExtension extends AbstractMigration
{

    public function up()
    {
        $enableHelperText = "Provides an interface to manage Delivery Areas | ".
            "Customers that are mapped to the configured delivery areas will only be served |"
          . " Allows users to define different delivery fee for different delivery areas that are configured";
        $disableHelperText = "Delivery Areas interface will be disabled | ".
            "It will be assumed that all customer locations will be served |"
          . " User will not be able to define different custom delivery fee for different locations";
        $data = [
            "name" => "Delivery Area Support",
            "slug" => "DeliveryAreaSupport",
            "description" => "Allows you to manage the areas that are serviceable"
            . " by your organization",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE for 2 delivery areas and ₹ 100 per month for every delivery area after that"
            . " for every area after that",
            "pricing_rule" => json_encode(['FREE' => 2, 'TYPE' => 'MONTHLY', 'RATE' => 'FIXED', 'COST' => 100])
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow(
            "SELECT `id` from `extensions` where `slug` = 'DeliveryAreaSupport'"
        )['id'];
        $urls = [
            "'logistics-service/serviceable-area'",
            "'logistics-service/delivery-area'"
        ];
        $this->query(
            "UPDATE endpoints SET `extension_id`='" . $extensionId . "' WHERE `url` in ("
            . implode(',', $urls) . ")"
        );
        $oldUrls = ["'logistics-service/pincode'",
            "'logistics-service/polygonal-zone'",
            "'logistics-service/radial-zone'"];
        $this->query(
            "DELETE from endpoints WHERE `url` in (". implode(',', $oldUrls) . ")"
        );
    }

    public function down()
    {
        $urls = [
            "'logistics-service/serviceable-area'",
            "'logistics-service/delivery-area'"
        ];
        $this->execute(
            "UPDATE endpoints SET `extension_id`=NULL WHERE `url` in (". implode(',', $urls) . ")"
        );
        $this->execute('DELETE from `extensions` where `slug` = "DeliveryAreaSupport"');
    }

}
