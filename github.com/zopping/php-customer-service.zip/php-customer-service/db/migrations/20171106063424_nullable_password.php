<?php


use Phinx\Migration\AbstractMigration;

class NullablePassword extends AbstractMigration
{
    /**
     * Making password column nullable to store offline customers' data
     * without registration
     *
     */
    public function up()
    {
        $customers = $this->table('customers');
        $customers->changeColumn('password', 'string', array('limit' => 45, 'null' => true))
            ->save();
    }

    public function down()
    {
        $customers = $this->table('customers');
        $customers->changeColumn('password', 'string', array('limit' => 45))
            ->save();
    }
}
