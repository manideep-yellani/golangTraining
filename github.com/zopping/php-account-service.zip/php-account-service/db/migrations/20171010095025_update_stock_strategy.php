<?php

use Phinx\Migration\AbstractMigration;

class UpdateStockStrategy extends AbstractMigration
{
    /**
     * For all existing organizations, whose settings have been configured,
     *  the stockStrategy must be stored as BooleanStrategy if it is not set.
     */
    public function change()
    {
        $organizationIds = array_column(
                $this->fetchAll("select distinct organization_id from configurations"), 'organization_id' 
        );
        foreach ($organizationIds as $organizationId) {
            $this->execute(
                "insert into configurations(organization_id , `key`, value )"
                . " select * from (select $organizationId, 'inventory.stockStrategy', 'BooleanStrategy') AS tmp"
                . " where NOT EXISTS (select organization_id from configurations c"
                . " where c.organization_id = $organizationId and c.`key` = 'inventory.stockStrategy');");
            
        }

    }
}
