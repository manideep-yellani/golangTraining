<?php

use Phinx\Migration\AbstractMigration;

class AddMultiLanguageExtension extends AbstractMigration
{
    
    private $slug = "MultiLingualSupport";
    public function up()
    {
        $enableHelperText = "Allows to manage multiple language for your store";
         $disableHelperText = "Disables management of  MultiLingualSupport| "
            . "only supports english language";
        $data = [
            "name" => "Multi Lingual Support",
            "slug" => $this->slug,
            "description" => "Allows you to support multiple language for your organization",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "icon" => "https://storage.googleapis.com/zopsmart-uploads/originals/20190329/multilingual-20190329-095105.png",
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
    }
    
    public function down()
    {
        $this->execute("DELETE extension_organization.* from `extension_organization` inner join extensions on extensions.id = extension_id and `slug` ='$this->slug'");
        $this->execute("DELETE from `extensions` where `slug` ='$this->slug'");
    }
}
