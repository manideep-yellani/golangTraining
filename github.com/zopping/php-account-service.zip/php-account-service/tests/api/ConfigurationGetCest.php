<?php

/*
 * Class consists of the test cases for the get API in organization
 * which the API should handle
 */

class ConfigurationGetCest extends BaseCest
{
    protected static $endpoint = '/configuration';
    protected static $table = 'configurations';

    public function listConfigurations(ApiTester $I)
    {
        $I->wantTo('Get list of configurations');
        parent::getAll($I);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "configuration" => "array"
            )
        ));
    }

    public function listConfigurationsInvalidPage(ApiTester $I)
    {
        //Get the list of configurations for page number out of range
        $I->wantTo('Get list of configurations for page number out of range');
        $I->sendGET(self::$endpoint . "?page=50000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        //Check if the response contains the expected response format
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "configuration" => "array"
            )
        ));
        $I->seeResponseContainsJson(array('data' => ['configuration' => []]));
    }

    public function listConfigurationsWithOrganizationId(ApiTester $I)
    {
        //Sending an organization id as a filter and checking if the required data is returned
        $I->wantTo('Get list of configurations with organization id filter');
        $I->sendGET(self::$endpoint . "?organizationId=3");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "configuration" => "array"
            )
        ));
    }

    public function listConfigurationsValidKey(ApiTester $I)
    {
        //Sending an valid key as a filter and checking if the required data is returned
        $I->wantTo('Get list of configurations with valid key filter');
        $I->sendGET(self::$endpoint . "?key=basic.organizationName");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "configuration" => "array"
            )
        ));
        $I->seeResponseContainsJson(['data' => ['configuration' => array("key" => "basic.organizationName", "value" => "Zopnow")]]);
    }

    public function listConfigurationsInvalidKey(ApiTester $I)
    {
        //Sending an invalid key to check if the API returns an error response
        $I->wantTo('Get list of configurations with invalid key filter');
        $I->sendGET(self::$endpoint . "?key=abc");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "configuration" => "array"
            )
        ));
        $I->seeResponseContainsJson(array('data' => ['configuration' => []]));
    }

    public function getConfiguration(ApiTester $I)
    {
        $I->wantTo('Get details of a configuration with a valid id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['key' => 'basic.supportEmail', 'organization_id' => 2]);
        parent::getSingle($I, $id);
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "configuration" => "array"
            )
        ));
        $I->seeResponseContainsJson(array("id" => $id, "key" => 'basic.supportEmail', 'organizationId' => 2));
    }

    public function getConfigurationInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of a configuration with invalid id');
        $I->sendGET(self::$endpoint . "/1000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Configuration with id: 1000 not found'));
    }

    public function getConfigurationKeyId(ApiTester $I)
    {
        //Sending a key with a valid id. The key filter will not be applied
        $I->wantTo('Get details of a configuration with a valid id and a key');
        $id = $I->grabFromDatabase(self::$table, 'id', ['key' => 'catalogue.categoryProperties', 'organization_id' => 3]);
        $I->sendGET(self::$endpoint . "/$id?key=order.orderProperties");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('id' => $id, 'key' => 'catalogue.categoryProperties'));
        $I->dontSeeResponseContainsJson(array('key' => 'order.orderProperties'));
    }

    public function getConfigurationKeyInvalidId(ApiTester $I)
    {
        //Sending a key with a invalid id. The key filter will not be applied
        $I->wantTo('Get details of a configuration with a invalid id and a key');
        $I->sendGET(self::$endpoint . "/configId?key=order.orderProperties");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Configuration with id: configId not found'));
        $I->dontSeeResponseContainsJson(array('key' => 'order.orderProperties'));
    }
}