<?php

use Phinx\Migration\AbstractMigration;

class SlotsExtension extends AbstractMigration
{

    private $slug = "DeliverySlots";

    public function up()
    {
        $enableHelperText = "Allows to manage delivery slots for the store | "
            . "Provides support for placing and receiving delivery type orders for a configured slot ";
        $disableHelperText = "Disables management of slots | "
            . "Disables support for slot based delivery type orders";
        $data = [
            "name" => "Delivery Slots",
            "slug" => $this->slug,
            "description" => "Allows you to support delivery slots for orders in your organization",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "icon" => "https://s3.ap-south-1.amazonaws.com/zopnow-uploads/Delivery%20slot-20180706-065455.png",
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $endpointData = [
            [
                "url" => "order-service/slot",
                "extension_id" => $extensionId,
                "allowed_methods" => json_encode(['GET', 'POST', 'DELETE'])
            ],
            [
                "url" => "order-service/store-slot-rule",
                "extension_id" => $extensionId,
                "allowed_methods" => json_encode(['GET', 'POST', 'PUT', 'DELETE'])
            ],
            [
                "url" => "order-service/delivery-area-slot-rule",
                "extension_id" => $extensionId,
                "allowed_methods" => json_encode(['GET', 'POST', 'PUT', 'DELETE'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'order-service/slot'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `name` = 'Universal Key' and organization_id is null")['id'];
        $this->insert('endpoint_developer_permissions', array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1
        ));
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `extension_id` = '$extensionId'"),
            'id'
        );
        $this->execute("DELETE from `endpoint_developer_permissions` where endpoint_id in"
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoints` where `extension_id` = '$extensionId'");
        $this->execute("DELETE from `extension_organization` where `extension_id` = '$extensionId'");
        $this->execute("DELETE from `extensions` where `id` = $extensionId");
    }

}
