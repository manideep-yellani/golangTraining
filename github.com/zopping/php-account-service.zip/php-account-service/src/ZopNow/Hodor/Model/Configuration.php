<?php

namespace ZopNow\Hodor\Model;

class Configuration extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;
    /**
     * Get the organization for the configuration.
     */
    public function organization()
    {
        return $this->belongsTo('ZopNow\Hodor\Model\Organization');
    }

    protected function setValueAttribute($value)
    {
        if (is_bool($value) || is_array($value)) {
            $value = json_encode($value);
        }
        $this->attributes['value'] = $value;
    }

    protected function getValueAttribute($value)
    {
        $val = json_decode($value, true);
        if (json_last_error() == JSON_ERROR_NONE) {
            return $val;
        }
        return $value;
    }

    public function isExists($organizationId, $key)
    {
        $configuration = Configuration::where([['organization_id', $organizationId], ['key', $key], ['store_id', null]])->first();
        if (!is_null($configuration)) {
            if (!is_null($this->id) && $configuration->id == $this->id) {
                return false;
            }
            return true;
        }
        return false;
    }
}
