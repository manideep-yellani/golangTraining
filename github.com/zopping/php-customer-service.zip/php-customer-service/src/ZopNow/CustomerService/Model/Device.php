<?php

namespace ZopNow\CustomerService\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class Device extends \ZopNow\Arya\Model\Base
{

    use SoftDeletes;
    protected $with = ['customer'];
    protected $casts = [
        'metadata' => 'array',
    ];

    public function customer()
    {
        return $this->belongsTo('ZopNow\CustomerService\Model\Customer');
    }

}