<?php

namespace ZopNow\Hodor\Model;

class Endpoint extends \ZopNow\Arya\Model\Base
{
    protected $casts = [
        'allowed_methods' => 'array'
    ];

    public function extension(){
        return $this->belongsTo("\ZopNow\Hodor\Model\Extension");
    }
}
