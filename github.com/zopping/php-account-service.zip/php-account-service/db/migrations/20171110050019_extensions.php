<?php

use Phinx\Migration\AbstractMigration;

class Extensions extends AbstractMigration
{
    /**
     *
     * Table for extension and their mapping to endpoints
     *
     */
    public function up()
    {
        $extensionTable = $this->table('extensions');
        $extensionTable
            ->addColumn('name', 'string', array('limit' => 45, 'null' => false))
            ->addColumn('slug', 'string', array('limit' => 45))
            ->addColumn('description', 'text', array('null' => true))
            ->addColumn('created_at', 'timestamp', array('null' => false, 'default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addIndex(['slug'], ['unique' => true, "name" => "slug_idx"])
            ->create();
        $extensionOrganization = $this->table('extension_organization');
        $extensionOrganization
            ->addColumn('extension_id','integer')
            ->addColumn('organization_id', 'integer')
            ->addColumn('created_at', 'timestamp', array('null' => false, 'default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addForeignKey('extension_id', 'extensions', 'id', array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
            ->addForeignKey('organization_id', 'organizations', 'id', array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
            ->addIndex(['extension_id','organization_id'], ['unique' => true, "name" => "extension_organization_uq"])
            ->create();
        $endpointExtension = $this->table('endpoints');
        $endpointExtension
            ->addColumn('extension_id', 'integer', array('null' => true, 'default' => null))
            ->addForeignKey('extension_id', 'extensions', 'id', array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
            ->update();

    }

    public function down()
    {
        $endpointExtension = $this->table('endpoints');
        $endpointExtension
            ->dropForeignKey('extension_id')
            ->removeColumn('extension_id')
            ->update();
        $this->dropTable('extension_organization');
        $this->dropTable('extensions');
    }
}
