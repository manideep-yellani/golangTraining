<?php

use Phinx\Migration\AbstractMigration;

class UpdateMonthlyServiceCosts extends AbstractMigration
{

    public function up()
    {
        $this->execute('DELETE from `services` where `slug` = "defaulyMonthlyRental"');
        // Update monthly rental for clients maravanthe, faizan furniture and woodart to zero
        $this->table("organization_services")
            ->insert([
                [
                    "organization_id" => 22,
                    "service_id" => 2,
                    "pricing_rule" => json_encode([
                        "COST" => 0,
                        "RATE" => "FIXED",
                        "TYPE" => "MONTHLY"
                    ])
                ],
                [
                    "organization_id" => 43,
                    "service_id" => 2,
                    "pricing_rule" => json_encode([
                        "COST" => 0,
                        "RATE" => "FIXED",
                        "TYPE" => "MONTHLY"
                    ])
                ],
                [
                    "organization_id" => 62,
                    "service_id" => 2,
                    "pricing_rule" => json_encode([
                        "COST" => 0,
                        "RATE" => "FIXED",
                        "TYPE" => "MONTHLY"
                    ])
                ]
            ])
            ->saveData();
        $pricingRule = json_encode(['TYPE' => 'MONTHLY', 'RATE' => 'FIXED', 'COST' => 2000]);
        $this->query("UPDATE services SET `pricing_rule`='" . $pricingRule . "' WHERE `slug` = 'accountService'");
    }

    public function down() 
    {
        // Not required
    }

}
