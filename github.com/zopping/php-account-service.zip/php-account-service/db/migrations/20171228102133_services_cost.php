<?php

use Phinx\Migration\AbstractMigration;

class ServicesCost extends AbstractMigration
{

    public function up()
    {
        $this->table("services")
            ->addColumn("name", 'string', array('limit' => 100))
            ->addColumn('slug', 'string', array('limit' => 100))
            ->addColumn('description', 'text', array('null' => true))
            ->addColumn("pricing_rule", "string", ['null' => true])
            ->addColumn('created_at', 'timestamp', array('null' => false, 'default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addIndex(['slug'], ['unique' => true, "name" => "services_slug_idx"])
            ->create();

        $this->table("services")
            ->insert([
                [
                    "name" => "Order Service",
                    "slug" => "orderService" // variable fee [based on order amount]
                ],
                [
                    "name" => "Account Management",
                    "slug" => "accountService" // Monthly rental charges required to manage account
                ]
            ])
            ->saveData();

        $this->table("organization_services")
            ->addColumn("service_id", "integer")
            ->addColumn("organization_id", "integer")
            ->addColumn("pricing_rule", "string", ['null' => true])
            ->addColumn('created_at', 'timestamp', array('null' => false, 'default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addForeignKey("service_id", "services", "id", array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
            ->addForeignKey("organization_id", "organizations", "id", array('delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'))
            ->addIndex(['organization_id', 'service_id'], ['unique' => true, "name" => "organization_service"])
            ->create();

        /*
         * Service cost for current organizations
         * i) Marvanthe  orgId = 22, 6% per order
         * ii) Faizan furnitute orgId = 43, 1.75% per order
         * iii) Furniture town orgId = 50, 1.75%per order
         */
        $this->table("organization_services")
            ->insert([
                [
                    "organization_id" => 22,
                    "service_id" => 1,
                    "pricing_rule" => json_encode([
                        "COST" => 6,
                        "RATE" => "PERCENT", // "FIXED"
                        "TYPE" => "DAILY",
                        "RULE" => "PER ORDER" // "INDIVIDUAL" OR "CUMULATIVE"
                    ])
                ],
                [
                    "organization_id" => 43,
                    "service_id" => 1,
                    "pricing_rule" => json_encode([
                        "COST" => 1.75,
                        "RATE" => "PERCENT",
                        "TYPE" => "DAILY",
                        "RULE" => "PER ORDER"
                    ])
                ],
                [
                    "organization_id" => 50,
                    "service_id" => 1,
                    "pricing_rule" => json_encode([
                        "COST" => 1.75,
                        "RATE" => "PERCENT",
                        "TYPE" => "DAILY",
                        "RULE" => "PER ORDER",
                    ])
                ],
                [
                    "organization_id" => 57,
                    "service_id" => 2,
                    "pricing_rule" => json_encode([
                        "COST" => 1500,
                        "RATE" => "FIXED",
                        "TYPE" => "MONTHLY"
                    ])
                ]
            ])
            ->saveData();
    }

    public function down()
    {
        $this->dropTable("organization_services");
        $this->dropTable("services");
    }

}
