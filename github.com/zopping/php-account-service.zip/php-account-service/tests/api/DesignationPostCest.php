<?php

class DesignationPostCest
{
    protected static $endpoint = '/designation';
    
    public function createDesignationWithoutName(ApiTester $I)
    {
        $I->wantTo("Create designation with FLEXI timing type details");
        $data = [
            'organizationId' => 1,
            'timingType' => 'FLEXI'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
        ));
    }

    public function createFlexiTimingDesignation(ApiTester $I)
    {
        $I->wantTo("Create designation with FLEXI timing type details");
        $data = [
            'organizationId' => 1,
            'name' => 'Tech Lead',
            'timingType' => 'FLEXI'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(['status' => 'SUCCESS']);
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' => 'array'
           )
        );
    }

    public function createFixedTimingDesignation(ApiTester $I)
    {
        $I->wantTo("Create designation with FIXED timing type details");
        $managerId = $I->grabFromDatabase('designations', 'id', ['name' => 'Tech Lead', 'organization_id' => 1]);
        $data = [
            'organizationId' => 1,
            'name' => 'Tech Support',
            'timingType' => 'FIXED',
            'managerId' => $managerId
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'code' => 'integer',
            'data' => 'array'
           )
        );
    }

    public function createDesignationWithInvalidManager(ApiTester $I)
    {
        $I->wantTo("Create designation with invalid manager");
                $data = [
            'organizationId' => 1,
            'name' => 'Tech -A',
            'timingType' => 'FIXED',
            'managerId' => '1000'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
        ));
    }

}
