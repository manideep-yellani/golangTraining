<?php


use Phinx\Migration\AbstractMigration;

class CustomerWishlist extends AbstractMigration
{
    public function up()
    {
        $this->execute("CREATE TABLE IF NOT EXISTS  `customers_wish_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `customers_wish_lists_customers_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
)ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        $this->execute("CREATE TABLE IF NOT EXISTS `wishlist_product_mapping`(
  `wishlist_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  KEY `wishlist_id` (`wishlist_id`),
  CONSTRAINT `wishlist_product_mapping_customers_wish_lists_id` FOREIGN KEY (`wishlist_id`) REFERENCES `customers_wish_lists` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
)ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    }
    public function down()
    {
       $this->execute("drop table wishlist_product_mapping");
       $this->execute("drop table customers_wish_lists");
    }
}
