<?php

namespace ZopNow\CustomerService\Controller;

class Email extends Base
{

    public function post()
    {
        $mandatoryFields = array("organizationId","email");
        $data = $this->getRequestParams($mandatoryFields, []);
        //Validating and fetching customerId
        $customerId = $this->getCustomerIdFromRequest();
        $organizationId = $data['organizationId'];
        if ( !\ZopNow\Arya\Utility\Validator::isEmail($data['email'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Email");
        }
        //validating if email exists in this organization
        $customer = Customer::getFromEmail($data['email'], $organizationId);
        $currentCustomer = \ZopNow\CustomerService\Model\Customer::where(["id" => $customerId])->first();
        if (!empty($customer)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Email already exists");
        }
        $deletedEmail = \ZopNow\CustomerService\Model\Email::onlyTrashed()->where([['email', "=", $data['email']],['customer_id', "=", $customerId]])->first();
        if (empty($deletedEmail)) {
            $data['customerId'] = $customerId;
            $this->add($data);
            if (empty($currentCustomer->default_email_id)) {
                $currentCustomer->default_email_id = $this->data['id'];
            }
            $currentCustomer->updated_at = date("Y-m-d H:i:s");
            $currentCustomer->save();
        } else {
            $deletedEmail->restore();
            $this->model = $this->modelClass::findOrFail($deletedEmail->id);
        }
        $customer = $this->model->customer;
        $customer->updated_at = date("Y-m-d H:i:s");
        $customer->save();
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => ["email" => $this->model->toArray()]
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function delete()
    {
        $customerId = $this->getCustomerIdFromRequest();
        if (empty($this->data['id'])) {
              throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid id");
        }
        if ($this->model->customer_id != $customerId) {
            throw new \ZopNow\Arya\Exception\ModelException("Email not found");
        }

        $defaultEmailId = $this->model->customer->default_email_id;
        if ($defaultEmailId == $this->data['id']) {
            throw new \ZopNow\Arya\Exception\ValidationException("Default email cannot be deleted");
        }

        //if count of emails is 1 then dont allow deletion
        $emailCount = $this->model->customer->emails->count();
        if ($emailCount== 1) {
            throw new \ZopNow\Arya\Exception\ValidationException("Email cannot be deleted as the customer has only 1 email");
        }
        parent::delete();
        $customer = $this->model->customer;
        $customer->updated_at = date("Y-m-d H:i:s");
        $customer->save();
        return (new \ZopNow\Arya\View\Base([
                'status' => "SUCCESS",
                'message' => 'Email deleted successfully',
                'data' => NULL
            ])
        );
    }

    public function getCustomerId()
    {
        return $this->model->customer_id;
    }

}