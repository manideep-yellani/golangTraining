<?php

use Phinx\Migration\AbstractMigration;

class DropUniqueKeyFromCustomField extends AbstractMigration
{
     public function up() {
        $this->execute("ALTER TABLE config_service.custom_fields drop index `idx_custom_fields_key`");
    }

       
    public function down() {
        $this->execute("ALTER TABLE config_service.custom_fields ADD CONSTRAINT idx_custom_fields_key UNIQUE (`organization_id`, `key`,`entity`)");
    }

}
