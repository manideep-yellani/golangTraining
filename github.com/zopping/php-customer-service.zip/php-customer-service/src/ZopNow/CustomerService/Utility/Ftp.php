<?php

namespace ZopNow\CustomerService\Utility;

class Ftp
{
    private $credentials;
    private $passiveMode = false;
    private $conn;

    public function __construct($user, $password, $host, $port = 21)
    {
        $this->credentials = compact('host', 'port', 'user', 'password');
    }

    public function setPassive(bool $val)
    {
        $this->passiveMode = $val;
    }

    private function getConnection()
    {
        if (!isset($this->conn)) {
            $this->conn = ftp_connect($this->credentials['host'], $this->credentials['port']);
            $res = ftp_login($this->conn, $this->credentials['user'], $this->credentials['password']);
            if ($res === false) {
                throw new \Exception("Unable to connect to ftp");
            }
            ftp_pasv($this->conn, $this->passiveMode);
        }
        return $this->conn;
    }

    public function put($localFile, $remoteFile, $mode = FTP_BINARY)
    {
        $this->getConnection();
        $this->mkdir(dirname($remoteFile));
        return ftp_put($this->conn, basename($remoteFile), $localFile, $mode);
    }

    public function get($localFile, $remoteFile, $mode = FTP_BINARY)
    {
        $this->getConnection();
        return ftp_get($this->conn, $localFile, $remoteFile, $mode);
    }

    private function mkdir($ftpath)
    {
        $parts = explode('/', $ftpath);
        foreach ($parts as $part) {
            if (!@ftp_chdir($this->conn, $part)) {
                ftp_mkdir($this->conn, $part);
                ftp_chdir($this->conn, $part);
            }
        }
    }
}