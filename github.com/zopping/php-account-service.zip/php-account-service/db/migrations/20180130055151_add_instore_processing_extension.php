<?php

use Phinx\Migration\AbstractMigration;

class AddInstoreProcessingExtension extends AbstractMigration
{

    public function up()
    {
        $enableHelperText = "Provides users to support picking of orders based on a logic "
                . " which the user can define |"
                . " Users can also support quality checking of items and its packing |"
                . " Users can configure different settings like how the barcode needs to be represented,"
                . " and labelling of orders and its format at different junctions of the order process flow";

        $disableHelperText = "Users will not be able to support In-store processes "
                . " like picking, checking and packing of orders |"
                . " Users can only either complete or cancel the order";
                
        $data = [
            "name" => "In Store Processing",
            "slug" => "InStoreProcessing",
            "description" => "Facilitates the organization to support in-store processes like Picking,"
            . " Checking and Packing of Items in the order",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "1% of the order processed"
        ];
        $this->insert('extensions',$data);
    }

    public function down()
    {
        $this->execute('DELETE from `extensions` where `slug` = "InStoreProcessing"');
    }

}
