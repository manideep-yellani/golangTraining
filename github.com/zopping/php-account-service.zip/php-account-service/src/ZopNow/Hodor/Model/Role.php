<?php

namespace ZopNow\Hodor\Model;

class Role extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'pivot', 'organization_id'];
    protected $appends = ["editable"];

    public function endpoints()
    {
        return $this->belongsToMany("\ZopNow\Hodor\Model\Endpoint")->withPivot('method');
    }

    public function getEditableAttribute()
    {
        return (bool) !empty($this->organization_id);
    }

    public function updatePermissions($permissionsToAdd, $permissionsToDelete)
    {
        //delete the permissions that are not required
        $deleteValues = [];
        $id = \ZopNow\Arya\DB\MySql::escape($this->id);
        foreach ($permissionsToDelete as $permission) {
            $endpointId = \ZopNow\Arya\DB\MySql::escape($permission['endpointId']);
            $method = \ZopNow\Arya\DB\MySql::escape($permission['method']);
            $deleteValues[] = "(`endpoint_id` = '$endpointId' AND `method` = '$method')";
        }
        if (sizeof($deleteValues)) {
            $deleteStr = implode(' OR ', $deleteValues);
            \ZopNow\Arya\DB\MySql::update("update `endpoint_role` set"
                . " deleted_at = NOW() where role_id = '$id' and ($deleteStr)");
        }

        //Add the required permissions
        foreach ($permissionsToAdd as $permission) {
            $endpointId = \ZopNow\Arya\DB\MySql::escape($permission['endpointId']);
            $method = \ZopNow\Arya\DB\MySql::escape($permission['method']);
            $values[] = "('$id', '$endpointId', '$method')";
        }
        if (sizeof($values)) {
            $valuesStr = implode(',', $values);
            \ZopNow\Arya\DB\MySql::insert("insert into `endpoint_role`"
                ." (`role_id`, `endpoint_id`, `method`) values $valuesStr"
                . " on duplicate key update deleted_at = null");
        }
    }

    public function users()
    {
        return $this->belongsToMany("\ZopNow\Hodor\Model\User");
    }

    public static function getIdFromName($name, $organizationId = null)
    {
        $query = "select id from roles where name = '"
            . \ZopNow\Arya\DB\MySql::escape($name) . "' and deleted_at is null ";
        if (!empty($organizationId)) {
            $query .= " and (organization_id = " . \ZopNow\Arya\DB\MySql::escape($organizationId)
                . " or organization_id is null)";
        } else {
            $query .= " and organization_id is null";
        }
        $id = \ZopNow\Arya\DB\MySql::one($query);
        return $id;
    }

    public static function getListItems(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        if ($list->paginated) {
            $data->limit($list->getPerPage())->skip($list->getOffset());
        }
        return $data->select('roles.*')->orderBy("roles." . $list->getSortField(), $list->getSortOrder())->get();
    }

    public static function getListItemsCount(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        return $data->count();
    }

    private static function getQueryBuilder(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::query();
        $filters = $list->getFilters();
        $filterKeys = array_column($filters, 0);
        $orgKey = array_search('organization_id', $filterKeys);
        if ($orgKey !== false) {
            //Fetching organization specific roles and global roles
            $organizationId = $filters[$orgKey][1];
            $data->where(function ($query)  use ($organizationId) {
                $query->whereNull('organization_id')
                      ->orWhere('organization_id', "=" , $organizationId);
            });
            unset($filters[$orgKey]);
        }
        $data = self::addFilterQuery($data, $filters);
        return $data;
    }

}
