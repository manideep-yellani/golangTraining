<?php

namespace ZopNow\Hodor\Extension;


use ZopNow\Arya\Exception\ValidationException;

class CapacityPlanning extends Base
{
    public function enable()
    {
        $organizationId = $this->organization->id;
        $slotResponse = \ZopNow\Arya\Utility\MicroService::callService("order-service", "/slot", 'GET', ['organizationId' => "$organizationId"]);
        $data = json_decode($slotResponse['body'], true);
        if(sizeof($data['data']['slot']) == 0) {
            throw new ValidationException("You need to first configure the slots before installing this extension");
        }    
    }

    public function disable()
    {
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        //toDo
    }

}