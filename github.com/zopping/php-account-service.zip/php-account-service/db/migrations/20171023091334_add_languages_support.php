<?php

use Phinx\Migration\AbstractMigration;

class AddLanguagesSupport extends AbstractMigration
{

    public function change()
    {
        $table = $this->table('languages');
        $table->addColumn('name', 'string', array('limit' => 45, 'null' => true))
                ->addColumn('iso_code', 'string')
                ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addIndex(['iso_code'], array('unique' => true));
        $table->create();
        $this->insert("languages", [
            ["name" => 'English', 'iso_code' => 'en'],
            ["name" => 'हिंदी', 'iso_code' => 'hi'],
            ["name" => 'عربى', 'iso_code' => 'ar'],
            ["name" => 'ಕನ್ನಡ', 'iso_code' => 'kn']]);
    }

}
