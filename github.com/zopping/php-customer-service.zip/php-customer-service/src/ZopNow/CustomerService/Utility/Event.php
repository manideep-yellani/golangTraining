<?php

namespace ZopNow\CustomerService\Utility;

use Google\Cloud\PubSub\PubSubClient;

class Event
{
    private static $pubSubClient;
    private static $configs;
    private static $env;
    private $name, $data;

    private static function getClient()
    {
        if (!isset(self::$pubSubClient)) {
//            putenv('PUBSUB_EMULATOR_HOST=http://localhost:8085');
            self::$pubSubClient = new PubSubClient(['projectId' => self::$configs['pubsubProjectId']]);
        }
        return self::$pubSubClient;
    }

    public static function configure(array $configs)
    {
        self::$configs = $configs;
        self::$env = getenv("ENVIRONMENT");
    }

    public function __construct(string $name, array $data)
    {
        $this->name = $name;
        $this->data = $data;
    }

    public function publish()
    {
        if (self::$configs['pretend']) {
            return;
        }
        if (self::$env === 'STAGING') {
            $this->name .= "-staging";
        }
        try {
            $pubSubClient = self::getClient();
            $pubSubClient->topic($this->name)->publish(['data' => json_encode($this->data)]);
            $this->data['name'] = $this->name;
            \ZopNow\Arya\App\Application::log("Event published", ['data' => $this->data]);
        } catch (\Exception $e) {
            \ZopNow\Arya\App\Application::log("Event publish failed", ['data' => $this->data, 'error' => $e->getMessage()]);
        }
    }
}