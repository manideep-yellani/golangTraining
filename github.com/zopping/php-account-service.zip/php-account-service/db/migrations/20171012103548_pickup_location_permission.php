<?php

use Phinx\Migration\AbstractMigration;

class PickupLocationPermission extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $url = "account-service/pickup-location";
        $developerId = $this->fetchRow("select id from developers where token='59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $this->insert("endpoints", [["url"=>$url]]);
        $endpointId = $this->fetchRow("select id from endpoints where url='$url'")['id'];
        $this->insert("endpoint_developer_permissions", [[
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1,
            "is_customer_required" => 0
        ]]);
    }
}
