<?php

class LeaveSummaryGetCest
{

    protected static $endpoint = '/leave-summary';
    protected static $table = 'user_leaves';

    public function getLeaveSummaryForLoggedInUser(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d', strtotime("-20 days")),
                'to_date' => date('Y-m-d', strtotime("-10 days")),
                'reason' => "Personal",
                'type' => 'EARNED']
        );
        $data = [
            "user"=> '{
                        "id": ' . $userId . ',
                        "name": "User"
                }',
            "organizationId" => 1,
            "from" => date('Y-m-d', strtotime("-1 month")),
            "to" => date('Y-m-d')
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "leavesummary" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $leaveId]);
    }

    public function getLeaveSummaryForTeam(ApiTester $I)
    {
        return;
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support', 'manager_id' => $managerDesigId];
        $juniorId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $juniorId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Personal",
                'type' => 'SICK',
                'status' => 'APPROVED']
        );
        $userId2 = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $juniorId]
        );
        $leaveId2 = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId2,
                'from_date' => date('Y-m-d', strtotime("-15 days")),
                'to_date' => date('Y-m-d', strtotime("-15 days")),
                'reason' => "Personal",
                'type' => 'SICK',
                'status' => 'APPROVED']
        );
        $data = [
            "user"=> '{
                        "id": ' . $managerId . ',
                        "name": "User"
                }',
            "organizationId" => 1,
            "from" => date('Y-m-d', strtotime("-1 month")),
            "to" => date('Y-m-d'),
            "forTeam" => true
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "leavesummary" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $leaveId]);
        $I->seeResponseContainsJson(['id' => $leaveId2]);
    }

    public function getLeaveSummaryForMemberInTeam(ApiTester $I)
    {
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support', 'manager_id' => $managerDesigId];
        $juniorId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $juniorId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Personal",
                'type' => 'SICK',
                'status' => 'APPROVED']
        );
        $userId2 = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $juniorId]
        );
        $leaveId2 = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId2,
                'from_date' => date('Y-m-d', strtotime("-15 days")),
                'to_date' => date('Y-m-d', strtotime("-15 days")),
                'reason' => "Personal",
                'type' => 'SICK',
                'status' => 'APPROVED']
        );
        $data = [
            "user"=> '{
                        "id": ' . $managerId . ',
                        "name": "User"
                }',
            "organizationId" => 1,
            "from" => date('Y-m-d', strtotime("-1 month")),
            "to" => date('Y-m-d'),
            "forTeam" => true,
            "userId" => $userId
        ];
        $I->sendGET(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "leavesummary" => "array"
            )
        ));
        $I->seeResponseContainsJson(['id' => $leaveId]);
        $I->dontSeeResponseContainsJson(['id' => $leaveId2]);
    }

}
