<?php

use Phinx\Migration\AbstractMigration;

class AddDesignationsSupport extends AbstractMigration
{

    public function up()
    {
        $userTimingsTable = $this->table("designations");
        $userTimingsTable
            ->addColumn("organization_id","integer")
            ->addColumn("name", "string", array('null' => false))
            ->addColumn("manager_id", "integer", array('null' => true))
            ->addColumn('timing_type', 'enum',  ['values' => array('FIXED','FLEXI'), 'null' => false, 'default' => 'FLEXI'])
            ->addColumn('created_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addColumn('deleted_at', 'timestamp', ['null' => true])
            ->addForeignKey('organization_id', 'organizations', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addForeignKey('manager_id', 'designations', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->create();

        $usersTable = $this->table("users");
        $usersTable
            ->addColumn("designation_id", "integer", ['null' => true])
            ->addForeignKey('designation_id', 'designations', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->save();
    }

    public function down()
    {
        $this->table('users')
             ->dropForeignKey(['designation_id'])
             ->removeColumn('designation_id')
             ->save();
        $this->dropTable('designations');
    }

}
