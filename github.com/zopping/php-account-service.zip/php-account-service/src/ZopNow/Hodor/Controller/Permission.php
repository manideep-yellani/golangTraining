<?php

namespace ZopNow\Hodor\Controller;

class Permission extends \ZopNow\Arya\Controller\Base
{

    const ALLOWED_METHODS = ["GET", "POST", "PUT", "DELETE"];

    public function put()
    {
        $data = $this->getRequestParams(['organizationId', 'permissions'], ['userId', 'roleId']);
        if (empty($data['userId']) && empty($data['roleId'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Either user id or role id must be passed");
        }
        if (!empty($data['userId'])) {
            $userModel = \ZopNow\Hodor\Model\User::find($data['userId']);
            if (empty($userModel) || $userModel->organization_id != $data['organizationId']) {
                throw new \ZopNow\Arya\Exception\ModelException(
                    "User with id : " . $data['userId'] . " not found"
                );
            }
        }

        if (!is_array($data['permissions']) || empty($data['permissions'])) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Permissions must be passed as an array and cannot be empty"
            );
        }
        $permissionsToAdd = $permissionsToDelete = [];
        foreach ($data['permissions'] as $permissionDetails) {
            $method = $permissionDetails['method'];
            $hasPermission = $permissionDetails['hasPermission'];
            $permission = filter_var($hasPermission, FILTER_VALIDATE_BOOLEAN);
            $endpointId = $this->validateAndGetEndpointId($permissionDetails);

            if (!empty($data['userId'])) {
                $permissionExists = $userModel->updatePermissionIfExists(
                        $endpointId, $method, $permission
                );
                if (!$permissionExists) {
                    $userModel->endpoints()
                        ->attach(
                            [$endpointId => ['method' => $method, 'has_permission' => $permission]]
                        );
                }
            } elseif (!empty ($data['roleId'])) {
                $permissionDetails['endpointId'] = $endpointId;
                if ($permission) {
                    $permissionsToAdd[] = $permissionDetails;
                } else {
                    $permissionsToDelete[] = $permissionDetails;
                }
            }
        }
        if (!empty($data['roleId'])) {
            $roleModel = \ZopNow\Hodor\Model\Role::find($data['roleId']);
                if (empty($roleModel)) {
                    throw new \ZopNow\Arya\Exception\ModelException(
                        "Role with id : " . $data['roleId'] . " not found"
                    );
                }
                $roleModel->updatePermissions($permissionsToAdd, $permissionsToDelete);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'message' => "Permission added successfully",
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    private function validateAndGetEndpointId($permissionDetails)
    {
        if (empty($permissionDetails['endpoint'])
            || empty($permissionDetails['method'])
            || !isset($permissionDetails['hasPermission'])
        ) {
            throw new \ZopNow\Arya\Exception\ValidationException(
            "Each permission must have the fields endpoint, method and hasPermission"
            );
        }
        $endpoint = $permissionDetails['endpoint'];

        //Fetch endpoint details
        $endpointResponse = (new Endpoint(['url' => $endpoint]))->get()->getData();
        if (empty($endpointResponse['data']['endpoint'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid endpoint");
        }
        $endpointDetails = $endpointResponse['data']['endpoint'][0];
        $endpointId = $endpointDetails['id'];

        //Validate method and hasPermission fields
        $this->validateFields($permissionDetails, $endpointDetails['allowedMethods']);
        return $endpointId;
    }

    private function validateFields($permissionDetails, $allowedMethods)
    {
        //Validate hasPermission to have boolean value
        $isValid = \ZopNow\Hodor\Helper\Validator::isBoolean(
            $permissionDetails['hasPermission']
        );
        if (!$isValid && !is_bool($permissionDetails['hasPermission'])) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "hasPermission should have a boolean value"
            );
        }
        $isMethodValid = \ZopNow\Hodor\Helper\Validator::isEnum(
            $permissionDetails['method'], $allowedMethods
        );
        if (!$isMethodValid) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "method should have one of the values: "
                . implode(',', $allowedMethods)
            );
        }
    }
}
