<?php

use Phinx\Seed\AbstractSeed;

class UsersChange extends AbstractSeed
{

    public function run()
    {
        $faker = Faker\Factory::create();
        $userId = array_column($this->fetchAll('select id from users order by id'), 'id');
        $phoneData = [];
        $emailData = [];
        $emails = ["", "admin@carrefour.zopnow.express", "admin@zopnow.com", "admin@ruchisbiryani.zopnow.express", "admin@silbatti.zopnowexpress.com", "admin@rashtrakutas.zopexpress.com"];
        $phones = ["", "9999999001", "9999999002", "9999999003", "9999999004", "9999999005"];
        foreach ($userId as $id) {
            $phoneData[] = [
                'user_id' => $id,
                'phone' => $phones[$id] ?? $faker->unique->numberBetween($min = 8000000000, $max = 9999999000),
                'verified' => (int) ($id < 4)
            ];
            $emailData[] = [
                'user_id' => $id,
                'email' => $emails[$id] ?? $faker->email,
                'verified' => (int) ($id < 5)
            ];
        }
        $this->table('phones')->insert($phoneData)->save();
        $this->table('emails')->insert($emailData)->save();
    }
}
