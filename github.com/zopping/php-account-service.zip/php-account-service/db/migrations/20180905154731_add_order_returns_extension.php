<?php

use Phinx\Migration\AbstractMigration;

class AddOrderReturnsExtension extends AbstractMigration
{
    public function up()
    {
        $data = [
            "name" => "Order Returns",
            "slug" => "OrderReturns",
            "description" => "Allows you to manage returns for an order.",
        ];
        $this->insert('extensions',$data);
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'OrderReturns'")['id'];
        $this->query("DELETE from extension_organization where extension_id='$extensionId'");
    }
}
