<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Exception\ValidationException;

class User extends \ZopNow\Arya\Controller\ModelController
{
    const SIGNUP_COMMUNICATION = "client/signup";
    const VERIFIED_COMMUNICATION = "client/verified";
    const FORGOT_PASSWORD_COMMUNICATION = "client/forgotPassword";
    const RESEND_EMAIL_VERIFICATION_COMMUNICATION = 'client/resendEmailVerificationLink';
    const INVITE_COMMUNICATION = "client/invitee";
    protected static $filterableFields = ['id', 'role_id', 'organization_id', 'name', 'is_owner', 'verified', 'store_id', 'designation_id', 'timing_type'];
    protected $allowNonPaginated = true;
    private static $include = [];

    public function get()
    {
        if (!empty($this->data['include']) && is_array($this->data['include'])) {
            self::$include = $this->data['include'];
        }
        if (!empty($this->data['id']) && !is_array($this->data['id'])) {
            $data = $this->getDetails();
            if ($this->data['organizationId'] != $this->model->organization->id) {
                $data = NULL;
            }
        } else {
            if (!empty($this->data['name'])) {
                $this->data['name'] = $this->data['name'] . "*";
            }
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function getFromPhone()
    {
        $data = $this->getRequestParams(['phone']);
        $user = \ZopNow\Hodor\Model\Phone::getUserFromPhone($data['phone']);
        if (!is_null($user)) {
            return $user->toArray();
        } else {
            throw new \ZopNow\Arya\Exception\ValidationException("User not found.");
        }
    }

    public function getFromEmail()
    {
        $data = $this->getRequestParams(['email']);
        $user = \ZopNow\Hodor\Model\Email::getUserFromEmail($data['email']);
        if (!is_null($user)) {
            return $user->toArray();
        } else {
            throw new \ZopNow\Arya\Exception\ValidationException("User not found.");
        }
    }

    public function resetPassword()
    {
        $data = $this->getRequestParams(['id']);
        $password = \ZopNow\Hodor\Helper\Password::generate();
        $user = \ZopNow\Hodor\Model\User::findOrFail($data['id']);
        $user->password = \ZopNow\Arya\Utility\Encryption::encrypt($password, false);
        $user->save();

        //Send SMS using communication service
        $smsData =[];
        $smsData['phone'] = $user->phones()->first()->phone;
        $smsData['type'] = self::FORGOT_PASSWORD_COMMUNICATION;
        $smsData['data'] = ["password" => "$password"];
        $smsData['transactional'] = true;
        $smsData['lang'] = $this->getLanguageForCommunication();
        \ZopNow\Arya\Utility\MicroService::callService("go-communication-service", "/sms", 'POST', $smsData);

        return new \ZopNow\Arya\View\Base(['code' => 200, 'status' => "SUCCESS", "message" => "Password reset successfully"]);
    }

    public function changePassword()
    {
        $userDetails = $this->getRequestParams(['oldPassword', 'newPassword', 'id']);
        $oldPassword = \ZopNow\Arya\Utility\Encryption::encrypt($userDetails['oldPassword'], false);

        //Raising an exception to prevent the new password to be same as the old password.
        if ($userDetails['oldPassword'] == $userDetails['newPassword']) {
            throw new \ZopNow\Arya\Exception\ValidationException("New password cannot be same as the old password");
        }
        if ($this->model->password !== $oldPassword) {
            throw new \ZopNow\Arya\Exception\ValidationException("Cannot change password, old password incorrect");
        } else {
            //validatePasswordParameters
            $errorMessage = \ZopNow\Hodor\Helper\Validator::passwordValidation($userDetails['newPassword'],$this->model->organization_id);
            if ($errorMessage != "") {
                throw new \ZopNow\Arya\Exception\ValidationException($errorMessage);
            }
            $this->model->password = \ZopNow\Arya\Utility\Encryption::encrypt($userDetails['newPassword'], false);
            $this->model->save();
        }

        return new \ZopNow\Arya\View\Base([
            "code" => 200,
            "status" => "SUCCESS",
            "message" => "Password changed successfully!",
        ]);
    }

    /*
     * Anyone who can access this function can change the password.
     */
    public function setNewPassword()
    {
        $userDetails = $this->getRequestParams(['newPassword', 'id']);
        //validatePasswordParameters
        $errorMessage = \ZopNow\Hodor\Helper\Validator::passwordValidation($userDetails['newPassword'],$this->model->organization_id);
        if ($errorMessage != "") {
            throw new \ZopNow\Arya\Exception\ValidationException($errorMessage);
        }
        $encryptedPassword = \ZopNow\Arya\Utility\Encryption::encrypt($userDetails['newPassword'], false);
        $this->model->password = $encryptedPassword;
        $this->model->save();
        return new \ZopNow\Arya\View\Base([
            "code" => 200,
            "status" => "SUCCESS",
            "message" => "Password set successfully!",
        ]);
    }

    public function post()
    {
        $mandatoryFields = array();
        $optionalFields = array("name","organizationId", "langIsoCode", "imageUrl",
            "roleIds", "storeIds", "hasToolAccess", "password", "email","sendInvite", "isInvite",
            "designationId", "shiftStart", "shiftEnd", "weeklyOff","employeeId", "userSignup", "phone", "email");
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);

        if(empty($data['name']) && !empty($data['organizationId'])){
            throw new \ZopNow\Arya\Exception\ValidationException("Missing Required Field - user : name");
        }

        if (empty($data['phone']) && empty($data['email'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("phone/email is required");
        }
        if (!empty($data['phone'])) {
            //Check if phone number is correct
            $checkPhone = \ZopNow\Hodor\Helper\Validator::validate($data['phone'], "phone");
            if ($checkPhone == false) {
                throw new \ZopNow\Arya\Exception\ValidationException("Incorrect Phone number");
            }
            $phoneExists = \ZopNow\Hodor\Model\Phone::getUserFromPhone($data['phone']);
            if (!is_null($phoneExists)) {
                throw new \ZopNow\Arya\Exception\ValidationException("This phone number is already registered");
            }
        }
        //Check if email is correct
        if(!empty($data['email'])) {
            $checkEmail = \ZopNow\Hodor\Helper\Validator::validate($data['email'], "email");
            if ($checkEmail == false) {
                throw new \ZopNow\Arya\Exception\ValidationException("Incorrect Email");
            }

            $emailExists = \ZopNow\Hodor\Model\Email::getUserFromEmail($data['email']);
            if (!is_null($emailExists)) {
                throw new \ZopNow\Arya\Exception\ValidationException("This email is already registered");
            }
        }
        $data['isOwner'] = empty($data['organizationId']) ? 1 : 0;
        $sendInvite = isset($data['sendInvite'])
            ? filter_var($data['sendInvite'], FILTER_VALIDATE_BOOLEAN) : true;

        //validatePasswordParameters
        if(!empty($data['password'])) {
            $errorMessage = \ZopNow\Hodor\Helper\Validator::passwordValidation($data['password'],$data["organizationId"]);
            if ($errorMessage != "") {
                throw new \ZopNow\Arya\Exception\ValidationException($errorMessage);
            }
        }

        //Generate a username password
        if (!$sendInvite && !empty($data['password'])) {
            $rand = $data['password'];
        } else {
            $rand = \ZopNow\Hodor\Helper\Password::generate();
        }
        $password = \ZopNow\Arya\Utility\Encryption::encrypt($rand, false);
        $data['password'] = $password;
        $communicationType = self::INVITE_COMMUNICATION;
        //Check if organization exists.
        if (empty($data['organizationId'])) {
            $regionCode = "IN";
            if (!empty($data['phone'])) {
                $phoneUtil = \libphonenumber\PhoneNumberUtil::getInstance();
                $phoneNumber = $phoneUtil->parse($data['phone']);
                $regionCode = $phoneUtil->getRegionCodeForNumber($phoneNumber);
            }
            $currencyData = (new Country(['countryIsoCode' => $regionCode]))->get()->getData();
            $currencyId = $currencyData['data']['country']['currency']['id'] ?? null;
            $organization = new Organization(['currencyId' => $currencyId]);
            $organizationDetails = $organization->post()->getData()['data']['organization'];
            $data['organizationId'] = $organizationDetails['id'];
            $communicationType = self::SIGNUP_COMMUNICATION;
        }

        //Verify that language code is valid
        if (!empty($data['langIsoCode'])) {
            $language = new Lang(['id' => $data['langIsoCode']]);
            $response = $language->get()->getData();
        }

        //Validate the image url
        if (!empty($data['imageUrl'])
            && !\ZopNow\Hodor\Helper\Validator::isUrl($data['imageUrl'])
        ) {
            throw new ValidationException("Invalid value for 'imageUrl'");
        }
        if (!$sendInvite) {
            $data['verified'] = 1;
        }

        $setShift = false;
        if (isset($data['weeklyOff']) && is_array($data['weeklyOff'])) {
            $setShift = true;
            if (!empty($data['weeklyOff'])) {
                $data['weeklyOff'] = $this->convertWeeklyOff($data['weeklyOff']);
            } else {
                $data['weeklyOff'] = null;
            }
        }
        if (!empty($data['designationId'])) {
            $designationController = new Designation(
                ['id' => $data['designationId'], 'organizationId' => $data['organizationId']]
            );
            $designationDetails = $designationController->get()->getData()['data']['designation'];
            if (!empty($designationDetails['roles'])) {
                $data['roleIds'] = array_column($designationDetails['roles'], 'id');
            }
            if ($designationDetails['timingType'] == 'FIXED'
                && (empty($data['shiftStart']) || empty($data['shiftEnd']))
            ) {
                throw new ValidationException("Shift timings are missing");
            }
            if (!empty($data['shiftStart']) && !empty($data['shiftEnd'])) {
                $setShift = true;
                if (!\ZopNow\Arya\Utility\Validator::validate($data['shiftStart'],'date', ['format' => "H:i:s"]) ||
                    !\ZopNow\Arya\Utility\Validator::validate($data['shiftEnd'],'date', ['format' => "H:i:s"])) {
                    throw new \ZopNow\Arya\Exception\ValidationException("Invalid shift timings");
                }
            }
        }
        \ZopNow\Arya\DB\MySql::startTransaction();
        $this->add($data);
        if (!empty($data['roleIds']) && is_array($data['roleIds'])) {
            $this->addRoles($data['roleIds']);
        }
        if (!empty($data['storeIds']) && is_array($data['storeIds'])) {
            $this->addStores($data['storeIds']);
        }
        if ($setShift) {
            $shiftStart = $data['shiftStart'] ?? null;
            $shiftEnd = $data['shiftEnd'] ?? null;
            $this->model->addShiftDetails($data['weeklyOff'], $shiftStart, $shiftEnd);
        }
        $permissions = [];
        /**
         * isInvite flag added to support existing scenario where users that are created
         * through invite API has permission to all endpoints
         */
        if (!$this->model->is_owner && !empty($data['isInvite']) && $data['isInvite'] == true) {
            // All permissions being added currently to user who is not an owner currently
            $endpoints = \ZopNow\Hodor\Model\Endpoint::all();
            foreach($endpoints as $endpoint) {
                $allowedMethods =  $endpoint->allowed_methods;
                foreach ($allowedMethods as $allowedMethod) {
                    $permissions[$allowedMethod][$endpoint->id] = ['has_permission' => 1, 'method' => $allowedMethod];
                }
            }
        }
        foreach ($permissions as $reqMethod => $presentEndpoints) {
            $this->model->endpoints()->attach($presentEndpoints);
        }
        if (!empty($data['phone'])) {
            //Add phone and link it to the user
            $phone = new \ZopNow\Hodor\Model\Phone();
            $phone->phone = $data['phone'];
            $this->model->phones()->save($phone);
        }

        if (!empty($data['email'])) {
            //Add email and link it to the user
            $email = new \ZopNow\Hodor\Model\Email();
            $email->email = $data['email'];
            $this->model->emails()->save($email);
        }
        \ZopNow\Arya\DB\MySql::commit();
        $this->model = $this->modelClass::findOrFail($this->model->id);
        $user = $this->getDetails();

        $language = $this->getLanguageForCommunication();
        //Sending confirmation message with password for verification.
        if($this->model->has_tool_access && $sendInvite){
            //Send verification email and password via SMS only if it should be sent
            // and the user has access to dashboard
            $smsData = [];
            $smsData['phone'] = $phone->phone;
            $smsData['type'] = $communicationType;
            $smsData['data'] = ["password" => "$rand"];
            $smsData['transactional'] = true;
            $smsData['lang'] = $language;
            \ZopNow\Arya\Utility\MicroService::callService("go-communication-service", "/sms", 'POST', $smsData);

            //Generate an email and send it.
            $hash = \ZopNow\Arya\Utility\Encryption::encrypt($email->id, true);
            $emailData = [];
            $emailData['to'] = $data['email'];
            $emailData['type'] = $communicationType;
            $adminURL = defined('ZOPSMART_ADMIN') ? ZOPSMART_ADMIN : getenv("ZOPSMART_ADMIN");
            $emailData['data'] = [
                "username" => $user['user']['name'] ?? 'Customer',
                "password" => "$rand",
                "verifyUrl" => $adminURL . "/verify?e=$hash"
            ];
            $emailData['transactional'] = true;
            $emailData['lang'] = $language;
            \ZopNow\Arya\Utility\MicroService::callService("communication-service", "/email", 'POST', $emailData);
        }
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $user
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    public function verifyEmail()
    {
        $data = $this->getRequestParams(array("hash"));
        $hashDecrypt = \ZopNow\Arya\Utility\Encryption::decrypt($data['hash']);
        try {
            $email = \ZopNow\Hodor\Model\Email::findOrFail($hashDecrypt);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Email");
        }
        if ($email->verified == 1) {
            return "Email has already been verified";
        }
        $email->verified = 1;
        $email->save();
        $user = $email->user;
        foreach ($user->phones as $phone) {
            if ($phone->verified == 1) {
                $user->verified = 1;
                $user->save();
                break;
            }
        }

        //Generate and send verified email
        $emailData = [];
        $emailData['to'] = $email->email;
        $emailData['data'] = [
            "loginUrl" => ZOPSMART_ADMIN,
            "username" => $user->name
        ];
        $emailData['type'] = self::VERIFIED_COMMUNICATION;
        $emailData['transactional'] = true;
        $emailData['lang'] = $this->getLanguageForCommunication();
        \ZopNow\Arya\Utility\MicroService::callService("communication-service", "/email", 'POST', $emailData);
        return 'Email verified!';
    }

    public function resendVerificationEmail($name, \ZopNow\Hodor\Model\Email $email, $orgID)
    {
        $hash = \ZopNow\Arya\Utility\Encryption::encrypt($email->id, true);
        $emailData['to'] = $email->email;
        $emailData['type'] = self::RESEND_EMAIL_VERIFICATION_COMMUNICATION;
        $emailData['organizationId'] = (string)$orgID;
        $emailData['data'] = [
            "username" => $name,
            "verifyUrl" => ZOPSMART_ADMIN . "/verify?e=$hash"
        ];
        $emailData['transactional'] = true;
        $emailData['lang'] = $this->getLanguageForCommunication();
        \ZopNow\Arya\Utility\MicroService::callService("go-communication-service", "/email", 'POST', $emailData);
    }

    public function put()
    {
        $optFields = ['name', 'langIsoCode', 'imageUrl', 'roleIds', 'storeIds', 'designationId',
            'email','phone',
            'shiftStart', 'shiftEnd', 'weeklyOff', 'hasToolAccess'];
        $data = $this->getRequestParams(['id'],$optFields);
        $updatePhone = false;
        $updateEmail = false;
        $isOwner = $this->model->is_owner;
        if (isset($data['phone'])) {
            if (!\ZopNow\Hodor\Helper\Validator::validate($data['phone'], "phone")) {
                throw new \ZopNow\Arya\Exception\ValidationException("Incorrect Phone number");
            }
            $user = \ZopNow\Hodor\Model\Phone::getUserFromPhone($data['phone']);
            if (!is_null($user) && $user->id != $data['id']) {
                throw new \ZopNow\Arya\Exception\ValidationException("This phone number is already registered.");
            }
            $updatePhone = true;
            foreach ($this->model->phones()->get() as $phone) {
                if ($phone->phone == $data['phone']) {
                    $updatePhone = false;
                } else if ($isOwner) {
                    throw new \ZopNow\Arya\Exception\ValidationException("Owner can't update the phone");
                }
            }
        }
        if (isset($data['email'])) {
            if (!\ZopNow\Hodor\Helper\Validator::validate($data['email'], "email")) {
                throw new \ZopNow\Arya\Exception\ValidationException("Incorrect Email");
            }
            $user = \ZopNow\Hodor\Model\Email::getUserFromEmail($data['email']);
            if (!is_null($user) && $user->id != $data['id']) {
                throw new \ZopNow\Arya\Exception\ValidationException("This email is already registered");
            }
            $updateEmail = true;
            foreach ($this->model->emails()->get() as $email) {
                if ($email->email == $data['email']) {
                    $updateEmail = false;
                } else if ($isOwner) {
                    throw new \ZopNow\Arya\Exception\ValidationException("Owner can't update the email");
                }
            }
        }
        if (!empty($data['langIsoCode']) && $this->model->lang_iso_code != $data['langIsoCode']) {
            //Validate the language iso code
            $language = new Lang(['id' => $data['langIsoCode']]);
            $language->get()->getData();
        }
        //Validate the image url
        if (!empty($data['imageUrl'])
            && !\ZopNow\Hodor\Helper\Validator::isUrl($data['imageUrl'])
        ) {
            throw new ValidationException("Invalid value for 'imageUrl'");
        }
        \ZopNow\Arya\DB\MySql::startTransaction();
        if (!empty($data['storeIds']) && is_array($data['storeIds'])) {
            $this->addStores($data['storeIds']);
        }
        $designationDetails = [];
        if (!empty($data['designationId'])) {
            $designationDetails = (new Designation(['id' => $data['designationId'], 'organizationId' => $this->model->organization_id]))->get()->getData();
        } else if (isset($data['designationId']) && empty($data['designationId'])) { // when empty string is passed, to remove designation
            $data['designationId'] = null;
        } else if (!empty($this->model->designation_id)) {
            $designationDetails =(new Designation(['id' => $this->model->designation_id, 'organizationId' => $this->model->organization_id]))->get()->getData();
        }
        if (isset($designationDetails['data']['designation']['roles'])) {
            $data['roleIds'] = array_column($designationDetails['data']['designation']['roles'], 'id');
        }
        if (!empty($data['shiftStart']) && !empty($data['shiftEnd']) && (empty($designationDetails) ||
                $designationDetails['data']['designation']['timingType'] != 'FIXED')) {
            throw new ValidationException("Shift details can be provided for designations with FIXED timing type");
        }
        $setShift = false;
        if (isset($data['weeklyOff']) && is_array($data['weeklyOff'])) {
            $setShift = true;
            if (!empty($data['weeklyOff'])) {
                $data['weeklyOff'] = $this->convertWeeklyOff($data['weeklyOff']);
            } else {
                $data['weeklyOff'] = null;
            }
        }
        if (!empty($data['shiftStart']) && !empty($data['shiftEnd'])) {
            $setShift = true;
            if (!\ZopNow\Arya\Utility\Validator::validate($data['shiftStart'],'date', ['format' => "H:i:s"]) ||
                !\ZopNow\Arya\Utility\Validator::validate($data['shiftEnd'],'date', ['format' => "H:i:s"])) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid shift timings");
            }
        }
        if ($setShift) {
            $shiftDetails = $this->model->getShiftDetails(date('Y-m-d'));
            $curWeeklyOff = !empty($shiftDetails['weeklyOff']) ? $this->convertWeeklyOff($shiftDetails['weeklyOff']) : null;
            $weeklyOff = $data['weeklyOff'] ?? null;
            if ((!empty($data['shiftStart']) && $data['shiftStart'] != $shiftDetails['shiftStart']) ||
                (!empty($data['shiftEnd']) && $data['shiftEnd'] != $shiftDetails['shiftEnd']) ||
                ($weeklyOff != $curWeeklyOff)) {
                $shiftStart = $data['shiftStart'] ?? $shiftDetails['shiftStart'];
                $shiftEnd = $data['shiftEnd'] ?? $shiftDetails['shiftEnd'];
                $this->model->addShiftDetails($weeklyOff, $shiftStart, $shiftEnd);
            }
        }
        if ($updatePhone) {
            //Add phone and link it to the user
            if ($isOwner) {
                $phone = new \ZopNow\Hodor\Model\Phone();
                $phone->phone = $data['phone'];
            } else {
                $this->model->phones()->delete();
                $phone = \ZopNow\Hodor\Model\Phone::withTrashed()->where([['phone', ltrim($data['phone'])]])->first();
                if (empty($phone)) {
                    $phone = new \ZopNow\Hodor\Model\Phone();
                    $phone->phone = $data['phone'];
                } else {
                    $phone->restore();
                }
            }
            $this->model->phones()->save($phone);
        }
        if ($updateEmail) {
            //Add email and link it to the user
            if ($isOwner) {
                $email        = new \ZopNow\Hodor\Model\Email();
                $email->email = $data['email'];
            } else {
                $this->model->emails()->delete();
                $email = \ZopNow\Hodor\Model\Email::withTrashed()->where([['email', $data['email']]])->first();
                if (empty($email)) {
                    $email        = new \ZopNow\Hodor\Model\Email();
                    $email->email = $data['email'];
                } else {
                    $email->restore();
                }
            }
            $this->model->emails()->save($email);
        }
        $user = $this->edit($data);
        if (isset($data['roleIds']) && is_array($data['roleIds'])) {
            $this->addRoles($data['roleIds']);
        }
        if ($isOwner) {
            $this->refreshCache();
        }
        \ZopNow\Arya\DB\MySql::commit();
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $this->getDetails()
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    private function refreshCache() {
        $org = $this->organizationId;
        $r = \ZopNow\Arya\DB\Redis::getInstance();
        $r->del("O:Organization:$org");
    }

    private function getLanguageForCommunication()
    {
        //If language is passed as parameter, verify and return that language
        if (!empty($this->langIsoCode)) {
            $language = new Lang(['id' => $this->langIsoCode]);
            $language->get()->getData();
            return $this->langIsoCode;
        }
        //Return the language of the user if it has been set
        $userLanguage = $this->model->lang_iso_code;
        if (!empty($userLanguage)) {
            return $userLanguage;
        }
        //If the country iso code has been passed, return the default language for that country
        if (!empty($this->countryIsoCode)) {
            $countryController = new Country(['countryIsoCode' => $this->countryIsoCode]);
            $countryDetails = $countryController->get()->getData();
            return $countryDetails['data']['country']['defaultLang']['isoCode'];
        }
        //If the language cannot be determined from the above factors,
        // return "en" as the default language.
        return "en";
    }

    public function delete()
    {
        $this->getRequestParams(['id']);
        if($this->model->is_owner){
                throw new ValidationException("Cannot delete the owner");
        }
        $emails = $this->model->emails;
        foreach($emails as $email){
            $email->delete();
        }
        $phones = $this->model->phones;
        foreach($phones as $phone){
            $phone->delete();
        }
        parent::delete();
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'message' => 'User deleted successfully',
            'data' => null
        ])
        );
    }

    public function getDetails()
    {
        $details = parent::getDetails();
        $exclude = $this->exclude ?? [];
        if (!in_array("permissions", $exclude)) {
            $userPermissions = $this->model->getPermissions();
            $details['user']['rolePermissions'] = array_values($userPermissions['roleEndpointPermissions']);
            $details['user']['endpointPermissions'] = array_merge($details['user']['rolePermissions'], array_values($userPermissions['userEndpointPermissions']));
        }
        if (in_array('shiftDetails', self::$include)) {
            $details['user'] = array_merge($details['user'], $this->model->getShiftDetails(date('Y-m-d')));
        }
        $details['user']['roles'] = $this->model->roles()->get();
        $details['user']['stores'] = $this->model->stores()->get();
        foreach ($details['user']['stores'] as $store) {
            $store['has_delivery_hub'] = $store['has_delivery_hub'] == 1 ? true : false;
            $store['has_click_collect'] = $store['has_click_collect'] == 1 ? true : false;
            $store['has_picking'] = $store['has_picking'] == 1 ? true : false;
            $store['has_self_checkout'] = $store['has_self_checkout'] == 1 ? true : false;
        }
        return $details;
    }

    private function addRoles($roles)
    {
        foreach ($roles as $roleId) {
            (new Role(['id' => $roleId]))->get();
        }
       $this->model->roles()->sync($roles);
    }

    private function addStores($stores)
    {
        foreach ($stores as $storeId) {
            (new Store(['id' => $storeId, 'organizationId' => $this->model->organization_id]))->get();
        }
       $this->model->stores()->sync($stores);
    }

    private function convertWeeklyOff($weeklyOff)
    {
        $days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        if (!is_array($weeklyOff) || sizeof(array_diff($weeklyOff, $days)) > 0) {
            throw new ValidationException("Invalid value for weekly off");
        }
        $indexes = array_flip($days);
        $weeklyOffValue = 0;
        foreach ($weeklyOff as $day) {
            $weeklyOffValue += 2**$indexes[$day];
        }
        return $weeklyOffValue;
    }

    public function getTeamMembers()
    {
        $params = $this->getRequestParams(['organizationId', 'id']);
        $designationId = $this->model->designation_id;
        $request = ['organizationId' => $params['organizationId'], 'managerId' => $designationId];
        $designationController = new Designation($request);
        $designations = $designationController->get()->getData()['data']['designation'];
        $designationIds = array_column($designations, 'id');
        $allReportingDesignations = [];
        while (!empty($designationIds)) {
            $allReportingDesignations = array_merge($allReportingDesignations, $designationIds);
            $request = ['organizationId' => $params['organizationId'], 'managerId' => $designationIds];
            $designationController = new Designation($request);
            $designations = $designationController->get()->getData()['data']['designation'];
            $designationIds = array_column($designations, 'id');
        }
        $userParams = [
            'organizationId' => $params['organizationId'],
            'designationId' => $allReportingDesignations,
            'paginated' => false
        ];
        if (!empty($designationId) && !empty($this->model->designation()->first()->roles()->where(['name' => 'HR Manager'])->first())) {
            unset($userParams['designationId']);
        }
        $userController = new User($userParams);
        $users = $userController->get()->getData()['data']['user'];
        return $users;
    }

    public function getWeeklyOff($date)
    {
        $params = $this->getRequestParams(['id']);
        $shiftDetails =  $this->model->getShiftDetails($date);
        return $shiftDetails['weeklyOff'];
    }

    public static function getListData(\ZopNow\Arya\Listing\BaseList $list)
    {
        $objects = $list->getListItems();
        $data = array();
        foreach ($objects as $key => $model) {
            $oldData = $model->toArray();
            $additionalData = [];
            if (in_array('shiftDetails', self::$include)) {
                $additionalData = self::getShiftDetails($model);
            }
            $data[$key] = array_merge($oldData, $additionalData);
        }
        $count = $list->getTotalCount();
        return array(
            "count" => $count,
            "offset" => ($list->paginated) ? $list->getOffset() : 0,
            "limit" => ($list->paginated) ? $list->getPerPage() : $count,
            "user" => $data
        );
    }

    private static function getShiftDetails($userModelObj, $date = null)
    {
        $shiftDate = $date ?? date('Y-m-d');
        return  $userModelObj->getShiftDetails($shiftDate);
    }

}
