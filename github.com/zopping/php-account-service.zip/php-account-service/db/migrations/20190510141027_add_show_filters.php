<?php

use Phinx\Migration\AbstractMigration;

class AddShowFilters extends AbstractMigration
{
    public function up()
    {
        $this->execute("ALTER TABLE organization_page ADD show_filter bool DEFAULT TRUE");
    }
    public function down()
    {
        $this->execute("ALTER TABLE organization_page DROP COLUMN show_filter");
    }
}
