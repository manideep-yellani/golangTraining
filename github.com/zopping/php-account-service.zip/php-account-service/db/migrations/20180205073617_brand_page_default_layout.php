<?php

use Phinx\Migration\AbstractMigration;

class BrandPageDefaultLayout extends AbstractMigration
{
    public function up()
    {
        $layout = '[{"data":{"tag":"","brand":"CURRENT","title":"","sorting":"","category":"","hasImage":"","hasStock":"","hasOffers":""},"name":"ProductCollection"}]';
        $this->execute("insert into organization_page (page_id, organization_id,layouts) select id, null, '$layout' from pages where name = 'BRAND'");
    }

    public function down()
    {
        $this->execute("delete from organization_page where organization_id is null and page_id in (select id from pages where name = 'BRAND')");
    }
}
