<?php

namespace ZopNow\Hodor\Controller;

class Lang extends \ZopNow\Arya\Controller\ModelController
{

    public function __construct(array $data = [])
    {
        if (!empty($data['id'])) {
            $modelObject = \ZopNow\Hodor\Model\Lang::where([['iso_code', $data['id']]])
                ->first();
            if (empty($modelObject)) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid Language");
            }
            $data['iso_code'] = $modelObject['iso_code'];
            $data['id'] = $modelObject['id'];            
        }
        parent::__construct($data);
    }

    public function get()
    {
        if (!empty($this->data['id'])) {
            $response = $this->getDetails();
        } else{
            $list = $this->getList();
            $response = self::getListData($list);
        }
        return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $response
        ]);
    }

    public function getDetails()
    {
        $basicDetails = parent::getDetails();
        $file = $this->data['iso_code'] . ".json";
        $fileName = DATA_DIRECTORY . "languages/" . $file;
        if (file_exists($fileName)) {        
            $basicDetails['lang']['translations'] = json_decode(file_get_contents($fileName), true);
        }
        return $basicDetails;
    }

}