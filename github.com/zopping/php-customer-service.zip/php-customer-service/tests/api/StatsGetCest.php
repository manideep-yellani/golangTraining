<?php
class StatsGetCest
{
    protected static $endpoint = '/stats';

    public function testCustomerAcquisitionWithoutOrganizationId(ApiTester $I)
    {
        $I->sendGET(self::$endpoint, ["startDate" => "2017-11-11"]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - stats : organization Id"]);
    }

    public function startsWithInvalidStartDate(ApiTester $I)
    {
        $I->sendGET(self::$endpoint, ["startDate" => "2017-11-11 23:59:59", "organizationId" => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Invalid Date format"]);
    }

    public function passingStartDateGreaterThanEndDate(ApiTester $I)
    {
        $I->sendGET(self::$endpoint, ["startDate" => "2017-11-11", "endDate" => "2017-11-01", "organizationId" => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Start Date should be lesser than the end Date"]);
        
    }

    public function getStats(ApiTester $I)
    {
        $startDate = "2017-10-11";
        $endDate = "2017-10-18";
        $organizationId = 1;
        $I->sendGet(self::$endpoint, ["organizationId" => $organizationId, "startDate" => $startDate, "endDate" => $endDate]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseMatchesJsonType([
            "data" => [
                "stats" => [
                    "2017-10-11" => "integer",
                    "2017-10-12" => "integer",
                    "2017-10-13" => "integer",
                    "2017-10-14" => "integer",
                    "2017-10-15" => "integer",
                    "2017-10-16" => "integer",
                    "2017-10-17" => "integer",
                    "2017-10-18" => "integer",
                ]
            ]
        ]);
    }
    
}
