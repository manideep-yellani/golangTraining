<?php

use Phinx\Migration\AbstractMigration;

class AddImageLayoutExtn extends AbstractMigration
{
    public function up()
    {   
        $this->execute("UPDATE extensions SET icon = 'https://storage.googleapis.com/zopsmart-staging-uploads/originals/20190411/layoutscheduling-20190411-083626.png' WHERE slug ='LayoutSchedulingSupport'");            
    }
    public function down()
    {
        $this->execute("UPDATE extensions SET icon = '' WHERE slug ='LayoutSchedulingSupport'");             
    }
}
