<?php

use Phinx\Migration\AbstractMigration;

class AddOrderPackEndpoint extends AbstractMigration
{
    public function change()
    {
        $endpointData = [
            [
                "url" => "order-service/order/{id}/pack",
                "allowed_methods" => json_encode(['PUT'])
            ]
        ];
        $endpoints = [
            "order-service/order/{id}/pack" => ['PUT']
        ];
        $this->insert('endpoints', $endpointData);
        $roleEndpoints = $this->fetchAll("select id, url from endpoints where `url` = 'order-service/order/{id}/pack'");
        $roleId = $this->fetchRow("select id from roles where `name` = 'STORE MANAGER'")['id'];
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);

    }
    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach ($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'],
                    'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }
}
