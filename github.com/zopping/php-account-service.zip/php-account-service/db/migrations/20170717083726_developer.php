<?php

use Phinx\Migration\AbstractMigration;

class Developer extends AbstractMigration
{
    /**
     * Database schema for "developers" table
     * It consists of the following fields :
     * name : stores the name of the developer associated
     * token : stores a unique token to identify and validate a developer
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     * deleted_at : field will be NULL. This field will be set to the timestamp when the organization is deleted and it is a soft delete.
     *
     * "id" is the primary key for the table. "token" is a unique index for the table
     * "organization_id" is a foreign key which references the organizations table
     */
    public function change()
    {
        $developers = $this->table('developers');
        $developers->addColumn('organization_id', 'integer', array('limit' => 11))
            ->addColumn('name', 'string', array('limit' => 200))
            ->addColumn('token', 'char', array('length' => 36))
            ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp',
                array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addForeignKey('organization_id', 'organizations', 'id')
            ->addIndex(array('token'), array('unique' => true))
            ->create();
    }
}
