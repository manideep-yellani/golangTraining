<?php

class UserGetCest extends BaseCest
{

    protected static $endpoint = '/user';
    protected static $table = 'users';

    public function listUsers(ApiTester $I)
    {
        $I->wantTo('Get list of users');
        parent::getAll($I);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "user" => array(
                    array(
                        "id" => "integer",
                        "name" => "string",
                        "isOwner" => "integer",
                        "phones" => "array",
                        "emails" => "array",
                    )
                )
            )
        ));
    }

    public function listUsersInvalidPage(ApiTester $I)
    {
        //Sending a page number which does not have data
        $I->wantTo('Get list of users with invalid page number');
        $I->sendGET(self::$endpoint . "?page=10000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['user' => []]));
    }

    public function listUsersWithOrganizationId(ApiTester $I)
    {
        //Sending a organization_id as a filter and checking if the required data is returned
        $I->wantTo('Get list of users with organization id filter');
        $I->sendGET(self::$endpoint . "?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "user" => array(
                    array(
                        "id" => "integer",
                        "name" => "string",
                        "isOwner" => "integer",
                        "phones" => "array",
                        "emails" => "array",
                    )
                )
            )
        ));
    }

    public function listUsersInvalidOrganizationId(ApiTester $I)
    {
        //Sending an invalid organization id to the API
        $I->wantTo('Get list of users with invalid organization id filter');
        $I->sendGET(self::$endpoint . "?organizationId=1000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['user' => []]));
    }

    public function listUsersWithName(ApiTester $I)
    {
        //Sending a client_user_id as a filter and checking if the required data is returned
        $I->wantTo('Get list of users with name filter');
        $I->sendGET(self::$endpoint . "?name=Admin");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "user" => array(
                    array(
                        "id" => "integer",
                        "name" => "string",
                        "isOwner" => "integer",
                        "phones" => "array",
                        "emails" => "array",
                    )
                )
            )
        ));
        $I->seeResponseContainsJson(array('data' => ['user' => ['name' => 'Admin']]));
    }

    public function getUser(ApiTester $I)
    {
        $I->wantTo('Get details of a user with a valid id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Admin', 'organization_id' => 1]);
        $I->sendGET(self::$endpoint . "/$id?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['id' => $id]);
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "user" => array(
                    "id" => "integer",
                    "name" => "string",
                    "isOwner" => "integer",
                    "phones" => "array",
                    "emails" => "array",
                    "endpointPermissions" => "array",
                )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'Admin']);
    }

    public function getUserInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of a user with invalid id');
        $I->sendGET(self::$endpoint . "/user1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: User with id: user1 not found'));
    }

}
