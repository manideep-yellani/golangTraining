<?php

use Phinx\Migration\AbstractMigration;

class ExtensionEndpoint extends AbstractMigration
{
    public function up()
    {
        $endpointData = [
            ["url" => "account-service/extension","allowed_methods" => json_encode(['GET', 'PUT'])],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE FROM `endpoints` where `url` = "account-service/extension"');
    }
}
