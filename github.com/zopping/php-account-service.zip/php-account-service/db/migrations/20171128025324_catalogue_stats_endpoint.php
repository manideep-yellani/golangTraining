<?php

use Phinx\Migration\AbstractMigration;

class CatalogueStatsEndpoint extends AbstractMigration
{
    public function up()
    {
        $endpointData = [
            ["url" => "catalogue-service/stats","allowed_methods" => json_encode(['GET'])],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE FROM `endpoints` where `url` = "catalogue-service/stats"');
    }
}
