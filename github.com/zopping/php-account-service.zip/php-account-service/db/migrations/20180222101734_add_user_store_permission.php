<?php

use Phinx\Migration\AbstractMigration;

class AddUserStorePermission extends AbstractMigration {

    public function up() {
        $this->table('store_user')
            ->addColumn('user_id','integer')
            ->addColumn('store_id', 'integer')
            ->addColumn('created_at', 'timestamp', ['null' => false, 'default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addForeignKey('store_id', 'stores', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addForeignKey('user_id', 'users', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addIndex(['store_id','user_id'], ['unique' => true, "name" => "store_user_idx"])
            ->create();
        //Map existing stores and users
        $users = $this->fetchAll("select id, organization_id from users");
        $orgs = array_column($users, "id", "organization_id");
        foreach ($orgs as $orgId => $userId) {
            $stores = $this->fetchAll("select id from stores where organization_id = $orgId");
            $storesToBeAdded = [];
            foreach ($stores as $store) {
                $storesToBeAdded[] = ["store_id" => $store['id'], "user_id" => $userId];
            }
            $this->insert("store_user", $storesToBeAdded);
        }
    }

    public function down() {
        $this->dropTable('store_user');
    }

}
