<?php

namespace ZopNow\Hodor\Model;

class PaymentAccount extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;
    protected $hidden = ['updated_at', 'deleted_at', 'slug', 'access_token', 'access_key', 'secret_key'];

    public function getPaymentAccount($organizationId)
    {
        return \ZopNow\Hodor\Model\PaymentAccount::where([['organization_id', $organizationId]])->first();
    }

    public function organization()
    {
        return $this->belongsTo("\ZopNow\Hodor\Model\Organization");
    }
}
