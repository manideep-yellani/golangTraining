<?php

use Phinx\Migration\AbstractMigration;

class UpdatePaymentAccounts extends AbstractMigration
{

    public function up()
    {
        $this->table("payment_accounts")
            ->addColumn('access_token', 'string', array("null" => true, 'after' => 'access_key'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->update();
        // existing accounts access token needs to be updated
    }

    public function down()
    {
        $this->table("payment_accounts")
            ->removeColumn('access_token')
            ->removeColumn('deleted_at')
            ->update();
    }

}
