<?php

use Phinx\Seed\AbstractSeed;

class OrganizationSeeder extends AbstractSeed
{
    /*
     * Seeding the organization table with name, slug and domain.
     * Using faker factory for populating the database for 50 organizations
     * created_at, updated_at will be set to the current timestamp
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        $data = array(
            array(
                'name' => 'ZopNow',
                'slug' => 'zopnow',
                'domain' => 'zopnow.com',
                'logo' => 'http://sn.zopnow.com/images/icons/logo/ZopNow-logo.svg',
            ),
            array(
                'name' => 'Ruchi\'s Biryani',
                'slug' => 'ruchis-biryani',
                'domain' => 'ruchisbiryani.zopexpress.com',
                'logo' => 'https://dinerdeliver.com/assets/images/profile-images/ruchis%20biryani-logo.jpg',
            ),
            array(
                'name' => 'Silbatti',
                'slug' => 'silbatti',
                'domain' => 'silbatti.zopexpress.com',
                'logo' => 'https://d1bj9m7vro2dcz.cloudfront.net/mp_487852_2016-11-29-16-54-48-000913.png',
            ),
            array(
                'name' => 'Rashtrakutas',
                'slug' => 'rashtrakutas',
                'domain' => 'rashtrakutas.zopexpress.com',
                'logo' => 'https://media-cdn.tripadvisor.com/media/photo-s/0d/5c/15/1f/logo.jpg',
            ),
        );
        for ($i = 0; $i < 50; $i++) {
            $name = $faker->name;
            $slug = str_slug($name);
            $data[] = [
                'name' => $name,
                'slug' => $slug,
                'domain' => $faker->unique->domainName,
            ];
        }
        $organizations = $this->table('organizations');
        $organizations->insert($data)
                      ->save();
    }
}
