<?php

/*
 * Class consists of the basic test cases which are common to all the classes.
 * The cest classes should extend from this BaseCest class to use the basic test cases.
 */

class BaseCest
{
    protected static $endpoint;
    protected static $table;
    protected static $serviceDownMessage = "Server Error: Seems like our service is experiencing some issues. Please try later";

    // tests
    protected function getList(ApiTester $I)
    {
        $I->sendGET(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }

    protected function getDetails(ApiTester $I, $id)
    {
        $I->sendGET(static::$endpoint . "/$id");
        try {
            $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
            $I->seeResponseContainsJson(['id' => $id]);
        } catch (Exception $ex) {
            self::serviceDownTest($I);
        }
        $I->seeResponseIsJson();
    }

    protected function create(ApiTester $I, $data = null)
    {
        $I->sendPOST(static::$endpoint, []);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($data);
        $id = $I->grabDataFromResponseByJsonPath('$.data.id')[0];
        $data['id'] = $id;
        $I->sendGET(static::$endpoint . "/$id");
        $I->seeResponseCodeIs(200);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($data);
    }

    protected function update(ApiTester $I, $id, $updatedData = null, $initialData = null)
    {
        $I->sendPUT(static::$endpoint . "/$id", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson($updatedData);
        $I->seeInDatabase(static::$table, $updatedData);
        $I->dontseeResponseContainsJson($initialData);
        $I->dontSeeInDatabase(static::$table, $initialData);
    }

    protected function delete(ApiTester $I, $id)
    {
        $I->sendDELETE(static::$endpoint . "/$id");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
    }

    protected function serviceDownTest(ApiTester $I)
    {
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => self::$serviceDownMessage]);
    }

}