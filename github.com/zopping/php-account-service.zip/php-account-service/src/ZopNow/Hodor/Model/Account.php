<?php

namespace ZopNow\Hodor\Model;


class Account extends \ZopNow\Arya\Model\Base
{
    
    protected $table = 'organizations';   
    protected $hidden = ['updated_at', 'deleted_at', 'slug','pivot', 'theme_id'];
    protected $casts = ['meta_data' => 'array'];
}
