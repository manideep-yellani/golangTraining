<?php

namespace ZopNow\Hodor\Controller;

/**
 * Class consists of the APIs for the CRUD operations on Configurations
 */

class Configuration extends \ZopNow\Arya\Controller\ModelController
{
    protected static $filterableFields = ['organization_id', 'store_id', 'key'];
    protected $allowNonPaginated = true;

    private $configKeyToActions = [
        "basic.logo" => "LOGO_ADDITION",
        "basic.supportEmail" => "CONTACT_DETAILS",
        "basic.supportPhone" => "CONTACT_DETAILS",
    ];

    public function get()
    {
        if (!empty($this->data['id'])) {
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function post()
    {
        $mandatoryFields = array("organizationId", "key", "value");
        $data = $this->getRequestParams($mandatoryFields);
        $exists = $this->model->isExists($data['organizationId'], $data['key']);
        if ($exists) {
            throw new \ZopNow\Arya\Exception\ValidationException('Configuration already exists');
        }
        $config = $this->add($data);
        $this->publishActionChangeEvent($data['organizationId'], $data['key']);
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $config
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    private function publishActionChangeEvent($orgId, $key) {
        $actionsTopic = getenv("ACTIONS_TOPIC");
        if ($actionsTopic != '' && isset($this->configKeyToActions[$key])) {
            $event = new \ZopNow\Hodor\Utility\Event($actionsTopic, [
                "actions" => [
                    ["status" => "COMPLETED", "id" => $this->configKeyToActions[$key]]
                ],
                "organizationId" => strval($orgId)
            ]);
            $event->publish();
        }
    }

    public function put()
    {
        if (empty($this->data['id'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid id");
        }
        $optionalFields = array("key", "value");
        $data = $this->getRequestParams([], $optionalFields);
        $key = !empty($data['key']) ? $data['key'] : $this->model->key;
        $exists = $this->model->isExists($this->model->organization_id, $key);
        if ($exists) {
            throw new \ZopNow\Arya\Exception\ValidationException("Configuration exists with the same key");
        }
        $data['id'] = $this->data['id'];
        $responseData = $this->edit($data);
        $this->publishActionChangeEvent($this->model->organization_id, $key);
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $responseData
        );
        return new \ZopNow\Arya\View\Base($response);
    }
}
