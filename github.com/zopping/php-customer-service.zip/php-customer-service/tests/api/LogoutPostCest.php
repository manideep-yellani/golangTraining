<?php

class LogoutPostCest
{
    protected static $endpoint = "/logout";
    private static $organizationId = 1;

    private function getGuidFromLogin($I)
    {
        //login customer
        $I->sendPOST("/login", ["username" => "+919876543210", "password" => "password", "organizationId" => self::$organizationId]);
        return $I->grabDataFromResponseByJsonPath("$.data.customer.accessToken")[0];
    }

    public function logoutCustomerWithValidData(ApiTester $I)
    {
        $I->wantToTest("Customers logout with valid Data");
        $guid = $this->getGuidFromLogin($I);
        $data = [
            "accessToken" => $guid,
            "organizationId" => self::$organizationId
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(["message" => "Successfully logged out"]);
    }

    public function logoutCustomerWithoutOrganizationId(ApiTester $I)
    {
        $I->wantToTest("Customers logout without organizationId");
        $guid = $this->getGuidFromLogin($I);
        $data = [
            "accessToken" => $guid
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - logout : organization Id"]);
    }

    public function logoutCustomerWithoutToken(ApiTester $I)
    {
        $I->wantToTest("Customers logout without token");
        $guid = $this->getGuidFromLogin($I);
        $data = [
            "organizationId" => self::$organizationId
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - logout : access Token"]);
    }
}
