<?php

namespace ZopNow\Hodor\Extension;


class Seo extends Base
{
    protected static $defaultData = array(
        array(
            'pageId' => 1,
            'title' => '{{organization_name}} : Home',
            'description' => 'Now shop online on {{organization_name}}',
            'keywords' => "{{organization_name}}",
            'url' => null,
        ),
        array(
            'pageId' => 2,
            'title' => '{{organization_name}} : {{brand_name}}',
            'description' => 'Buy {{brand_name}} on {{organization_name}}',
            'keywords' => '{{organization_name}}, {{brand_name}}',
            'url' => null,
        ),
        array(
            'pageId' => 3,
            'title' => '{{organization_name}} : {{category_name}}',
            'description' => 'Buy {{category_name}} on {{organization_name}}',
            'keywords' => '{{organization_name}}, {{category_name}}',
            'url' => null,
        ),
        array(
            'pageId' => 4,
            'title' => '{{organization_name}} : {{product_name}}',
            'description' => 'Buy {{product_name}} on {{organization_name}}',
            'keywords' => '{{organization_name}}, {{product_name}}',
            'url' => null,
        ),
        array(
            'pageId' => 6,
            'title' => '{{organization_name}} : {{tag_name}}',
            'description' => '{{tag_name}} on {{organization_name}}',
            'keywords' => '{{organization_name}}, {{tag_name}}',
            'url' => null,
        )
    );

    /**
     * Abstract method that will be executed when an extension is enabled for an organization
     * @return null
     */
    public function enable()
    {
        $organizationId = $this->organization->id;
        $seoController = new \ZopNow\Hodor\Controller\Seo(['organizationId' => $organizationId]);
        $existingData = $seoController->get()->getData()['data']['seo'];
        if(count($existingData) != count(self::$defaultData)) {
            $existingPages = array_column(array_column($existingData, 'page'),'id');
            foreach(self::$defaultData as $insertData){
                if(!in_array($insertData['pageId'], $existingPages)){
                    $insertData['organizationId'] = $organizationId;
                    $seoController = new \ZopNow\Hodor\Controller\Seo($insertData);
                    $seoController->post();
                }
            }
        }
    }

    /**
     * Abstract method that will be executed when an extension is disabled for an organization
     * @return null
     */
    public function disable()
    {
        // TODO: Implement disable() method.
    }

    /**
     * Abstract method that will be give called to get the cost of the extension for the given date range
     * @return Cost of the extension service for the given date range
     */
    public function getBillingAmount($startDate, $endDate, $pricingRule)
    {
        // TODO: Implement getBillingAmount() method.
    }
}