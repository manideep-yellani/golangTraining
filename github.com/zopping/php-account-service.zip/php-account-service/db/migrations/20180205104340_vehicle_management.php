<?php

use Phinx\Migration\AbstractMigration;

class VehicleManagement extends AbstractMigration
{
    private $logisticsSupportSlug = 'LogisticsSupport';

    public function up()
    {
        $data = [
            "name" => "Logistics Support",
            "slug" => $this->logisticsSupportSlug,
            "description" => "Facilitates the organization to manage logistics",
            "enable_helper_text" => "Provides user an interface to manage trips , vehicles , vehicle vendors|"
            . " Enables user to start trips for orders which are ready to be dispatched",
            "disable_helper_text" => "User will not be able to manage trips, vehicles.",
            "pricing" => "FREE"
        ];
        $this->insert('extensions', $data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '{$this->logisticsSupportSlug}'")['id'];
        $tripEndpoints = ['logistics-service/vehicle-vendor' => ['GET', 'PUT', 'POST'] ,
                'logistics-service/vehicle' => ['GET', 'PUT', 'POST'],
                'logistics-service/planned-trip' => ['GET'],
            'logistics-service/trip' => ['GET', 'PUT', 'POST']];
        foreach ($tripEndpoints as $api => $allowedMethods) {
            $endpointData = [["url" => $api, "allowed_methods" => json_encode($allowedMethods),
                'extension_id' => $extensionId]];
            $this->insert('endpoints', $endpointData);
        }
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '{$this->logisticsSupportSlug}'")['id'];
        $this->execute("DELETE from `endpoints` where `extension_id` = $extensionId");
        $this->execute("DELETE from `extensions` where `slug` = '{$this->logisticsSupportSlug}'");
    }
}
