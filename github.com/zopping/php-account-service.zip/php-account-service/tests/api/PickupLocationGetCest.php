<?php

class PickupLocationGetCest
{

    protected static $endpoint = '/pickup-location';
    protected static $table = 'pickup_locations';

    public function listPickupLocationsWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get list of pickup locations without organization id');
        $I->sendGET(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Validation Exception: Missing Required Field'
                . ' - pickuplocation : organization Id')
        );
    }

    public function listPickupLocations(ApiTester $I)
    {
        $I->wantTo('Get list of pickup locations');
        $I->sendGET(static::$endpoint . "?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "pickuplocation" => "array"
            )
        ));
    }

    public function listPickupLocationsInvalidPage(ApiTester $I)
    {
        //Sending a page number which does not have data
        $I->wantTo('Get list of pickup locations with invalid page number');
        $I->sendGET(self::$endpoint . "?organizationId=1&page=1000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['pickuplocation' => []]));
    }

    public function listPickupLocationsInvalidOrganizationId(ApiTester $I)
    {
        //Sending an invalid organization id to the API
        $I->wantTo('Get list of pickup locations with invalid organization id filter');
        $I->sendGET(self::$endpoint . "?organizationId=10000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['pickuplocation' => []]));
    }

    public function getPickupLocation(ApiTester $I)
    {
        $I->wantTo('Get details of a pickup location with a valid id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'More, Sahkar Nagar']);
        $I->sendGET(static::$endpoint . "/$id?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['id' => $id]);
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'More, Sahkar Nagar']);
    }

    public function getPickupLocationWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get details of a pickup location without organization id');
        $I->sendGET(static::$endpoint . "/1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Validation Exception: Missing Required Field'
                . ' - pickuplocation : organization Id')
        );
    }

    public function getPickupLocationOfDifferentOrganization(ApiTester $I)
    {
        $I->wantTo('Get details of a pickup location with id not belonging to passed organization');
        $id = $I->grabFromDatabase(
            self::$table, 'id', ['name' => 'More, Sahkar Nagar', 'organization_id' => 1]
        );
        $I->sendGET(static::$endpoint . "/$id?organizationId=2");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => "Model Exception: Pickup location with id: $id not found")
        );
    }

    public function getPickupLocationInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of a pickup location with invalid id');
        $I->sendGET(self::$endpoint . "/location1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Model Exception: PickupLocation with id: location1 not found')
        );
    }

    public function getPickupLocationOrganizationId(ApiTester $I)
    {
        //Sending organization_id with a valid id. The organization_id filter will not be applied
        $I->wantTo('Get details of a pickup location with a valid id and an organization id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Metro, Yeshwantpur']);
        $orgId = $I->grabFromDatabase(
            self::$table, 'organization_id', ['name' => 'Hypercity, Meenakshi Mall']
        );
        $I->sendGET(self::$endpoint . "/$id?organizationId=$orgId");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('id' => $id, 'name' => 'Metro, Yeshwantpur'));
        $I->dontSeeResponseContainsJson(array('name' => 'Hypercity, Meenakshi Mall'));
    }

}
