<?php

use Phinx\Migration\AbstractMigration;

class AddHrExtensionSupport extends AbstractMigration
{

    public function up()
    {
        $enableHelperText = "Allows to manage shifts and weekly off details of users | ".
            " Allows to manage designations of the users  | Provides an interface to manage user leaves";
        $disableHelperText = "Disables management of shifts, leaves and designations for users";
        $data = [
            "name" => "HR Management",
            "slug" => "HrManagement",
            "description" => "Allows you to manage the users of your organization",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'HrManagement'")['id'];
        $endpointData = [
                [
                    "url" => "account-service/employee",
                    "extension_id" => $extensionId,
                    "allowed_methods" => json_encode(['GET', 'PUT'])
                ],
                [
                    "url" => "account-service/designation",
                    "extension_id" => $extensionId,
                    "allowed_methods" => json_encode(['GET', 'POST', 'PUT', 'DELETE'])
                ],
                [
                    "url" => "account-service/attendance",
                    "extension_id" => $extensionId,
                    "allowed_methods" => json_encode(['GET', 'POST', 'PUT', 'DELETE'])
                ],
                [
                    "url" => "account-service/user-leave",
                    "extension_id" => $extensionId,
                    "allowed_methods" => json_encode(['GET', 'POST', 'PUT'])
                ],
                [
                    "url" => "account-service/leave-summary",
                    "extension_id" => $extensionId,
                    "allowed_methods" => json_encode(['GET',])
                ],
                [
                    "url" => "account-service/attendance-summary",
                    "extension_id" => $extensionId,
                    "allowed_methods" => json_encode(['GET'])
                ],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'HrManagement'")['id'];
        $this->execute("DELETE from `endpoints` where `extension_id` = '$extensionId'");
        $this->execute('DELETE from `extensions` where `slug` = "HrManagement"');
    }

}
