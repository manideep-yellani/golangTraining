<?php

class RoleGetCest
{
    protected static $endpoint = '/role';
    protected static $table = 'roles';

    public function listRoles(ApiTester $I)
    {
        $I->wantTo('Get list of roles');
        $I->sendGET(static::$endpoint . "?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "role" => "array"
            )
        ));
    }

    public function listRolesInvalidPage(ApiTester $I)
    {
        //Sending a page number which does not have data
        $I->wantTo('Get list of roles with invalid page number');
        $I->sendGET(self::$endpoint . "?organizationId=1&page=1000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['role' => []]));
    }

    public function getRole(ApiTester $I)
    {
        $I->wantTo('Get details of a role with a valid id');
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Manager', 'organization_id' => 1]
        );
        $I->sendGET(static::$endpoint . "/$id?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "role" => array(
                    "id" => "integer",
                    "name" => "string"
                )
            )
        ));
        $I->seeResponseContainsJson(['id' => $id]);
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'Manager']);
    }

    public function getRoleInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of a role with invalid id');
        $I->sendGET(self::$endpoint . "/role1?organizationId=1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Role with id: role1 not found'));
    }

    public function getRoleWithNameFilter(ApiTester $I)
    {
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Manager', 'organization_id' => 1]
        );
        $I->sendGET(static::$endpoint . "?organizationId=1&name=Manager");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'Manager']);
    }

}
