<?php

use Phinx\Migration\AbstractMigration;

class AddDefaultMonthlyRental extends AbstractMigration
{

    public function up()
    {
        $this->table("services")
            ->insert([
                [
                    "name" => "Default Monthly Rental",
                    "slug" => "defaulyMonthlyRental",
                    "pricing_rule" => json_encode([
                        "COST" => 2000,
                        "RATE" => "FIXED",
                        "TYPE" => "MONTHLY"
                    ])
                ]
            ])
            ->saveData();
    }

    public function down() 
    {
        $this->execute('DELETE from `services` where `slug` = "defaulyMonthlyRental"');
    }

}
