<?php

use Phinx\Migration\AbstractMigration;

class CustomerApiPermissions extends AbstractMigration
{
    /**
     * Adding Customer as a required  value for deleting customer's phone,
     * email and addresses
     */
    public function change()
    {
        $urls = [
            "customer-service/address",
            "customer-service/email",
            "customer-service/phone",
           ];
        $data = $this->fetchAll("select * from endpoints where url in ('" . implode("','", $urls) . "')");
        $endpointIds = array_column($data, "id");
        $this->execute("update endpoint_developer_permissions set is_customer_required = 1"
                        . " where endpoint_id in ('" . implode("','", $endpointIds) . "') and method = 'DELETE'");
    }
}
