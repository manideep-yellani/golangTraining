<?php

use Phinx\Migration\AbstractMigration;

class SapphireThemeImage extends AbstractMigration
{
    public function change()
    {
        $image = '{"desktop":"https:\/\/s3.ap-south-1.amazonaws.com\/zopnow-uploads\/sapphire-20171219-113736.png",'
            . '"mobile":"http://via.placeholder.com/414x736",'
            . '"tablet":"http://via.placeholder.com/1024x768"}';
        $this->execute("update themes set image = '$image' where slug = 'theme-sapphire'");
    }
}
