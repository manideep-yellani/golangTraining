<?php

use Phinx\Migration\AbstractMigration;

class AddSlotChargeEnpoint extends AbstractMigration
{
    public function up()
    {
       $this->execute('INSERT INTO endpoints(url,allowed_methods) values("order-service/slot-charge","[\"GET\",\"PUT\"]")');
    }
    public function down()
        {
            $this->execute("delete from endpoints where url='order-service/slot-charge'");
        }
}
