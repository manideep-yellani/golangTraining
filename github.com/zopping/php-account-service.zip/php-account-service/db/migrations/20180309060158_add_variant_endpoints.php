<?php

use Phinx\Migration\AbstractMigration;

class AddVariantEndpoints extends AbstractMigration
{

    public function change()
    {
        $endpointData = [[
            "url" => "catalogue-service/variant",
            "extension_id" => $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'MultiVariantSupport'")['id'],
            "allowed_methods" => json_encode(['GET', 'PUT'])
        ]];
        $this->insert('endpoints', $endpointData);
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'catalogue-service/variant'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `token` = 'f64ff4c2-e1ef-4559-825e-f72d0da011c9'")['id'];
        foreach (['GET', 'PUT'] as $method) {
            $this->insert('endpoint_developer_permissions',
                array(
                "endpoint_id" => $endpointId,
                "developer_id" => $developerId,
                "method" => $method,
                "has_permission" => 1
            ));
        }
    }
}