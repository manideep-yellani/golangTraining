<?php

use Phinx\Migration\AbstractMigration;

class ExtensionIndexName extends AbstractMigration
{

    public function change()
    {
        $this->table('extensions')
            ->addIndex(['name'], ['unique' => true, "name" => "name_index"])
            ->save();
    }
}
