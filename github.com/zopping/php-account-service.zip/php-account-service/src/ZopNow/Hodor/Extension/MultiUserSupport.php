<?php

namespace ZopNow\Hodor\Extension;


use ZopNow\Hodor\Controller\User;

class MultiUserSupport extends Base
{

    public function enable()
    {
        return true;
    }

    public function disable()
    {
        $userIds = $this->organization->users->where("is_owner",false)->pluck('id')->toArray();
        foreach($userIds as $userId){
            $userController = new User(['id' => $userId]);
            $userController->delete();
        }
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        $organizationId = $this->organization->id;
        $cost  = $count = $billingPeriod = 0;
        $metaData = null;
        $users = [];
        if (!empty($pricingRule['TYPE']) && $pricingRule['TYPE'] == 'MONTHLY') {
            $start = date('Y-m-d 00:00:00', strtotime($startTime));
            $end = date('Y-m-d 23:59:59', strtotime($endTime));
            $rows = \ZopNow\Arya\DB\MySql::select("select id, created_at, deleted_at  from `users` "
                    . " where `organization_id` = $organizationId and ( `deleted_at` is null or `deleted_at` "
                    . " > '$start') order by created_at");
            foreach ($rows as $row) {
                $diffDays = 0;
                if ((strtotime($row['created_at']) < strtotime($end)) && (!is_null($row['deleted_at']) ||
                    strtotime($row['deleted_at']) < strtotime($end) || is_null($row['deleted_at']))) {
                    $startPeriod = strtotime($row['created_at']) < strtotime($start) ? strtotime($start) : strtotime($row['created_at']);
                    $endPeriod = !is_null($row['deleted_at']) ? strtotime($row['deleted_at']) : strtotime($end);
                    $diffDays = round(($endPeriod - $startPeriod)/86400);
                    if ($diffDays > 0) {
                        $users[$row['id']] = $diffDays;
                    }
                }
            }
        }
        $numDays = date('t', strtotime($startTime));
        $count = sizeof($users);
        arsort($users);
        $freeCount = $pricingRule['FREE'] ?? 0;
        $users = array_slice($users, $freeCount, NULL, true);
        foreach ($users as $userId => $billingPeriod) {
            $cost += $pricingRule['COST'] * $billingPeriod /$numDays;
        }
        if (!empty($cost)) {
            \ZopNow\Arya\App\Application::log("Users billied for organization $organizationId", $users);
            $metaData = date('Y-m-d',strtotime($startTime))."-".date('Y-m-d',strtotime($endTime)).", Active number of users $count.";
        }
        return ['cost' => $cost, 'metaData' => $metaData ?? null];
    }

}