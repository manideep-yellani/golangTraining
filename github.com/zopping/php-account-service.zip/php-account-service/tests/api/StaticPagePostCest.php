<?php

class StaticPagePostCest
{

    protected static $endpoint = '/static-page';

    public function addStaticPageWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Add static page without organization id');
        $data = [
            'layouts' => json_encode([
                [
                    "title" => "Title",
                    "message" => "Just a message"
                ]
            ])
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Missing Required Field'
                . ' - staticpage : organization Id']
        );
    }

    public function addStaticPageWithoutRequiredFields(ApiTester $I)
    {
        $I->wantTo("Add static page without any of the required fields");
        $data = [
            'organizationId' => 1
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Missing Required Field'
                . ' - staticpage : layouts']
        );

        $data['layouts'] = json_encode([
            [
            "title" => "Title",
            "message" => "Just a message"
            ]
        ]);
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Missing Required Field'
                . ' - staticpage : url']
        );

        $data['url'] = 'test-page';
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Missing Required Field'
                . ' - staticpage : title']
        );
    }

    public function addStaticPageWithValidData(ApiTester $I)
    {
        $I->wantTo("Add static page with valid data");
        $data = [
            'organizationId' => 4,
            'layouts' => json_encode([
                [
                    "name" => 'ImageSlideshow',
                    "data" => [
                        "text" => "Title",
                        "link" => "http://link1.com",
                        "imageUrl" => "http://www.image.com"
                    ]
                ]
            ]),
            'url' => 'sample',
            'title' => 'Sample Page'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "staticpage" => array(
                    "id" => "integer",
                    "layouts" => "string",
                    "url" => "string",
                    "title" => "string",
                    "status" => "string"
                )
            )
        ));
        unset($data['organizationId']);
        $I->seeResponseContainsJson($data);
    }

    public function addPageLayoutsWithInvalidOrganizationId(ApiTester $I)
    {
        $I->wantTo('Add page layout data with invalid organization id');
        $data = [
            'organizationId' => 100,
            'layouts' => json_encode([
                [
                    "title" => "Title",
                    "message" => "Just a message"
                ]
            ]),
            'url' => 'test',
            'title' => 'Test Page'
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Organization with id: 100 not found'));
    }

    public function addStaticPageWithoutUrl(ApiTester $I)
    {
        $I->wantTo('Add page layout data for CONSTANT page without url filter');
        $layoutData = json_encode(
            array(
                0 => array(
                    'data' => array(
                        'link' => '',
                        'title' => 'Static Page',
                        'imageUrl' => "http://via.placeholder.com/250X141",
                        'description' => 'Test Static page description',
                        ),
                    'name' => 'ImageWithText',
                ),
            )
        );
        $data = [
            'organizationId' => 4,
            'layouts' => $layoutData,
        ];
        $I->sendPOST(self::$endpoint . "/CONSTANT", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Missing Required Field - staticpage : url']
        );
    }

}
