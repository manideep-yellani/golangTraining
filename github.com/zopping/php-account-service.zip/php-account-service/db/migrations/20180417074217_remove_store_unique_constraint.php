<?php

use Phinx\Migration\AbstractMigration;

class RemoveStoreUniqueConstraint extends AbstractMigration
{
    public function up()
    {
        $this->table("stores")
            ->dropForeignKey('organization_id')
            ->removeIndex(['organization_id', 'name'])
            ->addForeignKey('organization_id', 'organizations', 'id',
                array('delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->save();
    }

    public function down()
    {
        $this->table("stores")
            ->addIndex(['organization_id', 'name'], array('unique' => true))
            ->save();
    }
}
