<?php

namespace ZopNow\Hodor\Model;

class UserLeave extends \ZopNow\Arya\Model\Base
{

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'user_id', 'pivot'];
    protected $appends = ['applied_on'];
    protected $with = ['user'];

    public function user()
    {
        return $this->belongsTo("\ZopNow\Hodor\Model\User");
    }

    public function getAppliedOnAttribute()
    {
        return $this->attributes['created_at'];
    }

    public static function getListItems(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        if ($list->paginated) {
            $data->limit($list->getPerPage())->skip($list->getOffset());
        }
        return $data->select('user_leaves.*')->orderBy("user_leaves." . $list->getSortField(), $list->getSortOrder())->get();
    }

    public static function getListItemsCount(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        return $data->count();
    }

    private static function getQueryBuilder(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::query();
        $filters = $list->getFilters();
        $filterKeys = array_column($filters, 0);
        $designationKey = array_search('designation_id', $filterKeys);
        if ($designationKey !== false) {
            $data->join('users', 'user_leaves.user_id', 'users.id')
                ->where("users.designation_id", "=" ,$filters[$designationKey][1]);
            unset($filters[$designationKey]);
        }
        $fromKey = array_search('from', $filterKeys);
        $toKey = array_search('to', $filterKeys);
        if ($fromKey !== false && $toKey !== false) {
            $from = $filters[$fromKey][1];
            $to = $filters[$toKey][1];
            $data->where(function ($query) use ($from, $to) {
                $query->whereBetween('from_date', [$from, $to])
                    ->orWhereBetween('to_date', [$from, $to])
                    ->orWhere(function ($q) use ($from, $to) {
                        $q->where('from_date', '<=', $from)
                           ->where('to_date', '>=', $to);
                    });
            });
            unset($filters[$fromKey]);
            unset($filters[$toKey]);
        }
        $orgKey = array_search('organization_id', $filterKeys);
        if ($orgKey !== false) {
            $data->join('users', 'user_leaves.user_id', 'users.id')
                ->where("users.organization_id", "=" ,$filters[$orgKey][1]);
            unset($filters[$orgKey]);
        }
        $data = self::addFilterQuery($data, $filters);
        return $data;
    }

}
