<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Exception\ValidationException;

class Role extends \ZopNow\Arya\Controller\ModelController 
{
    protected static $filterableFields = ['name', 'organization_id'];

    public function get()
    {
        if (!empty($this->data['id'])) {
            $data = $this->getDetails();
        } else {
            if (!empty($this->data['name'])) {
                $this->data['name'] = $this->data['name'] . "*";
            }
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function post()
    {
        $data = $this->getRequestParams(['organizationId', 'name']);
        $existingId = $this->modelClass::getIdFromName($data['name'], $data['organizationId']);
        if (!empty($existingId)) {
            throw new ValidationException(
                "Role with name '" . $data['name'] . "' already exists"
            );
        }
        $details = $this->add($data);
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $details,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function put()
    {
        $data = $this->getRequestParams(['organizationId', 'id', 'name']);
        if ($this->model->organization_id != $data['organizationId']) {
            if (empty($this->model->organization_id)) {
                throw new ValidationException("Global roles cannot be edited");
            }
            throw new \ZopNow\Arya\Exception\ModelException("Role with id "
                . $data['id'] . " not found");
        }
        $existingId = $this->modelClass::getIdFromName($data['name'], $data['organizationId']);
        if (!empty($existingId) && $existingId != $data['id']) {
            throw new ValidationException(
                "Role with name '" . $data['name'] . "' already exists"
            );
        }
        $details = $this->edit($data);
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $details,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function delete()
    {
        $data = $this->getRequestParams(['organizationId', 'id']);
        if ($this->model->organization_id != $data['organizationId']) {
            if (empty($this->model->organization_id)) {
                throw new ValidationException("Global roles cannot be deleted");
            }
            throw new \ZopNow\Arya\Exception\ModelException("Role with id "
                . $data['id'] . " not found");
        }
        $users = $this->model->users->toArray();
        if (!empty($users)) {
            throw new ValidationException(
                "Role cannot be deleted as there are users mapped to the role"
            );
        }
        parent::delete();
        $response = array(
            'status' => 'SUCCESS',
            'message' => 'Role deleted successfully',
            'data' => null
        );
        return new \ZopNow\Arya\View\Base($response);
    }

}
