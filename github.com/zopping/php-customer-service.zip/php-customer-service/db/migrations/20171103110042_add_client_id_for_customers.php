<?php


use Phinx\Migration\AbstractMigration;

class AddClientIdForCustomers extends AbstractMigration
{
    /**
     * ClientId column added to customers table.
     * The field stores the id used by client to reference the customer.
     *
     */
    public function change()
    {
        $this->table("customers")
            ->addColumn('client_id', 'integer', array('limit' => 15, 'after' => 'id', 'null' => true))
            ->save();
    }
}
