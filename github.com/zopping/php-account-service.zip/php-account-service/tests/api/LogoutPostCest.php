<?php

class LogoutPostCest
{
    protected static $endpoint = "/logout";

    private function getGuidFromLogin($I)
    {
        $I->sendPOST(
            "/auth", ["username" => "admin@zopnow.com", "password" => "justatestpassword"]
        );
        return $I->grabDataFromResponseByJsonPath('$.data.user.accessToken')[0];
    }

    public function logoutUserWithValidData(ApiTester $I)
    {
        $I->wantToTest("User logout with valid Data");
        $guid = $this->getGuidFromLogin($I);
        $data = [
            "accessToken" => $guid,
            "organizationId" => 2
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(["message" => "Successfully logged out"]);
    }

    public function logoutUserFromAllDevices(ApiTester $I)
    {
        $I->wantToTest("User logout from all devices with valid data");
        $guid = $this->getGuidFromLogin($I);
        $data = [
            "accessToken" => $guid,
            "organizationId" => 2,
            "logoutFromAll" => true,
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(["message" => "Successfully logged out"]);
    }

    public function logoutUserWithoutOrganizationId(ApiTester $I)
    {
        $I->wantToTest("User logout without organizationId");
        $guid = $this->getGuidFromLogin($I);
        $data = [
            "accessToken" => $guid
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Missing Required Field"
                . " - logout : organization Id"]
        );
    }

    public function logoutUserWithoutToken(ApiTester $I)
    {
        $I->wantToTest("Users logout without token");
        $guid = $this->getGuidFromLogin($I);
        $data = [
            "organizationId" => 2
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Missing Required Field - logout"
                . " : access Token"]
        );
    }
}
