<?php

use Phinx\Migration\AbstractMigration;

class AddMissingEndpoints extends AbstractMigration
{

    public function up()
    {
        $endpointsToBeDeleted = [
            "'catalogue-service/variant'",
            "'inventory-service/item'",
            "'inventory-service/stock'"
        ];
        $this->execute(
            "delete from endpoint_developer_permissions where endpoint_id in "
            . "(select id from endpoints where url in ("
            . implode(',', $endpointsToBeDeleted) . "))"
        );
        $this->execute(
            "delete from endpoints where url in (" . implode(',', $endpointsToBeDeleted) . ")"
        );
        $endpointData = [
            [
                "url" => "account-service/permission",
                "allowed_methods" => json_encode(['PUT'])
            ],
            [
                "url" => "customer-service/customer-upload",
                "allowed_methods" => json_encode(['GET','POST'])
            ],
            [
                "url" => "order-service/order-upload",
                "allowed_methods" => json_encode(['GET','POST'])
            ],
            [
                "url" => "order-service/payment-enquiry",
                "allowed_methods" => json_encode(['POST'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $endpointsToBeDeleted = [
            "'account-service/permission'",
            "'customer-service/customer-upload'",
            "'order-service/order-upload'",
            "'order-service/payment-enquiry'"
        ];
        $this->execute(
            "delete from endpoints where url in (" . implode(',', $endpointsToBeDeleted) . ")"
        );
        $endpointData = [
            [
                "url" => "catalogue-service/variant",
                "allowed_methods" => json_encode(['GET','POST','PUT','DELETE'])
            ],
            [
                "url" => "inventory-service/item",
                "allowed_methods" => json_encode(['GET','POST','PUT'])
            ],
            [
                "url" => "inventory-service/stock",
                "allowed_methods" => json_encode(['GET','PUT'])
            ],
        ];
        $this->insert('endpoints', $endpointData);
    }

}
