<?php

namespace ZopNow\Hodor\Helper;

class Validator
{

    public static function validate($value, string $type, array $extraData = []): bool
    {
        $validationFunction = "is".ucfirst($type);
        $isValid = false;
        if (method_exists(__CLASS__, $validationFunction)) {
            $isValid = self::$validationFunction($value, $extraData);
        } elseif (function_exists("is_{$type}")) {
            $validationFunction = "is_{$type}";
            $isValid = $validationFunction($value);
        } else {
            throw new \ZopNow\Arya\Exception\ValidationException("Unknown validation type $type.");
        }
        return $isValid;
    }

    public static function isPositive($value): bool
    {
        return is_numeric($value) && $value > 0;
    }

    public static function passwordValidation($password, $organizationId): string
    {

        $configs=array("minPasswordLength"=>0,"minNumberOfNumericCharacters"=>0,"minNumberOfUppercaseAlphabets"=>0,"minNumberOfLowercaseAlphabets"=>0,"minNumberOfSymbols"=>0);
        $response = null; 
        try{
            $response=\ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/passwordPolicy", 'GET', ['organizationId' => $organizationId]);

            
        } catch (\ZopNow\Arya\Exception\AppException $e) {
            return "";
        }
        $adminConfig=json_decode($response["body"],true)["data"]["passwordPolicy"]["admin"];
        if(is_array($adminConfig)){
            foreach ($adminConfig as $key=> $value){
                if (is_numeric($value)){
                    $configs[$key]=$value;
                }
            }
        }

        $passwordProperty=array("minNumberOfNumericCharacters"=>0,"minNumberOfUppercaseAlphabets"=>0,"minNumberOfLowercaseAlphabets"=>0,"minNumberOfSymbols"=>0);

        if (!is_string($password)){
            return "Password needs to be a string";
        }
        if (strlen($password)<$configs["minPasswordLength"]){
            return "Password should be atleast {$configs["minPasswordLength"]} characters long";
        }

        $passwordChars=str_split($password);
        foreach ($passwordChars as $char){
            if (ctype_lower($char)){
                $passwordProperty["minNumberOfLowercaseAlphabets"]++;
                continue;
            }
            if (ctype_digit($char)){
                $passwordProperty["minNumberOfNumericCharacters"]++;
                continue;
            }
            if (ctype_upper($char)){
                $passwordProperty["minNumberOfUppercaseAlphabets"]++;
                continue;
            }
            $passwordProperty["minNumberOfSymbols"]++;
        }

        if ($passwordProperty["minNumberOfNumericCharacters"]<$configs["minNumberOfNumericCharacters"]){
            return "Password should have atleast {$configs["minNumberOfNumericCharacters"]} numeric characters";
        }
        if ($passwordProperty["minNumberOfLowercaseAlphabets"]<$configs["minNumberOfLowercaseAlphabets"]){
            return "Password should have atleast {$configs["minNumberOfLowercaseAlphabets"]} lowercase alphabet";
        }
        if ($passwordProperty["minNumberOfUppercaseAlphabets"]<$configs["minNumberOfUppercaseAlphabets"]){
            return "Password should have atleast {$configs["minNumberOfUppercaseAlphabets"]} uppercase alphabet";
        }
        if ($passwordProperty["minNumberOfSymbols"]<$configs["minNumberOfSymbols"]){
            return "Password should have atleast {$configs["minNumberOfSymbols"]} symbol characters";
        }

        return "";
    }

    public static function isPhone($value): bool
    {
        $phoneUtil = \libphonenumber\PhoneNumberUtil::getInstance();
        $isValid = false;
        try {
            $phoneNumber = $phoneUtil->parse($value);
            $isValid = $phoneUtil->isValidNumber($phoneNumber);
        } catch (\libphonenumber\NumberParseException $e) {
            \ZopNow\Arya\App\Application::log("Phone Number Validation failed with message: ".$e->getMessage(), ['phone' => $value], 'ERROR');
        }
        return $isValid;
    }

    public static function isEmail($value): bool
    {
        return is_string($value) && filter_var($value, FILTER_VALIDATE_EMAIL);
    }

    public static function isUrl($value): bool
    {
        $value = (parse_url($value, PHP_URL_SCHEME)) ? $value : 'http://' . $value;
        return is_string($value) && filter_var($value, FILTER_VALIDATE_URL);
    }

    public static function isText($value, array $extraData = []): bool
    {
        if (!is_string($value)) {
            return false;
        }
        if (sizeof($extraData)) {
            if (isset($extraData['min_length']) && (strlen($value) < $extraData['min_length'])) {
                return false;
            }
            if (isset($extraData['max_length']) && (strlen($value) > $extraData['max_length'])) {
                return false;
            }
        }
        return true;
    }

    public static function isBoolean($value): bool
    {
        $value = strtolower($value);
        switch ($value) {
            case "true":
            case "false":
            case "1":
            case "0":
                $isBool = true;
                break;
            default:
                $isBool = false;
        }
        return $isBool;
    }

    public static function isBinary($value): bool
    {
        return ($value === 0) || ($value === 1);
    }

    public static function isEnum($value, array $acceptableValues): bool
    {
        return in_array($value, $acceptableValues, true);
    }

    public static function isColor($value): bool
    {
        return preg_match("/^#([a-f0-9]{6}|[a-f0-9]{3})$/i", $value); // hex color validation only.
    }

    public static function isFile($filename, array $extraData = []): bool
    {
        if (!file_exists($filename)) {
            return false;
        }
        if (isset($extraData['min_size']) && filesize($filename) < $extraData['min_size']) {
            return false;
        }
        if (isset($extraData['max_size']) && filesize($filename) > $extraData['max_size']) {
            return false;
        }
        if (isset($extraData['mime_type'])) {
            $mimeType = trim(shell_exec("file --mime-type --brief ".escapeshellarg($filename)));
            $allowedMimeTypes = is_array($extraData['mime_type']) ? $extraData['mime_type']
                    : [$extraData['mime_type']];
            if (!in_array($mimeType, $allowedMimeTypes)) {
                return false;
            }
        }
        return true;
    }

    public static function isImage($filename, array $extraData = []): bool
    {
        if (!self::isFile($filename, $extraData)) {
            return false;
        }
        list ($width, $height) = getimagesize($filename);
        if ((isset($extraData['min_width']) && $width < $extraData['min_width'])
            ||
            (isset($extraData['max_width']) && $width > $extraData['max_width'])
            ||
            (isset($extraData['min_height']) && $height < $extraData['min_height'])
            ||
            (isset($extraData['max_height']) && $height > $extraData['max_height'])
        ) {
            return false;
        }
        return true;
    }

    public static function isQuantity($value, array $units): bool
    {
        $value = strtolower($value);
        $details = explode(" ", $value);
        if ((sizeof($details) !== 2) || !preg_match("/^([0-9]+x)?[0-9]+(\.[0-9]+)?$/", $details[0]) || (array_search($details[1], $units) === false)) {
            return false;
        } else {
            return true;
        }
    }

    public static function isArray($value, array $extraData = []): bool
    {
        if (!is_array($value) || empty($value)) {
            return false;
        }
        if (isset($extraData['item'])) {
            foreach ($value as $item) {
                $extraItemData = $extraData['item']['typeMeta'] ?? [];
                $isValid = self::validate($item, $extraData['item']['type'], $extraItemData);
                if (!$isValid) {
                    return false;
                }
            }
        }
        return true;
    }

    public static function isHash($value, $keys): bool
    {
        foreach($keys as $key) {
            if (!isset($value[$key])) {
                return false;
            }
        }
        return true;
    }
}
