<?php

use Phinx\Migration\AbstractMigration;

class UpdateThemeImages extends AbstractMigration
{

    public function change()
    {
        $data = [
            "theme-default" => '{"desktop":"https://s3.ap-south-1.amazonaws.com/zopnow-uploads/blue-20171213-070321.png",'
                . '"mobile":"http://via.placeholder.com/414x736",'
                . '"tablet":"http://via.placeholder.com/1024x768"}',
            "theme-ruby" => '{"desktop":"https://s3.ap-south-1.amazonaws.com/zopnow-uploads/red-20171213-070651.png",'
                . '"mobile":"http://via.placeholder.com/414x736",'
                . '"tablet":"http://via.placeholder.com/1024x768"}',
            "theme-emerald" => '{"desktop":"https://s3.ap-south-1.amazonaws.com/zopnow-uploads/green-20171213-070727.png",'
                . '"mobile":"http://via.placeholder.com/414x736",'
                . '"tablet":"http://via.placeholder.com/1024x768"}',
        ];
        foreach ($data as $themeName => $image) {
            $this->execute("update themes set image = '$image' where slug = '$themeName'");
        }
    }
}
