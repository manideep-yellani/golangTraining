<?php

use Phinx\Migration\AbstractMigration;

class BannerApi extends AbstractMigration
{
    public function up() {
        $endpoints = [
            [
                'url' => 'promo-service/banner',
                'allowed_methods' => json_encode(["GET", "POST","PUT","DELETE"]),
                "allow_enterprise_access" => 1
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('promo-service/banner')"), 'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoint_role` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('promo-service/banner')");
    }

}
