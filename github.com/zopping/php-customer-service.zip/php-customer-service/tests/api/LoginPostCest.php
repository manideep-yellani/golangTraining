<?php

class LoginPostCest
{
    protected static $endpoint = '/login';
    protected static $table = "customer";

    public function loginCustomerWithoutOrganizationId(ApiTester $I)
    {
        $I->wantToTest("Customers login without organization ID");
        $data = [
            "username" => "+919876543210",
            "password" => "password"
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - login : organization Id"]);
    }

    public function loginCustomerValid(ApiTester $I)
    {
        $I->wantToTest("Customers login with valid credentials");
        $data = [
            "username" => "+919876543210",
            "password" => "password",
            "organizationId" => 1,
            "remember" => 1
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseContainsJson(['name' => 'Vishal Kumar']);
        $I->dontSeeResponseContainsJson(['password' => 'a4aa5d018cf6a98582b9202fe35df83c']);
    }

    public function loginCustomerInvalidUsername(ApiTester $I)
    {
        $I->wantToTest("Customer login with invalid username");
        $data = [
            "username" => "+91987654321",
            "password" => "password",
            "organizationId" => 1
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseContainsJson(array('status' => "ERROR"));
        $I->seeResponseContainsJson(array("message"=> "Auth Exception: Invalid username"));
    }

    public function loginCustomerInvalidPassword(ApiTester $I)
    {
        $I->wantToTest("Customer login with invalid password");
        $data = [
            "username" => "+919876543210",
            "password" => "password1",
            "organizationId" => 1
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseContainsJson(array('status' => "ERROR"));
        $I->seeResponseContainsJson(array("message"=> "Auth Exception: Incorrect password"));
    }

    public function loginCustomerOrganizationMismatch(ApiTester $I)
    {
        $I->wantToTest("Customer login with an organization that they are not a customer of");
        $data = [
            "username" => "+919876543210",
            "password" => "password",
            "organizationId" => 10
        ];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::UNAUTHORIZED);
        $I->seeResponseContainsJson(array('status' => "ERROR"));
        $I->seeResponseContainsJson(array("message"=> "Auth Exception: Invalid username"));
    }
}