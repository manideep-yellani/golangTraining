<?php

namespace ZopNow\Hodor\Model;

class PickupLocation extends \ZopNow\Arya\Model\Base
{

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'organization_id', 'store_id'];
    protected $with = ['store'];

    public function exists($organizationId, $name)
    {
        $location = PickupLocation::where([['organization_id', $organizationId], ['name', $name]])->first();
        if (!is_null($location)) {
            if (!is_null($this->id) && $location->id == $this->id) {
                return false;
            }
            return true;
        }
        return false;
    }

    public function store()
    {
        return $this->belongsTo('\ZopNow\Hodor\Model\Store');
    }

}
