<?php

namespace ZopNow\CustomerService\Model;

class Guest extends \ZopNow\Arya\Model\Base
{
    protected $hidden = ['updated_at', "created_at","deleted_at", "organization_id"];

}

