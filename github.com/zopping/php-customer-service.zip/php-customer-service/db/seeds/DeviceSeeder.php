<?php

use Phinx\Seed\AbstractSeed;

class DeviceSeeder extends AbstractSeed
{
    /**
     * Seeding devices table
     *
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        $deviceData = [
            [
                'uuid' => "eab86a40-bfa9-4c30-b4b3-7e5c0ea060d4",
                "organization_id" => "1",
                "token" => "APA91bHx2GgNYjkqZ8WUfwCaAIr3X2eySkv3Hcje1wq1sPf8OHWlU4oROekIG6H1Clzs0Y2gWpDztD08Rhe7q_XrrBy6U8uEQ60OoCbewBINay3yaxQ1pDg",
                "customer_id" => "1",
                "metadata" => "{\"available\": true,\"platform\": \"Android\",\"version\": \"5.1.1\",\"uuid\": \"ebe7403f82b1d71e\",\"cordova\": \"4.1.1\",\"model\": \"victara\",\"manufacturer\": \"motorola\"}",
                "os" => "Android",
            ],
            [
                'uuid' => "eab86a40-bfa9-4c30-b4b3-7e5c0ea060d4",
                "organization_id" => "2",
                "token" => "APA91bGGkYdbJOqmwx7JCzBP5fPgTX4L2ViJ6Pvj9qHKCNv5GPAsfYvBH09Hoi35j5bQuFlt7-o9ZiTju48drpndtPPWYED9Q9Yp7LZNtz_TBFJdEWZNqbA",
                "customer_id" => "5",
                "metadata" => "{\"available\": true,\"platform\": \"Android\",\"version\": \"5.1.1\",\"uuid\": \"ebe7403f82b1d71e\",\"cordova\": \"4.1.1\",\"model\": \"victara\",\"manufacturer\": \"motorola\"}",
                "os" => "Android",

            ],
            [
                "uuid" => "fc9e717a-adc0-41e6-aa9a-a91807dd53ad",
                "organization_id" => "1",
                "token" => "APA91bFBl5OMO8FMFyscvxMI6sF4t_DQdEcFzETQrwVLsGG60_NOWoC2n7nmgFI1ozVLtRg8W52MN3bLYBQ6LLiICMK2ORpfIsCZTS4f_GgMoh5nVWqd_d4",
                "customer_id" => "1",
                "metadata" => '{"available":true,"platform":"Android","version":"4.2.2","cordova":"4.1.1","model":"A550s IPS","manufacturer":"XOLO"}',
                "last_notification_send_time" => "2017-10-02 14:07:54",
                "last_notification_click_time" => "2017-10-02 15:07:54",
                "os" => "Android",
            ]
        ];
        for ($i = 0; $i < 100; $i++) {
            $os = $faker->randomElement(['Android', 'iOS']);
            $deviceData[] = [
                "uuid" => $faker->uuid,
                "token" => $faker->unique()->sha256,
                "customer_id" => $faker->numberBetween(1, 106),
                "organization_id" => $faker->numberBetween(1, 4),
                "metadata" => '{"available": true,"platform":"' . $os . '","version":5.0.0"}',
                "os" => $os,
                "last_notification_send_time" => $faker->date() . " " . $faker->time(),
                "last_notification_click_time" => $faker->date() . " " . $faker->time(),
            ];
        }
        $this->table('devices')->insert($deviceData)->save();
    }
}
