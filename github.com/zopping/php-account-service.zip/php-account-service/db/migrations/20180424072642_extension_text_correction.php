<?php

use Phinx\Migration\AbstractMigration;

class ExtensionTextCorrection extends AbstractMigration
{

    public function up()
    {
        $variantDisableHelperText = "Products interface will not allow you to add variants to products | "
            . " Website will show only the products. None of the variants will be shown | "
            . " Product which earlier had multi variants will now get the price, stock etc from the first variant | "
            . " Pricing, discount, stock etc will be for products and not for variants";
        $this->execute(
            "update extensions set disable_helper_text = '$variantDisableHelperText'"
            . " where slug = 'MultiVariantSupport'"
        );
        $brandDisableHelperText = "Disables brand management interfaces | "
            . "Brand Association with products will be lost | "
            . "Brand filters for products on website will be disabled | "
            . "Brand specific pages would be removed from website and SEO | "
            . "Brand specific analytics would not be available";
        $this->execute(
            "update extensions set disable_helper_text = '$brandDisableHelperText'"
            . " where slug = 'MultiBrandSupport'"
        );
    }
}
