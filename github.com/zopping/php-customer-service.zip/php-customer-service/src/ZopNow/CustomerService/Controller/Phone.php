<?php

namespace ZopNow\CustomerService\Controller;

class Phone extends Base
{

    public function post()
    {
        $mandatoryFields = array("organizationId", "phone");
        $data = $this->getRequestParams($mandatoryFields, []);
        //Validating and fetching customerId
        $customerId = $this->getCustomerIdFromRequest();
        $organizationId = $data['organizationId'];
        /**
         *  @todo ISD code to be made mandatory to check for phone numbers
         *  Indian ISD code appended by default
         */
        //Check if phone number validation is required
        $organizationResponse = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/config/customers", 'GET', ['organizationId' => $organizationId]);
        $configData = json_decode($organizationResponse['body'], true)['data']['config']['customers'];
        $validate = (isset($configData['validatePhone']) && !$configData['validatePhone']) ? FALSE : TRUE;
        $phone = /*(strlen($data['phone']) == 10) ? "+91".$data['phone'] : */$data['phone'];
        if ($validate && !is_numeric($phone)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Phone");
        }
        $data['phone'] = ltrim($phone,"+");
        //validating if phone exists in this organization
        $customer = Customer::getFromPhone($data['phone'], $organizationId);
        $currentCustomer = \ZopNow\CustomerService\Model\Customer::where(["id" => $customerId])->first();
        //if duplicatePhonesAllowed do not throw an error
        $configResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", 'GET', ['organizationId' => $data["organizationId"]]);
        $configData = json_decode($configResponse['body'], true)['data']['customers'];
        $duplicatePhonesAllowed = (isset($configData['duplicatePhonesAllowed']) && !$configData['duplicatePhonesAllowed']) ? FALSE : TRUE;
        if (!$duplicatePhonesAllowed && !empty($customer)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Phone already exists");
        }
        $deletedPhone = \ZopNow\CustomerService\Model\Phone::onlyTrashed()->where([['phone', "=", $data['phone']],['customer_id', "=", $customerId]])->first();
        if (empty($deletedPhone)) {
            $data['customerId'] = $customerId;
            if (!($this->exists($data['phone'],$data['organizationId'], $customerId))){
                $this->add($data);
                if (empty($currentCustomer->default_phone_id)) {
                    $currentCustomer->default_phone_id = $this->data['id'];
                }
                $currentCustomer->updated_at = date("Y-m-d H:i:s");
                $currentCustomer->save();
            }
        } else {
            $deletedPhone->restore();
            $this->model = $this->modelClass::findOrFail($deletedPhone->id);
            if (empty($currentCustomer->default_phone_id)) {
                $currentCustomer->default_phone_id = $deletedPhone->id;
            }
            $currentCustomer->updated_at = date("Y-m-d H:i:s");
            $currentCustomer->save();
        }
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => ["phone" => $this->model->toArray()]
        );
        return new \ZopNow\Arya\View\Base($response);
    }

    public function delete()
    {
        $customerId = $this->getCustomerIdFromRequest();
        if (empty($this->data['id'])) {
              throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid id");
        }
        if ($this->model->customer_id != $customerId) {
            throw new \ZopNow\Arya\Exception\ModelException("Phone not found");
        }

        $defaultPhoneId = $this->model->customer->default_phone_id;
        if ($defaultPhoneId == $this->data['id']) {
            throw new \ZopNow\Arya\Exception\ValidationException("Default phone cannot be deleted");
        }
        //if count of verified phones is 1 then dont allow deletion
        $phones = $this->model->customer->phones;
        $deletable = false;
        if( (count($phones) - 1) != 0){ //if there is at least one phone number left,
            $deletable = true;           // we can delete the phone number
        }
        if (!$deletable) {
            throw new \ZopNow\Arya\Exception\ValidationException("Phone cannot be deleted as the customer has only 1 phone number");
        }
        parent::delete();
        $customer = $this->model->customer;
        $customer->updated_at = date("Y-m-d H:i:s");
        $customer->save();
        return (new \ZopNow\Arya\View\Base([
                'status' => "SUCCESS",
                'message' => 'Phone deleted successfully',
                'data' => NULL
            ])
        );
    }

    /**
     * To check whether this phone exists in this organization
     * @return boolean
     */
    public function exists($phone, $organizationId, $customerId = null)
    {
        return $this->model->exists($phone, $organizationId, $customerId);
    }

    public function getCustomerId()
    {
        return $this->model->customer_id;
    }
}
