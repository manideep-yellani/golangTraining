<?php

use Phinx\Migration\AbstractMigration;

class CustomerAddressPut extends AbstractMigration
{
    /**
     * Adds PUT method for customer-service/address endpoint
     */
    public function up()
    {
       $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['POST','PUT','DELETE'])
                . '\' where url = "customer-service/address"');

    }

    public function down()
    {
       $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
                . json_encode(['POST','DELETE'])
                . '\' where url = "customer-service/address"');

    }
}
