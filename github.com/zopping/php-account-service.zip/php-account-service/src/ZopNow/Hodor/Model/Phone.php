<?php

namespace ZopNow\Hodor\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class Phone extends \ZopNow\Arya\Model\Base
{

    public $timestamps = false;
    use SoftDeletes;
    protected $hidden = ['deleted_at', 'user_id'];

    public function getPhoneAttribute($value){
        return '+'.$value;
    }

    public function user()
    {
        return $this->belongsTo("\ZopNow\Hodor\Model\User");
    }

    public static function getUserFromPhone($phone)
    {
        $phoneObj = Phone::where('phone', $phone)->where(deleted_at, NULL)->first();
        if (!empty($phoneObj)) {
            return $phoneObj->user;
        }
        return null;
    }

    public function setPhoneAttribute($value)
    {
        $this->attributes['phone'] = ltrim($value, '+');
    }
}
