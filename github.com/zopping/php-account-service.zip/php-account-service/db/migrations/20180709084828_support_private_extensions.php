<?php

use Phinx\Migration\AbstractMigration;

class SupportPrivateExtensions extends AbstractMigration
{

    public function change()
    {
        $this->table("extensions")
            ->addColumn("is_private", "boolean", ['default' => 0])
            ->save();
    }

}
