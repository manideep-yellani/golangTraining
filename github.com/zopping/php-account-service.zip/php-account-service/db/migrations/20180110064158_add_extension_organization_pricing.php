<?php


use Phinx\Migration\AbstractMigration;

class AddExtensionOrganizationPricing extends AbstractMigration
{

    public function up()
    {
        $this->table("extension_organization")
             ->addColumn("pricing", "string", ['null' => true, 'after' => 'organization_id'])
             ->addColumn("pricing_rule", "string", ['null' => true, 'after' => 'pricing'])
             ->update();
    }

    public function down()
    {
        $this->table("extension_organization")
             ->removeColumn("pricing")
             ->removeColumn("pricing_rule")
             ->update();
    }
    
}
