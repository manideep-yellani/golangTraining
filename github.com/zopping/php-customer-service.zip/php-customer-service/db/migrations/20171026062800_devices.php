<?php

use Phinx\Migration\AbstractMigration;

class Devices extends AbstractMigration
{
    /**
     * Adding table to store information about devices using the application and
     * map devices to the corresponding customer.
     * 
     */
    public function change()
    {
        $this->table('devices')
            ->addColumn('uuid', 'string', array('limit' => 255))
            ->addColumn('organization_id', 'integer', array('limit'=> 11))
            ->addColumn('token', 'string', array('limit'=> 255))
            ->addColumn('customer_id','integer',array('limit'=> 11, "null" => true, 'default' => null))
            ->addColumn('last_notification_send_time', 'timestamp', array('null' => true,'default'=> null))
            ->addColumn('last_notification_click_time', 'timestamp', array('null' => true,'default'=> null))
            ->addColumn('metadata','text',array("null" => true))
            ->addColumn('os','char',array('limit' => 16, "null" => true, "default" => null))
            ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addIndex(['uuid','organization_id'],['name'=>'idx_device_organization','unique'=>'true'])
            ->addIndex(['token'],['name'=>'idx_token','unique'=>'true'])
            ->addForeignKey("customer_id", "customers", "id", array('constraint' => 'fk_customers_device_organization','delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->addIndex(['os'],['name' => 'idx_devices_os'])
            ->create();
        }
}
