<?php

namespace ZopNow\CustomerService\Model;

class Phone extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'customer_id','customer'];

    public function exists($phone, $organizationId, $customerId = null) {
        $phoneQuery = Phone::where(['phone' => $phone])
        ->join('customers', "phones.customer_id", "=", "customers.id")
        ->where("customers.organization_id", "=", $organizationId);
        if (!empty($customerId)) {
            $phoneQuery = $phoneQuery->where('customers.id' , '=', $customerId);
        }
        return $exists = $phoneQuery->exists();
    }

    public function customer()
    {
        return $this->belongsTo("\ZopNow\CustomerService\Model\Customer");
    }

    public function getPhoneAttribute($value)
    {
        return '+'.$value;
    }

    public function setPhoneAttribute($value)
    {
        $this->attributes['phone'] = ltrim($value, '+');
    }

}