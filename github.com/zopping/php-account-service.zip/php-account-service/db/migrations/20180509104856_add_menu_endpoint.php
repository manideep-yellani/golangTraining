<?php

use Phinx\Migration\AbstractMigration;

class AddMenuEndpoint extends AbstractMigration
{

    public function up()
    {
        $endpointData = [
            [
                "url" => "catalogue-service/menu",
                "allowed_methods" => json_encode(['GET'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'catalogue-service/menu'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `name` = 'Universal Key' and organization_id is null")['id'];
        $this->insert('endpoint_developer_permissions', array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1
        ));
    }

    public function down()
    {
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'catalogue-service/menu'")['id'];
        $this->execute('DELETE FROM `endpoint_developer_permissions` '
            . 'where `endpoint_id`= "' . $endpointId . '"');
        $this->execute('DELETE FROM `endpoint_user_permissions`'
            . ' where `endpoint_id`= "' . $endpointId . '"');
        $this->execute("DELETE FROM `endpoints` where id = $endpointId");
    }

}
