<?php

namespace ZopNow\Hodor\Controller;

class ResetPassword extends \ZopNow\Arya\Controller\Base
{

    public function post()
    {
        $data = $this->getRequestParams(['username']);
        if (\ZopNow\Hodor\Helper\Validator::isPhone($data['username'])) {
            $user = (new User(['phone' => $data['username']]))->getFromPhone();
        } elseif (\ZopNow\Hodor\Helper\Validator::isEmail($data['username'])) {
            $user = (new User(['email' => $data['username']]))->getFromEmail();
        } else {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid username");
        }
        $parameters = ['id' => $user['id']];
        if (!empty($this->countryIsoCode)) {
            //If the country code has been passed in parameters, forwarding it to user controller
            $parameters['countryIsoCode'] = $this->countryIsoCode;
        }
        if (!empty($this->langIsoCode)) {
            //If the language code has been passed in parameters, forwarding it to user controller
            $parameters['langIsoCode'] = $this->langIsoCode;
        }
        return (new User($parameters))->resetPassword();
    }
}
