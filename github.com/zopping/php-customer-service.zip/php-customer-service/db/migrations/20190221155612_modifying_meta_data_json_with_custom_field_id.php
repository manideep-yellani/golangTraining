<?php


use Phinx\Migration\AbstractMigration;

class ModifyingMetaDataJsonWithCustomFieldId extends AbstractMigration
{
    public function up()
    {
        //customers
        $rows = $this->fetchAll("SELECT * from config_service.custom_fields where entity='Customer'");
        $mapKeyID = $this->getMapKeyId($rows);
        $page = 1;
        $limit = 1000;
        while (true) {
            $offset = ($page-1) * $limit;
            $rows = $this->fetchAll("SELECT id,organization_id,meta_data from customers where meta_data is not null order by id asc limit $limit offset $offset");
            if (sizeof($rows) == 0) {
                break;
            }
            $this->updateMetaData($rows, "customers", $mapKeyID);
            $page++;
        }
        //addresses
        $rows = $this->fetchAll("SELECT * from config_service.custom_fields where entity='Address'");
        $mapKeyID = $this->getMapKeyId($rows);
        $page = 1;
        $limit = 1000;
        while (true) {
            $offset = ($page-1) * $limit;
            $rows = $this->fetchAll("SELECT addresses.id,customers.organization_id,addresses.meta_data from addresses inner join customers where addresses.customer_id=customers.id and addresses.meta_data is not null order by addresses.id asc limit $limit offset $offset");
            if (sizeof($rows) == 0) {
                break;
            }
            $this->updateMetaData($rows, "addresses", $mapKeyID);
            $page++;
        }
    }

    //create a map of map[organizationID][key]=[id]
    private function getMapKeyId($rows)
    {
        $mapKeyID = array();
        foreach ($rows as $row) {
            $orgID = $row['organization_id'];
            $key = $row['key'];
            $mapKeyID[$orgID][$key] = $row['id'];
        }
        return $mapKeyID;
    }

    private function updateMetaData($rows, $tableName, $mapKeyID)
    {
        foreach ($rows as $row) {
            $metaData = $row['meta_data'];
            $orgID = $row['organization_id'];
            $id = $row['id'];
            if (isset($metaData)) {
                $mp = json_decode($metaData, true);
                foreach ($mp as $key => $value) {
                    if (isset($mapKeyID[$orgID][$key])) {
                        $mp[$mapKeyID[$orgID][$key]] = $value;
                    }
                    unset($mp[$key]);
                }
                if (empty($mp)) {
                    $this->execute('update ' . $tableName . ' set meta_data= NULL  where id=' . $id);
                } else {
                    $mp = json_encode($mp);
                    \ZopNow\Arya\DB\MySql::update('update ' . $tableName . ' set meta_data= \'' . \ZopNow\Arya\DB\MySql::escape($mp) . '\'  where id=' . $id);
                }
            }
        }
    }

    public function down()
    {
        //customers
        $rows = $this->fetchAll("SELECT * from config_service.custom_fields where entity='Customer'");
        $mapIDkey = $this->getMapIdKey($rows);
        $rows = $this->fetchAll("SELECT id,organization_id,meta_data from customers");
        $this->updateMetaData($rows, "customers", $mapIDkey);
        //addresses
        $rows = $this->fetchAll("SELECT * from config_service.custom_fields where entity='Address'");
        $mapIDkey = $this->getMapIdKey($rows);
        $rows = $this->fetchAll("SELECT addresses.id,customers.organization_id,addresses.meta_data from addresses inner join customers where addresses.customer_id=customers.id");
        $this->updateMetaData($rows, "addresses", $mapIDkey);
    }

    //create a map of map[organizationID][id]=[key]
    private function getMapIdKey($rows)
    {
        $mapIDKey = array();
        foreach ($rows as $row) {
            $orgID = $row['organization_id'];
            $id = $row['id'];
            $mapIDKey[$orgID][$id] = $row['key'];
        }
        return $mapIDKey;
    }
}
