<?php

use Phinx\Migration\AbstractMigration;

class AddOrderCountEndpoint extends AbstractMigration
{
    public function up() {
        $endpoints = [
            [
                'url' => 'order-service/order-count',
                'allowed_methods' => json_encode(["GET"])
            ]
        ];
        $this->insert('endpoints', $endpoints);
    }

    public function down() {
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `url` in "
                    . "('order-service/order-count')"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("delete from endpoints where url in ('order-service/order-count')");
    }
}
