<?php

namespace ZopNow\CustomerService\Controller;

class Stats extends \ZopNow\Arya\Controller\Base
{
    public function get()
    {
        $mandatoryFields = ["organizationId", "startDate"];
        $optionalFields = ["endDate"];
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);
        $startDate = $data['startDate'];
        $endDate = $data['endDate'] ?? date("Y-m-d");
        // Validating startDate and endDate
        if (!\ZopNow\Arya\Utility\Validator::isDate($startDate) || !\ZopNow\Arya\Utility\Validator::isDate($startDate)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Date format");
        }
        if ($startDate >= $endDate) {
            throw new \ZopNow\Arya\Exception\ValidationException("Start Date should be lesser than the end Date");
        }
        $requestData = ["organizationId" => $data['organizationId'], "startDate" => $data['startDate'], "endDate" => $endDate];
        $response['stats'] = (new Customer($requestData))->getStats();

        return (new \ZopNow\Arya\View\Base([
               'code' => 200,
               'status' => "SUCCESS",
               'data' => $response
           ])
        );
    }
}
