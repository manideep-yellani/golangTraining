<?php

use Phinx\Migration\AbstractMigration;

class EntityMetaData extends AbstractMigration
{
    private $slug = "EntityMetaData";

    public function up()
    {
        $enableHelperText  = "Allows user to set the metadata acceptable for various entities | "
                . "If order entity config is set, customers can provide additional information while placing orders | "
                . "If customer/product entity config is set, user can provide additional information while adding/editing the same";
        $disableHelperText = "User can not set the metadata properties acceptable| "
                . "User/Customers will not be able to provide any additional entity information";
        $data = [
            "name" => "Entity Metadata",
            "slug" => $this->slug,
            "description" => "Provides an option to accept custom metadata/notes/comments for various entities",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE"
        ];
        $this->insert('extensions', $data);
    }

    public function down()
    {
        $this->execute("DELETE extension_organization.* from `extension_organization` inner join extensions on extensions.id = extension_id and `slug` ='$this->slug'");
        $this->execute("DELETE from `extensions` where `slug` ='$this->slug'");
    }
}