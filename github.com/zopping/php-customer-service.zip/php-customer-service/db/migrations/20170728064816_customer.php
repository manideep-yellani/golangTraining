<?php

use Phinx\Migration\AbstractMigration;

class Customer extends AbstractMigration
{
    /**
     * Database schema for customers, phones , emails and addresses table
     */
    public function change()
    {
        $this->table("customers")
             ->addColumn('name', 'string', array('limit' => 200))
             ->addColumn('image', 'string', array('limit' => 500, 'null' => true))
             ->addColumn('organization_id', 'integer', array('limit'=> 11))
             ->addColumn('password', 'string', array('limit' => 45))
             ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
             ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
             ->addIndex(['organization_id'], ['name' => 'orgnization'])
             ->create();

        $this->table("phones")
             ->addColumn("customer_id",'integer')
             ->addColumn("phone", 'biginteger', array('limit' => 12,'signed' => false))
             ->addColumn("status", 'enum', ['values' => ['NEW', 'VERIFIED'], 'default' => 'NEW'])
             ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
             ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
             ->addColumn('deleted_at', 'timestamp', array('null' => true))
             ->addIndex(['customer_id', 'phone'], ['name' => 'customer_phone', 'unique' => true])
             ->addForeignKey("customer_id", "customers", "id", array('constraint' => 'fk_phones_customers','delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
             ->create();

        $this->table("emails")
             ->addColumn("customer_id",'integer')
             ->addColumn('email', 'string', array('limit' => 100))
             ->addColumn("status", 'enum', ['values' => ['NEW', 'VERIFIED'], 'default' => 'NEW'])
             ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
             ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
             ->addColumn('deleted_at', 'timestamp', array('null' => true))
             ->addIndex(['customer_id', 'email'], ['name' => 'customer_email', 'unique' => true])
             ->addForeignKey("customer_id", "customers", "id", array('constraint' => 'fk_emails_customers','delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
             ->create();

        $this->table("addresses")
             ->addColumn("customer_id",'integer')
             ->addColumn('address', 'string', array('limit' => 500))
             ->addColumn('landmark', 'string', array('limit' => 500, 'null' => true))
             ->addColumn('pincode', 'integer', array('limit' => 6, 'null' => true))
             ->addColumn('city', 'string', array('limit' => 200))
             ->addColumn('latitude', 'decimal', array('precision' => 16, 'scale' => 13, 'null' => true))
             ->addColumn('longitude', 'decimal', array('precision' => 16, 'scale' => 13, 'null' => true))
             ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
             ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
             ->addColumn('deleted_at', 'timestamp', array('null' => true))
             ->addForeignKey("customer_id", "customers", "id", array('constraint' => 'fk_addresses_customers','delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
             ->create();
    }
}
