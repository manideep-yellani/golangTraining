<?php

use Phinx\Migration\AbstractMigration;

class ImageUploadDeveloperKey extends AbstractMigration
{

    public function change()
    {
        $token       = 'f64ff4c2-e1ef-4559-825e-f72d0da011c9';
        $data        = [[
            'name' => 'Cloud Functions Image Upload',
            'token' => $token
        ]];
        $this->insert('developers', $data);
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `token` = '$token'")['id'];
        $endpoints   = ['media-service/image-upload' => ["POST"], 'catalogue-service/product' => [
                "GET", "PUT"]];
        foreach ($endpoints as $endpoint => $methods) {
            $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = '$endpoint'")['id'];
            foreach ($methods as $method) {
                $this->insert('endpoint_developer_permissions',
                    array(
                    "endpoint_id" => $endpointId,
                    "developer_id" => $developerId,
                    "method" => $method,
                    "has_permission" => 1
                ));
            }
        }
    }
}