<?php

namespace ZopNow\CustomerService\Controller;

class Guest extends \ZopNow\Arya\Controller\Base
{
    /**
     * API to support Guest checkout. If the customer already exists for given phone/email
     * then we will return the details.
     * Else we will create a new account for the customer.
     */
    public function post() {
        $mandatoryFields = array("name", "organizationId");
        $optionalFields  = array("clientId", "address", "addressMetaData", "metaData", "landmark", "pincode", "city", "state", "countryCode", "longitude", "latitude", "phone", "email", "clientAddressId", "password");
        $data = $this->getRequestParams($mandatoryFields, $optionalFields);
        if (!empty($data['clientId'])) {
            $oldCustomerFromClientId = Customer::getFromClientId($data['clientId'], $data['organizationId']);
        }
        if (empty($data['phone']) && empty($data['email'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Atleast one of phone, email must be provided");
        }

        if(empty(trim($data["state"],' '))){
            $data["state"] = null;
        }
        if(empty(trim($data["countryCode"],' '))){
            $data["countryCode"] = $this->getCountryCode($data["organizationId"]);
        }
        $pincode = trim($data["pincode"],' ');
        if(empty($pincode)){
            $data["pincode"] = null;
        }

        $configResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", 'GET', ['organizationId' => $data["organizationId"]]);
        $configData = json_decode($configResponse['body'], true)['data']['customers'];
        $duplicatePhonesAllowed = (isset($configData['duplicatePhonesAllowed']) && !$configData['duplicatePhonesAllowed']) ? FALSE : TRUE;
        if (!$duplicatePhonesAllowed && isset($data['phone'])) {
            $oldCustomerFromPhone = Customer::getFromPhone($data['phone'], $data['organizationId']);
        }
        if (isset($data['email'])) {
            $oldCustomerFromEmail = Customer::getFromEmail($data['email'], $data['organizationId']);
        }
        $oldCustomer = $oldCustomerFromClientId ?? ($oldCustomerFromEmail ?? $oldCustomerFromPhone);
        $customerId = $oldCustomer->id ?? null;
        \ZopNow\Arya\DB\MySql::startTransaction();
        if (empty($oldCustomer)) {
            // create a new account for given phone,email
            $requestData = $this->data;
            $requestData['isSignup'] = 0;
            $customerId = (new Customer($requestData))->post()->getData()['data']['customer']['id'];
        } else if (empty($oldCustomerFromPhone) && !empty ($data['phone'])){
            // add this new phone to oldCustomer
            $phoneData = ["customerId" => $customerId, "organizationId" => $data['organizationId'],
                "phone" => $data['phone']];
            (new Phone($phoneData))->post();
        } else if (empty($oldCustomerFromEmail) && !empty ($data['email'])) {
            // add this new email to oldCustomer
            $emailData = ["customerId" => $customerId, "organizationId" => $data['organizationId'],
                "email" => $data['email']];
            (new Email($emailData))->post();
        } else if (!empty($data['phone']) && !empty($data['email']) && ($oldCustomerFromEmail['id'] != $oldCustomerFromPhone['id'])) {
            // Phone and email belongs to different customers
            throw new \ZopNow\Arya\Exception\ValidationException("Phone and Email already exists");
        }

        //updating name/clientId/metaData for older customer
        if (!empty($oldCustomer)) {
            $editRequestData = ["name" => $data['name'], "id" => $customerId, "organizationId" => $data['organizationId']];
            if (!empty($data['clientId'])) {
                $editRequestData["clientId"] = $data['clientId'];
            }
            if (!empty($data['metaData'])) {
                $editRequestData["metaData"] = $data['metaData'];
            }
            (new Customer($editRequestData))->put();
        }

        $defaultAddress = null;
        //update default address
        if (!empty($oldCustomer)) {
            $addressData = ["customerId" => $customerId, "organizationId" => $data['organizationId']];
            $addressDetails = (new Address($addressData))->get()->getData()['data']['address'];
            $newAddress = $data['address'];
            foreach($addressDetails as $addressDetail) {
                if(strtolower($addressDetail['address']) == strtolower($newAddress)){
                    $defaultAddress = $addressDetail;
                    break;
                }
            }

            if(!isset($defaultAddress)) {
                $newAddress = null;
                if (!empty($data['address'])) {
                    $latitude    = $data['latitude'] ?? null;
                    $longitude   = $data['longitude'] ?? null;
                    $addressData = ["customerId" => $customerId, "organizationId" => $data['organizationId'],
                        "address" => $data['address'], "landmark" => $data['landmark'] ?? null,
                        "pincode" => $data['pincode'] ?? null, "city" => $data['city'], "state" => $data['state'] ?? null, "countryCode" => $data['countryCode'] ?? $this->getCountryCode($data["organizationId"]),
                        "metaData" => $data['addressMetaData'] ?? null,
                        "latitude" => $latitude, "longitude" => $longitude, 'clientId' => $data['clientAddressId']?? null,
                        "verifyAddress" => FALSE
                    ];
                    $newAddress = (new Address($addressData))->post()->getData()['data']['address'];
                    $defaultAddress = $newAddress;
                }
            }
        } else {
            $addressData = ["customerId" => $customerId, "organizationId" => $data['organizationId']];
            $addressDetails = (new Address($addressData))->get()->getData()['data']['address'];
            if (sizeof($addressDetails) > 0) {
                $defaultAddress = $addressDetails[0];
            }
        }

        \ZopNow\Arya\DB\MySql::commit();

        $customerController = new Customer(['id' => $customerId, 'organizationId' => $data['organizationId']]);
        $details = $customerController->getDetails();
        $details['customer']['defaultAddress'] = $defaultAddress;

        $response = array(
            "code" => 200,
            "status" => "SUCCESS",
            "data" => $details
        );
        return new \ZopNow\Arya\View\Base($response);
    }
    private function getCountryCode($organizationId)
    {
        $orgData = \ZopNow\Arya\Utility\MicroService::callService(
            "go-account-service", "/organization", "GET", array("id" => $organizationId)
        );

        return json_decode($orgData['body'], true)['data']['organization']['countryCode'];
    }
}
