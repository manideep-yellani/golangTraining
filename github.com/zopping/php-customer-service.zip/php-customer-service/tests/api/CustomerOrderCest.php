<?php

class CustomerOrderCest extends BaseCest
{
    protected static $endpoint = '/customer';

    public function listCustomerOrders(ApiTester $I)
    {
        $I->wantTo('Get list of orders for this customer');
        $I->sendGET(static::$endpoint."/1/order?organizationId=1");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => array(
                    "count" => "integer",
                    "offset" => "integer",
                    "limit" => "integer",
                    "order" => "array"
                )
            ));
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function listCustomerWithNoOrders(ApiTester $I)
    {

        $I->wantTo('Get list of orders for customer with id as 1');
        $I->sendGET(static::$endpoint."/1/order?organizationId=8");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => "array"
            ));
            $I->seeResponseContainsJson([
                "status" => "SUCCESS",
                "message" => "OK",
                "data" => array(
                    "count" => 0,
                    "order" => []
                )
            ]);
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function listCustomerOrdersWithPagination(ApiTester $I)
    {

        $I->wantTo('Test pagination for order listing');
        $I->sendGET(static::$endpoint."/1/order?organizationId=1");
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $I->seeResponseMatchesJsonType(array(
                "status" => "string",
                "message" => "string",
                "data" => "array"
            ));
            $I->dontSeeResponseContainsJson([
                "status" => "SUCCESS",
                "message" => "OK",
                "data" => array(
                   "order" => []
                )
            ]);
            //page 2
            $I->sendGET(static::$endpoint."/1/order?organizationId=1&page=2");
            $I->dontSeeResponseContainsJson([
                "status" => "SUCCESS",
                "message" => "OK",
                "data" => array(
                    "order" => []
                )
            ]);
            //page 4
            $I->sendGET(static::$endpoint."/1/order?organizationId=1&page=4");
            $I->seeResponseContainsJson([
                "status" => "SUCCESS",
                "message" => "OK",
                "data" => array(
                    "order" => []
                )
            ]);
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function listOrderInvalidCustomerId(ApiTester $I)
    {
        $I->wantTo('Get list of orders for customer with invalid id');
        $I->sendGET(static::$endpoint."/10000/order");
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Model Exception: Order with id: 10000 not found"]);
    }

    public function listOrderWithoutCustomerId(ApiTester $I)
    {
        $I->wantTo('Get list of orders for customer without passing an id');
        $I->sendGET(static::$endpoint."//order");
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Please pass a valid ID"]);
    }

    public function listOrderWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get list of orders for customer without passing an organization id');
        $I->sendGET(static::$endpoint."/1/order");
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - order : organization Id"]);
    }

    public function listOrderWithGivenOrderNumber(ApiTester $I)
    {
        $I->wantTo('Test search by order number');
        $I->sendGET(static::$endpoint."/1/order?organizationId=1");
        //customer 1 has more than 20 orders in organization id =1 (During seeding)
        $I->seeResponseIsJson();
        try {
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $count = $I->grabDataFromResponseByJsonPath('$.data.count')[0];
            $I->assertGreaterThan(20, $count);

            //customer 3 has an order with reference_number 2 in organiztion id =2 (During seeding)
            $I->sendGET(static::$endpoint."/3/order?organizationId=2&referenceNumber=2");
            $I->seeResponseIsJson();
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $count = $I->grabDataFromResponseByJsonPath('$.data.count')[0];
            codecept_debug($count);
            $I->assertEquals(1, $count); //there can be only 1 order with this reference number
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }
}