<?php

use Phinx\Migration\AbstractMigration;

class MarketingExtension extends AbstractMigration
{
  public function up()
    {
        $slug = 'Marketing';
        $data = [
            "name" => "Marketing Support",
            "slug" => "$slug",
            "description" => "Allows you to engage with your customer base to promote your product through various methods and channels like campaigns(via SMS, Email) and coupons.",
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$slug'")['id'];
        $this->execute("insert into extension_organization(extension_id, organization_id) select $extensionId, id from organizations where is_enterprise = 0 and deleted_at is null");
    }

    public function down()
    {
        $slug = 'Marketing';
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$slug'")['id'];
        $this->query("DELETE from extension_organization where extension_id='$extensionId'");
        $this->execute("DELETE from `extensions` where `slug` = '$slug'");
    }
}
