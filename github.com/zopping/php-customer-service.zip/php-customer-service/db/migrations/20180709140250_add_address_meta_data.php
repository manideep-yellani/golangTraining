<?php


use Phinx\Migration\AbstractMigration;

class AddAddressMetaData extends AbstractMigration
{
    public function up()
    {
        $this->table('addresses')
             ->addColumn('meta_data', 'string', array('limit' => 500, 'null' => true))
             ->save();
    }

    public function down()
    {
        $this->table('addresses')
             ->removeColumn('meta_data')
             ->save();
    }
}
