<?php

namespace ZopNow\CustomerService\Controller;

class ChangePassword extends \ZopNow\Arya\Controller\Base
{

    public function post()
    {
        $data = $this->getRequestParams(['oldPassword', 'newPassword'], ['customer','customerId']);
        $customerId = empty($data['customer']) ? $data['customerId'] : json_decode($data['customer'], true)['id'] ?? null;
        if (empty($customerId)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please pass a valid Customer object or customerId");
        }
        return (new Customer(['id' => $customerId, 'oldPassword' => $data['oldPassword'],
            'newPassword' => $data['newPassword']]))->changePassword();
    }
}

