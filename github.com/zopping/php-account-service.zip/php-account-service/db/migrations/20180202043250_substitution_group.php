<?php

use Phinx\Migration\AbstractMigration;

class SubstitutionGroup extends AbstractMigration
{
    public function up()
    {
        $enableHelperText = "Allows user to create groups of products which can be substituted in case of"
            . " unavailability of one of them |"
            . " Can set a price deviation to substitute products whose price lie in that range |";

        $disableHelperText = "Deletes all substitution groups |"
            . " Out of stock products will not be suggested with replacements";

        $data = [
            "name" => "Substitution Groups",
            "slug" => "SubstitutionGroups",
            "description" => "Facilitates the organization to support substitutions of products",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'SubstitutionGroups'")['id'];
        $endpointData = [
            ["url" => "catalogue-service/substitution-group","allowed_methods" => json_encode(['GET','PUT','POST']), 'extension_id' => $extensionId]
        ];
        $this->insert('endpoints', $endpointData);
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'catalogue-service/substitution-group'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `token` = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $this->insert('endpoint_developer_permissions', array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1
        ));
    }

    public function down()
    {
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'catalogue-service/substitution-group'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `token` = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $this->execute('DELETE FROM `endpoint_developer_permissions` 
            where `developer_id` = "'.$developerId.'" and `endpoint_id`= "'.$endpointId.'"');
        $this->execute('DELETE from `endpoints` where `url` = \'catalogue-service/substitution-group\'');
        $this->execute('DELETE from `extensions` where `slug` = "SubstitutionGroups"');
    }
}
