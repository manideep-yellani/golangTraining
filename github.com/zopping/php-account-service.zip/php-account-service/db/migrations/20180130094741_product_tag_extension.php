<?php

use Phinx\Migration\AbstractMigration;

class ProductTagExtension extends AbstractMigration
{
    public function up()
    {
        $enableHelperText = "Products interface will allow user to add product tags to their products | "
            . "Interface to view product tags and corresponding products | "
            . "Website will support tag pages with list of products | "
            . "Website will now support filter on product collection based on tags";

        $disableHelperText = "Products interface will not allow you to add product tags | "
            . "There won't be an interface to view product tags and corresponding products | "
            . "Website will not support tag pages | "
            . "Website will not support tag-based filters on product collection";

        $data = [
            "name" => "Product Tag Support",
            "slug" => "ProductTagSupport",
            "description" => "Facilitates the organization to support tags for their products",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => 'FREE'
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'ProductTagSupport'")['id'];
        $this->query("UPDATE endpoints SET 
            `allowed_methods`='" . json_encode(['GET','POST','PUT','DELETE']) . "', 
            `extension_id`='".$extensionId."' WHERE `url` = 'catalogue-service/tag'");
    }

    public function down()
    {
        $this->query("UPDATE endpoints SET 
            `allowed_methods`='" . json_encode(['GET','POST','PUT']). "', 
            `extension_id`=NULL WHERE `url` = 'catalogue-service/tag'");
        $this->execute('DELETE from `extensions` where `slug` = "ProductTagSupport"');
    }

}