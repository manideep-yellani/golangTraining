<?php

use Phinx\Migration\AbstractMigration;

class ConfigBooleanValueFixes extends AbstractMigration
{
    /**
     * All existing configuration values that have boolean values must be updated
     *  to store the json encoded boolean value
     */
    public function up()
    {
        $configKeysToBeUpdated = [
            '"catalogue.hasMultipleBrands"',
            '"catalogue.hasMultipleVariants"',
            '"inventory.taxExclusivePrice"',
            '"social.hasFacebookLogin"',
            '"social.hasTwitterLogin"',
            '"social.hasGooglePlusLogin"'
        ];
        $rowsToBeUpdated = $this->fetchAll(
            "select id, value from configurations where `key` in ("
            . implode(',', $configKeysToBeUpdated)
            . ")"
        );
        $trueValues = ['true', 'TRUE', 1, '1'];
        foreach ($rowsToBeUpdated as $row) {
            $updatedValue = in_array($row['value'], $trueValues) ? json_encode(true) : json_encode(false);
            $this->execute(
                "update configurations set value = '$updatedValue' where id = " . $row['id']
            );
        }
    }

    public function down()
    {
    }

}
