<?php


namespace ZopNow\Hodor\Controller;


use ZopNow\Arya\Controller\ModelController;
use ZopNow\Arya\Exception\ModelException;
use ZopNow\Arya\Exception\ValidationException;
use ZopNow\Arya\View\Base;

class Extension extends ModelController
{
    protected $allowNonPaginated = true;
    protected static $filterableFields = ['organizationId', 'name', 'status', 'is_private'];
    protected $extension = null;
    const EXTENSION_NAMESPACE = '\\ZopNow\\Hodor\\Extension';
    const STORE_EXTENSION_SLUG = 'MultiStoreSupport';

    public function __construct(array $data = [])
    {
        if(empty($data['id']) && !empty($data['slug'])){
            $id = \ZopNow\Hodor\Model\Extension::getIdFromSlug($data['slug']);
            if (empty($id)) {
                throw new ModelException("Extension with slug ".$data['slug']." not found");
            }
            $data['id'] = $id;
        }
        parent::__construct($data);
        if(!empty($this->model)){
            $className = self::EXTENSION_NAMESPACE."\\".$this->model->slug;
            if(class_exists($className)){
                $this->extension = new $className($data['organizationId'], []);
            }
        }
    }

    public function get()
    {
        if (!empty($this->data['id'])) {
            $data = $this->getDetails();
        } else {
            if (!empty($this->data['name'])) {
                $this->data['name'] = $this->data['name'] . "*";
            }
            if (!isset($this->data['isPrivate'])) {
                $this->data['isPrivate'] = false;
            }

            $list = $this->getList();
            $data = $this->getListData($list);
            $data = $this->addIncludeDataToExtension($data);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new Base($response);
    }

    protected function addIncludeDataToExtension($data) {
        $includePrerequisites = in_array('prerequisites', $this->data['include']);
        foreach ($data['extension'] as &$extension) {
            if (empty($this->data['organizationId'])) {
                $extension['prerequisites'] = null;
            } else {
                if ($includePrerequisites && $extension['status'] == 'DISABLED') {
                    $className = self::EXTENSION_NAMESPACE."\\".$extension['slug'];
                    if (class_exists($className)) {
                        $extension['prerequisites'] = (new $className($this->data['organizationId'], []))->configurePrerequisites($extension['prerequisites']);
                    }
                } else {
                    $extension['prerequisites'] = null;
                }
            }
        }

        return $data;
    }

    public function getDetails(){
        if (empty($this->data['id'])) {
            throw new \ZopNow\Arya\Exception\ControllerException("Please pass the id of the organization");
        }
        $details = $this->model->toArray();
        unset($details['organization']);
        $allowedConfig = $this->fetchConfigFile(lcfirst($this->model->slug).".json");
        $configs = [];
        if (!empty($allowedConfig)) {
            foreach ($allowedConfig['configs'] as $key => $config) {
                $configs[$config['name']] = ['typeMeta' => ($config['type'] == 'enum')? $config['typeMeta'] : null,
                    'default' => $config['default'] ?? null, 'required' => $config['required']];
            }
        }
        $details['allowedConfig'] = $configs;
        $details['isConfigurable'] = false;
        if (!is_null($this->organizationId)) {
            $details['status'] = $this->model->status($this->organizationId);
            if ($details['status'] == 'ENABLED' && !empty($allowedConfig)) {
                $details['isConfigurable'] = true;
                $isMultiStoreExtensionEnabled = false;
                if ($this->model->is_store_configurable) {
                    $multiStoreExtension = \ZopNow\Hodor\Model\Extension::where([['slug', self::STORE_EXTENSION_SLUG]])->first();
                    if(!empty($multiStoreExtension)) {
                        $status = $multiStoreExtension->status($this->organizationId);
                        $isMultiStoreExtensionEnabled = ($status == 'ENABLED')? true : false;
                    }
                }
                $config = $this->getConfigDetails(lcfirst($this->model->slug).".json", $allowedConfig, $isMultiStoreExtensionEnabled);
                $storeSpecificConfigs = $config['storeSpecificConfig'] ?? [];
                $stores = array_keys($storeSpecificConfigs);
                foreach ($allowedConfig['configs'] as $row) {
                    if (!isset($config['globalConfig'][$row['name']])) {
                        $config['globalConfig'][$row['name']] = null;
                    }
                    foreach ($stores as $store) {
                        if (!isset($config['storeSpecificConfig'][$store][$row['name']])) {
                            $config['storeSpecificConfig'][$store][$row['name']] = null;
                        }
                    }
                }
                if (!empty($config['storeSpecificConfig'])) {
                    foreach ($config['storeSpecificConfig'] as $storeId => $storeConfig) {
                        $config['storeSpecific'][] = array_merge($storeConfig,['storeId' => $storeId]);
                        unset($config['storeSpecificConfig'][$storeId]);
                    }
                    unset($config['storeSpecificConfig']);
                }
                $details['config'] = $config;
            }

            if (in_array('prerequisites', $this->include)) {
                $className = self::EXTENSION_NAMESPACE."\\".$details['slug'];
                if (class_exists($className)) {
                    $details['prerequisites'] = (new $className($this->organizationId, []))->configurePrerequisites($details['prerequisites']);
                }
            } else {
                $details['prerequisites'] = null;
            }
        } else {
            $details['prerequisites'] = null;
        }

        $details['dependantOn'] = $this->model->dependant_on;
        $startTime = $this->startTime;
        $endTime = $this->endTime;
        if (!empty($startTime) && !empty($endTime)) {
            $details['price'] = ['cost' => 0,  'metaData' => null];
            if (!is_null($this->extension)) {
                $startTime = date('Y-m-d H:i:s', strtotime($startTime));
                $endTime = date('Y-m-d H:i:s', strtotime($endTime));
                if (strtotime($startTime) > strtotime($endTime)) {
                    throw new ValidationException("Invalid time range");
                }
                $pricingRule = $this->model->organization->toArray()[0]['pivot']['pricing_rule'] ?? $this->model->pricing_rule;
                $details['price'] = $this->extension->getBillingAmount($startTime, $endTime, json_decode($pricingRule,true));
            }
        }
        return ['extension' => $details];
    }

    public function put()
    {
        $mandatoryFields = ['id', 'organizationId', 'status'];
        $data = $this->getRequestParams($mandatoryFields,['config']);
        new Organization(["id" => $data['organizationId']]);
        $currentStatus = $this->model->status($data['organizationId']);
        \ZopNow\Arya\DB\MySql::startTransaction();
        $status = strtoupper($data['status']);
        if ($status == 'ENABLED' && !empty($data['config'])) {
            $allowedConfig = $this->fetchConfigFile(lcfirst($this->model->slug).".json");
            if (!empty($allowedConfig)) {
                if (empty($data['config']['globalConfig'])) {
                    throw new ValidationException("Invalid format of configuration details");
                }
                (new Config(['id' => lcfirst($this->model->slug), 'organizationId' => $data['organizationId'], lcfirst($this->model->slug) => $data['config']['globalConfig']]))->put();
                if ($this->model->is_store_configurable) {
                    $this->updateStoreSpecificConfigurationDetails($allowedConfig, $data['config']['storeSpecific'] ?? []);
                }
            }
        }
        if($currentStatus !== $status){
            if($status == 'ENABLED'){
                $extDetail = $this->getDetails()['extension'];
                if (is_array($extDetail['incompatibleExtensions'])){
                    foreach ($extDetail['incompatibleExtensions'] as $extSlug) {
                        $extension = \ZopNow\Hodor\Model\Extension::where([['slug', $extSlug]])->first();
                        if (!empty($extension)) {
                            $status = $extension->status($this->organizationId);
                            if ($status == 'ENABLED'){
                                throw new \ZopNow\Arya\Exception\ValidationException("Please disable $extSlug extension to enable this extension");
                            }
                        }
                     }
                }
                
                if (is_array($extDetail['dependantOn'])) {
                    $enabledExtensions = "";
                    $dependantExtensions = [];

                    if (sizeof($extDetail['dependantOn']) > 0) {
                        $dependantExtensions = \ZopNow\Hodor\Model\Extension::getExtensions($this->organizationId, $extDetail['dependantOn']);
                    }

                    foreach ($dependantExtensions as $dependantExtension) {
                        if ($dependantExtension['status'] != 'ENABLED') {
                            $enabledExtensions .= $dependantExtension['name']. " AND ";
                        }
                    }
                    
                    if ($enabledExtensions != "") {
                        $enabledExtensions = rtrim($enabledExtensions, " AND ");
                        throw new \ZopNow\Arya\Exception\ValidationException(" You need to first install and configure $enabledExtensions extension before installing this extension");
                    }
                }
                $function = 'attach';
                $extensionFunction = 'enable';
            } else if($status == 'DISABLED') {
                $parentExtensions = \ZopNow\Hodor\Model\Extension::getParentExtensions($data['id']);
                $disabledExtensions = "";

                if (sizeof($parentExtensions) > 0) {
                    $parentExtensions = \ZopNow\Hodor\Model\Extension::getExtensions($this->organizationId, $parentExtensions);
                }
        
                foreach ($parentExtensions as $parentExtension) {
                    if ($parentExtension['status'] != 'DISABLED') {
                        $disabledExtensions .= $parentExtension['name'] . " AND ";
                    }
                }
             
                if ($disabledExtensions != "") {
                    $disabledExtensions = rtrim($disabledExtensions, " AND ");
                    throw new \ZopNow\Arya\Exception\ValidationException("You need to first uninstall $disabledExtensions extension before you can uninstall this extension");
                }

                $function = 'detach';
                $extensionFunction = 'disable';
            } else {
                throw new ValidationException("Invalid status");
            }
            if(!is_null($this->extension)){
                $this->extension->$extensionFunction();
            }
            $this->model->organization()->$function($data['organizationId']);
            $this->model = $this->modelClass::findOrFail($this->data['id']);
        }
        $this->refreshCache();
        \ZopNow\Arya\DB\MySql::commit();
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $this->getDetails(),
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    private function refreshCache() {
        $org = $this->organizationId;
        $slug = $this->model->slug;
        $r = \ZopNow\Arya\DB\Redis::getInstance();
        $r->del("O:Extension:Slug:$slug:$org");
        $r->del("O:Organization:$org");
        $r->select(8);
        $keys = $r->keys("$org:*:org");
        $r->del($keys);
        $r->select(0);
    }

    private function fetchConfigFile($configFile)
    {
        $fileName = DATA_DIRECTORY . "configurations/" . $configFile;
        if (!file_exists($fileName)) {
            return [];
        }
        return json_decode(file_get_contents($fileName), true);
    }

    private function getConfigDetails($filename, $allowedConfig, $isMultiStoreExtensionEnabled, $allConfigDetails = false)
    {
        $details = [];
        $organizationConfig = (new Config([]))->getAllConfigValues([$filename => $allowedConfig], $this->organizationId, $isMultiStoreExtensionEnabled);
        foreach ($organizationConfig as $config) {
            $key = explode(".", $config['key'])[1];
            if (empty($config['storeId'])) {
                $details['globalConfig'][$key] = ($allConfigDetails === true) ? $config : $config['value'];
            } else {
                $details['storeSpecificConfig'][$config['storeId']][$key] = ($allConfigDetails === true) ? $config : $config['value'];
            }
        }
        return $details;
    }

    private function updateStoreSpecificConfigurationDetails($allowedConfig, $storeConfig)
    {
        $multiStoreExtension = \ZopNow\Hodor\Model\Extension::where([['slug', self::STORE_EXTENSION_SLUG]])->first();
        if (empty($multiStoreExtension)) {
            return;
        }
        $status = $multiStoreExtension->status($this->organizationId);
        $isMultiStoreExtensionEnabled = ($status == 'ENABLED')? true : false;
        if (!$isMultiStoreExtensionEnabled) {
            return;
        }
        $allConfigDetails = $this->getConfigDetails(lcfirst($this->model->slug).".json", $allowedConfig, $isMultiStoreExtensionEnabled, true);
        if (empty($allConfigDetails['storeSpecificConfig']) && empty($storeConfig)) {
            return;
        }
        $storeSpecificConfigDetails = array_column($storeConfig, null, 'storeId');
        $allowedConfig = array_column($allowedConfig['configs'], null, 'name');
        // Disable all existing store config data if it is not sent in the request
        if (!empty($allConfigDetails['storeSpecificConfig']) && empty($storeSpecificConfigDetails)) {
            return $this->disableStoreSpecificConfigurations($allConfigDetails['storeSpecificConfig']);
        }
        $storeData = (new Store(['organizationId' => $this->organizationId, 'paginated' => 'false']))->get()->getData();
        $currenStores = array_column($storeData['data']['store'], 'id');
        $stores = array_keys($storeSpecificConfigDetails);
        if (!empty(array_diff($stores, $currenStores))) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid Stores provided");
        }
        foreach ($allowedConfig as $key => $details) {
            $extraData = !empty($details['typeMeta']) ? $details['typeMeta'] : [];
            $configKey = lcfirst($this->model->slug) . "." . $key;
            foreach ($stores as $store) {
                if (!isset($storeSpecificConfigDetails[$store][$key])) {
                    continue;
                }
                $isValid = \ZopNow\Arya\Utility\Validator::validate($storeSpecificConfigDetails[$store][$key], $details['type'], $extraData);
                if ($isValid && $details['type'] == 'text' && !empty($extraData['regex']) &&
                    !preg_match($extraData['regex'], $storeSpecificConfigDetails[$store][$key])) {
                    $isValid = false;
                }
                if (($isValid == false && $details['required'] == true) || ($isValid == false && $details['required'] == false && !empty($storeSpecificConfigDetails[$store][$key]))) {
                    throw new \ZopNow\Arya\Exception\ValidationException("Invalid data for $key");
                }
                if (isset($allConfigDetails['storeSpecificConfig'][$store][$key])) {
                    if ($storeSpecificConfigDetails[$store][$key] == $allConfigDetails['storeSpecificConfig'][$store][$key]) {
                        continue;
                    }
                    $requestMethod = "edit";
                    $requestData = ['id' => $allConfigDetails['storeSpecificConfig'][$store][$key]['id'],
                       'key' => $configKey, 'value' => $storeSpecificConfigDetails[$store][$key], 'organizationId' => $this->organizationId, 'storeId' => $store];
                    (new Configuration(['id' => $allConfigDetails['storeSpecificConfig'][$store][$key]['id']]))->edit($requestData);
                } else {
                    $requestMethod = "add";
                    $requestData = ['key' => $configKey, 'value' => $storeSpecificConfigDetails[$store][$key], 'organizationId' => $this->organizationId, 'storeId' => $store];
                    (new Configuration([]))->add($requestData);
                }
            }
        }
        foreach ($stores as $store) {
            unset($allConfigDetails['storeSpecificConfig'][$store]);
        }
        if (!empty($allConfigDetails['storeSpecificConfig'])) {
            $this->disableStoreSpecificConfigurations($allConfigDetails['storeSpecificConfig']);
        }
    }

    private function disableStoreSpecificConfigurations($storeSpecificConfigDetails)
    {
        foreach ($storeSpecificConfigDetails as $storeId => $configDetails) {
            foreach ($configDetails as $config => $details) {
                (new Configuration(['id' => $details['id']]))->delete();
            }
        }
    }

}
