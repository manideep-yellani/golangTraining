<?php

namespace ZopNow\Hodor\Controller;

class Verify extends \ZopNow\Arya\Controller\Base
{

    public function get()
    {
        $data = $this->getRequestParams(array("hash"));
        $userController = new User($data);
        $message = $userController->verifyEmail();
        $response = array(
            'status' => 'SUCCESS',
            'message' => $message,
        );
        return (new \ZopNow\Arya\View\Base($response));
    }
}
