<?php

namespace ZopNow\Hodor\Controller;

class PaymentGateway extends \ZopNow\Arya\Controller\Base
{

    public function get()
    {
        $fields = $this->getRequestParams(['organizationId']);
        $currency = (new \ZopNow\Hodor\Controller\Organization(['id' => $fields['organizationId']]))->getCurrency();
        $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor('payment-gateway.json', 'GET', ['paginated' => 'false', 'status' => 'ENABLED', 'currency' => $currency[0]['name']]))->execute();
        $details =  json_decode($response['response'], true);
        $gatewayDetails = $details['data'] ?? [];
        $camelCaseResponse = \ZopNow\Hodor\Utility\Utility::convertKeysToCamelCase($gatewayDetails);
        unset($details['data']);
        foreach ($camelCaseResponse as &$response) {
            $gatewayImageURL = $this->getGatewayImageUrl($response['id']);
            if (!empty($gatewayImageURL)){
                $response['imageUrl'] = $gatewayImageURL;
            }

            if (empty($response['paymentModes'])) {
                continue;
            }
            foreach ($response['paymentModes'] as &$paymentMode) {
                $imageUrl = (new PaymentMode(['id' => $paymentMode['id']]))->getImageUrl();
                if (!empty($imageUrl)) {
                    $paymentMode['imageUrl'] = $imageUrl;
                }
            }
        }
        $details['paymentgateway'] = $camelCaseResponse;
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'code' => 200,
            'data' => $details
            ])
        );
    }

    private static $gatewayIcons = [
        3 => "https://storage.googleapis.com/zopping-uploads/originals/20220203/payu-20220203-050733.png",
        13 => "https://storage.googleapis.com/zopping-uploads/originals/20220203/ccavenue-20220203-050839.png",
        17 => "https://storage.googleapis.com/zopping-uploads/originals/20220203/olamoney-20220203-050807.png",
        19 => "https://storage.googleapis.com/zopping-uploads/originals/20220203/razorpay-20220203-050403.png",
        21 => "https://storage.googleapis.com/zopping-uploads/originals/20220203/phonepay-20220203-050645.png",
        14 => "https://storage.googleapis.com/zopping-uploads/originals/20220302/Mobikwikpayment-20220302-055957.png",
        11 => "https://storage.googleapis.com/zopping-uploads/originals/20220302/Paytm-20220302-060033.png",
        24 => "https://storage.googleapis.com/zopping-uploads/originals/20220302/Stripe-20220302-094227.png",
        23 => "https://storage.googleapis.com/zopping-uploads/originals/20220302/paypal-20220302-094320.png"
    ];

    public function getGatewayImageUrl($id = 0)
    {
        return self::$gatewayIcons[$id] ?? null;
    }

}
