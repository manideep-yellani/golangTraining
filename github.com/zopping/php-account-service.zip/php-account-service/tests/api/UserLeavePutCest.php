<?php

class UserLeavePutCest
{

    protected static $endpoint = '/user-leave';
    protected static $table = 'user_leaves';

    public function cancelLeave(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Unwell",
                'type' => 'SICK']
        );
        $data = [
            "user"=> '{
                    "id": ' . $userId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $desigId . ',
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'CANCELLED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "userleave" => "array"
            )
        ));
    }

    public function cancelRejectedLeave(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Unwell",
                'type' => 'SICK',
                'status' => 'REJECTED']
        );
        $data = [
            "user"=> '{
                    "id": ' . $userId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $desigId . ',
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'CANCELLED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Only pending or approved leaves can be cancelled"]
        );
    }

    public function cancelOldLeave(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d', strtotime("-2 days")),
                'to_date' => date('Y-m-d', strtotime("-2 days")),
                'reason' => "Unwell",
                'type' => 'SICK',
                'status' => 'APPROVED']
        );
        $data = [
            "user"=> '{
                    "id": ' . $userId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $desigId . ',
                        "name": "Tech Support",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'CANCELLED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Cannot cancel your leave after the leave date."]
        );
    }

    public function approveLeave(ApiTester $I)
    {
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support', 'manager_id' => $managerDesigId];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Unwell",
                'type' => 'SICK']
        );
        $data = [
            "user"=> '{
                    "id": ' . $managerId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $managerDesigId . ',
                        "name": "Supervisor",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'APPROVED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(
            ["userleave" => ["id" => $leaveId, "status" => "APPROVED"]]
        );
    }

    public function approveOwnLeave(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Unwell",
                'type' => 'SICK']
        );
        $data = [
            "user"=> '{
                    "id": ' . $userId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $desigId . ',
                        "name": "Supervisor",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'APPROVED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: You are not entitled to approve this leave."]
        );
    }

    public function approveUnauthorisedLeave(ApiTester $I)
    {
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Unwell",
                'type' => 'SICK']
        );
        $data = [
            "user"=> '{
                    "id": ' . $managerId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $managerDesigId . ',
                        "name": "Supervisor",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'APPROVED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: You are not entitled to approve this leave."]
        );
    }

    public function rejectLeave(ApiTester $I)
    {
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support', 'manager_id' => $managerDesigId];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Personal",
                'type' => 'EARNED']
        );
        $data = [
            "user"=> '{
                    "id": ' . $managerId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $managerDesigId . ',
                        "name": "Supervisor",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'REJECTED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(
            ["userleave" => ["id" => $leaveId, "status" => "REJECTED"]]
        );
    }

    public function rejectOwnLeave(ApiTester $I)
    {
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Unwell",
                'type' => 'SICK']
        );
        $data = [
            "user"=> '{
                    "id": ' . $userId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $desigId . ',
                        "name": "Supervisor",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'REJECTED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: You are not entitled to reject this leave."]
        );
    }

    public function rejectUnauthorisedLeave(ApiTester $I)
    {
        $managerData = ['organization_id' => 1, 'name' => 'Supervisor'];
        $managerDesigId = $I->haveInDatabase('designations', $managerData);
        $managerId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $managerDesigId]
        );
        $memberDesignation = ['organization_id' => 1, 'name' => 'Tech Support'];
        $desigId = $I->haveInDatabase('designations', $memberDesignation);
        $userId = $I->haveInDatabase(
            'users', ['name' => 'User', 'password' => 'd94ebce3b206c791249430e5061dd2f6',
                'organization_id' => 1, 'designation_id' => $desigId]
        );
        $leaveId = $I->haveInDatabase(
            'user_leaves',
            [   'user_id' => $userId,
                'from_date' => date('Y-m-d'),
                'to_date' => date('Y-m-d'),
                'reason' => "Unwell",
                'type' => 'SICK']
        );
        $data = [
            "user"=> '{
                    "id": ' . $managerId . ',
                    "name": "User",
                    "designation": {
                        "id": ' . $managerDesigId . ',
                        "name": "Supervisor",
                        "timingType": "FLEXI",
                        "manager": null
                    }
                }',
            "organizationId" => 1,
            "status" => 'REJECTED',
        ];
        $I->sendPUT(static::$endpoint . "/$leaveId", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: You are not entitled to reject this leave."]
        );
    }

}
