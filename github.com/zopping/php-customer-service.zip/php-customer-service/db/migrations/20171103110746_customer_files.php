<?php


use Phinx\Migration\AbstractMigration;

class CustomerFiles extends AbstractMigration
{

    /**
     * Database schema for "customer_files" table
     * 
     * It consists of the following fields : 
     * organization_id : id of the organization to which the file corresponds to
     * location : the location where the file has been uploaded to
     * status : the status of the file indicating if it has been processed, or is pending
     * 
     */
    public function change()
    {
        $catalogueFiles = $this->table('customer_files');
        $catalogueFiles->addColumn('organization_id', 'integer', array('null' => false))
            ->addColumn('location', 'string', array('limit' => 500))
            ->addColumn('status', 'enum', array('values' => array('PENDING', 'PROCESSING', 'PROCESSED', 'FAILED'), 'default' => 'PENDING'))
            ->addColumn('created_at', 'timestamp', array('null' => false, 'default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->create();
    }
}
