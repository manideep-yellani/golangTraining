<?php


namespace ZopNow\Hodor\Extension;

class InStoreProcessing extends Base
{

    public function enable()
    {
        return true;
    }

    public function disable()
    {
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        $billingAmount = 0;
        $organizationId = $this->organization->id;
        $pickingStats = \ZopNow\Arya\Utility\MicroService::callService("order-service", "/picking-stats", "GET", ['organizationId' => $organizationId, 'startTime' => $startTime, 'endTime' => $endTime]);
        $response = json_decode($pickingStats['body'], true);
        $totalOrderAmountProcessed = $response['data']['pickingstats']['totalPickedAmount'];
        if (!empty($totalOrderAmountProcessed)) {
            $metaData = date('Y-m-d',strtotime($startTime))."-".date('Y-m-d',strtotime($endTime)).",Total number  of orders ".$response['data']['pickingstats']['numOrders'].", Total order amount processed - $totalOrderAmountProcessed.";
            $billingAmount = $pricingRule['COST'] * $totalOrderAmountProcessed/100;
        }
        return ['cost' => $billingAmount, 'metaData' => $metaData ?? null];
    }

}
