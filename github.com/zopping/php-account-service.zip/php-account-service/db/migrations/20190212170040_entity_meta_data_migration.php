<?php

use Phinx\Migration\AbstractMigration;

class EntityMetaDataMigration extends AbstractMigration
{
    public function up()
    {

        $table = $this->table('config_service.custom_fields');
        $table->addColumn('organization_id', 'integer', array('limit' => 11))
            ->addColumn('key', 'string', array('limit' => 500))
            ->addColumn('entity', 'enum', ['values' => ['Customer', 'Order', 'Product', 'Address', 'Variant', 'DeliveryArea', 'Store']])
            ->addColumn('type', 'enum', ['values' => ['Number', 'String', 'Text', 'MultiValued Enum', 'Enum', 'Boolean', 'Country', 'Date']])
            ->addColumn('type_meta', 'json', array('null' => true))
            ->addColumn('mandatory', 'boolean', array('default' => 0))
            ->addColumn('indexed', 'boolean', array('default' => 0))
            ->addColumn('parent_custom_field_id', 'integer', array('null' => true, 'limit' => 11))
            ->addColumn('created_at', 'timestamp', array('null' => false, 'default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addIndex(['organization_id', 'key', 'entity'], ['name' => 'idx_custom_fields_key', 'unique' => TRUE])
            ->addForeignKey('parent_custom_field_id', 'custom_fields', 'id', array('delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->create();


        $rows = $this->fetchAll("SELECT *  from configurations where `key` like 'entityMetaData.%'");
        foreach ($rows as $row) {
            $key = $row['key'];
            $slice = explode(".", $key);
            $value = $row['value'];
            $orgID = $row['organization_id'];
            $mapKeytype = json_decode($value);
            foreach ($mapKeytype as $key => $value) {
                if (isset($value->indexed)) {
                    if (is_bool($value->indexed) === true) {
                        if ($value->indexed == true) {
                            $indexed = 1;
                        } else {
                            $indexed = 0;
                        }
                    } else {
                        $indexed = $value->indexed;
                    }

                } else {
                    $indexed = 0;
                }

                if ($value->type == "enum") {
                    if ((isset($value->allowMultiple)) && ($value->allowMultiple == true)) {
                        $value->type = "MultiValued Enum";
                    }
                    $jsonVal = json_encode($value->typeMeta);
                    $this->execute('insert into config_service.custom_fields(`organization_id`,`key`,`entity`,`indexed`,`type`,`type_meta`) values (' . $orgID . ',"' . $key . '","' . $slice[1] . '",' . $indexed . ',"' . $value->type . '",\'' . $jsonVal . '\')');

                } else {
                    $this->execute('insert into config_service.custom_fields(`organization_id`,`key`,`entity`,`indexed`,`type`) values (' . $orgID . ',"' . $key . '","' . $slice[1] . '",' . $indexed . ',"' . $value->type . '")');
                }
            }

        }

    }
    public function down()
    {
       $this->table("config_service.custom_fields")->drop();
    }
}

