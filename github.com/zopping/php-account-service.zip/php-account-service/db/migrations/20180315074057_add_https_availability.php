<?php

use Phinx\Migration\AbstractMigration;

class AddHttpsAvailability extends AbstractMigration
{

    public function change()
    {
        $this->table('organizations')
            ->addColumn('https_enabled', 'integer', ['limit' => 1, 'default' => 0])
            ->update();
    }
}