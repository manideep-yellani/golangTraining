<?php

use Phinx\Migration\AbstractMigration;

class ContentManagerProductPermission extends AbstractMigration
{
    public function change()
    {
        $endpoints = [
           "config-service/meta-data" => ["GET"],
           "inventory-service/item" => ["GET"],
           "account-service/currency" => ["GET"],
           "catalogue-service/product-upload" => ["GET"],
           "inventory-service/item" => ["POST"],
        ];
        $roleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in ('" . implode("','",
                array_keys($endpoints)) . "')");
        $roleId = $this->fetchRow("select id from roles where `name` = 'CONTENT MANAGER' AND organization_id is null")['id'];
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);
        $roleId = $this->fetchRow("select id from roles where `name` = 'CONTENT WRITER' AND organization_id is null")['id'];
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach ($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'],
                    'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }

}
