<?php

use Phinx\Migration\AbstractMigration;

class UserAddVerified extends AbstractMigration
{
    public function change()
    {
        $this->table('users')
                ->addColumn('verified', 'boolean', ['default' => 0])
                ->save();
        $this->query("update users set verified = 1");
    }
}
