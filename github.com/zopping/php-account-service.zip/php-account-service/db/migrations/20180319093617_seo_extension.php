<?php

use Phinx\Migration\AbstractMigration;

class SeoExtension extends AbstractMigration
{
    public function up()
    {
        $enableHelperText = "Allows you to set title, description and keywords for pages to be used for Seo";

        $disableHelperText = "Disables all Seo tags for your website";

        $data = [
            "name" => "Seo",
            "slug" => "Seo",
            "description" => "The Search Engine Optimization (Seo) extension helps you increase the ".
                "visibility of your website by providing title, description and keywords for your web pages. ".
                "The keywords provided will be used by the search engines to provide results increasing the organic traffic to your website.",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE",
        ];
        $this->insert('extensions',$data);

        $extensionId = $this->fetchRow(
            "SELECT `id` from `extensions` where `slug` = 'Seo'"
        )['id'];
        $endpointData = [
            [
                "url" => "account-service/seo",
                "allowed_methods" => json_encode(['GET', 'PUT']),
                "extension_id" => $extensionId
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $extensionId = $this->fetchRow(
            "SELECT `id` from `extensions` where `slug` = 'Seo'"
        )['id'];
        $endpointId = $this->fetchRow(
            "select id from endpoints where url= 'account-service/seo'"
        )['id'];

        $this->execute('DELETE from `extension_organization` where extension_id = ' . $extensionId);
        $this->execute(
            "delete from endpoint_developer_permissions where endpoint_id = '$endpointId'"
        );
        $this->execute(
            "delete from endpoint_user_permissions where endpoint_id = '$endpointId'"
        );
        $this->execute(
            "delete from endpoints where id = '$endpointId'"
        );
        $this->execute('DELETE from `extensions` where `id` = "'.$extensionId.'"');
    }
}