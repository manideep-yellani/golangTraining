<?php

class ConfigurationPostCest extends BaseCest
{
    protected static $endpoint = '/configuration';
    protected static $table = 'configurations';

    public function createConfiguration(ApiTester $I)
    {
        $I->wantTo("Create configuration with basic data");
        $data = [
            'organizationId' => 1,
            'key' => 'basic.lang',
            'value' => 'en',
        ];
        parent::create($I, $data);
    }

    public function createConfigurationWithoutValue(ApiTester $I)
    {
        $I->wantTo("Create configuration without value");
        $data = ['organizationId' => 2, 'key' => 'test'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Missing Required Field - configuration : value']);
    }

    public function createConfigurationWithoutKey(ApiTester $I)
    {
        $I->wantTo("Create configuration without key");
        $data = ['organizationId' => 2, 'value' => 'test'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Missing Required Field - configuration : key']);
    }

    public function createConfigurationWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo("Create configuration without organization id");
        $data = ['key' => 'basic.organizationName', 'value' => 'test'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Missing Required Field - configuration : organization Id']);
    }

    public function createConfigurationWithJsonValue(ApiTester $I)
    {
        $I->wantTo("Create configuration with json value");
        $data = ['organizationId' => 5, 'key' => 'basic.categoryProperties',
            'value' => '[{"name":"status","displayName":"Status","type":"enum","typeMeta":{"values":["ENABLED","DISABLED","DELETED"],"default":"ENABLED"},"required":false}]'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['organizationId' => 5, 'key' => 'basic.categoryProperties']);
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "configuration" => array(
                    "id" => "integer",
                    "organizationId" => "integer",
                    "key" => "string",
                    "value" => "array"
                )
            )
        ));
    }

    public function createConfigurationWhichExists(ApiTester $I)
    {
        $I->wantTo("Create configuration by sending data having an existing key");
        $data = ['organizationId' => 1, 'key' => 'basic.organizationName', 'value' => 'ZopNow Store'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Configuration already exists"));
    }

}
