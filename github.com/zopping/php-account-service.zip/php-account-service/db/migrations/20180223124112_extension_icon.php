<?php

use Phinx\Migration\AbstractMigration;

class ExtensionIcon extends AbstractMigration
{
    
    public function change()
    {
        $this->table("extensions")
           ->addColumn('icon', 'string', array('limit' => 500, 'null' => true))
           ->save();

        $this->execute("update extensions set icon = 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/analytics%403x-20180223-095255.png' where slug = 'Analytics'");
        $this->execute("update extensions set icon = 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/delivery-area-support%403x-20180223-095255.png' where slug = 'DeliveryAreaSupport'");
        $this->execute("update extensions set icon = 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/instore-processing%403x-20180223-095255.png' where slug = 'InStoreProcessing'");
        $this->execute("update extensions set icon = 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/product-tag-support%403x-20180223-095255.png' where slug = 'ProductTagSupport'");
        $this->execute("update extensions set icon = 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/multi-user-support%403x-20180223-095255.png' where slug = 'MultiUserSupport'");
        $this->execute("update extensions set icon = 'https://s3.ap-south-1.amazonaws.com/zopnow-uploads/multi-brand-support%403x-20180223-095255.png' where slug = 'MultiBrandSupport'");
    }
}
