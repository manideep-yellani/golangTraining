<?php

use Phinx\Migration\AbstractMigration;

class AddMeEndpoint extends AbstractMigration
{

    public function up()
    {
        $endpointData = [
            ["url" => "account-service/me","allowed_methods" => json_encode(['GET','POST', 'PUT','DELETE'])],
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute('DELETE FROM `endpoints` where `url` = "account-service/me"');
    }
}
