<?php

use Phinx\Migration\AbstractMigration;

class LayoutValidityType extends AbstractMigration
{
    public function up()
    {
        $this->execute("ALTER TABLE `organization_page` MODIFY column valid_till TIMESTAMP NULL");
        $this->execute("ALTER TABLE `organization_page` MODIFY column valid_from TIMESTAMP NULL");
    }
    public function down()
    {
        $this->execute("ALTER TABLE `organization_page` MODIFY column valid_till date NULL");
        $this->execute("ALTER TABLE `organization_page` MODIFY column valid_from date NULL");
    }
    
}
