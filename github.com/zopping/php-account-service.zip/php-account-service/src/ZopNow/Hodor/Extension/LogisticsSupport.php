<?php

namespace ZopNow\Hodor\Extension;

class LogisticsSupport extends Base
{

    public function enable()
    {
        $organizationId = $this->organization->id;
        $resp = \ZopNow\Arya\Utility\MicroService::callService(
            "config-service", 
            "/config/website", 
            "GET", 
            ['organizationId' => $organizationId]
        );
        $googleMapsApiKey = json_decode($resp["body"], true)["data"]["website"]["googleApisKey"];
        if (empty($googleMapsApiKey)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please configure google maps api key");
        }

        return true;
    }

    public function disable()
    {
        return true;
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
        $billingAmount = 0;
        $organizationId = $this->organization->id;
        $pickingStats = \ZopNow\Arya\Utility\MicroService::callService("order-service", "/logistics-stats", "GET", ['organizationId' => $organizationId, 'startTime' => $startTime, 'endTime' => $endTime]);
        $response = json_decode($pickingStats['body'], true);
        $totalOrderAmountProcessed = $response['data']['logisticsstats']['totalAmount'];
        if (!empty($totalOrderAmountProcessed)) {
            $metaData = date('Y-m-d',strtotime($startTime))."-".date('Y-m-d',strtotime($endTime))."Total number  of orders ".$response['data']['logisticsstats']['numOrders'].", Total order amount processed - $totalOrderAmountProcessed.";
            $billingAmount = $pricingRule['COST'] * $totalOrderAmountProcessed/100;
        }
        return ['cost' => $billingAmount, 'metaData' => $metaData ?? null];
    }

    public function configurePrerequisites($prerequisites) {
        foreach ($prerequisites as &$prerequisite) {
            switch($prerequisite['name']) {
                case 'GOOGLE_MAP_API_KEY':
                    $organizationId = $this->organization->id;
                    $resp = \ZopNow\Arya\Utility\MicroService::callService(
                        "config-service", 
                        "/config/website", 
                        "GET", 
                        ['organizationId' => $organizationId]
                    );
                    $googleMapsApiKey = json_decode($resp["body"], true)["data"]["website"]["googleApisKey"];
                    $prerequisite['isConfigured'] = true;
                    if (empty($googleMapsApiKey)) {
                        $prerequisite['isConfigured'] = false;
                    }
            }
        }

        return $prerequisites;
    }
}