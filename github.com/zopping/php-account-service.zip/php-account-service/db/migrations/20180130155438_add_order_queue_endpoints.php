<?php

use Phinx\Migration\AbstractMigration;

class AddOrderQueueEndpoints extends AbstractMigration
{

    public function up()
    {
        $extensionId = $this->fetchRow(
                "SELECT `id` from `extensions` where `slug` = 'InStoreProcessing'"
            )['id'];
        $endpointData = [
            [
                "url" => "order-service/order-queue-strategy",
                "allowed_methods" => json_encode(['GET'])
            ],
            [
                "url" => "order-service/picking-queue",
                "allowed_methods" => json_encode(['GET']),
                "extension_id" => $extensionId
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $endpointsToBeDeleted = [
            "'order-service/order-queue-strategy'",
            "'order-service/picking-queue'",
        ];
        $this->execute(
            "delete from endpoints where url in (" . implode(',', $endpointsToBeDeleted) . ")"
        );
    }
}
