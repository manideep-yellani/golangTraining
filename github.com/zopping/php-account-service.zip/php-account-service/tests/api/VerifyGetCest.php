<?php

class VerifyGetCest
{
    protected static $endpoint = '/verify';

 /*   public function validHash(ApiTester $I)
    {
        //Fetch the configurations needed for the Encryption class
        $config = include 'config/test.php';
        $encryptionConfig['key'] = $config['ZopNow\Arya\Utility\Encryption']['key'];
        \ZopNow\Arya\Utility\Encryption::configure($encryptionConfig);

        $I->wantTo("Passing a valid hash value");
        $I->sendPOST("/user", ['name' => 'admin', 'phone' => '+919887890689',
            'email' => 'admin@something.com']);
        $id = $I->grabDataFromResponseByJsonPath('$.data.user.id')[0];
        $emailId = $I->grabFromDatabase("emails", 'id', ['user_id' => $id]);
        $hash = urlencode(ZopNow\Arya\Utility\Encryption::encrypt($emailId, true));
        $I->sendGET(static::$endpoint . "?hash=$hash");
        $I->seeResponseContainsJson(["message" => "Email verified!"]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Email verified!"]);
        $I->seeInDatabase("emails", ['verified' => 1, 'user_id' => $id, 'id' => $emailId]);
    }
 */

    public function invalidHash(ApiTester $I)
    {
        $I->wantTo("Passing an invalid email");
        $I->sendGET(static::$endpoint . "?hash=1235hgboummskgbcnkk");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Invalid Email"]);
    }

    public function withoutHash(ApiTester $I)
    {
        $I->wantTo("Without passing an hash");
        $I->sendGET(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing Required Field - verify : hash"]);
    }
/*
    public function alreadyVerifiedEmail(ApiTester $I)
    {
        $emailId = $I->grabFromDatabase("emails", 'id', ['user_id' => 1]);
        $hash = urlencode(ZopNow\Arya\Utility\Encryption::encrypt($emailId, true));
        $I->wantTo("Passing an invalid email");
        $I->sendGET(static::$endpoint . "?hash=$hash");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["message" => "Email has already been verified"]);
    }*/
}
