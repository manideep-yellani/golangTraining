<?php

require_once 'BaseCest.php';

class AddPhoneCest extends BaseCest
{
    protected static $endpoint = '/phone';
    protected static $table    = "phones";

    public function addPhoneWithCustomerObject(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "phone" => "+919999999992"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId = $I->grabDataFromResponseByJsonPath('$.data.phone.id')[0];
        $I->seeInDatabase(self::$table, ["id" => $phoneId, "customer_id" => $customerId, "phone" => $data['phone'], "status" => "NEW", "deleted_at" => null]);
    }

    public function addPhoneWithCustomerId(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customerId" => $customerId,
            "organizationId" => $organizationId,
            "phone" => "+353892031972"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId = $I->grabDataFromResponseByJsonPath('$.data.phone.id')[0];
        $I->seeInDatabase(self::$table, ["id" => $phoneId, "customer_id" => $customerId, "phone" => $data['phone'], "status" => "NEW", "deleted_at" => null]);
    }

    public function addPhoneWithoutCustomer(ApiTester $I)
    {
        $organizationId = 1;
        $data = [
            "organizationId" => $organizationId,
            "phone" => "+919999999992"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Please pass a valid Customer object or customerId"));
    }

    public function addPhoneWithoutOrganizationId(ApiTester $I)
    {
        $customerId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "phone" => "+919999999991"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Missing Required Field - phone : organization Id"));
    }

    
    public function addPhoneWithInvalidCustomerId(ApiTester $I)
    {
        $customerId = "xyz";
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "phone" => "+919999999991"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array("message"=>"Model Exception: Customer with id $customerId and organization_id $organizationId not found"));
    }

    public function addPhoneWithCustomerIdOfOtherOrganization(ApiTester $I)
    {
        $customerId = 5; //belongs to organization_id=2
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "phone" => "+919999999991"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array("message"=>"Model Exception: Customer with id $customerId and organization_id $organizationId not found"));
    }

    public function addInvalidPhone(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "phone" => "9999999a"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Invalid Phone"));
    }

    public function addEmptyPhone(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "phone" => ""
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Missing Required Field - phone : phone"));
    }

    public function addPhoneAgainInSameOrganization(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['id' => $customerId]),
            "organizationId" => $organizationId,
            "phone" => "+919876543210"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Phone already exists"));
    }

    public function addPhoneAgainInDifferentOrganization(ApiTester $I)
    {
        //9876543210 is for customer_id=1 which belongs to organization_id=1
        $phone = "+919876543210";
        $existingOrganizationId = 1;
        $existingCustomerId = 1;
        $newOrganizationId= 7;
        $newCustomerId = $I->haveInDatabase("customers", ['name' => "Sample User", "organization_id" => $newOrganizationId, "password" => 'a4aa5d018cf6a98582b9202fe35df83c']);
        $I->seeInDatabase("phones", ['phone'=> $phone, 'customer_id'=>$existingCustomerId]);
        $I->seeInDatabase("customers", ['id'=>$existingCustomerId, 'organization_id'=>$existingOrganizationId]);

        //adding same phone to the new customer of different organization_id =7
        $data = [
            "customer" => json_encode(['id' => $newCustomerId]),
            "organizationId" => $newOrganizationId,
            "phone" => $phone
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId = $I->grabDataFromResponseByJsonPath('$.data.phone.id')[0];
        $I->seeInDatabase(self::$table, ["id" => $phoneId, "customer_id" => $newCustomerId, "phone" => $phone, "status" => "NEW", "deleted_at" => null]);
    }

    public function addPhoneWithInproperCustomerFormat(ApiTester $I)
    {
        $customerId = 1;
        $organizationId = 1;
        $data = [
            "customer" => json_encode(['customer' => $customerId]),
            "organizationId" => $organizationId,
            "phone" => "+919876543210"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Please pass a valid Customer object or customerId"));
        $data = [
            "customer" => ['customer' => $customerId],
            "organizationId" => $organizationId,
            "phone" => "+919876543210"
        ];
        $I->sendPost(self::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array("message"=>"Validation Exception: Please pass a valid Customer object or customerId"));
    }

    public function checkingRestoringOfNumber(ApiTester $I)
    {
        $phone = "+919871111111";
        $organizationId = 1;
        //Adding this number to customer-1
        $I->sendPost(self::$endpoint, ["phone" => $phone, "organizationId" => $organizationId, "customerId"=>1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId = $I->grabDataFromResponseByJsonPath("$.data.phone.id")[0];
        //Adding to customer -2 :- should give error
        $I->sendPost(self::$endpoint, ["phone" => $phone, "organizationId" => $organizationId, "customerId"=>2]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        // Deleting this phone from customer-1
        $I->sendDELETE(self::$endpoint."/$phoneId",["organizationId" => $organizationId, "customerId" => 1]);
        $deletedAt = $I->grabColumnFromDatabase(self::$table, "deleted_at", ["id" => $phoneId, "customer_id" => 1, "phone" => $phone]);
        $I->assertNotNull($deletedAt);
        // Adding this phone back :- should restore it
        $I->sendPost(self::$endpoint, ["phone" => $phone, "organizationId" => $organizationId, "customerId"=>1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $deletedAt = $I->grabFromDatabase(self::$table, "deleted_at", ["id" => $phoneId, "customer_id" => 1, "phone" => $phone]);
        $I->seeResponseContainsJson([
            "data" => [
                "phone" => [
                    "id" => $phoneId,
                    "phone" => $phone
                ]
            ]
        ]);
        $I->assertNull($deletedAt);
    }

    public function addingDeletedPhoneToNewCustomer(ApiTester $I)
    {
        $phone = "+919872222222";
        $organizationId = 1;
        //Adding this number to customer-1
        $I->sendPost(self::$endpoint, ["phone" => $phone, "organizationId" => $organizationId, "customerId"=>1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId = $I->grabDataFromResponseByJsonPath("$.data.phone.id")[0];
        // Deleting this phone from customer-1
        $I->sendDELETE(self::$endpoint."/$phoneId",["organizationId" => $organizationId, "customerId" => 1]);
        $deletedAt = $I->grabColumnFromDatabase(self::$table, "deleted_at", ["id" => $phoneId, "customer_id" => 1, "phone" => $phone]);
        $I->assertNotNull($deletedAt);
        //Adding this phone to customer-2 : Should add
        $I->sendPost(self::$endpoint, ["phone" => $phone, "organizationId" => $organizationId, "customerId"=>2]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId2 = $I->grabDataFromResponseByJsonPath("$.data.phone.id")[0];
        $I->assertNotEquals($phoneId, $phoneId2);
        // Deleting this phone from customer-2
        $I->sendDELETE(self::$endpoint."/$phoneId2",["organizationId" => $organizationId, "customerId" => 2]);
        $deletedAt2 = $I->grabColumnFromDatabase(self::$table, "deleted_at", ["id" => $phoneId2, "customer_id" => 2, "phone" => $phone]);
        $I->assertNotNull($deletedAt2);
        //Addding to customer-3 should work
        $I->sendPost(self::$endpoint, ["phone" => $phone, "organizationId" => $organizationId, "customerId"=>3]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $phoneId3 = $I->grabDataFromResponseByJsonPath("$.data.phone.id")[0];
        $I->assertNotEquals($phoneId3, $phoneId2);
        $I->assertNotEquals($phoneId3, $phoneId);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson([
            "data" => [
                "phone" => [
                    "id" => $phoneId3,
                    "phone" => $phone
                ]
            ]
        ]);
    }
}