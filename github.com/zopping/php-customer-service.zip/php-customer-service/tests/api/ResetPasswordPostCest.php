<?php

class ResetPasswordPostCest extends BaseCest
{

    protected static $endpoint = '/resetPassword';
    protected static $table = 'users';

    public function resetPasswordOfUserWithPhone(ApiTester $I)
    {
        $I->wantTo("Reset the password of the user with phone as username");
        $I->sendPOST(static::$endpoint, ['username' => 919866544210, 'organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(["message" => "Password Reset Successfully"]);
    }

    public function resetPasswordOfUserWithEmail(ApiTester $I)
    {
        $I->wantTo("Reset the password of the user with phone as username");
        $I->sendPOST(static::$endpoint, ['username' => 'abraham14121994@gmail.com', 'organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(["message" => "Password Reset Successfully"]);
    }

    public function resetPasswordWithInvalidUsername(ApiTester $I)
    {
        $I->wantTo("Reset the password of the user with invalid username");
        $I->sendPost(static::$endpoint, ['username' => 'abc', 'organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(["message" => "Validation Exception: Invalid username"]);
    }

    public function resetPasswordWithUnRegisteredPhone(ApiTester $I)
    {
        $I->wantTo("Reset the password of the user with unregistered phone");
        $I->sendPost(static::$endpoint, ['username' => '9999999999', 'organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(["message" => "Model Exception: User with phone 9999999999 is not registered"]);
    }

    public function resetPasswordWithUnRegisteredEmail(ApiTester $I)
    {
        $I->wantTo("Reset the password of the user with unregistered email");
        $I->sendPost(static::$endpoint, ['username' => 'test_user@gmail.com', 'organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(["message" => "Model Exception: User with email test_user@gmail.com is not registered"]);
    }

}
