<?php

use Phinx\Migration\AbstractMigration;

class ItemUpdateEndpoint extends AbstractMigration
{
    public function up()
    {
        $endpointId = $this->fetchRow(
            "select id from endpoints where url='catalogue-service/item'"
        )['id'];
        $this->execute("update endpoints set allowed_methods = '[\"GET\",\"PUT\"]' where id = $endpointId");
        $details = ['role_id' => 4, 'endpoint_id' => $endpointId, 'method' => "PUT"];
        $this->insert('endpoint_role', $details);
    }

    public function down() {
        $endpointId = $this->fetchRow("select id from endpoints where url='catalogue-service/item'")['id'];
        $roleIds = array_column($this->fetchAll("select id from roles where `name` in ('CS MANAGER', 'CS AGENT')"), 'id');
        $this->execute("delete from endpoint_role where role_id =4 and endpoint_id = $endpointId and method = 'PUT'");
        $this->execute("update endpoints set allowed_methods = '[\"GET\"]' where id = $endpointId");
    }
}
