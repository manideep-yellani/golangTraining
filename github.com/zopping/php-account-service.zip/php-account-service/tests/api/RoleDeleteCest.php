<?php

class RoleDeleteCest
{
    protected static $endpoint = '/role';
    protected static $table = "roles";

    public function deleteRoleWithoutRequiredFields(ApiTester $I)
    {
        $I->sendDELETE(static::$endpoint . "/1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message" =>
                "Validation Exception: Missing Required Field - role : organization Id"]
        );

        $I->sendDELETE(static::$endpoint, ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Missing Required Field - role : id"]
        );
    }

    public function deleteRole(ApiTester $I)
    {
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Test Role', 'organization_id' => 1]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array("message" => "Role deleted successfully"));
    }

    public function deleteRoleInvalidId(ApiTester $I)
    {
        $I->wantTo('Delete a role with invalid id');
        $I->sendDELETE(static::$endpoint . "/10000", ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Model Exception: Role with id: 10000 not found"]
        );
    }

    public function deleteGlobalRole(ApiTester $I)
    {
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'PICKER']);
        $I->sendDELETE(self::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Global roles cannot be deleted"]
        );
    }

    public function deleteRoleWhichIsDeleted(ApiTester $I)
    {
        $I->wantTo("Delete a role which is already deleted");
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Test Role', 'organization_id' => 1]
        );
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->sendDELETE(static::$endpoint . "/$id", ['organizationId' => 1]);
        $I->seeResponseContainsJson(
            ["message" => "Model Exception: Role with id: $id not found"]
        );
    }

    public function deleteRoleWithUsersMappedToIt(ApiTester $I)
    {
        $roleId = $I->haveInDatabase(
            self::$table, ['name' => 'Test Role', 'organization_id' => 1]
        );
        $userId = $I->haveInDatabase(
            "users",
            ['name' => 'User', 'organization_id' => 1,
                'password' => 'd94ebce3b206c791249430e5061dd2f6']
        );
        $I->haveInDatabase('role_user', ['role_id' => $roleId, 'user_id' => $userId]);
        $I->sendDELETE(static::$endpoint . "/$roleId", ['organizationId' => 1]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message" => "Validation Exception: Role cannot be deleted"
                . " as there are users mapped to the role"]
        );
    }

}
