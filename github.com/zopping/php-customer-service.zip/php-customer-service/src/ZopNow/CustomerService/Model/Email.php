<?php

namespace ZopNow\CustomerService\Model;

class Email extends \ZopNow\Arya\Model\Base
{
    use \Illuminate\Database\Eloquent\SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'customer_id','customer'];

    public function customer()
    {
        return $this->belongsTo("\ZopNow\CustomerService\Model\Customer");
    }
}