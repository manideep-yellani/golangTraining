<?php

use Phinx\Migration\AbstractMigration;

class EncryptDeveloperKeys extends AbstractMigration
{

    public function change()
    {
        $config = include 'config/app.php';
        $encryptionConfig['key'] = $config['ZopNow\Arya\Utility\Encryption']['key'];
        \ZopNow\Arya\Utility\Encryption::configure($encryptionConfig);
        $developerKeys = $this->fetchAll("select id, token from developers");
        foreach ($developerKeys as $details) {
            $encryptedKey = \ZopNow\Arya\Utility\Encryption::encrypt(
                $details['token'], false
            );
            $this->execute(
                "update developers set token = '$encryptedKey' where id = " . $details['id']
            );
        }
    }
}
