<?php
require_once('BaseCest.php');

class DevicePostCest extends BaseCest
{
    protected static $endpoint = '/device';
    protected static $table = 'devices';

    private function testData(ApiTester $I, $data)
    {
        try {
            $I->sendPost(self::$endpoint, $data);
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $I->seeResponseIsJson();
            $deviceId = $I->grabDataFromResponseByJsonPath('$.data.device.id')[0];
            $metadata = $data['metadata'] ?? null;
            $os = null;
            if (!empty($metadata) && !empty($metadata['platform'])) {
                $os = $metadata['platform'];
            }
            $I->seeInDatabase(self::$table, [
                'id' => $deviceId,
                'uuid' => $data['uuid'],
                'token' => $data['token'],
                'customer_id' => $data['customerId'] ?? null,
                'organization_id' => $data['organizationId'],
                'os' => $os
            ]);
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }

    public function createDeviceWithValidData(ApiTester $I)
    {
        $I->wantToTest('Creating a device with valid data');
        $data = array(
            'uuid' => 'abcd-efghi-jklmn-opqr',
            'organizationId' => 1,
            'token' => 'thisisatesttoken',
            'customerId' => 1,
            'metadata' => [
                'available' => true,
                'platform' => 'Android',
                'version' => '7.0.0',
                'uuid' => 'abcd-efghi-jklmn-opqr',
                'model' => 'ASUS_T00J',
                'manufacturer' => 'asus',
            ],
        );
        $this->testData($I, $data);
    }

    public function createDeviceWithExistingUuidForOrganization(ApiTester $I)
    {
        $I->wantToTest('Creating a device with existing uuid for an organization');
        $data = array(
            'uuid' => 'eab86a40-bfa9-4c30-b4b3-7e5c0ea060d4',
            'organizationId' => '1',
            'token' => 'thisisatesttoken',
            'customer_id' => '2',
            'metadata' => '{\'available\': true,\'platform\': \'Android\',\'version\': \'5.1.1\',\'uuid\': \'ebe7403f82b1d71e\',\'cordova\': \'4.1.1\',\'model\': \'victara\',\'manufacturer\': \'motorola\'}',
            'os' => 'Android',
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Device already exists']);
    }

    public function createDeviceWithExistingToken(ApiTester $I)
    {
        $I->wantToTest('Creating a device with an existing token');
        $data = array(
            'uuid' => 'abvd-efgyi-jkfmn-zpqr',
            'organizationId' => 1,
            'token' => 'APA91bHx2GgNYjkqZ8WUfwCaAIr3X2eySkv3Hcje1wq1sPf8OHWlU4oROekIG6H1Clzs0Y2gWpDztD08Rhe7q_XrrBy6U8uEQ60OoCbewBINay3yaxQ1pDg',
            'customerId' => 1,
            'metadata' => [
                'available' => true,
                'platform' => 'Android',
                'version' => '7.0.0',
                'uuid' => 'abcd-efghi-jklmn-opqr',
                'model' => 'ASUS_T00J',
                'manufacturer' => 'asus',
            ],
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Token already exists']);
    }

    public function createDeviceWithoutOptionalFields(ApiTester $I)
    {
        $I->wantToTest('Creating a device without optional fields');
        $data = array(
            'uuid' => 'uuid-efgyi-jkfmn-zpqr',
            'organizationId' => 1,
            'token' => 'APA91bHx6TestNYjkqZ8WUfwCaAIr3X2eySkv3Hcje1wq1sPf8OHWlU4oROekIG6H1Clzs0Y2gWpDztD08Rhe7q_XrrBy6U8uEQ60OoCbewBINay3yaxQ1pDg',
        );
        $this->testData($I, $data);
    }

    public function createDeviceWithoutUuid(ApiTester $I)
    {
        $I->wantToTest('Creating a device without uuid');
        $data = array(
            'organizationId' => 1,
            'token' => 'thisisanothertesttoken',
            'customerId' => 1,
            'metadata' => [
                'available' => true,
                'platform' => 'Android',
                'version' => '7.0.0',
                'uuid' => 'abcd-efghi-jklmn-opqr',
                'model' => 'ASUS_T00J',
                'manufacturer' => 'asus',
            ],
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Missing Required Field - device : uuid']);
    }
}