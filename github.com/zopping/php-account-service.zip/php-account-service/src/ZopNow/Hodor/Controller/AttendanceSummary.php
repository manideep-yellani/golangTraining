<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Utility\Validator;

class AttendanceSummary extends \ZopNow\Arya\Controller\Base
{
    protected $allowNonPaginated = true;

    public function get()
    {
        $params = $this->getRequestParams(["organizationId", "from", "to"], ['userId', 'storeId', 'timingType']);
        $this->validateDateRange($params['from'], $params['to']);
        $requestData = [
            'organizationId' => $params['organizationId'],
            'date' => ":" . $params['from'] . "," . $params['to'],
            'paginated' => false
        ];
        if (!empty($params['userId'])) {
            $requestData['userId'] = $params['userId'];
        }
        if (!empty($params['storeId'])) {
            $requestData['storeId'] = $params['storeId'];
        }
        $attendanceController = new Attendance($requestData);
        $attendanceDetails = $attendanceController->get()->getData()['data']['attendance'];
        $updatedDetails = $this->getCompleteDetails($attendanceDetails, $params['from'], $params['to']);
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => ["attendancesummary" => $updatedDetails],
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    private function validateDateRange($fromDate, $toDate)
    {
        if (!Validator::isDate($fromDate) || !Validator::isDate($toDate)) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "The from and to parameters must be of the format 'Y-m-d'"
            );
        }
        $from = strtotime($fromDate);
        $to = strtotime($toDate);
        if ($from > $to) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "From date is greater than to date"
            );
        }
        $currentDate = date('Y-m-d');
        if ($toDate > $currentDate) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Attendance cannot be fetched for dates beyond current date"
            );
        }
        //Check if date range is less than a month approx.
        $dateDiff = 31 * 24 * 60 * 60;
        if ($dateDiff < ($to - $from)) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Can view summary only for a month at a time."
            );
        }
    }

    private function getCompleteDetails($attendanceData, $from, $to)
    {
        $response = [];
        $userAttendance = [];
        $startDate = new \DateTime($from);
        $endDate = new \DateTime($to);
        $endDate = $endDate->modify('+1 day');
        $dateRange = new \DatePeriod($startDate, new \DateInterval('P1D'), $endDate);
        foreach ($attendanceData as $details) {
            $userAttendance[$details['userId']][$details['date']] = $details;
        }
        $users = [];
        $userId = $this->userId;
        if (!empty($userId)) {
            $users[$userId] = (new User(['id' => $userId, 'exclude' => ['permissions'], 'organizationId' => $this->organizationId]))->getDetails()['user'];
        } else {
            $users = $this->getUsers($this->storeId, $this->timingType);
        }
        foreach ($users as $userId => $userDetails) {
            $attendance = $userAttendance[$userId] ?? [];
            $userJoinedOn = date('Y-m-d',strtotime($userDetails['createdAt']));
            $leaveParams = [
                'organizationId' => $this->organizationId, 'userId' => $userId,
                'from' => $from, 'to' => $to, 'paginated' => false
            ];
            $userLeaveController = new UserLeave($leaveParams);
            $userLeaves = $userLeaveController->get()->getData()['data']['userleave'];

            foreach ($dateRange as $dateObj) {
                $date = $dateObj->format('Y-m-d');
                if ($date >= $userJoinedOn) {
                    if (!array_key_exists($date, $attendance)) {
                        $attendance[$date] = NULL;
                        $attendance[$date]['status'] = 'ABSENT';
                        $userController = new User(['id' => $userId, 'organizationId' => $this->organizationId]);
                        $weeklyOff = $userController->getWeeklyOff($date);
                        if (in_array(date("l", strtotime($date)), $weeklyOff)) {
                            $attendance[$date]['status'] = 'WEEKLY_OFF';
                        } else if ($this->checkIsOnLeave($userLeaves, $date)) {
                            $attendance[$date]['status'] = 'ON_LEAVE';
                        }
                    } else {
                        $attendance[$date]['status'] = 'PRESENT';
                    }
                }
            }
            $data = [
                'id' => $userId,
                'name' => $userDetails['name'],
                'designation' => $userDetails['designation'],
                'attendance' => $attendance
            ];
            $response[] = $data;
        }
        return $response;
    }

    private function checkIsOnLeave($userLeaves, $date)
    {
        foreach ($userLeaves as $leave) {
            if ($date >= $leave['fromDate'] && $date <= $leave['toDate']) {
                return true;
            }
        }
        return false;
    }

    private function getUsers($storeId, $timingType)
    {
        $users = [];
        $page = 1;
        $request = ['organizationId' => $this->organizationId];
        if (!empty($storeId)) {
            $request['storeId'] = $storeId;
        }
        // by default consider user's with FIXED timing type designations
        $request['timingType'] = $timingType ?? "FIXED";
        do {
            $request['page'] = $page;
            $userList = (new User($request))->get()->getData();
            $users = array_merge($users, $userList['data']['user']);
            $page++;
        } while (($userList['data']['offset'] + $userList['data']['limit']) < $userList['data']['count']);
        return array_column($users, null, 'id');
    }

}
