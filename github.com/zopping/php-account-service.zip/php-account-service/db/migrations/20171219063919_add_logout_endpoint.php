<?php

use Phinx\Migration\AbstractMigration;

class AddLogoutEndpoint extends AbstractMigration
{

    public function up()
    {
        $endpointData = [
            [
                "url" => "account-service/logout",
                "allowed_methods" => json_encode(['POST'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute("delete from endpoints where url = 'account-service/logout'");
    }
}
