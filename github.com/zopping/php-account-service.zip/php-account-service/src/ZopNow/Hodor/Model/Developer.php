<?php

namespace ZopNow\Hodor\Model;

use ZopNow\Arya\Model\Base;

class Developer extends Base
{
    /**
     * Get the organization for the developer.
     */
    public function organization()
    {
        return $this->belongsTo('ZopNow\Hodor\Model\Organization');
    }

    public function endpoints()
    {
        return $this->belongsToMany("\ZopNow\Hodor\Model\Endpoint", "endpoint_developer_permissions")
                ->withPivot('has_permission', 'method', 'is_customer_required');
    }

    public function getPermissionDetails($api, $method, $organizationId = null)
    {
        $endpointModel = Endpoint::where(['url' => $api])->first();
        if (empty($endpointModel)) {
            throw new \ZopNow\Arya\Exception\ModelException("Invalid Endpoint");
        }
        if (!is_null($endpointModel->extension)) {
            if (!is_null($this->organization)) {
                $organizationId = $this->organization->id;
            }else if (is_null($organizationId)) {
                return null;
            }
            if(($endpointModel->extension->status($organizationId) == 'DISABLED')){
                return null;
            }
        }
        $endpointId =$endpointModel->toArray()['id'];
        $endpoint = $this->endpoints()
                ->where(["endpoint_id" => $endpointId, "method" => $method])
                ->first();
        if (!is_null($endpoint)) {
            $developerDetails = $endpoint->pivot;
            return $developerDetails->toArray();
        }
        return null;
    }
}
