<?php


use Phinx\Migration\AbstractMigration;

class ClientIdCustomerMappingChanges extends AbstractMigration
{

    public function up()
    {
        $this->table("client_customers")
            ->addColumn('organization_id', 'integer', array('limit' => 11))
            ->addColumn('client_id', 'integer', array('limit' => 15))
            ->addColumn('customer_id', 'integer', array('limit' => 11))
            ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addColumn('deleted_at', 'timestamp', array('null' => true))
            ->addForeignKey("customer_id", "customers", "id")
            ->addIndex(['organization_id', 'client_id'], ['name' => 'organization_client_id', 'unique' => true])
            ->create();
        $data = $this->fetchAll("select id, client_id, organization_id from customers where client_id is not null");
        $clientData = [];
        foreach ($data as $row) {
            $clientData[] = [
                'organization_id' => $row['organization_id'],
                'client_id' => $row['client_id'],
                'customer_id' => $row['id']
            ];
        }
        if (!empty($clientData)) {
            $this->table("client_customers")
                ->insert($clientData)
                ->save();
        }
        $this->table("customers")
            ->removeIndex(['organization_id', 'client_id'])
            ->removeColumn('client_id')
            ->save();
    }

    public function down()
    {
        $this->table("customers")
            ->addColumn('client_id', 'integer', array('limit' => 15, 'after' => 'id', 'null' => true))
            ->addIndex(['organization_id', 'client_id'], ['name' => 'organization_client_id', 'unique' => true])
            ->save();
        $data = $this->fetchAll("select customer_id, client_id, organization_id from client_customers");
        foreach ($data as $row) {
            $this->execute("update customers set client_id = " . $row['client_id']
                . " where id = " . $row['customer_id']);
        }
        $this->dropTable("client_customers");
    }
}
