<?php

use Phinx\Migration\AbstractMigration;

class UpdateServicesCost extends AbstractMigration
{
    
    public function change()
    {
        $organizations = $this->fetchAll("select id from organizations where id in (62,56,51,64,67)");
        $organizationIds = array_column($organizations, 'id');
        $monthlyRates = [56 => 2000, 51 => 1000, 64 => 1500, 67 => 1500];
        $variableFeeRates = [62 => 1.75];
        foreach ($organizationIds as $organizationId) {
            if (array_key_exists($organizationId, $monthlyRates)) {
                $this->addMonthlyBillingRate($organizationId, $monthlyRates[$organizationId]);
            } else {
                $this->addVariableFeeRate($organizationId, $variableFeeRates[$organizationId]);
            }
        }
    }
    
    private function addMonthlyBillingRate($organizationId, $cost) 
    {
        $this->table("organization_services")
            ->insert([
                [
                    "organization_id" => $organizationId,
                    "service_id" => 2,
                    "pricing_rule" => json_encode([
                        "COST" => $cost,
                        "RATE" => "FIXED",
                        "TYPE" => "MONTHLY"
                    ])
                ]
            ])
            ->saveData();
    }
    
    private function addVariableFeeRate($organizationId, $cost) 
    {
        $this->table("organization_services")
            ->insert([
                [
                    "organization_id" => $organizationId,
                    "service_id" => 1,
                    "pricing_rule" => json_encode([
                        "COST" => $cost,
                        "RATE" => "PERCENT",
                        "TYPE" => "DAILY",
                        "RULE" => "PER ORDER",
                    ])
                ]
            ])
            ->saveData();
    }

}
