<?php
/*
 * All the common tasks like header generation addition of menu is done here.
 * This file also gets the layout data from API and loops through each layout
 * and renders it.
 */
$tz = getenv("TIME_ZONE");
if ($tz == "") {
    $tz = "Asia/Kolkata";
}
date_default_timezone_set($tz);
require_once __DIR__ . '/../vendor/autoload.php';
//Load configurations
$configurationFile = __DIR__.'/../config/app.php';
if (!empty($_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_USER_AGENT'] == 'Symfony BrowserKit') {
    $configurationFile = __DIR__.'/../config/test.php';
}
$app = new \ZopNow\Arya\App\RestApplication($configurationFile);
$app->run();
