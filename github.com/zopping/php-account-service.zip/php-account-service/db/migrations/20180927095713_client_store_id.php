<?php

use Phinx\Migration\AbstractMigration;

class ClientStoreId extends AbstractMigration
{
    public function change()
    {
        $this->table("stores")->changeColumn('client_store_id', 'string', ['limit' => 20,'null' => true])->save();
    }
}
