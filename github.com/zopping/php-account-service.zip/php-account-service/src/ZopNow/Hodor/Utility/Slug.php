<?php

namespace ZopNow\Hodor\Utility;

class Slug
{
    /**
     * Used to generate unique slug for given table corresponding to a name
     * @param type $term
     * @param type $modelName
     * @return string
     */
    public static function generateUniqueSlug($term, $modelName)
    {
        $slug  = str_slug($term);
        $count = 1;
        $oldSlug = $slug;
        do {
            $data = $modelName::withTrashed()->where('slug', "$slug")->first();
            if (!is_null($data)) {
                $slug = $oldSlug.$count;
                $count++;
            }
        } while (!is_null($data));
        return $slug;
    }
}
