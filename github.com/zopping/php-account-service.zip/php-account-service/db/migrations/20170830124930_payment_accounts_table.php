<?php

use Phinx\Migration\AbstractMigration;

class PaymentAccountsTable extends AbstractMigration {

    public function change() {
        $table = $this->table("payment_accounts");
        $table->addColumn("organization_id", "integer", array("limit" => 11))
                ->addColumn("access_key", "string", array("null" => false))
                ->addColumn("secret_key", "string", array("null" => false))
                ->addColumn("pay_url", "string", array("null" => false))
                ->addColumn("verify_url", "string", array("null" => false))
                ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addForeignKey("organization_id", "organizations", "id")
                ->save();
    }

}
