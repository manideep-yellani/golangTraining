<?php

namespace ZopNow\CustomerService\Model;

use ZopNow\Arya\Utility\Validator;
use ZopNow\Arya\Exception\ModelException;


class Customer extends \ZopNow\Arya\Model\Base
{
    protected $hidden = ["created_at", "password", "organization_id", "default_address_id","default_phone_id", "default_email_id","salt"];
    protected $with = ["phones", "emails", "addresses"];
    protected $appends = ['total_orders', 'total_amount', 'last_ordered_on', 'is_registered', 'default_address', 'clientId'];
    protected $casts = ['meta_data' => 'array'];
    private $orderData = [];

    private static $customersOrderSummary = [];
    private static $customerFromPhone = [];
    private static $customerFromEmail = [];
    private static $validCustomerIds = [];

    public function phones()
    {
        return $this->hasMany('\ZopNow\CustomerService\Model\Phone')->orderBy("id", "desc");
    }

    public function emails()
    {
        return $this->hasMany('\ZopNow\CustomerService\Model\Email');
    }

    public function addresses()
    {
        return $this->hasMany('\ZopNow\CustomerService\Model\Address');
    }

    public function getDefaultAddressAttribute()
    {
        $addressId = $this->default_address_id;
        $allAddresses = $this->addresses->toArray();
        $defaultAddress = null;
        if (!empty($allAddresses)) {
            $defaultAddress = $allAddresses[0];
            if (!empty($addressId)) {
                $addressIds = array_column($allAddresses, 'id');
                $key = array_search($addressId, $addressIds);
                $defaultAddress = $allAddresses[$key] ?? null;
            }
        }
        return $defaultAddress;
    }

    public static function getListItems(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        if ($list->paginated) {
            $data->limit($list->getPerPage())->skip($list->getOffset());
        }
        return $data->select('customers.*')
                ->orderBy($list->getSortField(), $list->getSortOrder())
                ->get();
    }

    public static function getListItemsCount(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data = self::getQueryBuilder($list);
        return $data->count();
    }

    public function getLastOrderedOnAttribute()
    {
        return $this->order_data['last_ordered_on'];
    }

    public function getTotalOrdersAttribute()
    {
        return $this->order_data['total_orders'];
    }

    public function getTotalAmountAttribute()
    {
        return $this->order_data['total_amount'];
    }

    public function getOrderSummaryAttribute()
    {
        return $this->order_data['order_summary'];
    }

    public function getOrderDataAttribute()
    {
        if (!empty($this->orderData)) {
            return $this->orderData;
        }
        if (empty(self::$customersOrderSummary[$this->id])) {
            // We are showing summary for past 3 months
            $months = 3;
            $orderObj = \ZopNow\Arya\Utility\MicroService::callService("order-service", "/summary", 'GET', ["organizationId"=> $this->organization_id, "customerId" => $this->id, "exclude"=>["customer_data"], "months" => $months]);
            $data = [];
            if ($orderObj['statusCode'] == 200) {
                $orderData = json_decode($orderObj['body'], true);
                $data['total_orders'] = $orderData['data']['summary']['totalOrders'] ?? null;
                $data['last_ordered_on'] = $orderData['data']['summary']['lastOrderedOn'] ?? null;
                $data['total_amount'] = $orderData['data']['summary']['totalAmount'] ?? null;
                // TODO will remove totalAmount from order summry in future,
                // as we are always passing totalAmount in response.
                $data['order_summary'] = array(
                    "totalAmount" => $orderData['data']['summary']['totalAmount'] ?? null,
                    "monthlyPurchaseTrend" => $orderData['data']['summary']['monthlySummary'] ?? null
                );
            } else {
                throw new \ZopNow\Arya\Exception\AppException(\ZopNow\Arya\Utility\MicroService::SERVICE_UNAVAILABLE);
            }
            self::$customersOrderSummary[$this->id] = $data;
        }
        $this->orderData = self::$customersOrderSummary[$this->id];
        return $this->orderData;
    }

    public static function validateCustomer($id, $organizationId)
    {
        if (in_array($id, self::$validCustomerIds)) {
            return true;
        }
        if (!Customer::where(['id' => $id, 'organization_id' => $organizationId])->exists()) {
            throw new \ZopNow\Arya\Exception\ModelException("Customer with id ".$id." and "
                                                        ."organization_id ".$organizationId." not found");
        }
        self::$validCustomerIds[] = $id;
    }

    public static function getFromEmail($email, $organizationId)
    {
        if (!array_key_exists($email, self::$customerFromEmail)) {
            $user = Customer::where('organization_id', '=', $organizationId);
            $user->join('emails', function ($join) use ($email) {
                $join->on('emails.customer_id', '=', 'customers.id')->where('emails.email', '=', $email)->whereNull('deleted_at');
            });
            $customer =$user->select('customers.*')->first();
            self::$customerFromEmail[$email] = $customer;
            if (!empty($customer)) {
                //If customer exists, update local variable with all phones and emails of that customer
                self::setCustomerFromPhoneEmail($customer);
            }
        }
        return self::$customerFromEmail[$email];
    }

    public static function getFromPhone($phone, $organizationId)
    {
        $phone = /*(strlen($phone) == 10) ? "91".$phone : */ltrim($phone,"+");
        if (!array_key_exists($phone, self::$customerFromPhone)) {
            $user = Customer::where('organization_id', '=', $organizationId);
            $user->join('phones', function ($join) use ($phone) {
                 $join->on('phones.customer_id', '=', 'customers.id')->where('phones.phone', '=', $phone)->whereNull("deleted_at");
            });
            $customer = $user->select('customers.*')->first();
            self::$customerFromPhone[$phone] = $customer;
            if (!empty($customer)) {
                self::setCustomerFromPhoneEmail($customer);
            }
        }
        return self::$customerFromPhone[$phone];
    }

    public static function getUserFromLogin($username, $params = [])
    {
         $configResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/config/customers", 'GET', ['organizationId' => $params["organizationId"]]);
        $configData = json_decode($configResponse['body'], true)['data']['customers'];
        $validate = (isset($configData['validatePhone']) && !$configData['validatePhone']) ? FALSE : TRUE;
        $duplicatePhonesAllowed = (isset($configData['duplicatePhonesAllowed']) && !$configData['duplicatePhonesAllowed']) ? FALSE : TRUE;
        $user = null;
        //if duplicatePhones are allowed then user should not be able to login with the phone so throw an error
        if ($duplicatePhonesAllowed && Validator::isPhone($username)) {
            throw new \ZopNow\Arya\Exception\AuthException("Invalid username:Cannot login with phone");
        }
        if ($validate){
            if (Validator::isPhone($username) ) {
                $user = self::getFromPhone($username, $params['organizationId']);
            } else if (Validator::isEmail($username)) {
                $user = self::getFromEmail($username, $params['organizationId']);
            }
        } else{
            if (Validator::isEmail($username)) {
                $user = self::getFromEmail($username, $params['organizationId']);
            } else {
                $user = self::getFromPhone($username, $params['organizationId']);
            }
        }
        if (empty($user)) {
            throw new \ZopNow\Arya\Exception\AuthException("Invalid username");
        }
        return $user;
    }

    public function getIsRegisteredAttribute()
    {
         return !(empty($this->attributes['password']));
    }

    /**
     * Will give the count of number of customers signed up, datewise
     * @param type $startDate date of format (Y-m-d)
     * @param type $endDate date of format (Y-m-d)
     * @return array with keys as date
     */
    public static function getCustomerAcquired($organizationId, $startDate, $endDate)
    {
        return Customer::selectRaw('joined_on as date, count(id) as count')
            ->where("organization_id", "=", $organizationId)
            ->whereBetween('joined_on', [$startDate, $endDate])
            ->groupBy('date')->pluck("count", "date")->all();
    }

    public function clientIds()
    {
        return $this->hasMany('\ZopNow\CustomerService\Model\ClientCustomer');
    }

    public static function getFromClientId($clientId, $organizationId)
    {
        $user = Customer::where('client_customers.organization_id', '=', $organizationId);
        $user->join('client_customers', function ($join) use ($clientId) {
            $join->on('client_customers.customer_id', '=', 'customers.id')
                ->where('client_customers.client_id', '=', $clientId);
        });
        return $user->select('customers.*')->first();
    }

    private static function getQueryBuilder(\ZopNow\Arya\Listing\ObjectList $list)
    {
        $data    = self::query();
        $filters = $list->getFilters();
        $filterKeys = array_column($filters, 0);
        $key = array_search('updated_after', $filterKeys);
        if ($key !== FALSE) {
            $data->where('customers.updated_at','>=',$filters[$key][1]);
            unset($filters[$key]);
        }
        $key = array_search('updated_before', $filterKeys);
        if ($key !== FALSE) {
            $data->where('customers.updated_at','<=',$filters[$key][1]);
            unset($filters[$key]);
        }
        $key = array_search('phone', $filterKeys);
        if ($key !== FALSE) {
            $data->join('phones', function($join) use ($key, $filters) {
                $phone = /*(strlen($filters[$key][1]) == 10) ? "91".$filters[$key][1] : */ltrim($filters[$key][1],"+");
                $join->on('phones.customer_id', '=', 'customers.id')
                    ->where('phones.phone', $filters[$key][2], $phone)
                    ->whereNull('phones.deleted_at');
            });
            unset($filters[$key]);
        }
        $key = array_search('email', $filterKeys);
        if ($key !== FALSE) {
            $data->join('emails', function($join) use ($key, $filters) {
                $join->on('emails.customer_id', '=', 'customers.id')
                    ->where('emails.email', $filters[$key][2], $filters[$key][1])
                    ->whereNull('emails.deleted_at');
            });
            unset($filters[$key]);
        }
        $clientKey = array_search('client_id', $filterKeys);
        if ($clientKey !== FALSE) {
            $data->join('client_customers', function($join) use ($clientKey, $filters) {
                $join->on('client_customers.customer_id', '=', 'customers.id')
                    ->on('client_customers.organization_id', '=', 'customers.organization_id')
                    ->where('client_customers.client_id', $filters[$clientKey][2], $filters[$clientKey][1]);
            });
            unset($filters[$clientKey]);
        }
        $data    = self::addFilterQuery($data, $filters);
        return $data;
    }

    public function updateCustomerClientId($oldClientId , $clientId, $id, $orgId)
    {

       $query = "UPDATE client_customers SET client_id = '" . \ZopNow\Arya\DB\MySql::escape($clientId)."' WHERE deleted_at IS NULL AND customer_id = ". \ZopNow\Arya\DB\MySql::escape($id)
         ." AND organization_id = " . \ZopNow\Arya\DB\MySql::escape($orgId) . " AND client_id = " . \ZopNow\Arya\DB\MySql::escape($oldClientId);
      \ZopNow\Arya\DB\MySql::update($query);
    
    }

    private static function setCustomerFromPhoneEmail($customer)
    {
        if (!empty($customer->emails)) {
            $emails = $customer->emails->toArray();
            foreach ($emails as $emailData) {
                self::$customerFromEmail[$emailData['email']] = $customer;
            }
        }
        if (!empty($customer->phones)) {
            $phones = $customer->phones->toArray();
            foreach ($phones as $phoneData) {
                $phone = ltrim($phoneData['phone'], "+");
                self::$customerFromPhone[$phone] = $customer;
            }
        }
    }

    public function getClientIdAttribute()
    {
        $customerId = \ZopNow\Arya\DB\MySql::escape($this->id);
        $clientId = \ZopNow\Arya\DB\MySql::one(
            "select client_id from client_customers where customer_id = $customerId"
            . " order by updated_at desc limit 1"
        );
        return $clientId;
    }

    public static function acquireLock($field) { 
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $val = $redis->INCRBY("Customer:lock:$field", 1);
        if (intval($val) !== 1) {
            throw new ModelException("Unable to acquire lock");
        } else if (intval($val) === 1){
            $redis-> EXPIRE("Customer:lock:$field", 60);
        }
    }

    public static function revertLock($field) {
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $redis->INCRBY("Customer:lock:$field" , -1);
    }
}
