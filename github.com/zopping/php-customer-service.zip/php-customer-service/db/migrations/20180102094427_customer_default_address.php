<?php


use Phinx\Migration\AbstractMigration;

class CustomerDefaultAddress extends AbstractMigration
{
   
    public function change()
    {
        $this->table("customers")
            ->addColumn("default_address_id", "integer", ["after" => "joined_on", "null" => true])
            ->update();
    }
}
