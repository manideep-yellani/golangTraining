<?php

use Phinx\Migration\AbstractMigration;

class OrderPaymentPermissions extends AbstractMigration
{
     /**
     * Endpoint creation and adding permission to developer for order payment.
     */
    
    public function change()
     {
       $endpoints = array(
            array(
                "url" => 'order-service/verifyPayment',
            ),
        );
         $this->insert('endpoints', $endpoints);

         $verifyEpId = $this->fetchRow("select `id` from endpoints where url = 'order-service/verifyPayment'")['id'];
         $paymentEpId = $this->fetchRow("select `id` from endpoints where url = 'order-service/orderPayment'")['id'];

         $row = $this->fetchRow("SELECT `id` FROM developers where token = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'");
         $developerId = $row['id'];
         $data[] = array(
             "endpoint_id" => $paymentEpId,
             "developer_id" => $developerId,
             "method" => "POST",
             "has_permission" => 1
         );
         $data[] = array(
             "endpoint_id" => $paymentEpId,
             "developer_id" => $developerId,
             "method" => "GET",
             "has_permission" => 1
         );

        $data[] = array(
             "endpoint_id" => $paymentEpId,
             "developer_id" => $developerId,
             "method" => "PUT",
             "has_permission" => 1
         );

           $data[] = array(
             "endpoint_id" => $verifyEpId,
             "developer_id" => $developerId,
             "method" => "POST",
             "has_permission" => 1
         );
         $this->insert('endpoint_developer_permissions', $data);
     }
}
