<?php

class PermissionPutCest
{

    protected static $endpoint = '/permission';

    public function addUserPermissionsWithValidData(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user for an endpoint with valid data');
        $userId = $I->haveInDatabase('users', ['name' => 'Test User', 'organization_id' => 1, 'password' => 'd94ebce3b206c791249430e5061dd2f6']);
        $data = [
            'organizationId' => 1,
            'userId' => $userId,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'GET',
                    'hasPermission' => true
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('message' => 'Permission added successfully'));
    }

    public function addPermissionsWithMissingFields(ApiTester $I)
    {
        $I->wantTo("Add permissions for a user for an endpoint without any of the required fields");
        $data = [
            'organizationId' => 1,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'GET',
                    'hasPermission' => true
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Either user id or role id must be passed']);
    }

    public function addPermissionsWithInvalidEndpoint(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user for an invalid endpoint');
        $userId = $I->haveInDatabase('users', ['name' => 'Test User', 'organization_id' => 1, 'password' => 'd94ebce3b206c791249430e5061dd2f6']);
        $data = [
            'organizationId' => 1,
            'userId' => $userId,
            'permissions' => [
                [
                    'endpoint' => 'test',
                    'method' => 'GET',
                    'hasPermission' => true
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid endpoint'));
    }

    public function addPermissionsWithInvalidMethod(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user for an endpoint with invalid method');
        $userId = $I->haveInDatabase('users', ['name' => 'Test User', 'organization_id' => 1, 'password' => 'd94ebce3b206c791249430e5061dd2f6']);
        $data = [
            'organizationId' => 1,
            'userId' => $userId,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/brand',
                    'method' => 'Test',
                    'hasPermission' => true
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: method should have one of the values: GET,POST,PUT,DELETE'));
    }

    public function addPermissionsWithInvalidValueForHasPermission(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user for an endpoint with invalid value for hasPermission');
        $userId = $I->haveInDatabase('users', ['name' => 'Test User', 'organization_id' => 1, 'password' => 'd94ebce3b206c791249430e5061dd2f6']);
        $data = [
            'organizationId' => 1,
            'userId' => $userId,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/brand',
                    'method' => 'GET',
                    'hasPermission' => 'abc'
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: hasPermission should have a boolean value'));
    }

    public function addPermissionsForDifferentMethodsOfSameEndpoint(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user for different methods for an endpoint ');
        $userId = $I->haveInDatabase(
            'users', ['name' => 'Test User', 'organization_id' => 1,
                'password' => 'd94ebce3b206c791249430e5061dd2f6']
        );
        $data = [
            'organizationId' => 1,
            'userId' => $userId,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'GET',
                    'hasPermission' => true
                ],
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'POST',
                    'hasPermission' => true
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $endpointId = $I->grabFromDatabase('endpoints', 'id', ['url' => 'catalogue-service/product']);
        $I->seeInDatabase(
            'endpoint_user_permissions',
            ['user_id' => $userId, 'endpoint_id' => $endpointId, 'method' => 'GET', 'has_permission' => true]
        );
        $I->seeInDatabase(
            'endpoint_user_permissions',
            ['user_id' => $userId, 'endpoint_id' => $endpointId, 'method' => 'POST', 'has_permission' => true]
        );
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('message' => 'Permission added successfully'));
    }

    public function addPermissionWithInvalidValueForPermissions(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user with invalid value for permissions');
        $data = [
            'organizationId' => 2,
            'userId' => 2,
            'permissions' => "catalogue-service/product"
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Permissions must be'
                . ' passed as an array and cannot be empty']
        );
    }

    public function addPermissionWithInvalidArrayForPermissions(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user with invalid value for permissions');
        $data = [
            'organizationId' => 2,
            'userId' => 2,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/category'
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Validation Exception: Each permission must'
            . ' have the fields endpoint, method and hasPermission']
        );
    }

    public function addPermissionToInvalidUser(ApiTester $I)
    {
        $I->wantTo('Add permissions for a user that does not exist');
        $data = [
            'organizationId' => 1,
            'userId' => 10000,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'GET',
                    'hasPermission' => true
                ],
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'POST',
                    'hasPermission' => true
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => 'Model Exception: User with id : 10000 not found']
        );
    }

    public function addPermissionToUserOfDifferentOrganization(ApiTester $I)
    {
        $I->wantTo("Add permissions for a user belonging to a different organization");
        $userId = $I->haveInDatabase(
            'users', ['name' => 'Test User', 'organization_id' => 1,
                'password' => 'd94ebce3b206c791249430e5061dd2f6']
        );
        $data = [
            'organizationId' => 2,
            'userId' => $userId,
            'permissions' => [
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'GET',
                    'hasPermission' => true
                ],
                [
                    'endpoint' => 'catalogue-service/product',
                    'method' => 'POST',
                    'hasPermission' => true
                ]
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            ['message' => "Model Exception: User with id : $userId not found"]
        );
    }
}
