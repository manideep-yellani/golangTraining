<?php

use Phinx\Migration\AbstractMigration;

class Themes extends AbstractMigration
{

    /**
     * Database schema for "themes" table
     * It consists of the following fields :
     * title : stores the name/title of the theme
     * image : stores the url of the image of the theme
     * description : stores a brief description about the theme
     */
    public function change()
    {
        $table = $this->table('themes');
        $table->addColumn('name', 'string', array('limit' => 50))
                ->addColumn('image', 'string', array('limit' => 500, 'null' => true))
                ->addColumn('description', 'text', array('null' => true))
                ->addColumn('created_at', 'timestamp', array('null' => false, 'default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addColumn('deleted_at', 'timestamp', array('null' => true))
                ->create();
    }

}
