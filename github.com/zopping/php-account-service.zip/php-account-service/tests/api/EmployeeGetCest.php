<?php

class EmployeeGetCest
{
    protected static $endpoint = '/employee';
    protected static $table = 'employees';

    public function getEmployeeDetailsWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get employeee listing without passing organization id');
        $I->sendGet(self::$endpoint);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
    }

    public function getEmployeeListing(ApiTester $I)
    {
        $I->wantTo('Get employee listing for a given organization id');
        $I->sendGet(self::$endpoint, ['organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }

    public function getEmployeeListingForAGivenDesignation(ApiTester $I)
    {
        $I->wantTo('Get employee listing with designation filter');
        $I->sendGet(self::$endpoint, ['organizationId' => 1, 'designation_id' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }

}
