<?php


use Phinx\Migration\AbstractMigration;

class StockManagementExtension extends AbstractMigration
{
    public function up() {
        $enableHelperText = "Allows user to monitor and manage inventory stock|"
            . " Indicates the number of units of a product available instead of "
                . " just showing whether it is available or not";

        $disableHelperText = "Inventory stock will be reflected as only available/not available|"
            . " User cannot determine the number of units of a product available";

        $data = [
            "name" => "Stock Management",
            "slug" => "StockManagement",
            "description" => "Facilitates the organization to manage inventory stock",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
    }

    public function down() {
        $extensionId = $this->fetchRow(
                        "SELECT `id` from `extensions` where `slug` = 'StockManagement'"
                )['id'];
        $this->execute('DELETE from `extension_organization` where id = ' . $extensionId);
        $this->execute('DELETE from `extensions` where `slug` = "StockManagement"');
    }
}
