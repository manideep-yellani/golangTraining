<?php

use Phinx\Migration\AbstractMigration;

class ThemeChanges extends AbstractMigration
{
    /**
     * Modified the image column to be a json array
     * Added author field to store the name of the author of the theme
     * Added slug field to store the slug of the theme name
     */
    public function change()
    {
        $this->table('themes')
            ->changeColumn('image', 'text', array('null' => true))
            ->addColumn('author', 'string', array('null' => true, 'after' => 'description'))
            ->addColumn('slug', 'string', array('limit' => 50, 'after' => 'author'))
            ->save();
        $data = [
            [
                'name' => 'Default Theme',
                'slug' => 'theme-default',
                'description' => 'This is the default theme',
                'image' => '{"desktop":"http://via.placeholder.com/1920x1080",'
                    . '"mobile":"http://via.placeholder.com/414x736","tablet":"http://via.placeholder.com/1024x768"}'
            ],
            [
                'name' => 'Ruby',
                'slug' => 'theme-ruby',
                'description' => 'This is the red ruby theme',
                'image' => '{"desktop":"http://via.placeholder.com/1920x1080",'
                    . '"mobile":"http://via.placeholder.com/414x736","tablet":"http://via.placeholder.com/1024x768"}'
            ],
            [
                'name' => 'Sapphire',
                'slug' => 'theme-sapphire',
                'description' => 'This is the blue sapphire theme',
                'image' => '{"desktop":"http://via.placeholder.com/1920x1080",'
                    . '"mobile":"http://via.placeholder.com/414x736","tablet":"http://via.placeholder.com/1024x768"}'
            ],
            [
                'name' => 'Emerald',
                'slug' => 'theme-emerald',
                'description' => 'This is the green emerald theme',
                'image' => '{"desktop":"http://via.placeholder.com/1920x1080",'
                    . '"mobile":"http://via.placeholder.com/414x736","tablet":"http://via.placeholder.com/1024x768"}'
            ],
        ];
        $this->insert('themes', $data);
    }
}
