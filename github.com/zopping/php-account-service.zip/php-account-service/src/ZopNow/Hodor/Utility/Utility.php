<?php

namespace ZopNow\Hodor\Utility;

class Utility
{

    public static function convertKeysToCamelCase($apiResponseArray) 
    {
        $arr = [];
        foreach ($apiResponseArray as $key => $value) {
            $key = camel_case($key);
            if (is_array($value)) {
                $value = self::convertKeysToCamelCase($value);
            }
            $arr[$key] = $value;
        }
        return $arr;
    }

    public static function convertKeysToSnakeCase($apiResponseArray) 
    {
        $arr = [];
        foreach ($apiResponseArray as $key => $value) {
            $key = snake_case($key);            
            if (is_array($value)) {
                $value = self::convertKeysToSnakeCase($value);
            }
            $arr[$key] = $value;
        }
        return $arr;
    }

}
