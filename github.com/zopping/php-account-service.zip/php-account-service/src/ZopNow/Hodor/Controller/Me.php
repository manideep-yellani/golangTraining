<?php

namespace ZopNow\Hodor\Controller;


use ZopNow\Arya\View\Base;

class Me extends \ZopNow\Arya\Controller\Base
{

    public function get(){
        $data['id'] = $this->getCurrentUserId();
	$data['organizationId'] = $this->data['organizationId'];
        $userController = new User($data);
        return $userController->get();
    }

    public function post(){
        $this->data['hasToolAccess'] = 1;
        $userController = new User($this->data);
        return $userController->post();
    }

    public function put(){
        $data = $this->data;
        $data['id'] = $this->getCurrentUserId();
        $userController = new User($data);
        return $userController->put();
    }

    public function delete(){
        $data['id'] = $this->getCurrentUserId();
        $userController = new User($data);
        return $userController->delete();
    }

    protected function getCurrentUserId(){
        $userDetails = json_decode($this->user, true);
        return $userDetails['id'];
    }
}
