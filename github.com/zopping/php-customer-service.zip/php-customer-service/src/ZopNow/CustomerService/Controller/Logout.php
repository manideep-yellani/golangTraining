<?php

namespace ZopNow\CustomerService\Controller;

class Logout extends \ZopNow\Arya\Controller\Base
{

    public function post()
    {
        $data = $this->getRequestParams(['accessToken', 'organizationId']);
        \ZopNow\CustomerService\Auth\Auth::logout($data['accessToken']);

        return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'message' => "Successfully logged out",
        ]);
    }
}