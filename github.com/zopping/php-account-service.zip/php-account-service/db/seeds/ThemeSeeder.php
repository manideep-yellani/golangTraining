<?php

use Phinx\Seed\AbstractSeed;

class ThemeSeeder extends AbstractSeed
{

    public function run()
    {
        $faker = Faker\Factory::create();
        $data = [];
        for ($i = 0; $i < 20; $i++) {
            $name = $faker->name;
            $slug = str_slug($name);
            $data[] = [
                'name' => $name,
                'slug' => $slug,
                'image' => $faker->imageUrl(),
                'description' => $faker->paragraph
            ];
        }
        $themes = $this->table('themes');
        $themes->insert($data)
                ->save();
    }

}
