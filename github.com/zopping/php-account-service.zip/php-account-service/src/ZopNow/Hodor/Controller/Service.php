<?php

namespace ZopNow\Hodor\Controller;

class Service extends \ZopNow\Arya\Controller\ModelController
{

    public function __construct(array $data = [])
    {
        if(empty($data['id']) && !empty($data['slug'])){
            $modelObject = \ZopNow\Hodor\Model\Service::where([['slug', $data['slug']]])->first();
            if (empty($modelObject)) {
                throw new \ZopNow\Arya\Exception\ModelException("Service with slug ".$data['slug']." not found");
            }
            $data['id'] = $modelObject['id'];
        }
        parent::__construct($data);
    }

    public function get()
    {
        $data = $this->getRequestParams([], ["id", "organizationId"]);
        if (!empty($this->data['id'])) {
            $data = $this->getDetails();
        } else {
            $list = $this->getList();
            $data = $this->getListData($list);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    public function getDetails()
    {
        $details = $this->model->toArray();
        if(!is_null($this->organizationId)){
            $details['billingStrategy'] = $this->model->getBillingStrategy($this->organizationId);
        }
        return ['service' => $details];
    }
}