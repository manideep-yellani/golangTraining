<?php

use Phinx\Migration\AbstractMigration;

class OpsRolePermission extends AbstractMigration
{
    public function change()
    {
        $roles = [["name" => "OPS Manager"]];
        $this->insert('roles', $roles);
        $this->addTcPermissions();
    }

    private function addTcPermissions()
    {
        $roleId = $this->fetchRow("select id from roles where `name` = 'OPS Manager'")['id'];
        $endpoints = [
            'account-service/me' => ['GET', 'PUT'],
            'account-service/logout' => ['POST'],
            'catalogue-service/sales' => ['GET'],
            'order-service/stats' => ['GET'],
            'customer-service/stats' => ['GET'],
            'order-service/order-count' => ['GET'],
            'customer-service/customer' => ['GET'],
            'account-service/config' => ['GET'],
            'account-service/extension' => ['GET'],
            'logistics-service/trip' => ["GET", "PUT", "POST", "DELETE"],
            'order-service/order' => ['GET', 'POST', 'PUT'],
            'order-service/order-log' => ['GET'],
            'order-service/slot' => ['GET'],
            'order-service/picking-queue' => ['GET'],
            'logistics-service/vehicle' => ["GET", "PUT", "POST"],
            'logistics-service/vehicle-vendor' => ["GET", "PUT", "POST"],
            'logistics-service/vehicle-planner' => ["GET", "PUT", "POST", "DELETE"],
            'logistics-service/vehicle-attendance' => ["GET", "PUT", "POST"],
            'logistics-service/trip-eta' => ["GET"],
            'logistics-service/tripLocations' => ["GET"],
            'logistics-service/automation' => ["GET"],
            'account-service/employee' => ["GET", "POST", "PUT"],
            'account-service/attendance' => ["GET", "POST", "PUT", "DELETE"],
            'account-service/store' => ["GET"],
            'account-service/attendance-summary' => ["GET"],
            'account-service/designation' => ["GET", "POST", "PUT"],
        ];
        $roleEndpoints = $this->fetchAll("select id, url from endpoints where `url` in ('".implode("','",
                array_keys($endpoints))."')");
        $this->mapEndpoints($roleId, $roleEndpoints, $endpoints);
    }

    private function mapEndpoints($roleId, $roleEndpoints, $endpoints)
    {
        $details = [];
        foreach ($roleEndpoints as $roleEndpoint) {
            foreach ($endpoints[$roleEndpoint['url']] as $method) {
                $details[] = ['role_id' => $roleId, 'endpoint_id' => $roleEndpoint['id'],
                    'method' => $method];
            }
        }
        $this->insert('endpoint_role', $details);
    }
}
