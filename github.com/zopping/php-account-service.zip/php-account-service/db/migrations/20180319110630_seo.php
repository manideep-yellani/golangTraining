<?php

use Phinx\Migration\AbstractMigration;

class Seo extends AbstractMigration
{
    public function change()
    {
        $this->table('seo')
            ->addColumn('organization_id', 'integer', array('limit' => 11, 'null' => false))
            ->addColumn('page_id', 'integer', array('limit' => 11, 'null' => false))
            ->addColumn('url', 'string', array('limit' => 100, 'null' => true))
            ->addColumn('title', 'string', array('limit' => 70, 'null' => false))
            ->addColumn('description', 'text', array('null' => true, 'default' => null))
            ->addColumn('keywords', 'text', array('null' => true, 'default' => null))
            ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
            ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
            ->addForeignKey('organization_id','organizations','id', array('delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
            ->addForeignKey('page_id', 'pages','id')
            ->addIndex(['organization_id','page_id','url'], ['unique' => true])
            ->create();
    }
}
