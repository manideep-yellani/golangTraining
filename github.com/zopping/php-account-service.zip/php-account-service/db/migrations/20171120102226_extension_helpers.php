<?php

use Phinx\Migration\AbstractMigration;

class ExtensionHelpers extends AbstractMigration
{
    /**
     *
     * Add Helper Texts for enabling and disabling an extension
     */
    public function up()
    {
        $this->table("extensions")
            ->addColumn("enable_helper_text", "text", array("null" => true))
            ->addColumn("disable_helper_text", "text", array("null" => true))
            ->save();
        //Update Helper text for multi brand support extension
        $data = [
            "slug" => "MultiBrandSupport",
            "enable_helper_text" =>
                                    "Provides interfaces to manage brands | ".
                                    "Allows products to be associated with brands | ".
                                    "Website can use brands to filter their products | ".
                                    "Brand specific pages can be seen on the website | ".
                                    "Brand details will be added to SEO processing | ".
                                    "Analytics based on sales of products belonging to a brand will be available",
            "disable_helper_text" =>
                                    "Disables brand management interfaces | ".
                                    "Brand Association with products will be lost | | ".
                                    "Brand filters for products on website will be disabled | ".
                                    "Brand specific pages would be removed from website and SEO | ".
                                    "Brand specific analytics would not be available",
        ];
        $this->query("UPDATE extensions SET `enable_helper_text`='".$data['enable_helper_text']."', ".
                    "`disable_helper_text`='".$data['disable_helper_text']."' ".
                    "WHERE `slug` = '".$data['slug']."'");
    }

    public function down(){
        $this->table("extensions")
            ->removeColumn("enable_helper_text")
            ->removeColumn("disable_helper_text")
            ->save();
    }
}
