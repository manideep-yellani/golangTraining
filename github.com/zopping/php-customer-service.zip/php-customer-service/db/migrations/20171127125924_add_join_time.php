<?php


use Phinx\Migration\AbstractMigration;

class AddJoinTime extends AbstractMigration
{

    public function change()
    {
        $this->table("customers")
            ->addColumn('joined_time', 'timestamp', array('null' => true, 'after' => 'password'))
            ->addColumn('joined_on', 'date', array('null' => true, 'after' => 'joined_time'))
            ->addIndex('joined_on')
            ->save();

            $this->execute("update customers set joined_time = created_at");
            $this->execute("update customers set joined_on = DATE_FORMAT(created_at, '%Y-%m-%d')");
    }
}
