<?php

require_once('BaseCest.php');

class StorePostCest extends BaseCest
{
    protected static $endpoint = '/store';
    protected static $table = 'stores';
/*
    public function createStore(ApiTester $I)
    {
        $I->wantTo("Create store with basic data");
        $data = [
            'name' => 'My More Store',
            'organizationId' => 1,
            'clientStoreId' => '10001',
            'latitude' => "19.1109315000000",
            'longitude' => "72.9180475000000",
            'address' => "Banashankari 3rd stage, Bangalore - 85"
        ];
        parent::create($I, $data);
    }
*/
    public function createStoreWithoutName(ApiTester $I)
    {
        $I->wantTo("Create store without name");
        $data = [
            'organizationId' => 1,
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
        ));
    }

    public function createStoreWithoutOrganization(ApiTester $I)
    {
        $I->wantTo("Create store without organization");
        $data = [
            'name' => 'Naamdharis',
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - store : organization Id",
        ));
    }

    public function createStoreInvaidLatitude(ApiTester $I)
    {
        $I->wantTo("Create store with invalid latitude");
        $data = [
            'name' => 'Carrefour',
            'organizationId' => 1,
            'latitude' => "92.1109315000000",
            'longitude' => "72.9180475000000",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid latitude value']);
    }

    public function createStoreInvaidLongitude(ApiTester $I)
    {
        $I->wantTo("Create store with invalid latitude");
        $data = [
            'name' => 'Carrefour',
            'organizationId' => 1,
            'latitude' => "19.1109315000000",
            'longitude' => "190.9180475000000",
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid longitude value']);
    }
/*
    public function createStoreWithSameName(ApiTester $I)
    {
        $I->wantTo("Create store with existing name in the organization");
        $data = [
            'name' => 'My More Store',
            'organizationId' => 1,
            'clientStoreId' => '10001',
            'latitude' => "19.1109315000000",
            'longitude' => "72.9180475000000",
            'address' => "Banashankari 3rd stage, Bangalore - 85"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Store with the name My More Store already exists']);
    }

    public function createStoreWithNegativeLatLong(ApiTester $I)
    {
        $I->wantTo("Create store with negative values for latitude and longitude");
        $data = [
            'name' => 'Big Bazaar',
            'organizationId' => 1,
            'latitude' => "-67.6789000000000",
            'longitude' => "-121.6789850000000",
        ];
        parent::create($I, $data);
    }

    public function addDeletedStore(ApiTester $I)
    {
        $I->wantTo("Create a store with same name as that was previously deleted");
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Test Store', 'organization_id' => 2]
        );
        $I->sendDELETE(self::$endpoint . "/$id", ['organizationId' => 2]);
        $data = [
            'name' => 'Test Store',
            'organizationId' => 2,
            'latitude' => "-76.6789000000000",
            'longitude' => "-141.6789850000000",
        ];
        parent::create($I, $data);
    }*/
}