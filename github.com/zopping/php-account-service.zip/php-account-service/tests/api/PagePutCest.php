<?php

class PagePutCest
{

    protected static $endpoint = '/page';

    public function addPageLayoutsWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Add page layout data without organization id');
        $data = [
            'layouts' => json_encode([
                [
                    "title" => "Title",
                    "message" => "Just a message"
                ]
            ])
        ];
        $I->sendPUT(static::$endpoint . "/CATEGORY", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - page : organization Id'));
    }

    public function addPageLayoutsWithValidData(ApiTester $I)
    {
        $I->wantTo("Add page layout data with valid data");
        $data = [
            'organizationId' => 4,
            'layouts' => json_encode([
                [
                    "name" => 'ImageSlideshow',
                    "data" => [
                        "text" => "Title",
                        "link" => "http://link1.com",
                        "imageUrl" => "http://www.image.com"
                    ]
                ],
                [
                    "name" => "LinkCollection",
                    "data" => [
                        "text" => "Title",
                        "link" => "http://link.com"
                    ]
                ]
            ])
        ];
        $I->sendPUT(static::$endpoint . "/BRAND", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "page" => array(
                    "id" => "integer",
                    "name" => "string",
                    "layouts" => "string",
                )
            )
        ));
        $I->seeResponseContainsJson(['name' => 'BRAND']);
    }

    public function addPageLayoutsWithInvalidOrganizationId(ApiTester $I)
    {
        $I->wantTo('Add page layout data with invalid organization id');
        $data = [
            'organizationId' => 100,
            'layouts' => json_encode([
                [
                    "title" => "Title",
                    "message" => "Just a message"
                ]
            ])
        ];
        $I->sendPUT(static::$endpoint . "/CATEGORY", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Organization with id: 100 not found'));
    }

    public function addPageLayoutsWithValidDataForAUrl(ApiTester $I)
    {
        $I->wantTo("Add page layout data with valid data for a particular url");
        $layoutData = json_encode(
            array(
                0 => array(
                    "name" => 'ImageSlideshow',
                    "data" => array(
                        "text" => "Test Title",
                        "link" => "http://link1.com",
                        "imageUrl" => "http://www.image.com"
                    )
                ),
                1 => array(
                    "name" => "LinkCollection",
                    "data" => array(
                        "text" => "Test Title",
                        "link" => "http://link.com"
                    )
                )
            )
        );
        $data = [
            'organizationId' => 4,
            'layouts' => $layoutData,
            'url' => '/test'
        ];
        $I->sendPUT(static::$endpoint . "/BRAND", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "page" => array(
                    "id" => "integer",
                    "name" => "string",
                    "layouts" => "string",
                )
            )
        ));
        $I->seeResponseContainsJson(['name' => 'BRAND', 'layouts' => $layoutData]);
        $I->sendGET(static::$endpoint . "/BRAND?organizationId=4&url=/test");
        $I->seeResponseContainsJson(['name' => 'BRAND', 'layouts' => $layoutData]);
    }

    public function addStaticPageWithoutUrl(ApiTester $I)
    {
        $I->wantTo('Add page layout data for CONSTANT page without url filter');
        $layoutData = json_encode(
            array(
                0 => array(
                    'data' => array(
                        'link' => '',
                        'title' => 'Static Page',
                        'imageUrl' => "http://via.placeholder.com/250X141",
                        'description' => 'Test Static page description',
                        ),
                    'name' => 'ImageWithText',
                ),
            )
        );
        $data = [
            'organizationId' => 4,
            'layouts' => $layoutData,
        ];
        $I->sendPUT(self::$endpoint . "/CONSTANT", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - page : url'));
    }

    public function addStaticPageWithUrlFilter(ApiTester $I)
    {
        $I->wantTo('Add page layout data for CONSTANT page with url filter');
        $layoutData = json_encode(
            array(
                0 => array(
                    'data' => array(
                        'link' => '',
                        'title' => 'Static Page',
                        'imageUrl' => "http://via.placeholder.com/250X141",
                        'description' => 'Test Static page description',
                        ),
                    'name' => 'ImageWithText',
                ),
            )
        );
        $data = [
            'organizationId' => 4,
            'layouts' => $layoutData,
            'url' => 'test'
        ];
        $I->sendPUT(static::$endpoint . "/CONSTANT", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "page" => array(
                    "id" => "integer",
                    "name" => "string",
                    "layouts" => "string",
                )
            )
        ));
        $I->seeResponseContainsJson(['name' => 'CONSTANT', 'layouts' => $layoutData]);
        $I->sendGET(static::$endpoint . "/CONSTANT?organizationId=4&url=test");
        $I->seeResponseContainsJson(['name' => 'CONSTANT', 'layouts' => $layoutData]);
    }

    public function addPageWithEmptyLayouts(ApiTester $I)
    {
        $I->wantTo('Add page without any layouts');
        $data = [
            'organizationId' => 3,
            'layouts' => json_encode([])
        ];
        $I->sendPUT(static::$endpoint . "/BRAND", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "page" => array(
                    "id" => "integer",
                    "name" => "string",
                    "layouts" => "string",
                )
            )
        ));
        $I->seeResponseContainsJson(['name' => 'BRAND']);
    }

    public function addInvalidLayoutsForBrandPage(ApiTester $I)
    {
        $layouts = [
            [
                "data" => [],
                "name" => "ProductDetail"
            ]
        ];
        $I->sendPUT(self::$endpoint."/BRAND", ["layouts" => $layouts, "organizationId" => 2]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing required layouts - ProductCollection"]);
    }

    public function addInvalidLayoutsForCategoryPage(ApiTester $I)
    {
        $layouts = [
            [
                "data" => [],
                "name" => "ImageWithDescription"
            ]
        ];
        $I->sendPUT(self::$endpoint."/CATEGORY", ["layouts" => $layouts, "organizationId" => 2]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing required layouts - ProductCollection"]);

    }

    public function addInvalidLayoutsForProductPage(ApiTester $I)
    {
        $layouts = [
            [
                "data" => [
                    "tag" => "",
                    "brand" => ""
                ],
                "name" => "ProductCollection"
            ]
        ];
        $I->sendPUT(self::$endpoint."/PRODUCT", ["layouts" => $layouts, "organizationId" => 2]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing required layouts - ProductDetail"]);
    }

    public function addInvalidLayoutsForTagPage(ApiTester $I)
    {
        $layouts = [
            [
                "data" => [],
                "name" => "ImageWithDescription"
            ]
        ];
        $I->sendPUT(self::$endpoint."/TAG", ["layouts" => $layouts, "organizationId" => 2]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(["message" => "Validation Exception: Missing required layouts - ProductCollection"]);
    }

    public function addValidLayoutsForTagPage(ApiTester $I)
    {
        $layouts = [
            [
                "data" => [
                    "link"=> "",
                    "title" => "Fruits",
                    "imageUrl" => "https://www.zopnow.com/Fresh%20Strawberry-s.php"
                ],
                "name" => "ImageWithText"
            ],
            [
                "data" => [
                    "tag" => "CURRENT",
                    "brand" => "",
                    "title" => "Products"
                ],
                "name" => "ProductCollection"
            ]
        ];
        codecept_debug(json_encode($layouts));
        $I->sendPUT(self::$endpoint."/TAG", ["layouts" => $layouts, "organizationId" => 2]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $outputLayouts = $I->grabDataFromResponseByJsonPath("$.data.page.layouts")[0];
        $I->assertEquals("ImageWithText", $outputLayouts[0]['name']);
        $I->assertEquals("ProductCollection", $outputLayouts[1]['name']);
    }
}
