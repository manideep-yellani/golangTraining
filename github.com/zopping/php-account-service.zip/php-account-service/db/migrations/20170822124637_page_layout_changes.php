<?php

use Phinx\Migration\AbstractMigration;

class PageLayoutChanges extends AbstractMigration
{
    /**
     * Layouts table is dropped.
     * Adding TAG and STATIC pages in pages table.
     * Renaming page_layouts table to organization_page
     * Removed layout_id, configuration_values and sequence_number columns from page_layouts table
     * 
     */
    public function change()
    {
        $this->execute("SET FOREIGN_KEY_CHECKS = 0");
        $this->table("layouts")->drop();
        $pageData = array(
            array(
                "name" => "TAG"
            ),
            array(
                "name" => "STATIC"
            )
        );
        $page = $this->table("pages");
        $page->insert($pageData)
             ->save();
        $pageLayouts = $this->table("page_layouts");
        $pageLayouts->rename("organization_page")
                    ->dropForeignKey("layout_id")
                    ->removeColumn("layout_id")
                    ->removeColumn("configuration_values")
                    ->removeColumn("sequence_number")
                    ->renameColumn("data_values", "layouts")
                    ->save();        
    }
}