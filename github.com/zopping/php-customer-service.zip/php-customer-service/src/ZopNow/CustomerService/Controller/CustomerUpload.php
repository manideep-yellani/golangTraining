<?php

namespace ZopNow\CustomerService\Controller;

class CustomerUpload extends \ZopNow\Arya\Controller\Base
{
    private static $uploadDir;
    private static $fileIndex;
    private static $config;
    private static $ftpCredentials = [];

    public static function configure($option)
    {
        if (isset($option['uploadDir']) && $option['uploadDir'] !== "") {
            self::$uploadDir = $option['uploadDir'];
            if (!is_dir(self::$uploadDir)) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid Upload Path");
            }
        }
        if (isset($option['fileIndex']) && $option['fileIndex'] !== "") {
            self::$fileIndex = $option['fileIndex'];
        }
        self::$ftpCredentials = $option['ftpCredentials'];
    }

    public function get()
    {
        $variables = array(
            "ClientId",
            "Name",
            "Phone",
            "Email",
        );
        $metaData = $this->getMetadataConfig($this->organizationId);
        foreach ($metaData as $row) {
            array_push($variables, $row);
        }
        return (new \ZopNow\Arya\View\Base(
            [
                "code" => 200,
                "status" => "SUCCESS",
                "data" => array("customerUpload" => $variables)
            ]
        ));
    }

    public function post()
    {
        $data = $this->getRequestParams(["organizationId"]);
        if (empty($_FILES[self::$fileIndex])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please provide the file data");
        }
        $paths = $this->validateAndUpload($data['organizationId']);
        $path = $paths['localPath'];

        //Validate if the expected variables are present in the first row of the file.
        $handle = fopen($path, 'r');
        $variables = $this->get()->getData()['data']['customerUpload'];
        $firstRow = array_map("trim", fgetcsv($handle));
        $containsAllHeaders = array_diff($variables, $firstRow);
        if (!empty($containsAllHeaders)) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "The file does not contain the headers - " . implode(',', $containsAllHeaders)
            );
        }
        $this->validateAllRows($handle, $firstRow);

        $data['fileName'] = $path;
        \ZopNow\CustomerService\Model\CustomerFile::insert(
            ['location' => $paths['ftpPath'], 'organization_id' => $data['organizationId']]
        );
        return (new \ZopNow\Arya\View\Base(
            [
                "code" => 200,
                "status" => "SUCCESS",
                "message" => "File uploaded successfully."
                . " Once customers have been updated, you will be notified via email."
            ]
        ));
    }

    private function validateAndUpload($organizationId)
    {
        //Validate file type
        $type = trim(shell_exec('file --mime-type --brief '.$_FILES[self::$fileIndex]["tmp_name"]));
        if ($type !== "text/csv" && ($type !== "text/plain")) {
            throw new \ZopNow\Arya\Exception\ValidationException("File must be in csv format");
        }

        //Move file to the data folder
        $filename = $organizationId."-Customers-" . date('YmdHis') . ".csv";
        $path = self::$uploadDir . $filename;
        if (file_exists($path)) {
            throw new \ZopNow\Arya\Exception\ValidationException("File Already Exists");
        }
        if (move_uploaded_file($_FILES[self::$fileIndex]["tmp_name"], $path) === false) {
            throw new \ZopNow\Arya\Exception\ValidationException("Could not upload file");
        }
        //Remove all duplicate lines
        $lines = shell_exec("uniq $path");
        file_put_contents($path, $lines);
        //Place file in FTP location
        $date = date("Y-m-d");
        $name = "uploads/customers/$organizationId/$date/$filename";
        $ftp = new \ZopNow\CustomerService\Utility\Ftp(self::$ftpCredentials['user'], self::$ftpCredentials['password'], self::$ftpCredentials['host']);
        $ftp->setPassive(true);
        $ftp->put($path, $name);
        return [
            "ftpPath" => $name,
            "localPath" => $path
        ];
    }

    private function validateAllRows($fileHandle, $headerRow)
    {
        $headers = array_flip($headerRow);
        $lineNumber = 1;
        while (($row = fgetcsv($fileHandle)) !== false) {
            $lineNumber++;
            $row = array_map("trim", $row);
            //Validate all the fields in the row
            if (empty($row[$headers['Name']])) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Error on line $lineNumber - Name is missing"
                );
            }
            if (empty($row[$headers['ClientId']])
                && empty($row[$headers['Phone']])
                && empty($row[$headers['Email']])
           ) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Error on line $lineNumber - Either client id, phone or email must be given"
                );
            }
            if (!empty($row[$headers['Phone']])
                && !\ZopNow\Arya\Utility\Validator::isPhone($row[$headers['Phone']])
            ) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Error on line $lineNumber - Invalid Phone"
                );
            }
            if (!empty($row[$headers['Email']])
                && !\ZopNow\Arya\Utility\Validator::isEmail($row[$headers['Email']])
            ) {
                throw new \ZopNow\Arya\Exception\ValidationException(
                    "Error on line $lineNumber - Invalid Email"
                );
            }
        }
    }

    public function getMetadataConfig($organizationId)
    {
        if(!isset(self::$config[$organizationId])) {
            $organizationResponse = \ZopNow\Arya\Utility\MicroService::callService("account-service", "/config/entityMetaData", 'GET', ['organizationId' => $organizationId]);
            $configData = json_decode($organizationResponse['body'], true)['data']['config']['entityMetaData'];
            self::$config[$organizationId] = array_keys($configData['customer'] ?? []);
        }
        return self::$config[$organizationId];
    }

}
