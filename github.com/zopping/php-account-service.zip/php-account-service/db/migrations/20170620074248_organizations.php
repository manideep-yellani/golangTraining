<?php

use Phinx\Migration\AbstractMigration;

class Organizations extends AbstractMigration
{
    /**
     * Database schema for "organizations" table
     * It consists of the following fields :
     * name : stores the name of the organization
     * slug : slug is a unique field which will be generated from the name
     * domain : stores the domain name for the organization
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     * deleted_at : field will be NULL. This field will be set to the timestamp when the organization is deleted and it is a soft delete.
     *
     * "id" is the primary key for the table. "slug" and "domain" are the unique indexes for the table
     */
    public function change()
    {
        $organization = $this->table('organizations');
        $organization->addColumn('name', 'string', array('limit' => 200))
                    ->addColumn('slug', 'string', array('limit' => 250))
                    ->addColumn('domain', 'string', array('limit' => 100))
                    ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                    ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                    ->addColumn('deleted_at', 'timestamp', array('null' => true))
                    ->addIndex(array('slug'), array('unique' => true))
                    ->addIndex(array('domain'), array('unique' => true))
                    ->create();
    }
}
