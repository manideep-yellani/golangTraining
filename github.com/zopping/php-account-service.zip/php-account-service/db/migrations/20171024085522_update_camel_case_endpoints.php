<?php

use Phinx\Migration\AbstractMigration;

class UpdateCamelCaseEndpoints extends AbstractMigration
{

    public function change()
    {
        $endpoints = [
            'account-service/resetPassword' => 'account-service/reset-password',
            'account-service/changePassword' => 'account-service/change-password',
            'catalogue-service/productUpload' => 'catalogue-service/product-upload',
            'customer-service/OAuth' => 'customer-service/o-auth',
            'order-service/orderItem' => 'order-service/order-item',
            'order-service/orderPayment' => 'order-service/order-payment',
            'order-service/verifyPayment' => 'order-service/verify-payment',
            ];
        foreach ($endpoints as $oldEndpoint => $newEndpoint) {
            $this->execute("update endpoints set url = '$newEndpoint' where url= '$oldEndpoint'");
        }
    }
}
