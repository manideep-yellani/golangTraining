<?php

use Phinx\Migration\AbstractMigration;

class EndpointUserPermissions extends AbstractMigration
{

    public function change()
    {
        $endpoints = $this->table("endpoints");
        $endpoints->removeColumn("configuration_keys");

        $endpointUsers = $this->table('endpoint_user_permissions');
        $endpointUsers->addColumn('endpoint_id', 'integer', array('limit' => 11))
                ->addColumn('user_id', 'integer', array('limit' => 11))
                ->addColumn('method', 'enum', array('values' => ["GET", "POST", "PUT", "DELETE"], 'default' => 'GET'))
                ->addColumn('has_permission', 'boolean', array('default' => 0))
                ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addColumn('deleted_at', 'timestamp', array('null' => true))
                ->addForeignKey('endpoint_id', 'endpoints', 'id')
                ->addForeignKey('user_id', 'users', 'id')
                ->addIndex(array('user_id', 'endpoint_id', 'method'), array('unique' => true))
                ->create();

        $endpointDevelopers = $this->table('endpoint_developer_permissions');
        $endpointDevelopers->addColumn('endpoint_id', 'integer', array('limit' => 11))
                ->addColumn('developer_id', 'integer', array('limit' => 11))
                ->addColumn('method', 'enum', array('values' => ["GET", "POST", "PUT", "DELETE"], 'default' => 'GET'))
                ->addColumn('has_permission', 'boolean', array('default' => 0))
                ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addColumn('deleted_at', 'timestamp', array('null' => true))
                ->addForeignKey('endpoint_id', 'endpoints', 'id')
                ->addForeignKey('developer_id', 'developers', 'id')
                ->addIndex(array('developer_id', 'endpoint_id', 'method'), array('unique' => true))
                ->create();
    }

}
