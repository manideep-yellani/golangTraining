<?php

use Phinx\Seed\AbstractSeed;

class DeveloperSeeder extends AbstractSeed
{
    /**
     * Run Method.
     *
     * Write your database seeder using this method.
     *
     * More information on writing seeders is available here:
     * http://docs.phinx.org/en/latest/seeding.html
     */
    public function run()
    {
        $this->execute('SET FOREIGN_KEY_CHECKS = 0');
        $config = include 'config/test.php';
        $encryptionConfig['key'] = $config['ZopNow\Arya\Utility\Encryption']['key'];
        \ZopNow\Arya\Utility\Encryption::configure($encryptionConfig);
        $token = \ZopNow\Arya\Utility\Encryption::encrypt('7e57d004-2b97-0e7a-b45f-5387367791cd', false);
        $data = [
            [
                'organization_id' => 1,
                'name' => 'Self Checkout App',
                'token' => $token
            ]
        ];
        $faker = Faker\Factory::create();
        for ($i = 0; $i < 50; $i++) {
            $name = $faker->name;
            $data[] = [
                'organization_id' => $faker->numberBetween(1, 4),
                'name' => $name,
                'token' => \ZopNow\Arya\Utility\Encryption::encrypt($faker->unique->uuid, false),
            ];
        }
        $table = $this->table('developers');
        $table->insert($data)
            ->save();
    }
}
