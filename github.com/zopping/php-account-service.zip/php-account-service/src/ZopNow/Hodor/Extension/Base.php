<?php

namespace ZopNow\Hodor\Extension;

use ZopNow\Hodor\Model\Organization;

/**
 * Class Base
 * @package ZopNow\Hodor\Extension
 * Base class that every extension should extend from.
 * It provides hooks on enabling and disabling an extension
 *
 * Every class extended from Base needs to implement enable and disable methods.
 *
 */
abstract class Base
{
    protected $data, $organization;

    public function __construct($organizationId = null, array $data = [])
    {
        $this->data = $data;
        if(!is_null($organizationId)){
            $this->organization = Organization::findOrFail(['id' => $organizationId])->first();
        }
    }

    /**
     * Abstract method that will be executed when an extension is enabled for an organization
     * @return null
     */
    abstract public function enable();

    /**
     * Abstract method that will be executed when an extension is disabled for an organization
     * @return null
     */
    abstract public function disable();

    /**
     * Magic Method used to access protected data.
     * @param $var Variable being queried
     * @return Value of the variable in data if key exists or null
     */
    final public function __get($var)
    {
        return (isset($this->data[$var])) ? $this->data[$var] : null;
    }

    /**
     * Abstract method that will be give called to get the cost of the extension for the given date range
     * @return Cost of the extension service for the given date range
     */
    abstract public function getBillingAmount($startDate, $endDate, $pricingRule);

    /**
     * public method that will be executed when an extension prerequisites required
     * @return Prerequisites
     */
    public function configurePrerequisites($prerequisites) {
        return null;
    }

}