<?php

use Phinx\Migration\AbstractMigration;

class OrganizationRoles extends AbstractMigration
{

    public function up()
    {
        $this->table("roles")
            ->addColumn("organization_id", 'integer',
                array('limit' => 11, 'null' => true, 'after' => 'name'))
            ->addForeignKey('organization_id', 'organizations', 'id')
            ->removeIndex(['name'])
            ->addIndex(['name', 'organization_id'])
            ->save();
        $allowedMethods = json_encode(['GET','POST','PUT','DELETE']);
        $this->execute("update endpoints set allowed_methods = '$allowedMethods' "
            . " where url = 'account-service/role'");
    }

    public function down()
    {
        $this->table("roles")
            ->removeIndex(['name', 'organization_id'])
            ->addIndex(['name'])
            ->dropForeignKey("organization_id")
            ->removeColumn("organization_id")
            ->save();
        $allowedMethods = json_encode(['GET']);
        $this->execute("update endpoints set allowed_methods = '$allowedMethods' "
            . " where url = 'account-service/role'");
    }

}
