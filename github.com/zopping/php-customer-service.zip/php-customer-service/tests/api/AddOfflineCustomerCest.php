<?php

require_once('BaseCest.php');

class AddOfflineCustomerPostCest extends BaseCest
{
    protected static $endpoint = '/customer';
    protected static $table    = "customers";

    private function testData(ApiTester $I, $data, $statusCode = 200)
    {
        try {
            $I->sendPost(self::$endpoint, $data);
            $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
            $I->seeResponseIsJson();
            $customerId = $I->grabDataFromResponseByJsonPath('$.data.customer.id')[0];
            $name = $data['name'];
            $I->seeInDatabase(self::$table, ["id" => $customerId, "name" => $name,
                "organization_id" => $data['organizationId']]);
            if (!empty($data['email'])) {
                $I->seeInDatabase(
                    "emails", ["customer_id" => $customerId, "email" => $data['email'],
                    "deleted_at" => null]
                );
            }
            if (!empty($data['phone'])) {
                $I->seeInDatabase(
                    "phones", ["customer_id" => $customerId, "phone" => $data['phone'],
                    "deleted_at" => null]
                );
            }
            if (!empty($data['clientId'])) {
                $I->seeInDatabase(
                    "client_customers", ["customer_id" => $customerId,
                    "client_id" => $data['clientId'], "deleted_at" => null]
                );
            }
            $I->seeResponseContainsJson(['code' => $statusCode]);
        } catch (Exception $ex) {
            parent::serviceDownTest($I);
        }
    }
/*
    public function addOfflineCustomerWithValidData(ApiTester $I)
    {
        $I->wantToTest("Creating offline customer with valid data");
        $data = array(
            "name" => "Neha",
            "organizationId" => 1,
            "phone" => "+919988776465",
            "email" => "neha@gmail.com",
            "clientId" => 101,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 201);
    }

    public function addCustomerWithExistingClientId(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with existing client id and new phone and/or email"
        );
        /**
         * The new phone and email must be attached to the existing customer
         */
/*        $id = $I->haveInDatabase('customers', ['name' => 'Sam', 'organization_id' => 1]);
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 501]
        );
        $data = array(
            "name" => "Samuel",
            "organizationId" => 1,
            "phone" => "+919846342712",
            "email" => "samuel@gmail.com",
            "clientId" => 501,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $id]);
    }
*/
    public function createOfflineUserWithExistingPhoneDiffClientId(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with existing phone(linked to a client id)"
            . " and a new client id"
        );
        /**
         * Error should be thrown since phone is mapped to a different user
         */
        $id = $I->haveInDatabase('customers', ['name' => 'Sam', 'organization_id' => 1]);
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 501]
        );
        $I->haveInDatabase('phones', ['customer_id' => $id, 'phone' => '919846342723']);
        $data = array(
            "name" => "Diana",
            "organizationId" => 1,
            "phone" => "+919846342723",
            "email" => "diana@gmail.com",
            "clientId" => 502,
            "isSignup" => false,
            "isOffline" => true,
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ['message' => "Validation Exception: Phone already exists"]
        );
    }
/*
    public function createOfflineUserWithExistingPhoneNewClientId(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with existing phone(not linked to any client id)"
            . " and a new client id"
        );
        /**
         * The client id must be added to the existing customer
         */
/*        $id = $I->haveInDatabase('customers', ['name' => 'Mitchell', 'organization_id' => 1]);
        $I->haveInDatabase('phones', ['customer_id' => $id, 'phone' => '919846342724']);
        $data = array(
            "name" => "Mitchell",
            "organizationId" => 1,
            "phone" => "+919846342724",
            "email" => "mitchell@gmail.com",
            "clientId" => 513,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $id]);
    }

    public function createOfflineUserWithExistingPhoneNoClientId(ApiTester $I)
    {
        $I->wantTo("Add offline customer with existing phone, new email and no client id");
        /**
         * The email should be attached to the existing user
         */
/*        $id = $I->haveInDatabase('customers', ['name' => 'Eloise', 'organization_id' => 1]);
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 512]
        );
        $I->haveInDatabase('phones', ['customer_id' => $id, 'phone' => '919846342725']);
        $data = array(
            "name" => "Eloise",
            "organizationId" => 1,
            "phone" => "+919846342725",
            "email" => "eloise@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $id]);
    }
*/
    public function createOfflineUserWithExistingEmailDiffClientId(ApiTester $I)
    {
        $I->wantTo("Add offline customer with existing email and a new client id");
        /**
         * Error should be thrown since email is mapped to a different user
         */
        $id = $I->haveInDatabase('customers', ['name' => 'Sam', 'organization_id' => 1]);
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 503]
        );
        $I->haveInDatabase('emails', ['customer_id' => $id, 'email' => 'sam@gmail.com']);
        $data = array(
            "name" => "Samuel",
            "organizationId" => 1,
            "phone" => "+919846342726",
            "email" => "sam@gmail.com",
            "clientId" => 504,
            "isSignup" => false,
            "isOffline" => true,
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ['message' => "Validation Exception: Email already exists"]
        );
    }
/*
    public function createOfflineUserWithExistingEmailNewClientId(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with existing email(not linked to any client id)"
            . " and a new client id"
        );
        /**
         * The client id must be attached to the existing user
         */
 /*       $id = $I->haveInDatabase('customers', ['name' => 'Karlie', 'organization_id' => 1]);
        $I->haveInDatabase('emails', ['customer_id' => $id, 'email' => 'karlie@gmail.com']);
        $data = array(
            "name" => "Karlie",
            "organizationId" => 1,
            "email" => "karlie@gmail.com",
            "clientId" => 508,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $id]);
    }

    public function createOfflineUserWithExistingEmailNoClientId(ApiTester $I)
    {
        $I->wantTo("Add offline customer with existing email, new phone and no client id");
        /**
         * The phone should be attached to the existing user
         */
   /*     $id = $I->haveInDatabase('customers', ['name' => 'Sam', 'organization_id' => 1]);
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 501]
        );
        $I->haveInDatabase('emails', ['customer_id' => $id, 'email' => 'sam@gmail.com']);
        $data = array(
            "name" => "Samuel",
            "organizationId" => 1,
            "phone" => "+919846342727",
            "email" => "sam@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $id]);
    }
    
    public function addPhoneToExistingUser(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with new phone and existing client id and email"
            . " mapped to same user"
        );
        /**
         * The new phone must be added to the existing user
         */
     /*   $id = $I->haveInDatabase('customers', ['name' => 'Diana', 'organization_id' => 1]);
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 514]
        );
        $I->haveInDatabase('emails', ['customer_id' => $id, 'email' => 'diana@gmail.com']);
        $data = array(
            "name" => "Diana",
            "organizationId" => 1,
            "clientId" => 514,
            "phone" => "+919846342729",
            "email" => "diana@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $id]);
    }
    */
    public function addUserWithExistingClientIdAndEmail(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with new phone and existing client id and email"
            . " mapped to different users"
        );
        /**
         * Error must be thrown since email is mapped to different user
         */
        $customer1 = $I->haveInDatabase(
            'customers', ['name' => 'Ben', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customer1, 'organization_id' => 1, 'client_id' => 505]
        );
        $customer2 = $I->haveInDatabase(
            'customers', ['name' => 'Pete', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'emails', ['customer_id' => $customer2, 'email' => 'pete@gmail.com']
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customer2, 'organization_id' => 1, 'client_id' => 515]
        );
        $data = array(
            "name" => "Ben",
            "organizationId" => 1,
            "clientId" => 505,
            "phone" => "+919846342731",
            "email" => "pete@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ['message' => "Validation Exception: Email already exists"]
        );
    }
/*
    public function addEmailToExistingUser(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with new email and existing client id and phone"
            . " mapped to same user"
        );
        /**
         * The new email must be added to the existing user
         */
  /*      $id = $I->haveInDatabase(
            'customers', ['name' => 'Diana', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $id, 'organization_id' => 1, 'client_id' => 506]
        );
        $I->haveInDatabase('phones', ['customer_id' => $id, 'phone' => '919846342732']);
        $data = array(
            "name" => "Diana",
            "organizationId" => 1,
            "clientId" => 506,
            "phone" => "+919846342732",
            "email" => "diana@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $id]);
    }
*/
    public function addUserWithExistingClientIdAndPhone(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer with new email and existing client id and phone"
            . " mapped to different users"
        );
        /**
         * Error must be thrown since email is mapped to different user
         */
        $customer1 = $I->haveInDatabase(
            'customers', ['name' => 'Ben', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customer1, 'organization_id' => 1, 'client_id' => 505]
        );
        $customer2 = $I->haveInDatabase(
            'customers', ['name' => 'Pete', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'phones', ['customer_id' => $customer2, 'phone' => '919846342733']
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customer2, 'organization_id' => 1, 'client_id' => 515]
        );
        $data = array(
            "name" => "Ben",
            "organizationId" => 1,
            "clientId" => 505,
            "phone" => "+919846342733",
            "email" => "ben@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ['message' => "Validation Exception: Phone already exists"]
        );
    }
/*
    public function addUserWithoutClientIdAndExistingPhoneAndEmail(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer without client id and existing phone and email"
            . " mapped to same user"
        );
        /**
         * No changes to existing user. Successful response
         */
  /*      $customerId = $I->haveInDatabase(
            'customers', ['name' => 'Ben', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customerId, 'client_id' => 506, 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'phones', ['customer_id' => $customerId, 'phone' => '919846342733']
        );
        $I->haveInDatabase(
            'emails', ['customer_id' => $customerId, 'email' => 'ben@gmail.com']
        );
        $data = array(
            "name" => "Ben",
            "organizationId" => 1,
            "phone" => "+919846342733",
            "email" => "ben@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 211);
        $I->seeResponseContainsJson(['id' => $customerId]);
    }
*/
    public function addUserWithoutClientIdAndExistingDifferentPhoneAndEmail(ApiTester $I)
    {
        $I->wantTo(
            "Add offline customer without client id and existing phone and email"
            . " mapped to different users"
        );
        /**
         * Error must be thrown since email and phone are mapped to different users
         */
        $customer1 = $I->haveInDatabase(
            'customers', ['name' => 'Jess', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customer1, 'organization_id' => 1, 'client_id' => 507]
        );
        $I->haveInDatabase(
            'emails', ['customer_id' => $customer1, 'email' => 'jess@gmail.com']
        );
        $customer2 = $I->haveInDatabase(
            'customers', ['name' => 'Pete', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'phones', ['customer_id' => $customer2, 'phone' => '919846342734']
        );
        $data = array(
            "name" => "Jess",
            "organizationId" => 1,
            "phone" => "+919846342734",
            "email" => "jess@gmail.com",
            "isSignup" => false,
            "isOffline" => true,
        );
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ['message' => "Validation Exception: Email or phone already exists"]
        );
    }
/*
    public function addUserWithExistingDifferentEmailAndClientId(ApiTester $I)
    {
        $I->wantTo(
            "Add a user with existing client id and existing email mapped to"
            . " different users and user with existing email does not have client id"
        );
        /**
         * Merge the two users
         */
  /*      $customer1 = $I->haveInDatabase(
            'customers', ['name' => 'Sarah', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'emails', ['customer_id' => $customer1, 'email' => 'sarah@gmail.com']
        );
        $customer2 = $I->haveInDatabase(
            'customers', ['name' => 'Callan', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customer2, 'organization_id' => 1, 'client_id' => 509]
        );
        $I->haveInDatabase(
            'emails', ['customer_id' => $customer2, 'email' => 'callan@gmail.com']
        );
        $data = array(
            "name" => "Callan",
            "organizationId" => 1,
            "phone" => "+919846342787",
            "email" => "sarah@gmail.com",
            "clientId" => 509,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 212);
        $I->seeResponseContainsJson(['id' => $customer2]);
    }

    public function addUserWithExistingDifferentPhoneAndClientId(ApiTester $I)
    {
        $I->wantTo(
            "Add a user with existing client id and existing phone mapped to "
            . "different users and user with existing phone does not have client id"
        );
        /**
         * Merge the two users
         */
/*        $customer1 = $I->haveInDatabase(
            'customers', ['name' => 'Sarah', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'phones', ['customer_id' => $customer1, 'phone' => '919846342779']
        );
        $customer2 = $I->haveInDatabase(
            'customers', ['name' => 'Pia', 'organization_id' => 1]
        );
        $I->haveInDatabase(
            'client_customers',
            ['customer_id' => $customer2, 'organization_id' => 1, 'client_id' => 510]
        );
        $I->haveInDatabase(
            'emails', ['customer_id' => $customer2, 'email' => 'pia@gmail.com']
        );
        $data = array(
            "name" => "Pia",
            "organizationId" => 1,
            "phone" => "+919846342779",
            "email" => "pia@gmail.com",
            "clientId" => 510,
            "isSignup" => false,
            "isOffline" => true,
        );
        $this->testData($I, $data, 212);
        $I->seeResponseContainsJson(['id' => $customer2]);
    }

    public function userSignupForOfflineCustomer(ApiTester $I)
    {
        /**
         * User tries to sign up with phone and email that are mapped to
         *  different offline customers. The two customers must be merged together
         *  and both client ids must be mapped to the merged customer.
         */
  /*      $offlineData1 = [
            "name" => "Ray",
            "organizationId" => 1,
            "phone" => "+919846342791",
            "email" => "ray@gmail.com",
            "clientId" => 510,
            "isSignup" => false,
            "isOffline" => true,
        ];
        $this->testData($I, $offlineData1, 201);
        $customerId1 = $I->grabDataFromResponseByJsonPath('$.data.customer.id')[0];
        $offlineData2 = [
            "name" => "Ray",
            "organizationId" => 1,
            "phone" => "+919846342794",
            "email" => "ray123@gmail.com",
            "clientId" => 511,
            "isSignup" => false,
            "isOffline" => true,
        ];
        $this->testData($I, $offlineData2, 201);
        $customerId2 = $I->grabDataFromResponseByJsonPath('$.data.customer.id')[0];
        $signupData = [
            "name" => "Ray",
            "organizationId" => 1,
            "phone" => "+919846342794",
            "email" => "ray@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        ];
        $this->testData($I, $signupData, 212);
        $I->seeResponseContainsJson(['id' => $customerId2]);
        $I->seeInDatabase(
            "client_customers", ["customer_id" => $customerId2,
            "client_id" => 510, "deleted_at" => null]
        );
        $I->seeInDatabase(
            "client_customers", ["customer_id" => $customerId2,
            "client_id" => 511, "deleted_at" => null]
        );
    }

    public function addOfflineUserWithDataOfDiffExistingOnlineUsers(ApiTester $I)
    {
        /**
         * Try adding offline user with client id, phone and email
         *  that are mapped to existing signed up users.
         *  It should throw an exception
         */
    /*    $I->wantTo(
            "Add offline user with client id and phone mapped to different existing"
            . " users that have signed up"
        );
        //Create offline user with client id and phone
        $offlineData1 = [
            "name" => "Nicole",
            "organizationId" => 1,
            "phone" => "+919846342792",
            "clientId" => 520,
            "isSignup" => false,
            "isOffline" => true,
        ];
        $this->testData($I, $offlineData1, 201);
        $customerId1 = $I->grabDataFromResponseByJsonPath('$.data.customer.id')[0];
        //User signup with same phone
        $signupData = [
            "name" => "Nicole",
            "organizationId" => 1,
            "phone" => "+919846342792",
            "email" => "nicole@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        ];
        $this->testData($I, $signupData, 211);
        $I->seeResponseContainsJson(['id' => $customerId1]);

        //User signup with new data
        $signupData2 = [
            "name" => "Eliza",
            "organizationId" => 1,
            "phone" => "+919846342793",
            "email" => "eliza@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        ];
        $this->testData($I, $signupData2, 201);

        //Add offline user with client id of user1 and phone of user2
        $offlineData2 = [
            "name" => "Nicole",
            "organizationId" => 1,
            "phone" => "+919846342793",
            "clientId" => 520,
            "isSignup" => false,
            "isOffline" => true,
        ];
        $I->sendPOST(self::$endpoint, $offlineData2);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ['message' =>
                "Validation Exception: Different customers exist for the given details"]
        );
    }

    public function addOfflineUserWithExistingClientIdAndPhone(ApiTester $I)
    {
        /**
         * Adding offline user with existing client id of offline user
         *  and existing phone mapped to signed up user.
         *  Both users must be merged and the id should be that of the signed up user.
         */
      /*  $I->wantTo(
            "Add offline user with client id and phone mapped to different existing"
            . " users(one offline user and another signed up user)"
        );
        //Create offline user with client id and phone
        $offlineData1 = [
            "name" => "Nicole",
            "organizationId" => 1,
            "clientId" => 521,
            "isSignup" => false,
            "isOffline" => true,
        ];
        $this->testData($I, $offlineData1, 201);
        $customerId1 = $I->grabDataFromResponseByJsonPath('$.data.customer.id')[0];

        //User signup with new data
        $signupData = [
            "name" => "Nicole",
            "organizationId" => 1,
            "phone" => "+919846342795",
            "email" => "nicole12@gmail.com",
            "address" => "House no-6, Saket",
            "landmark" => "St. Peters School",
            "pincode" => 800023,
            "city" => "Ahmedabad"
        ];
        $this->testData($I, $signupData, 201);
        $customerId2 = $I->grabDataFromResponseByJsonPath('$.data.customer.id')[0];

        //Add offline user with client id of user1 and phone of user2
        $offlineData2 = [
            "name" => "Nicole",
            "organizationId" => 1,
            "phone" => "+919846342795",
            "clientId" => 521,
            "isSignup" => false,
            "isOffline" => true,
        ];
        $this->testData($I, $offlineData2, 212);
        $I->seeResponseContainsJson(['id' => $customerId2]);
    }*/
}
