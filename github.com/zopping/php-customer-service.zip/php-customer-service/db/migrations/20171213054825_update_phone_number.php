<?php


use Phinx\Migration\AbstractMigration;

class UpdatePhoneNumber extends AbstractMigration
{

    public function up()
    {
       $this->execute('UPDATE `phones` SET phone=concat(91, phone) WHERE length(phone) <= 10');
    }

    public function down() 
    {
        
    }

}
