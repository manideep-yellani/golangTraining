# account-service

Development Build Status:  [![CircleCI](https://circleci.com/gh/ZopNow/account-service/tree/development.svg?style=svg&circle-token=ac60491304b311c9bda1ebfd893773b5e809c2a2)](https://circleci.com/gh/ZopNow/account-service/tree/development)

For local setup:
* Clone the repo
* `composer install`

Based on your local environment, modify the test and app configuration defined in config folder

For Database Migration:
* `php vendor/bin/phinx migrate -e {environment}`
    * For testing, use environment as **test**
    * For production, use environment as **production**

For Database seeding (If data is required in the Database):
* `php vendor/bin/phinx seed:run -e {environment}`
    * For testing, use environment as **test**
    * For production, use environment as **production**

For running the tests:
* Run: `./vendor/bin/codecept run`
