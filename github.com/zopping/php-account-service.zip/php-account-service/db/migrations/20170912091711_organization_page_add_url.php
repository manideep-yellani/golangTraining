<?php

use Phinx\Migration\AbstractMigration;

class OrganizationPageAddUrl extends AbstractMigration
{
    /**
     * Adding url column in organization_page table to support specific pages
     */
    public function change()
    {
        $pageLayouts = $this->table("organization_page");
        $pageLayouts->addColumn('url','string', array('limit' => 100, 'null' => true))
                ->dropForeignKey(['organization_id', 'page_id'])
                ->removeIndex(['organization_id', 'page_id'])
                ->addForeignKey('organization_id', 'organizations', 'id', ['constraint' => 'fk_page_layouts_organizations', 'delete' => 'NO_ACTION',
                    'update' => 'NO_ACTION'])
                ->addForeignKey('page_id', 'pages', 'id', ['constraint' => 'fk_page_layouts_pages', 'delete' => 'NO_ACTION',
                    'update' => 'NO_ACTION'])
                ->addIndex(['organization_id', 'page_id', 'url'], ['unique' => 'true', 'name' => 'organization_page_url'])
                ->save();
    }
}
