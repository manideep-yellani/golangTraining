<?php

namespace ZopNow\Hodor\Model;

class Lang extends \ZopNow\Arya\Model\Base
{
    protected $table = 'languages';
    protected $hidden = ['id', 'created_at', 'updated_at'];

}
