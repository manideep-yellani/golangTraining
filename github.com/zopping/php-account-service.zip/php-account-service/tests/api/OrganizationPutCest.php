<?php

require_once('BaseCest.php');
/**
 * Class consists of all the test cases for the put request in Organization
 * which the API should handle
 */
class OrganizationPutCest extends BaseCest
{

    protected static $endpoint = '/organization';
    protected static $table = 'organizations';

    public function updateOrganizationWithoutId(ApiTester $I)
    {
        $I->wantTo('Updating an Organization without sending the id');
        $I->sendPUT(static::$endpoint, []);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please enter the id to be updated"));
    }

    public function updateOrganizationWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Updating a Organization by sending invalid id');
        $data = ['name' => 'Zopnow', 'domain' => 'zopnow.com'];
        $I->sendPUT(static::$endpoint . "/1000", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Model Exception: Organization with id: 1000 not found"));
    }
/*
    public function updateOrganizationName(ApiTester $I)
    {
        $I->wantTo('Update Organization name with all correct parameters');
        $initial = ['name' => 'Zopnow', 'domain' => 'zopnow.com'];
        $id = $I->grabFromDatabase(static::$table, 'id', $initial);
        $final = ['name' => 'Zopnow Store', 'domain' => 'www.zopsmart.com'];
        parent::update($I, $id, $final, $initial);
        $I->seeResponseMatchesJsonType(array(
            "status" => "string",
            "data" => array(
                "organization" => array(
                    "id" => "integer",
                    "name" => "string|null",
                    "domain" => "string|null",
                    "logo" => "string|null",
                    "currency" => "array"
                )
            )
        ));
    }

    public function updateOrganizationDomainAlreadyExist(ApiTester $I)
    {
        $I->wantTo('Update a Organization with domain that already exist');
        $initial = ['name' => "Zopnow Store", 'domain' => 'www.zopsmart.com', 'currency_id' => 1];
        $id = $I->grabFromDatabase(static::$table, 'id', $initial);
        $final = ['domain' => 'ruchisbiryani.zopexpress.com'];
        $I->sendPUT(static::$endpoint . "/$id", $final);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Domain already exists"));
    }

    public function invalidCurencyId(ApiTester $I)
    {
        $I->wantTo("Update a Organization with invalid currency id");
        $initial = ['name' => "ZopNow Store", 'domain' => 'www.zopsmart.com', 'currency_id' => 1];
        $id = $I->grabFromDatabase(static::$table, 'id', $initial);
        $final = ['currencyId' => 300];
        $I->sendPUT(static::$endpoint . "/$id", $final);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Model Exception: Currency with id: 300 not found"));
    }
*/
    public function updateOrganizationWithInvalidTheme(ApiTester $I)
    {
        $I->wantTo("Update organizations with invalid theme");
        $data = ["id" => 1, "themeId" => 998];
        $I->sendPUT(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(["message" => "Model Exception: Theme with id: 998 not found"]);
    }
/*
    public function updateOrganizationWithProperTheme(ApiTester $I)
    {
        $I->wantTo("Update organizations with valid theme");
        $data = ["name" => "FastExpress", "domain" => "fastxpress.com", "themeId" => 6];
        $I->sendPOST(self::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $oldThemeId = $I->grabDataFromResponseByJsonPath("$.data.organization.theme.id")[0];
        $id = $I->grabDataFromResponseByJsonPath("$.data.organization.id")[0];
        // updating theme to theme-2
        $I->sendPUT(self::$endpoint."/$id", ["themeId" => 2]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $newThemeId = $I->grabDataFromResponseByJsonPath("$.data.organization.theme.id")[0];
        $I->assertEquals($newThemeId, 2);
        $I->assertNotEquals($newThemeId, $oldThemeId);
    }

    public function updateOrganizationOfDifferentOrganization(ApiTester $I)
    {
        $I->wantTo("Update organization details of a different organization");
        $id = $I->haveInDatabase(
            self::$table, ['name' => 'Test Store', 'domain' => 'teststore.com']
        );
        $data = [
            'organizationId' => 1,
            'name' => 'Smart Store'
        ];
        $I->sendPUT(self::$endpoint."/$id", $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(
            ["message"=> "Validation Exception: Organization with id 61 cannot be edited"]
        );
    }
*/
}
