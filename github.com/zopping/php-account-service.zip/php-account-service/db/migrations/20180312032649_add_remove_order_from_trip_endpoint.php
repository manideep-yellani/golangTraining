<?php

use Phinx\Migration\AbstractMigration;

class AddRemoveOrderFromTripEndpoint extends AbstractMigration
{

    public function change()
    {
        $url = 'logistics-service/trip';
        $allowedMethods = json_encode(["GET","PUT","POST", "DELETE"]);
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = '$url'")['id'];

        $this->execute("update endpoints set allowed_methods = '$allowedMethods' where id = '$endpointId'");
        $this->execute("insert into endpoint_developer_permissions(developer_id,method,has_permission)"
            . " select developer_id, 'DELETE', has_permission from endpoint_developer_permissions"
            . " where endpoint_id = '$endpointId' and method = 'PUT'");
        $this->execute("insert into endpoint_developer_permissions(endpoint_id,developer_id,method,has_permission)"
            . " select endpoint_id,developer_id, 'DELETE', has_permission from endpoint_developer_permissions"
            . " where endpoint_id = '$endpointId' and method = 'PUT'");
        $this->execute("insert into endpoint_user_permissions(endpoint_id,user_id,method,has_permission)"
            . " select endpoint_id,user_id, 'DELETE', has_permission from endpoint_user_permissions"
            . " where endpoint_id = '$endpointId' and method = 'PUT'");
        $this->execute("insert into endpoint_role(endpoint_id,role_id,method)"
            . " select endpoint_id,role_id, 'DELETE' from endpoint_role"
            . " where endpoint_id = '$endpointId' and method = 'PUT'");

    }
}