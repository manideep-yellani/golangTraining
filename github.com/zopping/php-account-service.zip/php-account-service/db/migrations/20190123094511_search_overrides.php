<?php

use Phinx\Migration\AbstractMigration;

class SearchOverrides extends AbstractMigration
{
    private $slug = "SearchOverride";

    public function up()
    {
        $extData = [
          "slug" => $this->slug,
          "name" => "Search Overrides",
          "description" => "Helps you to fix the position of a product in category or search page",
          "enable_helper_text" => "You can boost certain products in category/search page.",
          "disable_helper_text" => "You will no longer be able to fix the position of a product in category or search page",
          "pricing" => "FREE",
          "icon" => "https://storage.googleapis.com/zopsmart-uploads/originals/20190123/searchconfig-20190123-102715.png",
        ];
        $this->insert('extensions',$extData);
    }

    public function down()
    {
        $this->execute("delete from extensions where slug = '$this->slug'");
    }
}
