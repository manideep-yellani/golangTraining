<?php

use Phinx\Migration\AbstractMigration;

class AddCallEndpoints extends AbstractMigration
{
    public function up() {
        $this->execute("update endpoints set allowed_methods = '[\"GET\",\"POST\",\"PUT\"]' where url = 'communication-service/call'");
    }

       
    public function down() {
        $this->execute("update endpoints set allowed_methods = '[\"POST\"]' where url = 'communication-service/call'");
    }
}
