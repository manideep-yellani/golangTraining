<?php

class EmployeePostCest
{

    protected static $endpoint = '/employee';
    protected static $table = 'users';
/*
    public function postEmployeeDetails(ApiTester $I) 
    {
        $I->wantTo("Add a new employee with the post method");
        $data = ['organizationId' => 1, 'name' => 'John Doe', 'phone' => '+919000058679',
            'email' => 'johndoe@zopnow.com', 'hasToolAccess' => 1];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
    }
 */
    public function postEmployeeDetailsWithParameterMissing(ApiTester $I) 
    {
        $I->wantTo("Add a new employee with the post method");
        $data = ['organizationId' => 1, 'name' => 'John Doe', 'phone' => '+919000058679',
            'email' => 'johndoe@zopnow.com'];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
    }
/*
    public function addEmployeeWithShiftTimings(ApiTester $I)
    {
        $designationId = $I->haveInDatabase(
            "designations", ['organization_id' => 1, 'name' => 'CS Agent', 'timing_type' => 'FIXED']
        );
        $data = [
            "organizationId" => 1,
            "name" => "Agent",
            "email" => "agent@zopnow.com",
            "phone" => "+919861543212",
            "hasToolAccess" => 1,
            "sendInvite" => 0,
            "password" => "password",
            "storeIds" => [1],
            "designationId" => $designationId,
            "shiftStart" => "08:00:00",
            "shiftEnd" => "05:00:00"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
    }
*/
}

