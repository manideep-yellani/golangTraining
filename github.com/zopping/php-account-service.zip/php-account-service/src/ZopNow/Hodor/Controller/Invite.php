<?php

namespace ZopNow\Hodor\Controller;

class Invite extends \ZopNow\Arya\Controller\Base
{

    public function post()
    {
        $mandatoryFields = ["name", "email", "phone", "organizationId"];
        $data = $this->getRequestParams($mandatoryFields);
        $data['hasToolAccess'] = 1;
        $data['isInvite'] = true;
        $userController = new User($data);
        return $userController->post();
    }
}
