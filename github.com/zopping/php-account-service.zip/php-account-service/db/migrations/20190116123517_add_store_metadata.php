<?php

use Phinx\Migration\AbstractMigration;

class AddStoreMetadata extends AbstractMigration
{
     public function change()
    {
        $this->table("stores")
            ->addColumn("meta_data", "text", ["after" => "deleted_at", "null" => true])
            ->update();
    }
}
