<?php

namespace ZopNow\CustomerService\Cron;

class AddOfflineCustomers extends BaseCron
{
    //communication-type used by commuication-service
    const STATUS_COMMUNICATION = "no-template";
    private $metaDataHeaders = [];
    private static $configs;

    public function shouldExecuteAt($timestamp)
    {
        return (date('i', $timestamp) % 15 == 0);
    }

    public static function configure($options)
    {
        self::$configs = $options['ftpCredentials'];
    }

    protected function steps()
    {
        /**
         * @todo The entire process must be put in a transaction.
         * Currently, if adding any one customer fails, all queries before it, will rollback.
         * To prevent this behavior, the process is not put into a transaction.
         */
        $fileData = \ZopNow\CustomerService\Model\CustomerFile::where("status", "=", "PENDING")
                ->get()->toArray();
        if (empty($fileData)) {
            return;
        }
        foreach ($fileData as $file) {
            try {
                $ftp = new \ZopNow\CustomerService\Utility\Ftp(self::$configs['user'], self::$configs['password'], self::$configs['host']);
                $ftp->setPassive(true);
                $remoteFile = $file['location'];
                $localFile = DATA_DIRECTORY . basename($remoteFile);
                $ok = $ftp->get($localFile, $remoteFile, FTP_BINARY);
                if (!$ok) {
                    $this->log("File not found".-$file['location']);
                    continue;
                }
                \ZopNow\CustomerService\Model\CustomerFile::where('id', '=', $file['id'])
                    ->update(["status" => "PROCESSING"]);
                $handle = fopen($localFile, 'r');
                if ($handle == false) {
                    throw new \ZopNow\Arya\Exception\ValidationException(
                        "Could not open file " . $localFile
                    );
                }
                $organizationId = $file['organizationId'];
                $timestamp = $file['createdAt'];
                $this->metaDataHeaders = (new \ZopNow\CustomerService\Controller\CustomerUpload([]))->getMetadataConfig($organizationId);
                $firstRow = array_map("trim", fgetcsv($handle));
                $headers = array_flip($firstRow);
                $status = $this->addCustomerData($handle, $organizationId, $headers);

                //Send status of upload to the owner of the organization via email
                $this->sendCustomerUploadStatus(
                    $organizationId, $timestamp, $firstRow, $status
                );
                //Update status of file as 'PROCESSED'
                \ZopNow\CustomerService\Model\CustomerFile::where('id', '=', $file['id'])
                    ->update(["status" => "PROCESSED"]);
            } catch (\Exception $e) {
                \ZopNow\Arya\App\Application::log(
                    "Error during Customer Bulk Upload", ["message" => $e->getMessage()]
                );
                \ZopNow\CustomerService\Model\CustomerFile::where('id', '=', $file['id'])
                    ->update(["status" => "FAILED"]);
            }
        }
        
    }

    private function addCustomerData($fileHandle, $organizationId, $headers)
    {
        $addedCount = 0;
        $editedCount = 0;
        $mergedCount = 0;
        $unprocessedCount = 0;
        $unprocessedRows = [];
        $rowCount = 0;
        while (($row = fgetcsv($fileHandle)) !== false) {
            try {
                $rowCount++;
                $row = array_map("trim", $row);
                //Add a new customer
                $customerData = [
                    'organizationId' => $organizationId,
                    'clientId' => $row[$headers['ClientId']],
                    'name' => $row[$headers['Name']],
                    'phone' => $row[$headers['Phone']],
                    'email' => $row[$headers['Email']],
                    'isSignup' => false,
                    'isOffline' => true,
                ];
                $metaData = [];
                foreach ($this->metaDataHeaders as $metaKey) {
                    if (isset($headers[$metaKey]) && !empty($row[$headers[$metaKey]])) {
                        $metaData[$metaKey] = $row[$headers[$metaKey]];
                    }
                }
                if (!empty($metaData)) {
                    $customerData['metaData'] = $metaData;
                }
                $customerController = new \ZopNow\CustomerService\Controller\Customer($customerData);
                $response = $customerController->post()->getData();
                $responseCode = $response['code'];
                switch ($responseCode) {
                    case 201:
                        $addedCount++;
                        break;
                    case 211:
                        $editedCount++;
                        break;
                    case 212:
                        $mergedCount++;
                        break;
                }
            } catch (\Exception $ex) {
                $unprocessedCount++;
                $row['reason'] = $ex->getMessage();
                $unprocessedRows[] = $row;
                \ZopNow\Arya\App\Application::log(
                    "Error during Customer Bulk Upload for $organizationId : " . $ex->getMessage(),
                    $row
                );
            }
            //End of single row processing
        }// end of entire file processing
        return [
            'totalCount' => $rowCount,
            'addedCount' => $addedCount,
            'editedCount' => $editedCount,
            'mergedCount' => $mergedCount,
            'unprocessedCount' => $unprocessedCount,
            'unprocessedRows' => $unprocessedRows
        ];
    }

    private function sendCustomerUploadStatus($organizationId, $time, $headers, $statusCounts)
    {
        //Fetch organization owner details
        $orgData = \ZopNow\Arya\Utility\MicroService::callService(
            "account-service", "/organization", "GET", array("id" => $organizationId)
        );
        $organizationOwner = json_decode($orgData['body'], true)['data']['organization']['owner'];
        $name = $organizationOwner['name'];

        $totalCount = $statusCounts['totalCount'];
        $unprocessedRows = $statusCounts['unprocessedRows'];
        $unProcessedCount = $statusCounts['unprocessedCount'];
        $addedCount = $statusCounts['addedCount'];
        $editedCount = $statusCounts['editedCount'];
        $mergedCount = $statusCounts['mergedCount'];

        $emailData['to'] = $organizationOwner['emails'][0]['email'];
        $emailData['type'] = self::STATUS_COMMUNICATION;
        $processedCount = $totalCount-$unProcessedCount;
        $body = "<div>"
            . "     Dear $name, <br><br> Here is the quick summary of your recent customer details"
            . "     upload at time : <i>$time</i>."
            . "</div>"
            . "<div style='font-size: 16px;padding-top: 12px;padding-bottom:10px;"
            . "font-family: Helvetica,Arial;"
            . "text-decoration: underline;'>"
            . "<br> $processedCount customer(s) out of $totalCount customer(s), successfully processed.";

        $body .= "<div style='font-size: 16px;padding-top: 12px;"
            . "font-family: Helvetica,Arial;"
            . "text-decoration: underline;'>"
            . "Number of customer(s) added : $addedCount</div>";

        $body .= "<div style='font-size: 16px;padding-top: 12px;"
            . "font-family: Helvetica,Arial;"
            . "text-decoration: underline;'>"
            . "Number of customer(s) updated : $editedCount</div>";

        if (!empty($mergedCount)) {
            $body .= "<div style='font-size: 16px;padding-top: 12px;"
                    . "font-family: Helvetica,Arial;"
                    . "text-decoration: underline;'>"
                    . "Number of customer(s) merged : $mergedCount</div>";
        }
        $attachments = [];
        // Showing unprocessed Rows
        if (!empty($unprocessedRows)) {
            $body .= "<div style='font-size: 16px;padding-top: 12px;padding-bottom:10px;"
                    . "font-family: Helvetica,Arial;"
                    . "text-decoration: underline;'>Number of customer(s) unprocessed : $unProcessedCount </div>";
            $body .= "PFA the details of the rows that were unprocessed.";
            $fileName = "UnprocessedCustomers_" . date('YmdHis', strtotime($time)) . ".csv";
            $filePath = "/tmp/$fileName";
            $output = fopen($filePath, "w");
            $headers[] = 'Reason for failure';
            fputcsv($output, $headers);
            foreach($unprocessedRows as $row) {
                fputcsv($output, $row);
            }
            fclose($output);
            $attachments['attachment'] = $filePath;
        }
        $body .= "</div>";
        $emailData['data'] = [
            "subject" => "[Zopsmart] Status Report For Your recent Customer details Upload",
            "body" => $body
        ];
        $emailData['transactional'] = true;
        \ZopNow\Arya\Utility\MicroService::callService(
            "communication-service", "/email", 'POST', $emailData, $attachments
        );
    }
}
