<?php

class StoreGetCest
{
    protected static $endpoint = '/store';
    protected static $table = 'stores';

    public function listStoresWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get list of stores without organization id');
        $I->sendGET(static::$endpoint);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - store : organization Id'));
    }
/*
    public function listStores(ApiTester $I)
    {
        $I->wantTo('Get list of stores');
        $I->sendGET(static::$endpoint . "?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "store" => "array"
            )
        ));
    }

    public function listStoresInvalidPage(ApiTester $I)
    {
        //Sending a page number which does not have data
        $I->wantTo('Get list of stores with invalid page number');
        $I->sendGET(self::$endpoint . "?organizationId=1&page=1000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['store' => []]));
    }

    public function listStoresInvalidOrganizationId(ApiTester $I)
    {
        //Sending an invalid organization id to the API
        $I->wantTo('Get list of stores with invalid organization id filter');
        $I->sendGET(self::$endpoint . "?organizationId=10000");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['store' => []]));
    }

    public function listStoresWithClientStoreId(ApiTester $I)
    {
        //Sending a client_store_id as a filter and checking if the required data is returned
        $I->wantTo('Get list of stores with client store id filter');
        $I->sendGET(self::$endpoint . "?clientStoreId=2001&organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "count" => "integer",
                "offset" => "integer",
                "limit" => "integer",
                "store" => "array"
            )
        ));
    }

    public function listStoresInvalidClientStoreId(ApiTester $I)
    {
        //Sending an invalid client store id to the API
        $I->wantTo('Get list of stores with invalid client store id filter');
        $I->sendGET(self::$endpoint . "?clientStoreId=20&organizationId=1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseContainsJson(array('data' => ['store' => []]));
    }

    public function getStore(ApiTester $I)
    {
        $I->wantTo('Get details of a store with a valid id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'More, Sahkar Nagar']);
        $I->sendGET(static::$endpoint . "/$id?organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['id' => $id]);
        $I->seeResponseContainsJson(['id' => $id, 'name' => 'More, Sahkar Nagar']);
    }

    public function getStoreWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Get details of a store without organization id');
        $I->sendGET(static::$endpoint . "/1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
    }
*/
    public function getStoreOfDifferentOrganization(ApiTester $I)
    {
        $I->wantTo('Get details of a store with id not belonging to passed organization');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'More, Sahkar Nagar']);
        $I->sendGET(static::$endpoint . "/$id?organizationId=2");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => "Model Exception: Store with id: $id not found"));
    }

    public function getStoreInvalidId(ApiTester $I)
    {
        //Sending an invalid id
        $I->wantTo('Get details of a store with invalid id');
        $I->sendGET(self::$endpoint . "/store1");
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Model Exception: Store with id: store1 not found'));
    }
/*
    public function getStoreOrganizationId(ApiTester $I)
    {
        //Sending organization_id with a valid id. The organization_id filter will not be applied
        $I->wantTo('Get details of a store with a valid id and an organization id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Metro, Yeshwantpur']);
        $orgId = $I->grabFromDatabase(self::$table, 'organization_id', ['name' => 'Hypercity, Whitefield']);
        $I->sendGET(self::$endpoint . "/$id?organizationId=$orgId");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('id' => $id, 'name' => 'Metro, Yeshwantpur'));
        $I->dontSeeResponseContainsJson(array('name' => 'Hypercity, Whitefield'));
    }

    public function getStoreClientStoreId(ApiTester $I)
    {
        //Sending client_store_id with a valid id. The client_store_id filter will not be applied
        $I->wantTo('Get details of a store with a valid id and a client store id');
        $id = $I->grabFromDatabase(self::$table, 'id', ['name' => 'Hypercity, Whitefield']);
        $clientId = $I->grabFromDatabase(self::$table, 'client_store_id', ['name' => 'More HM Mahadevapura']);
        $I->sendGET(self::$endpoint . "/$id?clientStoreId=$clientId&organizationId=1");
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('id' => $id, 'name' => 'Hypercity, Whitefield'));
        $I->dontSeeResponseContainsJson(array('name' => 'More HM Mahadevapura'));
    }*/
}