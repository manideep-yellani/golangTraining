<?php

namespace ZopNow\Hodor\Model;

/*
 * Class consists of the relationships which Organization model will have with the other models
 * and other related methods
 */

use Illuminate\Database\Eloquent\SoftDeletes;

class Organization extends \ZopNow\Arya\Model\Base
{
    use SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at', 'slug', 'currency_id', 'theme_id'];

    protected $with = ['currency', 'theme'];

    public function getHttpsEnabledAttribute() {
        return (strpos($this->domain, "smartstore.express") !== false && strpos($this->domain, "staging.smartstore.express") === false) ? 1 : (int) $this->attributes["https_enabled"];
    }

    public function isDomainExists($domain)
    {
        $organization = Organization::where('domain', $domain)->first();
        if (!is_null($organization)) {
            if (!is_null($this->id) && $organization->id == $this->id) {
                return false;
            }
            return true;
        }
        return false;
    }

    public function currency()
    {
        return $this->belongsTo("\ZopNow\Hodor\Model\Currency");
    }

    public function extension()
    {
        return $this->belongsToMany('\ZopNow\Hodor\Model\Extension');
    }

    public function users()
    {
        return $this->hasMany('\ZopNow\Hodor\Model\User');
    }

    public function stores()
    {
        return $this->hasMany('\ZopNow\Hodor\Model\Store');
    }

    public function theme()
    {
        return $this->belongsTo('\ZopNow\Hodor\Model\Theme');
    }

}
