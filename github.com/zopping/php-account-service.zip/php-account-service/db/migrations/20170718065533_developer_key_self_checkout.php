<?php

use Phinx\Migration\AbstractMigration;

class DeveloperKeySelfCheckout extends AbstractMigration
{
    /**
     * Insert organization for Carrefour and developer key for the organization.
     */
    public function change()
    {
        $organization = [
            'name' => 'Carrefour',
            'slug' => 'carrefour',
            'domain' => 'carrefour.zopnow.express',
            'currency_id' => 3
        ];
        $this->insert('organizations',$organization);
        $row = $this->fetchRow("SELECT `id` FROM organizations where slug='carrefour'");
        $store = array(
            array(
                'organization_id' => $row['id'],
                'name' => 'CarrerFour MT Haryono',
                'client_store_id' => 10015,
                'latitude' => '-6.244613',
                'longitude' => '106.861512',
                'address' => 'Komp. Lakespra TNI AU Saryanto, Daerah Khusus Ibukota Jakarta 12770, Indonesia'
            ),
            array(
                'organization_id' => $row['id'],
                'name' => 'CarrerFour Permata Hijau',
                'client_store_id' => 10016,
                'latitude' => '-6.220824',
                'longitude' => '106.783719',
                'address' => 'ITC Permata Hijau Lt. Dasar, Daerah Khusus Ibukota Jakarta 12210, Indonesia'
            ),
            array(
                'organization_id' => $row['id'],
                'name' => 'CarrerFour TamanPalem',
                'client_store_id' => 10017,
                'latitude' => '-6.1404034',
                'longitude' => '106.7323103',
                'address' => 'Jl. Kamal Raya, RT.13/RW.10, Daerah Khusus Ibukota Jakarta 11730, Indonesia'
            ),
        );
        $this->insert('stores', $store);
        $data = [
            [
                'organization_id' => $row['id'],
                'name' => 'Self Checkout App',
                'token' => '9d62d893-1992-45b3-80f0-08e27beb23c9'
            ]
        ];
        $this->insert('developers',$data);
    }
}
