<?php

use Phinx\Migration\AbstractMigration;

class AddClientAddressId extends AbstractMigration
{

    public function up()
    {
        $this->table('addresses')
            ->addColumn('client_address_id', 'string', ['limit' => 100, 'null' => true])
            ->addIndex(['client_address_id'])
            ->save();
    }

    public function down()
    {
        $this->table('addresses')
            ->removeColumn('client_address_id')
            ->save();
    }

}
