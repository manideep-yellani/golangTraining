<?php

use Phinx\Migration\AbstractMigration;

class Campaigns extends AbstractMigration {

    public function up() {
        $enableHelperText = "Allows user to send out promotional campaigns to their customer base|"
            . " Can select from different mediums - SMS, EMAIL|"
            . " Allows for scheduling campaigns in the future";

        $disableHelperText = "Disables all active campaigns scheduled for the future |"
            . " No campaigns will be run in future";

        $data = [
            "name" => "Campaigns",
            "slug" => "Campaigns",
            "description" => "Facilitates the organization to run promotional campaigns",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "1 paise per EMAIL and 12 paise per SMS",
            "pricing_rule" => json_encode(['TYPE' => 'MONTHLY', 'RATE' => 'FIXED', 'COST' => ['SMS' => 12, 'EMAIL' => 1]])
        ];
        $this->insert('extensions',$data);

        $extensionId = $this->fetchRow(
                        "SELECT `id` from `extensions` where `slug` = 'Campaigns'"
                )['id'];
        $endpointData = [
            [
                "url" => "promo-service/campaign",
                "allowed_methods" => json_encode(['GET', 'POST', 'PUT', 'DELETE']),
                "extension_id" => $extensionId
            ],
            [
                "url" => "promo-service/medium",
                "allowed_methods" => json_encode(['GET']),
                "extension_id" => $extensionId
            ],
            [
                "url" => "promo-service/campaignVariable",
                "allowed_methods" => json_encode(['GET']),
                "extension_id" => $extensionId
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down() {
        $endpointsToBeDeleted = [
            "'promo-service/campaign'",
            "'promo-service/medium'",
            "'promo-service/campaignVariable'"
        ];
        $rows = $this->fetchAll(
                "select id from endpoints where url in (" . implode(',', $endpointsToBeDeleted) . ")"
        );
        $endpointIds = array_column($rows, 'id');
        $extensionId = $this->fetchRow(
                        "SELECT `id` from `extensions` where `slug` = 'Campaigns'"
                )['id'];
        $this->execute('DELETE from `extension_organization` where id = ' . $extensionId);
        $this->execute(
                "delete from endpoint_developer_permissions where endpoint_id in ("
                . implode(',', $endpointIds) . ")"
        );
        $this->execute(
                "delete from endpoint_user_permissions where endpoint_id in ("
                . implode(',', $endpointIds) . ")"
        );
        $this->execute(
                "delete from endpoints where url in (" . implode(',', $endpointsToBeDeleted) . ")"
        );
        $this->execute('DELETE from `extensions` where `slug` = "Campaigns"');
    }

}
