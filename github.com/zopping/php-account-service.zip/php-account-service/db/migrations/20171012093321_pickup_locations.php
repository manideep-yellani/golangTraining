<?php

use Phinx\Migration\AbstractMigration;

class PickupLocations extends AbstractMigration
{
    /**
     * Database schema for "pickup_locations" table
     * This table is used to store the pickup locations for an organization.
     * It is being stored separately since store and pickup location need not be same.
     * It consists of the following fields :
     * organization_id : id of the organization to which the pickup location corresponds to
     * name : stores the name of the pickup location
     * latitude : stores the latitude of the pickup location
     * longitude : stores the longitude of the pickup location
     * address : stores the address of the store
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     * deleted_at : field will be NULL. This field will be set to the timestamp when the config is deleted and it is a soft delete.
     *
     * "id" is the primary key for the table. Combination of "organization_id" and "name" is the unique index for the table
     */
    public function change()
    {
        $stores = $this->table('pickup_locations');
        $stores
                ->addColumn('organization_id', 'integer', array('limit' => 11))
                ->addColumn('name', 'string', array('limit' => 45, 'null' => true))
                ->addColumn('latitude', 'decimal', array('precision' => 16, 'scale' => 13, 'null' => true))
                ->addColumn('longitude', 'decimal', array('precision' => 16, 'scale' => 13, 'null' => true))
                ->addColumn('address', 'string', array('limit' => 500, 'null' => false))
                ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                ->addColumn('deleted_at', 'timestamp', array('null' => true))
                ->addForeignKey('organization_id', 'organizations', 'id', array('delete' => 'NO_ACTION', 'update' => 'NO_ACTION'))
                ->addIndex(['organization_id', 'name'], array('unique' => true));
        $stores->create();
    }
}
