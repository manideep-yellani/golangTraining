<?php

use Phinx\Migration\AbstractMigration;

class AutomationEndpoint extends AbstractMigration
{
    private $slug = "LogisticsSupport";

    public function up()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $endpointData = [
            [
                "url" => "logistics-service/automation",
                "extension_id" => $extensionId,
                "allowed_methods" => json_encode(['GET'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = '$this->slug'")['id'];
        $endpointIds = array_column(
            $this->fetchAll("SELECT `id` from `endpoints` where `extension_id` = '$extensionId' and `url` = 'logistics-service/automation'"),
            'id'
        );
        $this->execute("DELETE from `endpoint_user_permissions` where endpoint_id in "
            . " ( " . implode(",", $endpointIds) . ")");
        $this->execute("DELETE from `endpoints` where `id` in (". implode(",", $endpointIds) . ")");
    }
}
