<?php


namespace ZopNow\Hodor\Extension;

class Wallet extends Base
{

    public function enable()
    {
        $organizationId = $this->organization->id;
        $paymentAccount = \ZopNow\Arya\Utility\MicroService::callService("go-account-service", "/payment-account", 'GET', ['organizationId' => $organizationId]);
        $data = json_decode($paymentAccount['body'], true)['data'];
        $paymentGateway = \ZopNow\Arya\Utility\MicroService::callService("go-account-service", "/payment-gateway", 'GET', ['organizationId' => $organizationId]);
        $paymentGateways = json_decode($paymentGateway['body'], true)['data']['paymentgateway'];

        if (sizeof($data['paymentaccount']) == 0 || sizeof($data['paymentaccount'][0]['paymentGateways']) == 0 ||
        ($this->isPaymentModeExists($data['paymentaccount'][0]['paymentGateways'][0]['providerName'], $paymentGateways)) && sizeof($data['paymentaccount'][0]['paymentGateways'][0]['paymentModes']) == 0 ) {
            throw new \ZopNow\Arya\Exception\ValidationException("You need to configure at least one payment gateway to install this extension");
        }

        $resp = \ZopNow\Arya\Utility\MicroService::callService("config-service",
                "/config/order", "GET", [
                    "organizationId" => (string)$this->organization->id
                ]);
        $paymentMethods=json_decode($resp["body"],true)["data"]["order"]["paymentMethods"];
        if(!in_array('WALLET', $paymentMethods)) {
            $paymentMethods[] = 'WALLET';
            \ZopNow\Arya\Utility\MicroService::callService("config-service",
                    "/config", "POST", [
                        "organizationId" => (string)$this->organization->id,
                        "order" => ["paymentMethods" => $paymentMethods]
                    ]);
        }
        
        return true;
    }

    function isPaymentModeExists($providerName, $paymentGateways)
    {
        foreach ($paymentGateways as $paymentGateway) {
            if ($paymentGateway['providerName'] == $providerName) {
                if (sizeof($paymentGateway['paymentModes']) > 0) {
                    return true;
                }
                break;
            }
        }
        return false;
    }

    public function disable()
    {
        $this->removePaymentMethod('WALLET');
        $stores = $this->organization->stores;
        foreach ($stores as $store) {
            $this->removePaymentMethod('WALLET', $store->id);
        }
        return true;
    }

    private function removePaymentMethod($paymentMethod, $storeId = NULL)
    {
        $resp = \ZopNow\Arya\Utility\MicroService::callService("config-service",
            "/config/order", "GET", [
                "organizationId" => (string)$this->organization->id,
                "storeId" => $storeId
            ]);
        $paymentMethods=json_decode($resp["body"],true)["data"]["order"]["paymentMethods"];
        $key = array_search($paymentMethod, $paymentMethods);
        if ($key !== false) {
            unset($paymentMethods[$key]);
            if (empty($paymentMethods)) {
                $paymentMethods = array("COD");
            }
            \ZopNow\Arya\Utility\MicroService::callService("config-service",
                    "/config", "POST", [
                        "organizationId" => (string)$this->organization->id,
                        "storeId" => $storeId,
                        "order" => ["paymentMethods" => array_values($paymentMethods)]
                    ]);
        }
    }

    public function getBillingAmount($startTime, $endTime, $pricingRule)
    {
    }

}
