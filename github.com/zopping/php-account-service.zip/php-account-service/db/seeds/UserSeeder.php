<?php

use Phinx\Seed\AbstractSeed;

class UserSeeder extends AbstractSeed
{
    /*
     * Seeding the users table with name, email, phone, username, password, organization_id and is_owner.
     * Using faker factory for populating the database for 50 users
     * created_at, updated_at will be set to the current timestamp
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        $config = include 'config/test.php';
        $encryptionConfig['key'] = $config['ZopNow\Arya\Utility\Encryption']['key'];
        \ZopNow\Arya\Utility\Encryption::configure($encryptionConfig);
        $password = \ZopNow\Arya\Utility\Encryption::encrypt('justatestpassword', false);
        $data = [
            [
                'name' => 'Admin',
                'password' => $password,
                'organization_id' => 1,
                'is_owner' => 1,
                'has_tool_access' => 1,
            ],
            [
                'name' => 'Admin',
                'password' => $password,
                'organization_id' => 2,
                'is_owner' => 0,
                'has_tool_access' => 1,
            ],
            [
                'name' => 'Admin',
                'password' => $password,
                'organization_id' => 3,
                'is_owner' => 1,
                'has_tool_access' => 1,
            ],
            [
                'name' => 'Admin',
                'password' => $password,
                'organization_id' => 4,
                'is_owner' => 1,
                'has_tool_access' => 1,
            ],
            [
                'name' => 'Admin',
                'password' => $password,
                'organization_id' => 5,
                'is_owner' => 1,
                'has_tool_access' => 1,
            ],
        ];
        for ($i = 0; $i < 50; $i++) {
            $name = $faker->name;
            $data[] = [
                'name' => $name,
                'password' => $password,
                'organization_id' => $faker->numberBetween(1, 4),
                'is_owner' => 0,
            ];
        }
        $users = $this->table('users');
        $users->insert($data)
              ->save();
    }
}
