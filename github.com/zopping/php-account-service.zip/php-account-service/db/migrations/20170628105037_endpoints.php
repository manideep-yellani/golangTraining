<?php

use Phinx\Migration\AbstractMigration;

class Endpoints extends AbstractMigration
{
    /**
     * Database schema for "endpoints" table
     * It consists of the following fields :
     * url : stores the endpoints of the APIs as called from platform-api
     * configuration_keys : stores the array of key values from configurations table that are required for the endpoint
     * created_at : stores the timestamp when the entry into the database is made
     * updated_at : stores the timestamp when the fields of the entry is updated
     * deleted_at : field will be NULL. This field will be set to the timestamp when the organization is deleted and it is a soft delete.
     *
     * "id" is the primary key for the table. "url" is a unique index for the table
     */
    public function change()
    {
        $endpoints = $this->table('endpoints');
        $endpoints->addColumn('url', 'string', array('limit' => 200))
                    ->addColumn('configuration_keys', 'json', array('null' => true))
                    ->addColumn('created_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP'))
                    ->addColumn('updated_at', 'timestamp', array('default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'))
                    ->addColumn('deleted_at', 'timestamp', array('null' => true))
                    ->addIndex(array('url'), array('unique' => true))
                    ->create();
    }
}
