<?php

class StorePutCest extends BaseCest
{

    protected static $endpoint = '/store';
    protected static $table = 'stores';
/*
    public function updateEditableFields(ApiTester $I)
    {
        $I->wantToTest("Editing store.");
        $initialData = array(
            "organizationId" => 1,
            "name" => "Big Bazaar, Surat",
            "clientStoreId" => 5001,
            "latitude" => "40.8329137232310",
            "longitude" => "13.2947508931600",
            "address" => "Opposite Gandi maidan, Near Ram mandir, Rajiv Nagar, Surat"
        );
        $storeId = (string) $I->haveInDatabase(static::$table, $this->getDatabaseDataArray($initialData));
        unset($initialData['organizationId']);
        $updatedData = array(
            "organizationId"=>1,
            "clientStoreId" => 5002,
            "latitude" => "21.6787583789220",
        );
        parent::update($I, $storeId, $updatedData, $initialData);
    }
*/
    public function updatingWithoutId(ApiTester $I)
    {
        $I->wantToTest("Updating without passing id");
        $updatedData = array(
            "clientStoreId" => 5002,
            "latitude" => "21.6787583789220",
        );
        $I->sendPUT(static::$endpoint . "/", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass a valid id"));
    }

    public function updatingWithInvalidLatitudeLongitute(ApiTester $I)
    {
        $I->wantToTest("Updating with invalid latitude");
        $initialData = array(
            "organization_id" => 1,
            "name" => "Big Bazaar, Surat",
            "client_store_id" => 5001,
            "latitude" => "40.8329137232310",
            "longitude" => "13.2947508931600",
            "address" => "Opposite Gandi maidan, Near Ram mandir, Rajiv Nagar, Surat"
        );
        $storeId = (string) $I->haveInDatabase(static::$table, $initialData);
        $updatedData = array(
            "organizationId"=>1,
            "latitude" => "21234",
        );
        $I->sendPUT(static::$endpoint . "/$storeId", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Invalid latitude value"));
    }

    public function updatingToAlreadyExistingName(ApiTester $I)
    {
        $I->wantToTest("Updating with invalid latitude");
        $initialData = array(
            "organization_id" => 1,
            "name" => "Big Bazaar, Surat",
            "client_store_id" => 5001,
            "latitude" => "40.8329137232310",
            "longitude" => "13.2947508931600",
            "address" => "Opposite Gandi maidan, Near Ram mandir, Rajiv Nagar, Surat"
        );
        $storeId = (string) $I->haveInDatabase(static::$table, $initialData);
        $updatedData = array(
            "organizationId"=>1,
            "name" => "Hypercity, Meenakshi Mall",
        );
        $I->sendPUT(static::$endpoint . "/$storeId", $updatedData);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Store with name '$updatedData[name]' already exists"));
    }
}
