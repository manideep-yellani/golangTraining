<?php

use Phinx\Migration\AbstractMigration;

class DeleteLayoutEndpoint extends AbstractMigration
{
    public function up()
    {
      $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
              . json_encode(['GET','PUT','DELETE'])
              . '\' where url = "website-service/layout"');
    }
  
    public function down()
    {
      $this->execute('UPDATE `endpoints` set `allowed_methods`=\''
              . json_encode(['GET','PUT'])
              . '\' where url = "website-service/layout"');
    }
}
