<?php

use Phinx\Migration\AbstractMigration;

class DeliveryAreaEndpointForTransportCoordinator extends AbstractMigration
{
    public function change()
    {
        
        $roleId = $this->fetchRow('select id from roles where name="Transport Coordinator"');
        $endpointId=$this->fetchRow('select id from endpoints where url="logistics-service/delivery-area"');
        $eId=$endpointId['id'];
        $rId=$roleId['id'];
            $this->execute("replace into endpoint_role(`endpoint_id`,`role_id`,`method`)values($eId,$rId,\"GET\")");
    }
}
