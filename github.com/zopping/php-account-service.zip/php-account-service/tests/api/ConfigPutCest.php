<?php

require_once('BaseCest.php');

class ConfigPutCest extends BaseCest
{

    protected static $endpoint = '/config';

    public function UpdateConfigsWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Update configs without organization id');
        $data = [
            'basic' => [
                'organizationName' => 'Hypercity',
                'siteUrl' => 'http://hypercity.zopexpress.com',
                'logo' => 'http://kikkidu.com/wp-content/uploads/2011/08/hyperCity_250.jpg',
            ]
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Missing Required Field - config : organization Id'));
    }
/*
    public function updateMultipleConfigs(ApiTester $I)
    {
        $I->wantTo('Updating the configuration values for multiple configs');
        $data = [
            'organizationId' => 1,
            'basic' => [
                'organizationName' => 'Zopnow',
                'siteUrl' => 'http://www.zopnow.com',
                'logo' => 'http://sn.zopnow.com/images/icons/logo/ZopNow-logo.svg',
                'siteTagLine' => 'Get Groceries Fast, Fresh, Easy',
            ],
            'catalogue' => [
                'hasMultipleBrands' => 'TRUE',
                'hasMultipleVariants' => 'TRUE'
            ],
            "analytics" => [
		"gaAccount" => "",
		"conversionTag" => ""
            ]
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(["status" => "SUCCESS"]);
        unset($data['organizationId'], $data['analytics']);
        $I->seeResponseContainsJson($data);
        $I->seeInDatabase("organizations", ["name" => "Zopnow", "domain" => "www.zopnow.com"]);
        $I->dontSeeInDatabase("configurations", ["key" => "analytics.gaAccount", "organization_id" => 1]);
    }

    public function updateValuesOfSingleConfig(ApiTester $I)
    {
        $I->wantTo('Updating the configuration values for only basic type');
        $data = [
            'organizationId' => 1,
            'basic' => [
                'organizationName' => 'Zopnow',
                'siteUrl' => 'http://www.zopnow.com',
                'siteTagLine' => 'Get Groceries Fast, Fresh, Easy',
            ],
        ];
        $I->sendPUT(static::$endpoint . "/basic", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        unset($data['organizationId']);
        $I->seeResponseContainsJson($data);
    }
*/
    public function updateValuesForConfigsThatDoesNotExist(ApiTester $I)
    {
        $I->wantTo('Updating the configuration values for which configs has not been added previously');
        $data = [
            'organizationId' => 11,
            'catalogue' => [
                'hasMultipleBrands' => 'FALSE',
                'hasMultipleVariants' => 'FALSE']];
        $I->sendPUT(static::$endpoint . "/catalogue", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
    }

    public function updateValuesWithInvalidTextData(ApiTester $I)
    {
        $I->wantTo('Updating the configuration values with invalid text field');
        $data = ['organizationId' => 1,
            'basic' => [
                'organizationName' => '@!']];
        $I->sendPUT(static::$endpoint . "/basic", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: organizationName'));
    }

    public function updateValuesWithInvalidUrlData(ApiTester $I)
    {
        $I->wantTo('Updating the configuration values with invalid url field');
        $data = ['organizationId' => 1,
            'basic' => [
                'organizationName' => 'Zopnow',
                'siteUrl' => ':zopnow']];
        $I->sendPUT(static::$endpoint . "/basic", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: siteUrl'));
    }

    public function updateValuesWithInvalidEmailData(ApiTester $I)
    {
        $I->wantTo('Updating the configuration values with invalid email field');
        $data = ['organizationId' => 1,
            'basic' => [
                'organizationName' => 'Zopnow',
                'siteUrl' => 'http://www.zopnow.com',
                'supportEmail' => 'zopnow.com']];
        $I->sendPUT(static::$endpoint . "/basic", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: supportEmail'));
    }

    public function updateValuesWithInvalidPhoneData(ApiTester $I)
    {
        $I->wantTo('Updating the configuration values with invalid phone field');
        $data = ['organizationId' => 1,
            'basic' => [
                'organizationName' => 'Zopnow',
                'siteUrl' => 'http://www.zopnow.com',
                'siteTagLine' => 'Get Groceries Fast, Fresh, Easy',
                'supportEmail' => 'cs@zopnow.com',
                'supportPhone' => 'abc']];
        $I->sendPUT(static::$endpoint . "/basic", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array('message' => 'Validation Exception: Invalid data for basic: supportPhone'));
    }

    public function updateValuesWithInvalidBooleanData(ApiTester $I)
    {
        $I->wantTo("Updating the configuration values with invalid boolean field");
        $data = [
            'organizationId' => 1,
            'catalogue' => [
                'hasMultipleBrands' => 'ABC',
                'hasMultipleVariants' => 'FALSE'
            ],
        ];
        $I->sendPUT(static::$endpoint . "/catalogue", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['status' => 'ERROR']);
        $I->seeResponseContainsJson(['message' => 'Validation Exception: Invalid data for catalogue: hasMultipleBrands']);
    }
/*
    public function updateValueOfThemeConfig(ApiTester $I)
    {
        $I->wantTo('Updating the configuration value for selected theme in basic type');
        $data = [
            'organizationId' => 1,
            'basic' => [
                'selectedTheme' => 'Basic Theme',
            ],
        ];
        $I->sendPUT(static::$endpoint . "/basic", $data);
        $I->seeResponseIsJson();
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        unset($data['organizationId']);
        $I->seeResponseContainsJson($data);
    }
*/
    public function updateConfigsWithValidBooleanData(ApiTester $I)
    {
        $I->wantTo("Update configs with value as boolean false");
        $data = [
            'organizationId' => 13,
            'catalogue' => [
                'hasMultipleBrands' => true,
                'hasMultipleVariants' => false
            ],
        ];
        $I->sendPUT(static::$endpoint . "/catalogue", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
    }

}
