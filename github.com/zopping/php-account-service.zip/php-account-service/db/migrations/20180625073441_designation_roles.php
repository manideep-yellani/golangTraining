<?php

use Phinx\Migration\AbstractMigration;

class DesignationRoles extends AbstractMigration
{

    public function up()
    {
        $this->table("designation_role")
            ->addColumn('designation_id', 'integer', ['limit' => 11])
            ->addColumn('role_id', 'integer', ['limit' => 11])
            ->addColumn('created_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'timestamp', ['default' => 'CURRENT_TIMESTAMP', "update" => 'CURRENT_TIMESTAMP'])
            ->addColumn('deleted_at', 'timestamp', ['null' => true])
            ->addForeignKey('designation_id', 'designations', 'id')
            ->addForeignKey('role_id', 'roles', 'id')
            ->addIndex(['designation_id','role_id'], ['unique' => true, "name" => "designation_role_idx"])
            ->create();
        $this->table('endpoint_role')
            ->addColumn('deleted_at', 'timestamp', ['null' => true])
            ->addIndex(['role_id', 'endpoint_id', 'method'], ['unique' => true, "name" => "permission"])
            ->save();
    }

    public function down()
    {
        $this->table("endpoint_role")
            ->dropForeignKey(['endpoint_id', 'role_id'])
            ->removeIndexByName("permission")
            ->addForeignKey('endpoint_id', 'endpoints', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->addForeignKey('role_id', 'roles', 'id', ['delete'=> 'NO_ACTION', 'update'=> 'NO_ACTION'])
            ->removeColumn('deleted_at')
            ->save();
        $this->dropTable("designation_role");
    }
}
