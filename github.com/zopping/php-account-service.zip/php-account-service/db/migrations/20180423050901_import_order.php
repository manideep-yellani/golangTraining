<?php

use Phinx\Migration\AbstractMigration;

class ImportOrder extends AbstractMigration {

    public function up() {
        $endpointData = [
            [
                "url" => "order-service/importOrder",
                "allowed_methods" => json_encode(['POST'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
        //Assign permission to universal developer
        $row = $this->fetchRow("SELECT `id` FROM developers where token = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'");
        $developerId = $row['id'];
        $endpointId = $this->fetchRow(
                        "select id from endpoints where url= 'order-service/importOrder'"
                )['id'];
        $permissions = array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "POST",
            "has_permission" => 1
        );
        $this->insert('endpoint_developer_permissions', $permissions);
    }

    public function down() {
        $endpointId = $this->fetchRow(
                        "select id from endpoints where url= 'order-service/importOrder'"
                )['id'];

        $this->execute(
                "delete from endpoint_developer_permissions where endpoint_id = '$endpointId'"
        );
        $this->execute(
                "delete from endpoint_user_permissions where endpoint_id = '$endpointId'"
        );
        $this->execute(
                "delete from endpoints where id = '$endpointId'"
        );
    }

}
