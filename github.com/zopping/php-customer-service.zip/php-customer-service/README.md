# Customer-Service #

ZopSmart Customers who subscribes for customer-service should be able to manage all the required data related to the customers of their organization. Key functionalities will be :-
* Able to see List of Customers with their details.
* Able to edit customer details.
* Able to add new customer.
* Able to manage customer's login/logout on their website, including necessary authentication and authorization.

For detailed documentation, kindly visit our [Wiki Page](https://github.com/ZopNow/customer-service/wiki)
