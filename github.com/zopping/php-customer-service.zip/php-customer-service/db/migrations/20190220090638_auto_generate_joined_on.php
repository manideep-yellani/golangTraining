<?php


use Phinx\Migration\AbstractMigration;

class AutoGenerateJoinedOn extends AbstractMigration
{
    public function change()
    {
        $this->execute("alter table customers modify `joined_on` date GENERATED ALWAYS AS (cast(`joined_time` as date)) STORED");
    }
}
