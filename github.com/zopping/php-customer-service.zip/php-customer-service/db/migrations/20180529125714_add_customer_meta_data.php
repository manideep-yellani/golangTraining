<?php


use Phinx\Migration\AbstractMigration;

class AddCustomerMetaData extends AbstractMigration
{

    public function up()
    {
        $this->table('customers')
             ->addColumn('meta_data', 'string', array('limit' => 500, 'null' => true))
             ->save();
    }

    public function down() 
    {
        $this->table('customers')
             ->removeColumn('meta_data')
             ->save();
    }

}
