<?php

use Phinx\Seed\AbstractSeed;

class StoreSeeder extends AbstractSeed
{
    /**
     * Seeding the data for stores table
     * It stores organization_id, name, latitude, longitude and address
     * 
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        $data = array(
            array(
                'organization_id' => 1,
                'name' => 'Hypercity, Whitefield',
                'client_store_id' => 1001,
                'latitude' => '12.8937000000000',
                'longitude' => '77.6444766000000',
            ),
            array(
                'organization_id' => 1,
                'name' => 'Hypercity, Meenakshi Mall',
                'client_store_id' => 1002,
                'latitude' => '12.9580030000000',
                'longitude' => '77.7162120000000',
                'address' => 'Lower Ground Floor, Royal Meenakshi Mall, Opposite Meenakshi Temple, Bannerghatta Road, Bengaluru, Karnataka 560076'
            ),
            array(
                'organization_id' => 1,
                'name' => 'More, Sahkar Nagar',
                'client_store_id' => 2001,
                'latitude' => '13.0575199000000',
                'longitude' => '77.5915385000000',
                'address' => 'Opposite To Police Station, Madiwala Commercial Complex, Hosur Road, Madivala, Bengaluru, Karnataka 560068'
            ),
            array(
                'organization_id' => 1,
                'name' => 'Metro, Yeshwantpur',
                'client_store_id' => 3001,
                'latitude' => '13.0137640000000',
                'longitude' => '77.5549010000000',
                'address' => 'Survey No. 26/3, Industrial Suburbs, Subramanyanagar Ward No. 9, Bengaluru, Karnataka 560055'
            ),
            array(
                'organization_id' => 1,
                'name' => 'More Hypermarket,Bull Temple Road',
                'client_store_id' => 2002,
                'latitude' => '12.9931900000000',
                'longitude' => '77.6616140000000',
                'address' => '96/112, Bull Temple Road, In Between Ramakrishna Math And Uma Theatre, Mahantara Lay Out, Kempegowda Nagar, Bengaluru, Karnataka 560019'
            ),
            array(
                'organization_id' => 1,
                'name' => 'More HM Mahadevapura',
                'client_store_id' => 2003,
                'latitude' => '12.9895123000000',
                'longitude' => '77.6890751000000',
                'address' => 'Survey No. 14, Near Shiva Ganga Layout, Outer Ring Road, Mahadevapura, Bengaluru, Karnataka 560048'
            ),
            array(
                'organization_id' => 2,
                'name' => 'Default Store',
                'address' => '97/112, Bull Temple Road, Bengaluru, Karnataka 560019',
                'latitude' => '12.9395123000000',
                'longitude' => '78.6890751000000',
            ),
        );
        for ($i = 0; $i < 20; $i++) {
            $data[] = [
                'organization_id' => $faker->randomElement([1,2,3,4]),
                'name' => $faker->company,
                'client_store_id' =>  $faker->unique()->numberBetween(4000, 5000),
                'latitude' => $faker->randomFloat(13, 0, 99),
                'longitude' => $faker->randomFloat(13, 0, 99),
                'address' => $faker->address
            ];
        }
        $stores = $this->table('stores');
        $stores->insert($data)
               ->save();
    }
}
