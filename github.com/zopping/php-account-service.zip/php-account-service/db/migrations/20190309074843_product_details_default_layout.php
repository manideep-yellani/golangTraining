<?php

use Phinx\Migration\AbstractMigration;

class ProductDetailsDefaultLayout extends AbstractMigration
{
    public function up()
    {
	$this->execute("update organization_page set layouts='[{\"data\": {}, \"name\": \"ProductDetail\"}, {\"data\": {}, \"name\": \"YouMayLikeProducts\"}]' where organization_id is null and page_id=4");
    }
   public function down()
    {
	$this->execute("update organization_page set layouts='[{\"data\": {}, \"name\": \"ProductDetail\"}]' where organization_id is null and page_id=4");
    }
}
