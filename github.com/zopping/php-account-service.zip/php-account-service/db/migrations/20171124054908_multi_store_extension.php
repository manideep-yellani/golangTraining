<?php

use Phinx\Migration\AbstractMigration;

class MultiStoreExtension extends AbstractMigration
{
    /**
     * Adds Multi-Store Support extension
     */
    public function up()
    {
        $enableHelperText = "Provides an interface to manage Stores | ".
            "Products can have different stock, mrp, discount etc. across stores | ".
            "Customers can be served based on the delivery areas configured for each store| ".
            "Store Specific Pages can be designed on the website | ".
            "Analytics based on sales and products behaviour can be obvserved across store, which will help targeting audience location-wise | ".
            "Campaigns and Coupons can be added store wise";
        
        $disableHelperText = "Store interface will be disabled | ".
            "All the store specific data will be considered from the first store, so products not present in the first store are no longer shown in website| ".
            "Store specific delivery areas will not be supported  | ".
            "Store specific website pages can't be designed  | ".
            "All types of analytics will show data for the single store | ".
            "Store Specific Campaigns are coupons are not supported";

        $data = [
            "name" => "Multi Store Support",
            "slug" => "MultiStoreSupport",
            "description" => "Facilitates the organization to support multiple store for their organization",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText
        ];
        $this->insert('extensions',$data);
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'MultiStoreSupport'")['id'];
        $this->query("UPDATE endpoints SET `extension_id`='".$extensionId."' WHERE `url` = 'account-service/store'");
    }

    public function down()
    {
        $this->execute('DELETE from `extensions` where `slug` = "MultiStoreSupport"');
        $this->query("UPDATE endpoints SET `extension_id`=NULL WHERE `url` = 'account-service/store'");
    }
}
