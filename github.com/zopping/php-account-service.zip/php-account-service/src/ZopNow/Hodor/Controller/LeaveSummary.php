<?php

namespace ZopNow\Hodor\Controller;

use ZopNow\Arya\Utility\Validator;

class LeaveSummary extends \ZopNow\Arya\Controller\Base
{

    public function get()
    {
        $params = $this->getRequestParams(['organizationId'], ['team']);
        if (isset($params['team']) && Validator::isBoolean($params['team'])
            && filter_var($params['team'], FILTER_VALIDATE_BOOLEAN) == true
        ) {
            $data = $this->getSummaryFor("team");
        } else {
            $parameters = array('page', 'perPage', 'paginated');
            $data = $this->getSummaryFor("employee", $parameters);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    private function getSummaryFor($method, $parameters = NULL)
    {
        $mandatoryFields = array('organizationId', 'user', 'from', 'to');
        $otherFields = array('userId', 'designationId');
        if ($method == "employee" and !is_null($parameters)) {
            $otherFields = array_merge($otherFields, $parameters);
        }
        $params = $this->getRequestParams($mandatoryFields, $otherFields);
        if (!Validator::isDate($params['from']) || !Validator::isDate($params['to'])) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "The from and to parameters must be of the format 'Y-m-d'"
            );
        }
        $from = strtotime($params['from']);
        $to = strtotime($params['to']);
        if ($from > $to) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "From date is greater than to date"
            );
        }
        //Check if date range is less than 2 months approx.
        $dateDiff = 2 * 31 * 24 * 60 * 60;
        if ($dateDiff < ($to - $from)) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Can view summary only for 2 months at a time."
            );
        }
        if ($method == "team") {
            $team = $this->getTeamMembers();
            $params["userId"] = $params['userId'] ?? $team;
            $params['paginated'] = false;
        } elseif ($method == "employee" && empty ($params['userId'])) {
            $userJson = json_decode($params['user'], true);
            $params['userId'] = $userJson['id'];
        }
        $params['status'] = ['APPROVED', 'PENDING'];
        
        $leaveController = new UserLeave($params);
        $leaveList = $leaveController->get()->getData()['data'];
        $leaveData = [];
        foreach ($leaveList['userleave'] as $details) {
            $lowerLimit = \max([$params['from'], $details["fromDate"]]);
            $upperLimit = \min([$params['to'], $details["toDate"]]);
            $details['noOfDays'] = $this->calculateLeaveBasedOnWeeklyOff($lowerLimit, $upperLimit, $details['user']['weeklyOff']);
            $leaveData[] = $details;
        }
        $leaveList["leavesummary"] = $leaveData;
        unset($leaveList['userleave']);
        return $leaveList;
    }

    private function getTeamMembers()
    {
        $params = $this->getRequestParams(['organizationId', 'user']);
        $userJson = json_decode($params['user'], true);
        $userId = $userJson['id'];
        $userController = new User(['id' => $userId, 'organizationId' => $params['organizationId']]);
        $teamMembers = $userController->getTeamMembers();
        return array_column($teamMembers, 'id');
    }

    private function calculateLeaveBasedOnWeeklyOff($lowerLimit, $upperLimit, $weeklyOffDetails)
    {
        $datetime1 = new \DateTime($lowerLimit);
        $datetime2 = new \DateTime($upperLimit);
        $difference = $datetime2->diff($datetime1);
        $woDays = 0;
        foreach ($weeklyOffDetails as $day) {
            $dayNumber = date('N', strtotime($day));
            $start = strtotime($lowerLimit);
            $end = strtotime($upperLimit);
            if (date("N", $start) != $dayNumber) {
                $start = strtotime("next " . $day, $start);
            }
            while ($start <= $end) {
                if ($dayNumber == date('N', $start)) {
                    $woDays+=1;
                }
                $start = strtotime("next " . $day, $start);
            }
        }
        return ($difference->days) + 1 - $woDays;
    }

}
