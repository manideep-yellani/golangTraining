<?php

namespace ZopNow\CustomerService\Controller;

class Login extends \ZopNow\Arya\Controller\Base
{

    public function post()
    {
        $mandatoryFields = array('username', 'password', 'organizationId');
        $data = $this->getRequestParams($mandatoryFields, ['remember']);
        $remember = !empty($data['remember']) ? filter_var($data['remember'], FILTER_VALIDATE_BOOLEAN) : false;
        $token = \ZopNow\CustomerService\Auth\Auth::getToken($data['username'], $data['password'], $data['organizationId'], $remember);
        if ($token == false) {
            throw new \ZopNow\Arya\Exception\AuthException('Incorrect password');
        }
        $modelClass = \ZopNow\CustomerService\Auth\Auth::AUTH_MODEL_NAME;
        $customer = $modelClass::find(\ZopNow\Arya\Auth\Auth::$id);
        if ($customer->status == "DISABLED"){
            throw new \ZopNow\Arya\Exception\AuthException('Your Account is Deactivated !! Please contact customer service for further assistance');
        }
        $phones = $customer->phones;
        foreach ($phones as $phone) {
            if ($phone->status != "VERIFIED") {
                $phone->status = "VERIFIED";
                $phone->save();
            }
        }
        $customer->last_login_time=date("Y-m-d H:i:s");
        $customer->save();
        $response = [];
        $response['customer'] = $customer->toArray();
        $response['customer']['accessToken'] = $token;
                $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'customer', 'paginate' => 'false']);
                $addressResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'address', 'paginate' => 'false']);
                $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
                $addressFieldData = json_decode($addressResponse['body'], true)['data']['customField'];
                    $response['customer']['metaData'] = (new Customer())->getMetaData($response['customer']['metaData'], $fieldData);
                    $response['customer']['defaultAddress']['metaData'] = (new Customer())->getMetaData($response['customer']['defaultAddress']['metaData'], $addressFieldData);
                    foreach ($response['customer']['addresses'] as &$address) {
                        $address['metaData'] = (new Customer())->getMetaData($address['metaData'], $addressFieldData);
                    }
        return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $response,
        ]);
    }

    public function get()
    {
        $mandatoryFields = array('accessToken', 'organizationId');
        $data = $this->getRequestParams($mandatoryFields);
        if (!empty($data['accessToken'])) {
                $user = \ZopNow\CustomerService\Auth\Auth::validateToken($data['accessToken'], $data['organizationId']);
                $responseData['customer'] = $user->toArray();
                $customFieldResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'customer', 'paginate' => 'false']);
                $addressResponse = \ZopNow\Arya\Utility\MicroService::callService("config-service", "/custom-field", 'GET', ['organizationId' => $data['organizationId'], 'entity' => 'address', 'paginate' => 'false']);
                $fieldData = json_decode($customFieldResponse['body'], true)['data']['customField'];
                $addressFieldData = json_decode($addressResponse['body'], true)['data']['customField'];
                    $responseData['customer']['metaData'] = (new Customer())->getMetaData($responseData['customer']['metaData'], $fieldData);
                    $responseData['customer']['defaultAddress']['metaData'] = (new Customer())->getMetaData($responseData['customer']['defaultAddress']['metaData'], $addressFieldData);
                    foreach ($responseData['customer']['addresses'] as &$address) {
                        $address['metaData'] = (new Customer())->getMetaData($address['metaData'], $addressFieldData);
                    }
            }
            return new \ZopNow\Arya\View\Base([
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $responseData,
        ]);
    }

}
