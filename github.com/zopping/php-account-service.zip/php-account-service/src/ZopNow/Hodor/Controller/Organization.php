<?php

namespace ZopNow\Hodor\Controller;

/**
 * Class consists of the APIs for the CRUD operations of organization and related methods
 */

class Organization extends \ZopNow\Arya\Controller\ModelController
{
    protected static $filterableFields = ['slug', 'domain'];
    const DEFAULT_THEME_ID = 1;

    /**
     * Method to list the details of all the organizations.
     * It supports the slug filter. The slug should be passed in the request. For example, /organization?slug=zopnow
     * If id is passed, the method gets the details of the organization which matches the id passed.
     * For example, /organization/1
     *
     * @return array Returns the status, message and data of the API.
     */
    public function get()
    {
        $domainFilter = $this->domain;
        $slugFilter = $this->slug;
        $organizationIdFromRequest = $this->organizationId;
        $id = $this->id;
        $data = null;
        if (!empty($id)) {
            $data = $this->getDetails();
            if (!empty($organizationIdFromRequest) && $organizationIdFromRequest != $id) {
                throw new \ZopNow\Arya\Exception\ModelException(
                    "Organization with id $id not found"
                );
            }
        } elseif (!empty($domainFilter) || !empty($slugFilter)) {
            $list = $this->getList();
            $data = $this->getListData($list, $this->include ?? []);
        }
        $response = [
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $data,
        ];
        return new \ZopNow\Arya\View\Base($response);
    }

    protected static function getListData(\ZopNow\Arya\Listing\BaseList $list, $includeParams = [])
    {
        $objects = $list->getListItems();
        $data = array();
        foreach ($objects as $object) {
            $details = $object->toArray();
            if (in_array('extension', $includeParams)) {
                $details['extension'] = $object->extension->toArray();
            }
            if (in_array('config', $includeParams)) {
                $details['config'] = (new Config(['organizationId' => $object->id]))->get()->getData()['data']['config'];
            }
            if (in_array('store', $includeParams)) {
                $details['store'] = (new Store(['organizationId' => $object->id, 'paginated' => false]))->get()->getData()['data']['store'];
            }
            $data[] = $details;
        }
        $count = $list->getTotalCount();
        $className = strtolower(self::getClassNameWithoutNamespace());
        return array(
            $className => $data,
            "offset" => ($list->paginated) ? $list->getOffset() : 0,
            "limit" => ($list->paginated) ? $list->getPerPage() : $count,
            "count" => $count
        );
    }

    public function post()
    {
        $optionalFields = array("name", "domain", "currencyId", "logo", "themeId");
        $data = $this->getRequestParams(array(), $optionalFields);
        if (!empty($data['name'])) {
            $data['slug'] = \ZopNow\Hodor\Utility\Slug::generateUniqueSlug($data['name'], $this->modelClass);
        }
        $hasCNAME = false;
        $subDomain = "";
        if (!empty($data['domain'])) {
            $isDomainValid = \ZopNow\Hodor\Helper\Validator::validate("http://" . $data['domain'], "url");
            if (!$isDomainValid) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid domain");
            }
            $data['domain'] = $this->stripProtocol($data['domain']);
            $exists = $this->model->isDomainExists($data['domain']);
            if ($exists) {
                throw new \ZopNow\Arya\Exception\ValidationException('Organization already exists');
            }

            if (ENABLE_DOMAIN_VALIDATION == 'true' && !strrpos($data['domain'], ".zopping.com")) {
                $resp = \ZopNow\Arya\Utility\MicroService::callService("go-account-service", "/domain-validation", "POST", ['domain' => $data['domain']]);
                if ($resp['statusCode'] != 200) {
                    throw new \ZopNow\Arya\Exception\ValidationException("DNS configuration is incorrect");
                }

                $body = json_decode($resp['body'], true);
                $hasCNAME = $body["data"]["domainValidation"]["hasCNAME"];
                $subDomain = $body["data"]["domainValidation"]["subDomain"]["domain"];
            }
        }
        if (!empty($data['currencyId'])) {
            (new Currency(array("id" => $data['currencyId'])));
        }
        if (!empty($data['themeId'])) {
            (new Theme(['id' => $data['themeId']]));
        } else {
            $data['themeId'] = self::DEFAULT_THEME_ID;
        }
        if (!empty($data["logo"])) {
            $isLogoValid = \ZopNow\Hodor\Helper\Validator::validate($data['logo'], "url");
            if (!$isLogoValid) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid logo");
            }
        }
        $this->add($data);
        (new Store(array("organizationId" => $this->model->id, "name" => "Default")))->post();
        $this->setDefaultPaymentMethod();
        if (!empty($data['domain']) && (getenv("ORGANIZATION_CHANGE_TOPIC") != '')) {
            $event = new \ZopNow\Hodor\Utility\Event(getenv("ORGANIZATION_CHANGE_TOPIC"), [
                "oldDomain" => "",
                "newDomain" => "" . $this->model->domain,
                "id" => intval($data['id']),
                'hasCNAME' => $hasCNAME,
                "subDomain" => $subDomain
            ]);
            $event->publish();
        }
        $response = array(
            'code' => 200,
            "status" => 'SUCCESS',
            "data" => $this->getDetails()
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    public function put()
    {
        if (empty($this->data['id'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Please enter the id to be updated");
        }
        $optionalFields = array("name", "domain", "currencyId", "logo", "themeId", "status", "countryCode");
        $data = $this->getRequestParams(array(), $optionalFields);
        $id = $this->id;
        $organizationIdFromRequest = $this->organizationId;
        if (!empty($organizationIdFromRequest) && $organizationIdFromRequest != $id) {
            throw new \ZopNow\Arya\Exception\ValidationException(
                "Organization with id $id cannot be edited"
            );
        }
        if (!empty($data['name']) && $data['name'] != $this->model->name) {
            $data['slug'] = \ZopNow\Hodor\Utility\Slug::generateUniqueSlug($data['name'], $this->modelClass);
        }
        $domainHasChanged = !empty($data['domain']) && $data['domain'] != $this->model->domain;
        $oldDomain = $this->model->domain;
        $paymentDetailsToBeUpdated = [];
        $hasCNAME = false;
        $subDomain = "";
        if ($domainHasChanged) {
            $isDomainValid = \ZopNow\Hodor\Helper\Validator::validate("http://" . $data['domain'], "url");
            if (!$isDomainValid) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid domain");
            }
            $data['domain'] = $this->stripProtocol($data['domain']);
            if ($this->model->isDomainExists($data['domain'])) {
                throw new \ZopNow\Arya\Exception\ValidationException("Domain already exists");
            }
            $data['httpsEnabled'] = 0;
            if (strrpos($data['domain'], ".zopping.com") || strrpos($data['domain'], ".staging.zopping.com") || strrpos($data['domain'], ".staging.zopsmart.com") || strrpos($data['domain'], ".zopsmart.com")) {
                $data['httpsEnabled'] = 1;
            }
            $paymentDetailsToBeUpdated['domain'] = $data['domain'];

            if (ENABLE_DOMAIN_VALIDATION == 'true') {
                $resp = \ZopNow\Arya\Utility\MicroService::callService("go-account-service", "/domain-validation", "POST", ['domain' => $data['domain'], 'organizationId' => $this->data['id']]);
                if ($resp['statusCode'] != 200) {
                    throw new \ZopNow\Arya\Exception\ValidationException("DNS configuration is incorrect");
                }

                $body = json_decode($resp['body'], true);
                $hasCNAME = $body["data"]["domainValidation"]["hasCNAME"];
                $subDomain = $body["data"]["domainValidation"]["subDomain"]["domain"];
            }
        }
        if (!empty($data['status']) && !in_array($data['status'], ['ENABLED', 'DISABLED'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid status");
        }
         if (!empty($data['countryCode']) && $data['countryCode'] != $this->model->country_code) {
             $CountryData = [
                                "countryIsoCode" => $data['countryCode'],
                            ];
                            $countryResp = (new Country($CountryData))->get()->getData();
                            $country = $countryResp['data']['country'];
                            if (!empty($country['currency'])){
                                $data['currencyId'] = $country['currency']['id'];
                            }
        }
        if (!empty($data['currencyId']) && $data['currencyId'] != $this->model->currency_id) {
            (new Currency(array("id" => $data['currencyId'])));
        }
        if (!empty($data['themeId'])) {
            (new Theme(['id' => $data['themeId']]));
        }
        if (!empty($data['logo']) && $data['logo'] != $this->model->logo) {
            $isLogoValid = \ZopNow\Hodor\Helper\Validator::validate($data['logo'], "url");
            if (!$isLogoValid) {
                throw new \ZopNow\Arya\Exception\ValidationException("Invalid logo");
            }
            $paymentDetailsToBeUpdated['logo'] = $data['logo'];
        }
        if (!empty($data['name']) && $data['name'] != $this->model->name) {
            $paymentDetailsToBeUpdated['name'] = $data['name'];
        }
        $data['id'] = $this->data['id'];
        $organization = $this->edit($data);
        if (!empty($paymentDetailsToBeUpdated)) {
            $paymentDetailsToBeUpdated['organizationId'] = $this->model->id;
            (new PaymentAccount($paymentDetailsToBeUpdated))->updateConfigDetails();
        }

        if ($domainHasChanged && (getenv("ORGANIZATION_CHANGE_TOPIC") != '')) {
            $event = new \ZopNow\Hodor\Utility\Event(getenv("ORGANIZATION_CHANGE_TOPIC"), [
                "oldDomain" => "$oldDomain",
                "newDomain" => "" . $this->model->domain,
                "id" => intval($data['id']),
                "hasCNAME" => $hasCNAME,
                "subDomain" => $subDomain,
            ]);
            $event->publish();
        }

        $actionsTopic = getenv("ACTIONS_TOPIC");
        if ($actionsTopic != '' && !strrpos($data['domain'], ".zopping.com") && !strrpos($data['domain'], ".zopsmart.com")){
          $event = new \ZopNow\Hodor\Utility\Event($actionsTopic, [
              "actions" => [
                  ["status" => "COMPLETED", "id" => "CUSTOM_DOMAIN"]
              ],
              "organizationId" => strval($data['id'])
          ]);
          $event->publish();
        }

        $this->refreshCache();
        $response = array(
            'code' => 200,
            'status' => "SUCCESS",
            'data' => $organization
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    private function stripProtocol($url)
    {
        if (!empty($url)) {
            $url = str_replace("http://", "", $url);
            $url = str_replace("https://", "", $url);
        }
        return $url;
    }

    private function refreshCache() {
        $org = $this->id;
        $r = \ZopNow\Arya\DB\Redis::getInstance();
        $r->del("O:Organization:$org");
        $r->select(8);
        $keys = $r->keys("$org:*:org");
        $r->del($keys);
        $r->select(0);
    }

    public function getDetails()
    {
        if (empty($this->data['id'])) {
            throw new \ZopNow\Arya\Exception\ControllerException("Please pass the id of the organization");
        }
        $details = $this->model->toArray();
        $details['extension'] = $this->model->extension->toArray();
        $defaultStoreId = \ZopNow\Hodor\Model\Store::getDefaultStoreIdForOrganization($this->id);
        $store = (new Store(array("organizationId" => $this->id, "id" => $defaultStoreId)))
                    ->get()->getData()['data']['store'];
        $details['defaultStore'] = !empty($store) ? $store : null;
        $orgId = $details['id'];
        $owner = \ZopNow\Hodor\Model\User::where('organization_id', $orgId)->where('is_owner', 1)->first();
        $details['owner'] = !empty($owner) ? $owner->toArray() : null;
        $includeValues = $this->include;
        if (!empty($includeValues) && is_array($includeValues) && in_array('config', $includeValues)) {
            $id = $this->id;
            $details['config'] = (new Config(['organizationId' => $id]))->get()->getData()['data']['config'];
        }
        return array("organization" => $details);
    }

    public function getCurrency()
    {
        return $this->model->currency()->get()->toArray();
    }

    /*
     *  set COD as default payment method for a new organization
     *  DELIVERY is also set as default order type
     */
    private function setDefaultPaymentMethod()
    {
        \ZopNow\Arya\Utility\MicroService::callService("config-service",
                "/config", "POST", [
                "organizationId" => (string)$this->model->id,
                "order" => ["paymentMethods" => ["COD"]]
                ]);
        return;
    }
}