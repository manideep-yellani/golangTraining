<?php

use Phinx\Migration\AbstractMigration;

class AddSlotAggregationEndpoint extends AbstractMigration
{

    public function up()
    {
        $extensionId = $this->fetchRow("SELECT `id` from `extensions` where `slug` = 'RedMartSupport'")['id'];
        $endpointData = [
            [
                "url" => "order-service/slot-aggregate",
                "extension_id" => $extensionId,
                "allowed_methods" => json_encode(['GET'])
            ]
        ];
        $this->insert('endpoints', $endpointData);
    }

    public function down()
    {
        $this->execute("delete from endpoints where url='order-service/slot-aggregate'");        
    }

}
