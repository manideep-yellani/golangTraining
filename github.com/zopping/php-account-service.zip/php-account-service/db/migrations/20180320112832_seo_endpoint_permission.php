<?php

use Phinx\Migration\AbstractMigration;

class SeoEndpointPermission extends AbstractMigration
{
    public function up()
    {
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'account-service/seo'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `token` = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $this->insert('endpoint_developer_permissions', array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1
        ));
    }

    public function down()
    {
        $endpointId = $this->fetchRow("SELECT `id` from `endpoints` where `url` = 'account-service/seo'")['id'];
        $developerId = $this->fetchRow("SELECT `id` from `developers` where `token` = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'")['id'];
        $this->execute('DELETE FROM `endpoint_developer_permissions` 
            where `developer_id` = "'.$developerId.'" and `endpoint_id`= "'.$endpointId.'"');
    }
}
