<?php

use Phinx\Migration\AbstractMigration;

class AddPricingRuleInExtensions extends AbstractMigration
{
    public function up()
    {
        // Add pricing_rule column in extensions
        $this->table("extensions")
            ->addColumn("pricing_rule", "string", ['null' => true])
            ->update();
        // Update pricing rule for extensions
        $extensions = [
            'MultiUserSupport' => json_encode(['FREE' => 2, 'TYPE' => 'MONTHLY', 'RATE' => 'FIXED', 'COST' => 100]),
            'MultiStoreSupport' => json_encode(['FREE' => 1, 'TYPE' => 'MONTHLY', 'RATE' => 'FIXED', 'COST' => 1000])
        ];
        foreach ($extensions as $slug => $pricingRule) {
            $this->execute("update extensions set pricing_rule='$pricingRule' where slug ='$slug'");
        }
    }

    public function down()
    {
        // Drop column pricing_rule from extensions
        $this->table("extensions")
            ->removeColumn("pricing_rule")
            ->update();
    }

}
