<?php

namespace ZopNow\Hodor\Model;

class UserTiming extends \ZopNow\Arya\Model\Base
{


}
