<?php

namespace ZopNow\CustomerService\Auth;

/**
 * Description of Auth
 */
class Auth extends \ZopNow\Arya\Auth\Auth {

    const LONG_TERM_TOKEN_TTL = 31536000;
    const SHORT_TERM_TOKEN_TTL = 900;
    const AUTH_MODEL_NAME = '\ZopNow\CustomerService\Model\Customer';

    public static function getToken($username, $password, $organizationId, $remember = false)
    {
        $ttl = $remember ? self::LONG_TERM_TOKEN_TTL : self::SHORT_TERM_TOKEN_TTL;
        $token = self::login($username, $password, self::AUTH_MODEL_NAME, ['organizationId' => $organizationId],
                $ttl);
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $redis->setex("remember:customer:".self::$id, $ttl, $remember);
        return $token;
    }

    public static function getTokenForOAuth($email, $organizationId, $remember = false)
    {
        $ttl = $remember ? self::LONG_TERM_TOKEN_TTL : self::SHORT_TERM_TOKEN_TTL;
        $token = self::forceLogin($email, self::AUTH_MODEL_NAME, ['organizationId' => $organizationId], $ttl);
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $redis->setex("remember:customer:".self::$id, $ttl, $remember);
        return $token;
    }

    public static function validateToken($guid, $organizationId)
    {
        $user = self::who($guid);
        if (is_null($user)) {
            throw new \ZopNow\Arya\Exception\AuthException("Unauthorized");
        }
        if ($organizationId != $user->organization_id) {
            throw new \ZopNow\Arya\Exception\AuthException("Unauthorized");
        }
        //The guid is for valid user. Hence, renewing it
        $redis = \ZopNow\Arya\DB\Redis::getInstance();
        $remember = $redis->get("remember:customer:".$user->id);
        self::$loginTtl = $remember ? self::LONG_TERM_TOKEN_TTL : self::SHORT_TERM_TOKEN_TTL;
        self::renewGuid($guid);
        return $user;
    }

    public static function logout($guid)
    {
        $user = parent::who($guid);
        if (!is_null($user)) {
            // unsetting remember-choice of user
            \ZopNow\Arya\Cache\CacheManager::delete("remember:customer:".$user->id);
        }
        parent::logout($guid);
    }
}