<?php

use Phinx\Migration\AbstractMigration;

class VerifyEndpointPermission extends AbstractMigration
{
    /**
     * Endpoint and creation and adding permission to developer for verify.
     */
    public function change()
    {
        $endpoints = array(
            array(
                "url" => 'customer-service/verify',
            ),
            array(
                "url" => 'customer-service/reset-password',
            ),
        );
        $this->insert('endpoints', $endpoints);
        $endpointId = $this->fetchRow("select max(id) as id from endpoints")['id'];
        $row = $this->fetchRow("SELECT `id` FROM developers where token = '59042d47-4b2a-4f87-8d78-6f8cae4ce199'");
        $developerId = $row['id'];
        $data[] = array(
            "endpoint_id" => $endpointId,
            "developer_id" => $developerId,
            "method" => "POST",
            "has_permission" => 1
        );
        $data[] = array(
            "endpoint_id" => $endpointId-1,
            "developer_id" => $developerId,
            "method" => "GET",
            "has_permission" => 1
        );
        $this->insert('endpoint_developer_permissions', $data);
    }
}
