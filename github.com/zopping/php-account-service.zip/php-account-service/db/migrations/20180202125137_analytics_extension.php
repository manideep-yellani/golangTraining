<?php

use Phinx\Migration\AbstractMigration;

class AnalyticsExtension extends AbstractMigration
{

    public function up()
    {
        $enableHelperText = "Allows user to add conversion tags to track conversions on various analytics interfaces"
            . " Allows user to add website analytics on Google Analytics";

        $disableHelperText = "Conversion tracking will be stopped | "
            . " Site traffic tracking on Google Analytics will be stopped";

        $data = [
            "name" => "Analytics",
            "slug" => "Analytics",
            "description" => "Facilitates the organization to track site traffic on Google Analytics and conversions",
            "enable_helper_text" => $enableHelperText,
            "disable_helper_text" => $disableHelperText,
            "pricing" => "FREE"
        ];
        $this->insert('extensions',$data);
    }

    public function down()
    {
        $this->execute('DELETE from `extensions` where `slug` = "Analytics"');
    }
}
