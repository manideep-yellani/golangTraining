<?php

namespace ZopNow\Hodor\Controller;

class PaymentAccount extends \ZopNow\Arya\Controller\ModelController
{
    protected static $filterableFields = ['organization_id'];
    protected $allowNonPaginated = true;
    private static $allowedTypes = ['DEFAULT', 'CUSTOM'];

    public function get()
    {
        $this->getRequestParams(['organizationId']);
        if (!empty($this->data['id'])) {
            $response = $this->getDetails();
            foreach($response['paymentaccount']['paymentGateways'] as $id=> $paymentGateway) {
                if (empty($paymentGateway['imageUrl'])) {
                    $response['paymentaccount']['paymentGateways'][$id]['imageUrl'] = (new PaymentGateway())->getGatewayImageUrl($paymentGateway['id']);;
                }
            }
        } else {
            $list = $this->getList();
            $response = self::getListData($list);
            foreach($response['paymentaccount'][0]['paymentGateways'] as $id=> $paymentGateway) {
                if (empty($paymentGateway['imageUrl'])) {
                    $response['paymentaccount'][0]['paymentGateways'][$id]['imageUrl'] = (new PaymentGateway())->getGatewayImageUrl($paymentGateway['id']);;
                }
            }
        }
        return (new \ZopNow\Arya\View\Base([
            'status' => "SUCCESS",
            'code' => 200,
            'data' => $response
            ])
         );
    }

    public static function getListData(\ZopNow\Arya\Listing\BaseList $list)
    {
        $objects = $list->getListItems();
        $data = array();
        foreach ($objects as $key => $value) {
            $oldData = $value->toArray();
            $additionalData = self::getAdditionalDetails($value);
            $data[$key] = array_merge($oldData, $additionalData);
        }
        $count = $list->getTotalCount();
        return array(
            "count" => $count,
            "offset" => ($list->paginated) ? $list->getOffset() : 0,
            "limit" => ($list->paginated) ? $list->getPerPage() : $count,
            "paymentaccount" => $data
        );
    }

    public function getAdditionalDetails($paymentObj)
    {
        $accessToken  = $paymentObj->access_token;
        $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor('account.json', 'GET', [], $accessToken))->execute();
        $data = json_decode($response['response'], true);
        $type = $data[0]['data']['config_type'] ?? null;
        $paymentGateways = $data[0]['data']['payment_gateways'] ?? [];
        $paymentModes = [];
        $details = \ZopNow\Hodor\Utility\Utility::convertKeysToCamelCase($paymentGateways);
        foreach ($details as $row) {
            foreach ($row['paymentModes'] as $paymentMode) {
                if (!isset($paymentModes[$paymentMode['id']])) {
                    unset($paymentMode['rate'],$paymentMode['accountPaymentGatewayId']);
                    $paymentModes[$paymentMode['id']] = $paymentMode;
                }
            }
        }
        $requiredDetails = ['type' => $type, 'paymentModes' => array_values($paymentModes)];
        if ($type == 'CUSTOM') {
            $requiredDetails['paymentGateways'] = $details;
        }
        return $requiredDetails;
    }

    public function getDetails()
    {
        $basicDetails = parent::getDetails();
        $additionalDetails = $this->getAdditionalDetails($this->model);
        return ['paymentaccount' =>array_merge($basicDetails['paymentaccount'], $additionalDetails)];
    }

    public function put()
    {
        $fields = $this->getRequestParams(['id', 'type', 'organizationId'], ['paymentGateways', 'type', 'paymentModes']);
        if ($fields['organizationId'] != $this->model->organization_id) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid account");
        }
        if (!in_array($fields['type'], self::$allowedTypes)) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid account type");
        }
        if (!empty($fields['paymentGateways']) && !is_array($fields['paymentGateways'])
              || !empty($fields['paymentModes']) && !is_array($fields['paymentModes'])) {
            throw new \ZopNow\Arya\Exception\ValidationException("Invalid payment configuration details");
        }
        switch ($fields['type']) {
            case "CUSTOM" :
                if (!empty($fields['paymentGateways'])) {
                    $request = \ZopNow\Hodor\Utility\Utility::convertKeysToSnakeCase($fields['paymentGateways']);
                    $this->updatePaymentConfigurations(['payment_gateways' => $request, 'config_type' => $fields['type']]);
                }
                break;
            case "DEFAULT" :
                if (!empty($fields['paymentModes'])) {
                    $request = \ZopNow\Hodor\Utility\Utility::convertKeysToSnakeCase($fields['paymentModes']);
                    $this->updatePaymentConfigurations(['payment_modes' => $request, 'config_type' => $fields['type']]);
                }
                break;
        }
        $details = $this->edit($fields);
        foreach($details['paymentaccount']['paymentGateways'] as $id=> $paymentGateway) {
            if (empty($paymentGateway['imageUrl'])) {
                $details['paymentaccount']['paymentGateways'][$id]['imageUrl'] = (new PaymentGateway())->getGatewayImageUrl($paymentGateway['id']);;
            }
        }

        $actionsTopic = getenv("ACTIONS_TOPIC");
        if ($actionsTopic != '') {
            $event = new \ZopNow\Hodor\Utility\Event($actionsTopic, [
                "actions" => [
                    ["status" => "COMPLETED", "id" => "ONLINE_PAYMENT"]
                ],
                "organizationId" => strval($fields['organizationId'])
            ]);
            $event->publish();
        }
        $response = array(
            'status' => "SUCCESS",
            'code' => 200,
            'data' => $details
        );
        return (new \ZopNow\Arya\View\Base($response));
    }

    /**
     * This updates the payment gateways and the payment modes  
     * that are configured by the client in zoppay
     */
    private function updatePaymentConfigurations($request)
    {
        $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor('update-account.json', 'POST', $request, $this->model->access_token))->execute();
        if ($response['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong, please try again later");
        }
        $data = json_decode($response['response'], true);
        if (!empty($data[0]) && ($data[0]['type'] == 'Error')) {
            throw new \ZopNow\Arya\Exception\ValidationException($data[0]['data']);
        }
    }

    /**
     *  this function is used to update the account details in zoppay if
     *  there is a change in client config
     */
    public function updateConfigDetails()
    {
        $fields = $this->getRequestParams(['organizationId'], ['domain', 'logo', 'name']);
        $paymentAccount = \ZopNow\Hodor\Model\PaymentAccount::where([['organization_id', $fields['organizationId']]])->first();
        if ((empty($paymentAccount)) || (empty($fields['domain']) && empty($fields['logo']) && empty($fields['name']))) {
            return;
        }
        $requestParams =  ['status' => 'ENABLED'];
        if (!empty($fields['domain'])) {
            $domainUrl = preg_replace('/^(?!https?:\/\/)/', 'http://', $fields['domain']);
            if ($paymentAccount->organization->getHttpsEnabledAttribute() === 1) {
                $domainUrl = str_replace('http://', 'https://', $domainUrl);
            }

            $requestParams['referral_url'] = $domainUrl."/pay.php";
            $requestParams['redirect_url'] = $domainUrl."/api/payment-response";
            $requestParams['payment_verification_callback'] = $domainUrl."/api/payment-response";
        }
        if (!empty($fields['logo'])) {
            $requestParams['image'] = $fields['logo'];
        }
        if (!empty($fields['name'])) {
            $requestParams['domain_name'] = $fields['name'];
            $requestParams['public_name'] = $fields['name'];
        }
        $accessToken  = $paymentAccount->access_token;
        $response = (new \ZopNow\Hodor\Utility\ZoppayInteractor("update-account.json", "POST", $requestParams , $accessToken))->execute();
        if ($response['statusCode'] != 200) {
            throw new \ZopNow\Arya\Exception\ValidationException("Something went wrong, please try again later");
        }
    }

}