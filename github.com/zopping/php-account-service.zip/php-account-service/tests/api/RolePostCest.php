<?php

class RolePostCest
{
    protected static $endpoint = '/role';
    protected static $table = 'roles';

    public function addRoleWithoutRequiredData(ApiTester $I)
    {
        //Without organization id
        $data = [
            "name" => "Intern"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - role : organization Id",
        ));
        //Without name
        $data = [
            "organizationId" => 1
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Missing Required Field - role : name",
        ));
    }

    public function addRoleWithExistingGlobalRole(ApiTester $I)
    {
        $data = [
            "organizationId" => 1,
            "name" => "Picker"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Role with name 'Picker' already exists",
        ));
    }

    public function addRoleWithExistingNameInOrganization(ApiTester $I)
    {
        $id = $I->haveInDatabase(self::$table, ['name' => 'CS Lead', 'organization_id' => 1]);
        $data = [
            "organizationId" => 1,
            "name" => "CS Lead"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array(
            "status" => "ERROR",
            "message" => "Validation Exception: Role with name 'CS Lead' already exists",
        ));
    }

    public function addRoleWithExistingNameInDifferentOrganization(ApiTester $I)
    {
        $id = $I->haveInDatabase(self::$table, ['name' => 'CS Lead', 'organization_id' => 1]);
        $data = [
            "organizationId" => 2,
            "name" => "CS Lead"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "role" => array(
                    "id" => "integer",
                    "name" => "string"
                )
            )
        ));
    }

    public function addRoleWithValidData(ApiTester $I)
    {
        $data = [
            "organizationId" => 1,
            "name" => "Intern"
        ];
        $I->sendPOST(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'SUCCESS'));
        $I->seeResponseMatchesJsonType(array(
            "code" => "integer",
            "status" => "string",
            "data" => array(
                "role" => array(
                    "id" => "integer",
                    "name" => "string"
                )
            )
        ));
    }

}
