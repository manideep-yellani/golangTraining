<?php

use Phinx\Migration\AbstractMigration;

class AddOrganizationStatus extends AbstractMigration
{

    public function up()
    {
        $this->table('organizations')
             ->addColumn('status', 'enum', array('after' => 'theme_id', 'values' => array('ENABLED', 'DISABLED'), 'null' => false, 'default' => 'ENABLED'))
             ->update();
    }

    public function down()
    {
        $this->table('organizations')
             ->removeColumn('status')
             ->update();
    }
    
}
