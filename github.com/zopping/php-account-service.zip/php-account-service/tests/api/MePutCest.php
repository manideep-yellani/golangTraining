<?php

class MePutCest
{

    protected static $endpoint = '/me';
    protected static $table = 'me';

    public function validData(ApiTester $I)
    {
        $I->wantTo('Update the user data with valid data');
        $data = [
            "user" => '{
                "id": 2,
                "name": "Admin",
                "isOwner": 0,
                "verified": true,
                "phones": [
                    {
                        "id": 2,
                        "phone": "+919999999002"
                    }
                ],
                "emails": [
                    {
                        "id": 2,
                        "email": "admin@zopnow.com"
                    }
                ],
                "lang": null,
                "accessToken": "1508914958.1462zop59f0370e23b082.19330739"
            }',
            "langIsoCode" => "en"
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseMatchesJsonType(array(
            'code' => 'integer',
            'status' => 'string',
            'data' => [
                "user" =>
                array(
                    'id' => 'integer',
                    'name' => 'string',
                    'isOwner' => 'integer',
                    'phones' => 'array',
                    'emails' => 'array',
                    'lang' => 'array',
                ),
            ]
        ));
        $I->seeResponseContainsJson(['lang' => ['name' => 'English', 'isoCode' => 'en']]);
    }

    public function missingParameterUser(ApiTester $I)
    {
        $I->wantTo('Check the API when user is missing');
        $data = ["langIsoCode" => "en"];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Validation Exception: Missing Required Field - user : id')
        );
    }

    public function invalidUser(ApiTester $I)
    {
        $I->wantTo('Check the API when given user does not exist');
        $data = [
            "user" => '{
                "id": 10000,
                "name": "Admin",
                "isOwner": 0,
                "verified": true,
                "phones": [
                    {
                        "id": 2,
                        "phone": "+919999999002"
                    }
                ],
                "emails": [
                    {
                        "id": 2,
                        "email": "admin@zopnow.com"
                    }
                ],
                "lang": null,
                "accessToken": "1508914958.1462zop59f0370e23b082.19330739"
            }',
            "langIsoCode" => "en"
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Model Exception: User with id: 10000 not found')
        );
    }

    public function invalidLanguageCode(ApiTester $I)
    {
        $I->wantTo('Add new user with invalid language code');
        $data = [
            "user" => '{
                "id": 2,
                "name": "Admin",
                "isOwner": 0,
                "verified": true,
                "phones": [
                    {
                        "id": 2,
                        "phone": "+919999999002"
                    }
                ],
                "emails": [
                    {
                        "id": 2,
                        "email": "admin@zopnow.com"
                    }
                ],
                "lang": null,
                "accessToken": "1508914958.1462zop59f0370e23b082.19330739"
            }',
            'langIsoCode' => 'abc',
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => 'Validation Exception: Invalid Language')
        );
    }

    public function updateUserWithImage(ApiTester $I)
    {
        $I->wantTo("Edit user and add a valid image url");
        $data = [
            "user" => '{
                "id": 2,
                "name": "Admin",
                "isOwner": 0,
                "verified": true,
                "phones": [
                    {
                        "id": 2,
                        "phone": "+919999999002"
                    }
                ],
                "emails": [
                    {
                        "id": 2,
                        "email": "admin@zopnow.com"
                    }
                ],
                "lang": null,
                "accessToken": "1508914958.1462zop59f0370e23b082.19330739"
            }',
            'imageUrl' => 'https://lorempixel.com/50/50/?89429',
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson(array('status' => "SUCCESS"));
        $I->seeResponseMatchesJsonType(array(
            'status' => 'string',
            'data' => [
                "user" =>
                array(
                    'id' => 'integer',
                    'name' => 'string',
                    'isOwner' => 'integer',
                    'phones' => 'array',
                    'emails' => 'array',
                    'imageUrl' => 'string|null'
                ),
            ]
        ));
        $I->seeResponseContainsJson(['imageUrl' => 'https://lorempixel.com/50/50/?89429']);
    }

    public function editUserWithInvalidImageUrl(ApiTester $I)
    {
        $I->wantTo("Edit user with invalid value for image url");
        $data = [
            "user" => '{
                "id": 2,
                "name": "Admin",
                "isOwner": 0,
                "verified": true,
                "phones": [
                    {
                        "id": 2,
                        "phone": "+919999999002"
                    }
                ],
                "emails": [
                    {
                        "id": 2,
                        "email": "admin@zopnow.com"
                    }
                ],
                "lang": null,
                "accessToken": "1508914958.1462zop59f0370e23b082.19330739"
            }',
            'imageUrl' => '%abc',
        ];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(
            array('message' => "Validation Exception: Invalid value for 'imageUrl'")
        );
    }
}
