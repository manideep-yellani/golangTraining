<?php
require_once('BaseCest.php');

class DevicePutCest extends BaseCest
{
    protected static $endpoint = '/device';
    protected static $table = 'devices';

    public function updateDeviceWithoutIdOrUuid(ApiTester $I)
    {
        $I->wantTo('Updating a device without sending the id or uuid');
        $data = ['customerId' => 1];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass a valid ID"));
    }

    public function updateDeviceWithoutOrganizationId(ApiTester $I)
    {
        $I->wantTo('Updating a device without sending organizationId');
        $data = ['customerId' => 1];
        $I->sendPUT(static::$endpoint . "/1", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Please pass Organization Id"));
    }

    public function updateDeviceWithInvalidId(ApiTester $I)
    {
        $I->wantTo('Updating a device by sending invalid id');
        $data = ['customerId' => 1, 'organizationId' => 1];
        $I->sendPUT(static::$endpoint . "/1000i", $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Model Exception: Device with id: 1000i not found"));
    }

    public function updateDeviceWithInvalidUuid(ApiTester $I)
    {
        $I->wantTo('Updating a device by sending invalid uuid');
        $data = ['uuid' => 'this-is-invalid-uuid', 'organizationId' => 1, 'customerId' => 1];
        $I->sendPUT(static::$endpoint, $data);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Model Exception: Device with uuid this-is-invalid-uuid and organization_id 1 not found"));
    }

    public function updateDeviceWithInvalidCustomer(ApiTester $I)
    {
        $I->wantTo('Updating a device by sending invalid customer');
        $I->sendPUT(static::$endpoint . "/1", ['customerId' => 5, 'organizationId' => 1]);
        $I->seeResponseCodeIs(Codeception\Util\HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Model Exception: Customer with id 5 and organization_id 1 not found"));
    }

    public function updateDeviceCustomerWithDeviceId(ApiTester $I)
    {
        $I->wantTo('Update customer for a device using device ID');
        $initial = ['uuid' => 'eab86a40-bfa9-4c30-b4b3-7se5c0ea060d4', 'organization_id' => 1, 'customer_id' => 2, 'token' => 'thisisasampletoken'];
        $id = $I->haveInDatabase(static::$table, $initial);
        $final = ['organizationId'=>1,'customerId' => 1];
        $I->sendPUT(static::$endpoint . "/$id", $final);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['organizationId'=>1]);
        $I->seeResponseContainsJson(['customerId' => 1]);
        $I->seeInDatabase(static::$table, ['organization_id'=>1,'customer_id' => 1,'id'=>$id]);
        $I->dontseeResponseContainsJson(['customerId' => 2]);
        $I->dontSeeInDatabase(static::$table, $initial);
    }

    public function updateDeviceCustomerWithUuid(ApiTester $I)
    {
        $I->wantTo('Update customer for a device using Uuid');
        $initialData = ['uuid' => 'fc9e717a-adc0-41e6-aa9a-a91807dd53ad', 'organization_id' => 1, 'customer_id' => 1];
        $I->sendPUT(static::$endpoint,
            ['uuid' => 'fc9e717a-adc0-41e6-aa9a-a91807dd53ad', 'organizationId' => 1, 'customerId' => 2]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseContainsJson(['customerId' => 2]);
        $I->seeInDatabase(static::$table,
            ['uuid' => 'fc9e717a-adc0-41e6-aa9a-a91807dd53ad', 'organization_id' => 1, 'customer_id' => 2]);
        $I->dontseeResponseContainsJson(['customerId' => 1]);
        $I->dontSeeInDatabase(static::$table, $initialData);
    }
    public function updateWithExistingTokenOfDiffDevice(ApiTester $I)
    {
        $I->wantTo("Update a device with existing token of another device");
        $I->sendPUT(static::$endpoint . "/1", [
            'organizationId' => 1,
            'token' => 'APA91bGGkYdbJOqmwx7JCzBP5fPgTX4L2ViJ6Pvj9qHKCNv5GPAsfYvBH09Hoi35j5bQuFlt7-o9ZiTju48drpndtPPWYED9Q9Yp7LZNtz_TBFJdEWZNqbA'
        ]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::BAD_REQUEST);
        $I->seeResponseContainsJson(array('status' => 'ERROR'));
        $I->seeResponseContainsJson(array("message" => "Validation Exception: Token already exists"));
    }

    public function updateWithExistingTokenOfSameDevice(ApiTester $I)
    {
        $I->wantTo("Update a device with existing token of another device");
        $I->sendPUT(static::$endpoint . "/2", [
            'organizationId' => 2,
            'token' => 'APA91bGGkYdbJOqmwx7JCzBP5fPgTX4L2ViJ6Pvj9qHKCNv5GPAsfYvBH09Hoi35j5bQuFlt7-o9ZiTju48drpndtPPWYED9Q9Yp7LZNtz_TBFJdEWZNqbA'
        ]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK);
        $I->seeResponseContainsJson([
            'token' => 'APA91bGGkYdbJOqmwx7JCzBP5fPgTX4L2ViJ6Pvj9qHKCNv5GPAsfYvBH09Hoi35j5bQuFlt7-o9ZiTju48drpndtPPWYED9Q9Yp7LZNtz_TBFJdEWZNqbA'
        ]);
    }
}