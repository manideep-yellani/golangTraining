<?php

use Phinx\Seed\AbstractSeed;

class PickupLocationSeeder extends AbstractSeed
{
    /**
     * Seeding the data for pickup_locations table
     * It stores organization_id, name, latitude, longitude and address
     * 
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        $data = array(
            array(
                'organization_id' => 1,
                'name' => 'Hypercity, Meenakshi Mall',
                'latitude' => '12.9580030000000',
                'longitude' => '77.7162120000000',
                'address' => 'Lower Ground Floor, Royal Meenakshi Mall, Opposite Meenakshi Temple, Bannerghatta Road, Bengaluru, Karnataka 560076',
                'store_id' => 2,
            ),
            array(
                'organization_id' => 1,
                'name' => 'More, Sahkar Nagar',
                'latitude' => '13.0575199000000',
                'longitude' => '77.5915385000000',
                'address' => 'Opposite To Police Station, Madiwala Commercial Complex, Hosur Road, Madivala, Bengaluru, Karnataka 560068',
                'store_id' => 3,
            ),
            array(
                'organization_id' => 1,
                'name' => 'Metro, Yeshwantpur',
                'latitude' => '13.0137640000000',
                'longitude' => '77.5549010000000',
                'address' => 'Survey No. 26/3, Industrial Suburbs, Subramanyanagar Ward No. 9, Bengaluru, Karnataka 560055',
                'store_id' => 4,
            ),
            array(
                'organization_id' => 1,
                'name' => 'More Hypermarket,Bull Temple Road',
                'latitude' => '12.9931900000000',
                'longitude' => '77.6616140000000',
                'address' => '96/112, Bull Temple Road, In Between Ramakrishna Math And Uma Theatre, Mahantara Lay Out, Kempegowda Nagar, Bengaluru, Karnataka 560019',
                'store_id' => 5,
            ),
            array(
                'organization_id' => 1,
                'name' => 'More HM Mahadevapura',
                'latitude' => '12.9895123000000',
                'longitude' => '77.6890751000000',
                'address' => 'Survey No. 14, Near Shiva Ganga Layout, Outer Ring Road, Mahadevapura, Bengaluru, Karnataka 560048',
                'store_id' => 6,
            ),
        );
        for ($i = 0; $i < 20; $i++) {
            $data[] = [
                'organization_id' => $faker->randomElement([1,2,3,4]),
                'name' => $faker->company,
                'latitude' => $faker->randomFloat(13, 0, 99),
                'longitude' => $faker->randomFloat(13, 0, 99),
                'address' => $faker->address,
                'store_id' => $faker->randomElement([1,2,3,4,5]),
            ];
        }
        $locations = $this->table('pickup_locations');
        $locations->insert($data)
               ->save();
    }
}
